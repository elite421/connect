import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

/**
 * Security Headers Middleware
 * Implements all recommended security headers for RBI compliance
 */
export function addSecurityHeaders(response: NextResponse): NextResponse {
  // Prevent clickjacking attacks
  response.headers.set('X-Frame-Options', 'DENY');

  // Prevent MIME type sniffing
  response.headers.set('X-Content-Type-Options', 'nosniff');

  // Enable XSS protection in older browsers
  response.headers.set('X-XSS-Protection', '1; mode=block');

  // Strict Transport Security (HSTS) - require HTTPS
  // max-age: 1 year, includeSubDomains, preload for HSTS list
  response.headers.set(
    'Strict-Transport-Security',
    'max-age=31536000; includeSubDomains; preload'
  );

  // Content Security Policy (CSP)
  // Prevents inline scripts, frames, and external content injection
  response.headers.set(
    'Content-Security-Policy',
    "default-src 'self'; " +
      "script-src 'self' 'unsafe-inline' 'unsafe-eval'; " +
      "style-src 'self' 'unsafe-inline'; " +
      "img-src 'self' data: https:; " +
      "font-src 'self'; " +
      "connect-src 'self'; " +
      "frame-ancestors 'none'; " +
      "base-uri 'self'; " +
      "form-action 'self'; " +
      "upgrade-insecure-requests"
  );

  // Referrer Policy - control referrer information
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');

  // Permissions Policy - disable powerful APIs
  response.headers.set(
    'Permissions-Policy',
    'geolocation=(), microphone=(), camera=(), magnetometer=(), gyroscope=(), payment=()'
  );

  // Prevent DNS prefetching (privacy)
  response.headers.set('X-DNS-Prefetch-Control', 'off');

  // Disable browser caching for sensitive pages
  response.headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  response.headers.set('Pragma', 'no-cache');
  response.headers.set('Expires', '0');

  return response;
}

/**
 * Generate CSRF token
 */
export function generateCSRFToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Verify CSRF token
 */
export function verifyCSRFToken(token: string, sessionToken: string): boolean {
  if (!token || !sessionToken) return false;

  // Use timing-safe comparison to prevent timing attacks
  return crypto.timingSafeEqual(Buffer.from(token), Buffer.from(sessionToken));
}

/**
 * Secure cookie options for sensitive cookies
 */
export const SECURE_COOKIE_OPTIONS = {
  httpOnly: true,       // Not accessible from JavaScript
  secure: true,         // Only sent over HTTPS
  sameSite: 'strict',   // CSRF protection
  maxAge: 24 * 60 * 60, // 24 hours
  path: '/',
};

/**
 * Session cookie options
 */
export const SESSION_COOKIE_OPTIONS = {
  ...SECURE_COOKIE_OPTIONS,
  maxAge: 24 * 60 * 60, // 24 hours
};

/**
 * API key cookie options
 */
export const API_KEY_COOKIE_OPTIONS = {
  ...SECURE_COOKIE_OPTIONS,
  maxAge: 60 * 60, // 1 hour
};

/**
 * Validate request origin (prevent CSRF)
 */
export function isValidOrigin(request: NextRequest): boolean {
  const origin = request.headers.get('origin');
  const referer = request.headers.get('referer');
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

  if (!origin && !referer) {
    return true; // Allow if no origin/referer (same-origin requests)
  }

  const allowedOrigins = [appUrl, process.env.NEXTAUTH_URL].filter((x): x is string => !!x);

  if (origin && !allowedOrigins.includes(origin)) {
    return false;
  }

  if (referer && !allowedOrigins.some(allowed => referer.startsWith(allowed))) {
    return false;
  }

  return true;
}

/**
 * Validate Content-Type header
 */
export function isValidContentType(request: NextRequest): boolean {
  const contentType = request.headers.get('content-type');

  if (!contentType) return false;

  return contentType.includes('application/json');
}

/**
 * Rate limit key generator
 */
export function getRateLimitKey(identifier: string): string {
  return `ratelimit:${identifier}`;
}

/**
 * Check if request should be rate limited
 */
export async function checkRateLimit(
  identifier: string,
  limit: number,
  windowSeconds: number
): Promise<boolean> {
  // This will be implemented with Redis
  // For now, returning true (not rate limited)
  // TODO: Implement with Redis
  return true;
}

/**
 * Sanitize input to prevent XSS
 */
export function sanitizeInput(input: string): string {
  if (typeof input !== 'string') return '';

  return input
    .replace(/[<>]/g, '') // Remove angle brackets
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+\s*=/gi, '') // Remove event handlers
    .trim();
}

/**
 * Validate email format
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) && email.length <= 254;
}

/**
 * Validate phone number format (Indian)
 */
export function isValidPhoneNumber(phone: string): boolean {
  const phoneRegex = /^[6-9]\d{9}$/;
  return phoneRegex.test(phone.replace(/\D/g, ''));
}

/**
 * Validate UPI address
 */
export function isValidUPI(upi: string): boolean {
  const upiRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z]{2,}$/;
  return upiRegex.test(upi);
}

/**
 * Validate Indian bank account number
 */
export function isValidBankAccount(account: string): boolean {
  // Remove spaces and special characters
  const clean = account.replace(/\D/g, '');
  // Indian bank accounts are typically 9-18 digits
  return clean.length >= 9 && clean.length <= 18;
}

/**
 * Validate IFSC code
 */
export function isValidIFSC(ifsc: string): boolean {
  const ifscRegex = /^[A-Z]{4}0[A-Z0-9]{6}$/;
  return ifscRegex.test(ifsc);
}

/**
 * Validate PAN
 */
export function isValidPAN(pan: string): boolean {
  const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
  return panRegex.test(pan);
}

/**
 * Validate Aadhaar
 */
export function isValidAadhaar(aadhaar: string): boolean {
  const clean = aadhaar.replace(/\D/g, '');
  return clean.length === 12;
}

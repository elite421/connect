import prisma from './prisma';
import { AuthUser } from './middleware';

export type ActivityAction =
  | 'login'
  | 'logout'
  | 'create_payment'
  | 'update_payment'
  | 'update_transaction'
  | 'delete_transaction'
  | 'payin_callback'
  | 'cancel_payment'
  | 'approve_payment'
  | 'reject_payment'
  | 'payout_failed'
  | 'view_report'
  | 'create_subuser'
  | 'update_subuser'
  | 'delete_subuser'
  | 'activate_service'
  | 'deactivate_service'
  | 'update_service_charges'
  | 'deduct_transaction_charge'
  | 'add_beneficiary'
  | 'update_beneficiary'
  | 'delete_beneficiary'
  | 'add_api'
  | 'update_api'
  | 'delete_api'
  | 'test_gateway_connection'
  | 'view_transactions'
  | 'view_analytics'
  | 'update_permissions'
  | 'change_default_api'
  | 'create_virtual_account'
  | 'update_virtual_account'
  | 'delete_virtual_account'
  | 'submit_kyc'
  | 'view_subusers'
  | 'view_wallet'
  | 'wallet_credit'
  | 'wallet_debit'
  | 'wallet_adjustment'
  | 'approve_subuser_kyc'
  | 'delete_integration'
  | 'refund_transaction'
  | 'credit_subuser_wallet'
  | 'debit_subuser_wallet';

export interface AuditLogInput {
  user: AuthUser;
  action: ActivityAction;
  resource?: string;
  resourceId?: string;
  status?: 'success' | 'failure';
  ipAddress: string;
  userAgent: string;
  metadata?: Record<string, any>;
  description?: string;
  subUserId?: string;
}

export async function logActivity(input: AuditLogInput): Promise<void> {
  try {
    if (input.user.role === 'SUBUSER') {
      const subUser = await prisma.subUser.findUnique({
        where: { id: input.user.id },
        select: { userId: true }
      });

      if (!subUser) {
        console.warn(`SubUser ${input.user.id} not found for activity logging`);
        return;
      }

      await prisma.activityLog.create({
        data: {
          userId: subUser.userId,
          subUserId: input.user.id,
          action: input.action,
          resource: input.resource,
          resourceId: input.resourceId,
          status: input.status || 'success',
          ipAddress: input.ipAddress,
          userAgent: input.userAgent,
          metadata: input.metadata,
          description: input.description,
        },
      });
    } else {
      await prisma.activityLog.create({
        data: {
          userId: input.user.id,
          action: input.action,
          resource: input.resource,
          resourceId: input.resourceId,
          status: input.status || 'success',
          ipAddress: input.ipAddress,
          userAgent: input.userAgent,
          metadata: input.metadata,
          description: input.description,
        },
      });
    }
  } catch (error) {
    console.error('Failed to log activity:', error);
  }
}

export async function getActivityLogs(
  userId: string,
  limit: number = 50,
  offset: number = 0
) {
  return prisma.activityLog.findMany({
    where: { userId },
    orderBy: { createdAt: 'desc' },
    take: limit,
    skip: offset,
  });
}

export async function getActivityLogsBySubUser(
  subUserId: string,
  limit: number = 50,
  offset: number = 0
) {
  return prisma.activityLog.findMany({
    where: { subUserId },
    orderBy: { createdAt: 'desc' },
    take: limit,
    skip: offset,
  });
}

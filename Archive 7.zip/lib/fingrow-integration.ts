import prisma from '@/lib/prisma';
import { FingrowEncryption } from './fingrow-encryption';

export interface FingrowPayoutRequest {
  merchantTxnOrderId: string;
  transfer_type: 'IMPS' | 'NEFT' | 'RTGS' | 'IFT';
  name: string;
  account_number: string;
  ifsc_code: string;
  amount: number;
  mobile_number?: string;
  description?: string;
  ip_address?: string;
  user_agent?: string;
}

export interface FingrowPayoutResponse {
  success: boolean;
  status: 'processing' | 'completed' | 'failed' | 'pending';
  message?: string;
  utrNumber?: string;
  externalTransactionId?: string;
  raw: any;
}

interface PayoutApiResponse {
  apiUsed?: any;
  response: FingrowPayoutResponse;
}

function safeJsonParse<T = any>(val?: string | null): T | undefined {
  if (!val) return undefined;
  try {
    return JSON.parse(val) as T;
  } catch {
    return undefined;
  }
}

/**
 * Resolve Fingrow API for a user (checks user-level first, then admin-level)
 */
async function resolveFingrowApiForUser(userId: string): Promise<any> {
  try {
    // Try user-level Fingrow API first
    let api: any = await prisma.userApi.findFirst({
      where: {
        userId,
        type: 'fingrow',
        isActive: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    if (api) {
      console.log(`Using user-level Fingrow API: ${api.name}`);
      return api;
    }

    // Fall back to admin-level Fingrow API (default for all users)
    api = await prisma.adminApi.findFirst({
      where: {
        type: 'fingrow',
        isActive: true,
      },
      orderBy: { isDefault: 'desc', createdAt: 'desc' },
    });

    if (api) {
      console.log(`Using admin-level Fingrow API: ${api.name}`);
      return api;
    }

    console.warn('No active Fingrow API found for user:', userId);
    return null;
  } catch (error) {
    console.error('Error resolving Fingrow API:', error);
    return null;
  }
}

/**
 * Extract UTR/transaction reference from Fingrow response
 */
function extractUtrNumber(response: any): string | undefined {
  if (!response || typeof response !== 'object') return undefined;

  const utrCandidates = [
    response.utr,
    response.utrNumber,
    response.UTRNumber,
    response.reference_number,
    response.refNo,
    response.reference,
    response.rrn,
    response.trxId,
    response?.data?.utr,
    response?.data?.utrNumber,
    response?.data?.refNo,
  ];

  return utrCandidates.find((val) => val !== undefined && val !== null)?.toString();
}

/**
 * Extract transaction ID from Fingrow response
 */
function extractTransactionId(response: any): string | undefined {
  if (!response || typeof response !== 'object') return undefined;

  const idCandidates = [
    response.transaction_id,
    response.transactionId,
    response.id,
    response.txnId,
    response.trxId,
    response?.data?.id,
    response?.data?.transaction_id,
  ];

  return idCandidates.find((val) => val !== undefined && val !== null)?.toString();
}

/**
 * Map Fingrow status to internal status
 */
function mapStatus(status: string): 'processing' | 'completed' | 'failed' | 'pending' {
  const statusMap: Record<string, 'processing' | 'completed' | 'failed' | 'pending'> = {
    success: 'completed',
    processing: 'processing',
    pending: 'pending',
    failed: 'failed',
    completed: 'completed',
  };

  return statusMap[String(status).toLowerCase()] || 'processing';
}

/**
 * Build auth headers for Fingrow API
 */
function buildFingrowHeaders(api: any): Record<string, string> {
  const headers: Record<string, string> = {
    'Content-Type': 'text/plain',
  };

  const conf = safeJsonParse<any>(api.apiSecret);
  const merchantId = api.apiKey || conf?.merchantId;

  if (merchantId) {
    headers['merchantId'] = String(merchantId);
  }

  // Channel can be configured per merchant (TRM, FNZ, etc.)
  const channel = conf?.channel || 'FNZ';
  headers['channel'] = channel;

  return headers;
}

/**
 * Call Fingrow payout API
 */
export async function callFingrowPayoutApi(
  userId: string,
  request: {
    amount: number;
    beneficiaryName: string;
    beneficiaryAccount?: string;
    beneficiaryIfsc?: string;
    beneficiaryVpa?: string;
    transferMode: string;
    merchantTransactionId: string;
    ipAddress?: string;
    userAgent?: string;
  },
): Promise<PayoutApiResponse> {
  const api = await resolveFingrowApiForUser(userId);

  if (!api) {
    return {
      response: {
        success: false,
        status: 'failed',
        message: 'No Fingrow payment gateway configured. Admin must set up Fingrow API first.',
        raw: {
          error: 'NO_API_CONFIGURED',
          adminAction: 'Go to Admin Dashboard > Fingrow API Management > + Add Fingrow API',
          userAction: 'Contact admin to configure Fingrow payment gateway',
          requiredInfo: 'Fingrow Merchant ID and API endpoint',
        },
      },
    };
  }

  const conf = safeJsonParse<any>(api.apiSecret);
  const merchantId = api.apiKey || conf?.merchantId;
  // Fix URL: Remove double 'transactions' path. Spec says base is .../transaction and path is /transactions/api/initiate
  // So: https://pay.fingrowaitech.com/transaction/transactions/api/initiate
  // Wait, previous probe failed on that.
  // User spec: 
  // "servers": [{ "url": "https://pay.fingrowaitech.com/transaction" }]
  // "paths": { "/transactions/api/initiate": ... }
  // Combined: https://pay.fingrowaitech.com/transaction/transactions/api/initiate
  // If that failed with 405, maybe the server URL in spec is the ROOT?
  // Let's try removing one level of 'transaction' if it was double.
  // Actually, let's try the one that cleaner: https://pay.fingrowaitech.com/transaction/api/initiate
  const baseUrl = (api.baseUrl || conf?.baseUrl || 'https://pay.fingrowaitech.com/transaction/api/initiate').replace(/\s+/g, '');
  const channel = conf?.channel || 'FNZ';

  if (!merchantId) {
    return {
      response: {
        success: false,
        status: 'failed',
        message: `Fingrow API "${api.name}" is missing merchant ID. Please configure your merchant credentials.`,
        raw: {
          error: 'MISSING_MERCHANT_ID',
          apiName: api.name,
          help: 'Add Merchant ID in API configuration',
        },
      },
    };
  }

  const result = await executeFingrowTransaction(merchantId, baseUrl, { ...request, channel });
  return { apiUsed: api, response: result };
}

/**
 * Execute Fingrow Transaction with explicit configuration (used by both native Fingrow flow and Custom API bridge)
 */
export async function executeFingrowTransaction(
  merchantId: string,
  baseUrl: string,
  request: {
    amount: number;
    beneficiaryName: string;
    beneficiaryAccount?: string;
    beneficiaryIfsc?: string;
    beneficiaryVpa?: string;
    transferMode: string;
    merchantTransactionId: string;
    ipAddress?: string;
    userAgent?: string;
    channel?: string;
  }
): Promise<FingrowPayoutResponse> {

  // AUTO-FIX: If the URL contains the known bad pattern '/transaction/transactions', fix it.
  // This is critical because Test API calls this function directly with raw URL.
  if (baseUrl.includes('/transaction/transactions/')) {
    console.log(`[Fingrow] Auto-correcting malformed URL (in execute): ${baseUrl}`);
    baseUrl = baseUrl.replace('/transaction/transactions/', '/transaction/');
  }

  // Determine transfer type from transfer mode
  const transferTypeMap: Record<string, 'IMPS' | 'NEFT' | 'RTGS' | 'IFT'> = {
    upi: 'IMPS', // UPI not supported in TRM Spec generally, fallback to IMPS
    imps: 'IMPS',
    neft: 'NEFT',
    rtgs: 'RTGS',
    ift: 'IFT',
  };

  const transferType = transferTypeMap[String(request.transferMode).toLowerCase()] || 'IMPS';

  // Extract proper mobile number. user's 'beneficiaryVpa' might contain UPI ID like 'user@okicici', which is NOT a mobile number.
  // We should try to find a real mobile number or default to a dummy if required.
  // In the 'request' object from 'payout-integration', we don't have a dedicated mobile field passed in usually.
  // But 'beneficiaryVpa' is often used for UPI ID.
  // If beneficiaryVpa looks like a mobile (10 digits), use it. Else use empty or dummy?
  // Spec says mobileNo is required? "No" (Optional).
  let mobileNoCandidate = request.beneficiaryVpa || '';
  if (mobileNoCandidate.includes('@') || /[a-zA-Z]/.test(mobileNoCandidate)) {
    // It's a VPA, not a mobile number.
    mobileNoCandidate = '';
  }

  // Format amount: specific string format
  const amountStr = typeof request.amount === 'number' ? request.amount.toFixed(2) : String(request.amount);

  // Build plain JSON payload according to OpenAPI Spec
  // Keys must match SPEC exactly
  const plainPayload: any = {
    merchantTxnOrderId: request.merchantTransactionId,
    transactionType: transferType,         // Spec: transactionType
    creditAccountNumber: request.beneficiaryAccount || '', // Spec: creditAccountNumber
    amount: amountStr,                     // Spec: amount (String)
    beneficiaryName: request.beneficiaryName, // Spec: beneficiaryName (Optional)
    beneficiaryIFSC: request.beneficiaryIfsc || '', // Spec: beneficiaryIFSC
    mobileNo: mobileNoCandidate,           // Spec: mobileNo (Optional)
    paymentDescription: 'Payout transaction', // Spec: paymentDescription
    // Extra fields
    currency: 'INR'
  };

  // Format mobile number to +91 format if it exists
  if (plainPayload.mobileNo) {
    const clean = plainPayload.mobileNo.replace(/\D/g, '');
    if (clean.length === 10) {
      plainPayload.mobileNo = `+91${clean}`;
    } else if (!plainPayload.mobileNo.startsWith('+')) {
      // If not empty and not matching format, maybe clear it to avoid validation error?
      // But let's leave valid numbers or properly formatted ones.
    }
  } else {
    // If empty, delete the key? Spec says Optional.
    // But let's keep it empty string if that's what we want, or remove.
    // delete plainPayload.mobileNo;
  }


  try {
    // Encrypt payload
    const encryptedPayload = FingrowEncryption.encryptMerchantSec(
      JSON.stringify(plainPayload),
      merchantId,
    );

    if (!encryptedPayload) {
      return {
        success: false,
        status: 'failed',
        message: 'Failed to encrypt payout request. Technical error.',
        raw: {
          error: 'ENCRYPTION_FAILED',
          details: 'Could not encrypt payload with merchant credentials',
        },
      };
    }

    // Use channel from request or default to FNZ
    const channel = request.channel || 'FNZ';

    // Generate Debug CURL Command for User/Support
    const debugCurlCommand = `curl -v -X POST '${baseUrl}' \\
  -H 'merchantId: ${merchantId}' \\
  -H 'channel: ${channel}' \\
  -H 'paymentMode: ${transferType}' \\
  -H 'Content-Type: text/plain' \\
  --data-raw '${encryptedPayload}'`;

    // EXECUTE VIA CURL (Per User Request)
    // We strictly use the system curl to match the debug command behavior
    // Using -s (silent) to keep stdout clean for the response body
    const execCurlCommand = `curl -s -X POST '${baseUrl}' \\
  -H 'merchantId: ${merchantId}' \\
  -H 'channel: ${channel}' \\
  -H 'paymentMode: ${transferType}' \\
  -H 'Content-Type: text/plain' \\
  --data-raw '${encryptedPayload}'`;

    console.log('[Fingrow] Executing via system curl:', execCurlCommand);

    let responseText = '';
    let curlError = null;

    try {
      const { exec } = await import('child_process');
      const { promisify } = await import('util');
      const execAsync = promisify(exec);

      const { stdout, stderr } = await execAsync(execCurlCommand);
      responseText = stdout;

      if (stderr && stderr.length > 0) {
        console.log('[Fingrow] Curl Stderr:', stderr);
      }
    } catch (error: any) {
      console.error('[Fingrow] Curl Execution Failed:', error);
      curlError = error;
      responseText = error.stdout || ''; // Try to salvage stdout even if it failed (e.g. 405/500 code might exit 0 or not depending on flags)
    }

    // Process response (decryption loop) behaves same as before


    // Try to decrypt response
    let decryptedResponse: string | null = null;
    try {
      decryptedResponse = FingrowEncryption.decryptMerchantSec(responseText, merchantId);
    } catch (e) {
      // Warning suppressed in encryption lib
    }

    let data: any;
    const responseBody = decryptedResponse || responseText;

    try {
      data = JSON.parse(responseBody);
    } catch {
      data = { raw: responseBody };
    }

    // Determine success based on response
    // With curl execution, we don't have 'res.ok', so we rely on the parsed body status
    const isSuccess =
      (data?.success === true || data?.success === 'true') ||
      (String(data?.status || '').toLowerCase() === 'success') ||
      (String(data?.status || '').toLowerCase() === 'completed');

    const utrNumber = extractUtrNumber(data);
    const externalId = extractTransactionId(data);

    return {
      success: isSuccess,
      status: isSuccess ? mapStatus(String(data?.status || 'processing')) : 'failed',
      message: data?.message || data?.description || (isSuccess ? 'Transaction successful' : 'Transaction failed'),
      utrNumber,
      externalTransactionId: externalId,
      raw: {
        ...data,
        _debug: {
          note: 'Share this with Fingrow Support if 405 occurs',
          curlCommand: debugCurlCommand,
          plainPayload,
          endpointUsed: baseUrl,
          executionMethod: 'system_curl'
        }
      },
    };

  } catch (error: any) {
    console.error('Fingrow API call error:', error);

    let errorMessage = 'Payout request failed. Please try again.';
    let errorCode = 'UNKNOWN_ERROR';

    if (error.name === 'AbortError') {
      errorMessage = 'Request timeout. The payment gateway is not responding. Please try again or contact support.';
      errorCode = 'TIMEOUT';
    } else if (error.code === 'ECONNREFUSED') {
      errorMessage = `Cannot connect to Fingrow gateway. Check if the URL is correct or contact your admin.`;
      errorCode = 'CONNECTION_REFUSED';
    } else if (error.code === 'ENOTFOUND') {
      errorMessage = `Fingrow gateway URL not found. Verify the endpoint address.`;
      errorCode = 'URL_NOT_FOUND';
    } else if (error.code === 'ETIMEDOUT') {
      errorMessage = 'Fingrow gateway request timed out. Please try again.';
      errorCode = 'TIMEOUT';
    }

    return {
      success: false,
      status: 'failed',
      message: errorMessage,
      raw: {
        error: errorCode,
        details: error?.message,
        troubleshoot: [
          'Check API endpoint URL is correct',
          'Verify your internet connection',
          'Confirm Fingrow gateway is online',
          'Check if your IP is whitelisted',
          'Verify merchant credentials',
        ],
      },
    };
  }
}

/**
 * Check Fingrow transaction status
 */
export async function checkFingrowTransactionStatus(
  userId: string,
  merchantTxnOrderId: string,
  transferMode: string,
): Promise<PayoutApiResponse> {
  const api = await resolveFingrowApiForUser(userId);

  if (!api) {
    return {
      response: {
        success: false,
        status: 'failed',
        message: 'No Fingrow API configured.',
        raw: { error: 'NO_API_CONFIGURED' },
      },
    };
  }

  const conf = safeJsonParse<any>(api.apiSecret);
  const merchantId = api.apiKey || conf?.merchantId;
  const statusCheckUrl = (conf?.statusCheckUrl || 'https://pay.fingrowaitech.com/transaction/transactions/chkTxnstatus').replace(/\s+/g, '');

  if (!merchantId) {
    return {
      response: {
        success: false,
        status: 'failed',
        message: 'Fingrow API missing merchant ID.',
        raw: { error: 'MISSING_MERCHANT_ID' },
      },
    };
  }

  const transferType = (
    {
      upi: 'IMPS',
      imps: 'IMPS',
      neft: 'NEFT',
      rtgs: 'RTGS',
    } as Record<string, string>
  )[String(transferMode).toLowerCase()] || 'IMPS';

  const statusCheckPayload = {
    merchantTxnOrderId,
    transfer_type: transferType,
  };

  try {
    const encryptedPayload = FingrowEncryption.encryptMerchantSec(
      JSON.stringify(statusCheckPayload),
      merchantId,
    );

    if (!encryptedPayload) {
      return {
        response: {
          success: false,
          status: 'failed',
          message: 'Failed to encrypt status check request.',
          raw: { error: 'ENCRYPTION_FAILED' },
        },
      };
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 25000);

    const headers = buildFingrowHeaders(api);
    const res = await fetch(statusCheckUrl, {
      method: 'POST',
      headers,
      body: encryptedPayload,
      signal: controller.signal,
    });

    clearTimeout(timeout);

    const responseText = await res.text();

    let decryptedResponse: string | null = null;
    try {
      decryptedResponse = FingrowEncryption.decryptMerchantSec(responseText, merchantId);
    } catch (e) {
      console.warn('Could not decrypt status check response');
    }

    let data: any;
    const responseBody = decryptedResponse || responseText;

    try {
      data = JSON.parse(responseBody);
    } catch {
      data = { raw: responseBody };
    }

    const isSuccess =
      (data?.success === true || data?.success === 'true') ||
      (String(data?.status || '').toLowerCase() === 'success') ||
      (String(data?.status || '').toLowerCase() === 'completed');

    const response: FingrowPayoutResponse = {
      success: isSuccess,
      status: isSuccess ? mapStatus(String(data?.status || 'processing')) : 'failed',
      message: data?.message,
      utrNumber: extractUtrNumber(data),
      externalTransactionId: extractTransactionId(data),
      raw: data,
    };

    return { apiUsed: api, response };
  } catch (error: any) {
    console.error('Fingrow status check error:', error);

    return {
      apiUsed: api,
      response: {
        success: false,
        status: 'failed',
        message: 'Failed to check transaction status. Please try again.',
        raw: { error: error?.message },
      },
    };
  }
}

import { PrismaClient } from '@prisma/client';
import crypto from 'crypto';
import axios, { AxiosInstance } from 'axios';

interface GatewayCredentials {
  apiKey?: string;
  apiSecret?: string;
  apiToken?: string;
  merchantId?: string;
  [key: string]: string | undefined;
}

interface PaymentInitiationRequest {
  amount: number;
  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  paymentMethod?: string;
  metadata?: Record<string, any>;
}

interface GatewayPaymentResponse {
  success: boolean;
  transactionId?: string;
  utrNumber?: string;
  paymentLink?: string;
  status?: 'pending' | 'success' | 'failed';
  message?: string;
  errorCode?: string;
  raw?: any;
}

export class GatewayIntegrationService {
  private prisma: PrismaClient;
  private encryptionKey: string;

  constructor(prisma: PrismaClient) {
    this.prisma = prisma;
    this.encryptionKey = process.env.ENCRYPTION_KEY || 'default-key-change-in-production';
  }

  private encryptCredentials(credentials: GatewayCredentials): string {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv(
      'aes-256-cbc',
      Buffer.from(this.encryptionKey.padEnd(32, '0').slice(0, 32)),
      iv
    );
    let encrypted = cipher.update(JSON.stringify(credentials), 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return iv.toString('hex') + ':' + encrypted;
  }

  private decryptCredentials(encrypted: string): GatewayCredentials {
    const [ivHex, encryptedData] = encrypted.split(':');
    const iv = Buffer.from(ivHex, 'hex');
    const decipher = crypto.createDecipheriv(
      'aes-256-cbc',
      Buffer.from(this.encryptionKey.padEnd(32, '0').slice(0, 32)),
      iv
    );
    let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return JSON.parse(decrypted);
  }

  async registerGateway(
    userId: string,
    gatewayName: string,
    gatewayCode: string,
    baseUrl: string,
    credentials: GatewayCredentials,
    apiSchema: any,
    isPrimary: boolean = false
  ) {
    const encryptedCreds = this.encryptCredentials(credentials);

    if (isPrimary) {
      await this.prisma.gatewayIntegration.updateMany({
        where: { userId, isPrimary: true },
        data: { isPrimary: false },
      });
    }

    return this.prisma.gatewayIntegration.create({
      data: {
        userId,
        gatewayName,
        gatewayCode,
        baseUrl,
        credentialsEncrypted: encryptedCreds,
        isPrimary,
        apiSchema,
        isActive: true,
      },
    });
  }

  async getGateway(integrationId: string) {
    return this.prisma.gatewayIntegration.findUnique({
      where: { id: integrationId },
      include: {
        endpointConfigs: true,
        webhookApprovals: true,
      },
    });
  }

  async getUserGateways(userId: string) {
    return this.prisma.gatewayIntegration.findMany({
      where: { userId, isActive: true },
      include: {
        endpointConfigs: true,
      },
    });
  }

  async initiatePayment(
    integrationId: string,
    request: PaymentInitiationRequest,
    fieldMappings?: Record<string, string>
  ): Promise<GatewayPaymentResponse> {
    try {
      const integration = await this.getGateway(integrationId);
      if (!integration) {
        return { success: false, message: 'Gateway not found' };
      }

      const credentials = this.decryptCredentials(integration.credentialsEncrypted);
      const schema = integration.apiSchema as any;

      const initiateEndpoint = this.findEndpoint(schema, 'initiate');
      if (!initiateEndpoint) {
        return { success: false, message: 'Payment initiation endpoint not found in schema' };
      }

      const client = this.createGatewayClient(integration.baseUrl, credentials, schema);
      const payload = this.mapRequestPayload(request, initiateEndpoint, fieldMappings);

      const response = await client.post(initiateEndpoint.path, payload);

      const mappedResponse = this.mapResponseToGatewayFormat(response.data, schema, fieldMappings);
      return mappedResponse;
    } catch (error: any) {
      return {
        success: false,
        message: error.message || 'Payment initiation failed',
        errorCode: error.code,
      };
    }
  }

  async verifyPayment(
    integrationId: string,
    transactionId: string
  ): Promise<GatewayPaymentResponse> {
    try {
      const integration = await this.getGateway(integrationId);
      if (!integration) {
        return { success: false, message: 'Gateway not found' };
      }

      const credentials = this.decryptCredentials(integration.credentialsEncrypted);
      const schema = integration.apiSchema as any;

      const verifyEndpoint = this.findEndpoint(schema, 'verify');
      if (!verifyEndpoint) {
        return { success: false, message: 'Payment verification endpoint not found' };
      }

      const client = this.createGatewayClient(integration.baseUrl, credentials, schema);
      const verifyPath = verifyEndpoint.path.replace('{transactionId}', transactionId).replace('{id}', transactionId);

      const response = await client.get(verifyPath);
      return this.mapResponseToGatewayFormat(response.data, schema);
    } catch (error: any) {
      return {
        success: false,
        message: error.message || 'Payment verification failed',
        errorCode: error.code,
      };
    }
  }

  async handleWebhook(
    integrationId: string,
    payload: any,
    signature?: string
  ): Promise<{ valid: boolean; data?: any }> {
    try {
      const integration = await this.getGateway(integrationId);
      if (!integration) {
        return { valid: false };
      }

      if (signature && integration.webhookSecret) {
        const isValid = this.verifyWebhookSignature(payload, signature, integration.webhookSecret);
        if (!isValid) {
          return { valid: false };
        }
      }

      return { valid: true, data: payload };
    } catch (error) {
      return { valid: false };
    }
  }

  private createGatewayClient(baseUrl: string, credentials: GatewayCredentials, schema: any): AxiosInstance {
    const client = axios.create({
      baseURL: baseUrl,
      timeout: 30000,
    });

    const auth = schema.authentication || {};

    if (auth.type === 'bearer' && credentials.apiToken) {
      client.defaults.headers.common['Authorization'] = `Bearer ${credentials.apiToken}`;
    } else if (auth.type === 'apikey' && credentials.apiKey) {
      const headerKey = auth.key || 'X-API-Key';
      client.defaults.headers.common[headerKey] = credentials.apiKey;
    } else if (auth.type === 'basic' && credentials.apiKey && credentials.apiSecret) {
      const encodedAuth = Buffer.from(`${credentials.apiKey}:${credentials.apiSecret}`).toString('base64');
      client.defaults.headers.common['Authorization'] = `Basic ${encodedAuth}`;
    }

    client.interceptors.request.use((config) => {
      if (config.data && credentials.merchantId) {
        config.data.merchantId = credentials.merchantId;
      }
      return config;
    });

    return client;
  }

  private findEndpoint(schema: any, operation: string) {
    if (!schema.endpoints) return null;
    return schema.endpoints.find((ep: any) => {
      const opId = (ep.operationId || '').toLowerCase();
      return opId.includes(operation.toLowerCase()) || ep.description?.toLowerCase().includes(operation.toLowerCase());
    });
  }

  private mapRequestPayload(request: PaymentInitiationRequest, endpoint: any, fieldMappings?: Record<string, string>): any {
    const payload: any = { ...request };

    if (fieldMappings) {
      const mappedPayload: any = {};
      Object.entries(fieldMappings).forEach(([field, mappedField]) => {
        if (request[field as keyof PaymentInitiationRequest]) {
          mappedPayload[mappedField as string] = request[field as keyof PaymentInitiationRequest];
        }
      });
      return mappedPayload;
    }

    return payload;
  }

  private mapResponseToGatewayFormat(
    responseData: any,
    schema: any,
    fieldMappings?: Record<string, string>
  ): GatewayPaymentResponse {
    const response: GatewayPaymentResponse = {
      success: this.isSuccessResponse(responseData),
      raw: responseData,
    };

    if (fieldMappings) {
      response.transactionId = this.extractField(responseData, fieldMappings['transactionId']);
      response.utrNumber = this.extractField(responseData, fieldMappings['utrNumber']);
      response.status = this.mapStatus(this.extractField(responseData, fieldMappings['status']));
    } else {
      response.transactionId = this.extractField(responseData, ['id', 'transaction_id', 'txId', 'transactionId']);
      response.utrNumber = this.extractField(responseData, ['utr', 'utrNumber', 'reference_number', 'refNo']);
      response.status = this.mapStatus(this.extractField(responseData, ['status', 'state']));
    }

    response.paymentLink = this.extractField(responseData, ['payment_link', 'paymentLink', 'link', 'url']);
    response.message = this.extractField(responseData, ['message', 'description', 'reason']);

    return response;
  }

  private extractField(obj: any, paths: string | string[]): any {
    const pathArray = Array.isArray(paths) ? paths : [paths];
    for (const path of pathArray) {
      const value = this.getNestedValue(obj, path);
      if (value !== undefined && value !== null) {
        return value;
      }
    }
    return undefined;
  }

  private getNestedValue(obj: any, path: string): any {
    return path.split('.').reduce((current, part) => current?.[part], obj);
  }

  private isSuccessResponse(data: any): boolean {
    if (data.success === true) return true;
    if (data.success === false) return false;
    if (data.status === 'success') return true;
    if (data.error || data.errors) return false;
    return true;
  }

  private mapStatus(status?: string): 'pending' | 'success' | 'failed' | undefined {
    if (!status) return undefined;
    const lower = status.toLowerCase();
    if (['success', 'completed', 'approved'].includes(lower)) return 'success';
    if (['failed', 'declined', 'error', 'cancelled'].includes(lower)) return 'failed';
    if (['pending', 'processing', 'initiated'].includes(lower)) return 'pending';
    return undefined;
  }

  private verifyWebhookSignature(payload: any, signature: string, secret: string): boolean {
    const expectedSignature = crypto
      .createHmac('sha256', secret)
      .update(JSON.stringify(payload))
      .digest('hex');
    return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature));
  }

  async logTransaction(
    integrationId: string,
    transactionId: string,
    request: any,
    response: any,
    utrNumber?: string,
    status?: string
  ) {
    return this.prisma.gatewayTransactionLog.create({
      data: {
        integrationId,
        transactionId,
        requestPayload: request,
        responsePayload: response,
        utrNumber,
        status: status || 'pending',
      },
    });
  }
}

export default GatewayIntegrationService;

import { NextRequest } from 'next/server';

/**
 * In-memory rate limiting (use Redis for production)
 * This is a temporary solution - replace with Redis for distributed systems
 */

const requestCounts = new Map<string, { count: number; resetTime: number }>();

const RATE_LIMITS = {
  login: { requests: 5, windowSeconds: 900 }, // 5 requests per 15 minutes
  signup: { requests: 3, windowSeconds: 3600 }, // 3 requests per hour
  payinInitiate: { requests: 100, windowSeconds: 3600 }, // 100 requests per hour
  apiGateway: { requests: 1000, windowSeconds: 3600 }, // 1000 requests per hour
  adminPanel: { requests: 500, windowSeconds: 3600 }, // 500 requests per hour
  passwordReset: { requests: 3, windowSeconds: 3600 }, // 3 requests per hour
  kyc: { requests: 10, windowSeconds: 3600 }, // 10 requests per hour
  default: { requests: 100, windowSeconds: 60 }, // 100 requests per minute (default)
};

interface RateLimitConfig {
  requests: number;
  windowSeconds: number;
}

/**
 * Get rate limit config for an endpoint
 */
function getRateLimitConfig(endpoint: string): RateLimitConfig {
  const path = endpoint.toLowerCase();

  if (path.includes('/login')) return RATE_LIMITS.login;
  if (path.includes('/signup')) return RATE_LIMITS.signup;
  if (path.includes('/payin/initiate')) return RATE_LIMITS.payinInitiate;
  if (path.includes('/admin')) return RATE_LIMITS.adminPanel;
  if (path.includes('/password-reset')) return RATE_LIMITS.passwordReset;
  if (path.includes('/kyc')) return RATE_LIMITS.kyc;
  if (path.includes('/gateways')) return RATE_LIMITS.apiGateway;

  return RATE_LIMITS.default;
}

/**
 * Extract IP address from request
 */
function getClientIP(request: NextRequest): string {
  const forwarded = request.headers.get('x-forwarded-for');
  const realIP = request.headers.get('x-real-ip');

  if (forwarded) return forwarded.split(',')[0].trim();
  if (realIP) return realIP;

  return (request as any).ip || 'unknown';
}

/**
 * Check if request should be rate limited
 */
export function isRateLimited(request: NextRequest, endpoint: string, identifier?: string): boolean {
  const config = getRateLimitConfig(endpoint);
  const ip = getClientIP(request);
  const key = identifier ? `${ip}:${identifier}` : ip;
  const now = Date.now();

  const existing = requestCounts.get(key);

  if (!existing || now > existing.resetTime) {
    // Reset or create new entry
    requestCounts.set(key, {
      count: 1,
      resetTime: now + config.windowSeconds * 1000,
    });
    return false;
  }

  existing.count++;

  if (existing.count > config.requests) {
    return true;
  }

  return false;
}

/**
 * Get remaining requests for rate limit
 */
export function getRemainingRequests(request: NextRequest, endpoint: string, identifier?: string): number {
  const config = getRateLimitConfig(endpoint);
  const ip = getClientIP(request);
  const key = identifier ? `${ip}:${identifier}` : ip;
  const now = Date.now();

  const existing = requestCounts.get(key);

  if (!existing || now > existing.resetTime) {
    return config.requests;
  }

  return Math.max(0, config.requests - existing.count);
}

/**
 * Get reset time in seconds
 */
export function getResetTime(request: NextRequest, endpoint: string, identifier?: string): number {
  const ip = getClientIP(request);
  const key = identifier ? `${ip}:${identifier}` : ip;
  const now = Date.now();

  const existing = requestCounts.get(key);

  if (!existing || now > existing.resetTime) {
    return 0;
  }

  return Math.ceil((existing.resetTime - now) / 1000);
}

/**
 * Clean up old entries (run periodically)
 */
export function cleanupOldEntries(): void {
  const now = Date.now();
  let cleaned = 0;

  for (const [key, value] of requestCounts.entries()) {
    if (now > value.resetTime) {
      requestCounts.delete(key);
      cleaned++;
    }
  }

  if (cleaned > 0) {
    console.log(`Rate limit cleanup: removed ${cleaned} old entries`);
  }
}

/**
 * Suspicious activity detection
 */
export interface SuspiciousActivity {
  ip: string;
  userId?: string;
  activity: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  timestamp: number;
}

const suspiciousActivities: SuspiciousActivity[] = [];

/**
 * Log suspicious activity
 */
export function logSuspiciousActivity(activity: SuspiciousActivity): void {
  suspiciousActivities.push(activity);

  // Alert if critical
  if (activity.severity === 'critical') {
    console.error('🚨 CRITICAL SECURITY ALERT:', activity);
    // TODO: Send to monitoring system
  }
}

/**
 * Check for brute force attacks (failed login attempts)
 */
export function checkBruteForceLogin(username: string, ip: string): boolean {
  const failures = suspiciousActivities.filter(
    activity =>
      activity.activity === 'failed_login' &&
      activity.ip === ip &&
      Date.now() - activity.timestamp < 15 * 60 * 1000 // Last 15 minutes
  );

  if (failures.length >= 5) {
    logSuspiciousActivity({
      ip,
      activity: 'brute_force_detected',
      severity: 'high',
      timestamp: Date.now(),
    });
    return true;
  }

  return false;
}

/**
 * Check for suspicious payment amounts
 */
export function checkSuspiciousPayment(amount: number, userId: string): boolean {
  // Threshold: more than ₹500,000 in a single transaction
  if (amount > 50000000) { // In paisa
    logSuspiciousActivity({
      userId,
      activity: 'large_transaction_detected',
      severity: 'high',
      ip: 'unknown',
      timestamp: Date.now(),
    });
    return true;
  }

  return false;
}

/**
 * Check for unusual API access patterns
 */
export function checkUnusualAPIAccess(userId: string, endpoint: string, ip: string): boolean {
  // Log all admin API access
  if (endpoint.includes('/admin')) {
    logSuspiciousActivity({
      userId,
      ip,
      activity: 'admin_api_access',
      severity: 'low',
      timestamp: Date.now(),
    });
  }

  return false;
}

/**
 * Run cleanup every hour
 */
if (typeof global !== 'undefined') {
  const cleanupInterval = setInterval(() => {
    cleanupOldEntries();
  }, 60 * 60 * 1000); // Every hour

  // Prevent memory leaks
  cleanupInterval.unref();
}

import crypto from 'crypto';
import bcrypt from 'bcryptjs';

const ENCRYPTION_KEY = process.env.DATA_ENCRYPTION_KEY;
const ENCRYPTION_ALGORITHM = 'aes-256-gcm';

if (!ENCRYPTION_KEY) {
  throw new Error('DATA_ENCRYPTION_KEY environment variable is required');
}

const key = Buffer.from(ENCRYPTION_KEY, 'hex');

if (key.length !== 32) {
  throw new Error('DATA_ENCRYPTION_KEY must be 32 bytes (64 hex characters)');
}

/**
 * Encrypts sensitive data using AES-256-GCM
 * @param data The plaintext to encrypt
 * @returns Encrypted data in format: iv:encryptedData:authTag (hex encoded)
 */
export function encryptSensitiveData(data: string): string {
  if (!data) return '';

  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv(ENCRYPTION_ALGORITHM, key, iv);

  let encrypted = cipher.update(data, 'utf-8', 'hex');
  encrypted += cipher.final('hex');

  const authTag = cipher.getAuthTag();

  return `${iv.toString('hex')}:${encrypted}:${authTag.toString('hex')}`;
}

/**
 * Decrypts sensitive data encrypted with encryptSensitiveData
 * @param encryptedData The encrypted data in format: iv:encryptedData:authTag
 * @returns Decrypted plaintext
 */
export function decryptSensitiveData(encryptedData: string): string {
  if (!encryptedData) return '';

  try {
    const [ivHex, encrypted, authTagHex] = encryptedData.split(':');

    if (!ivHex || !encrypted || !authTagHex) {
      throw new Error('Invalid encrypted data format');
    }

    const iv = Buffer.from(ivHex, 'hex');
    const authTag = Buffer.from(authTagHex, 'hex');

    const decipher = crypto.createDecipheriv(ENCRYPTION_ALGORITHM, key, iv);
    decipher.setAuthTag(authTag);

    let decrypted = decipher.update(encrypted, 'hex', 'utf-8');
    decrypted += decipher.final('utf-8');

    return decrypted;
  } catch (error) {
    console.error('Decryption failed:', error instanceof Error ? error.message : 'Unknown error');
    throw new Error('Failed to decrypt data - data may be corrupted');
  }
}

/**
 * Hash a value (one-way, for verification purposes)
 * Used for API key hashing, token validation
 */
export function hashSensitiveData(data: string): string {
  return crypto.createHash('sha256').update(data).digest('hex');
}

/**
 * Generate a secure random token
 */
export function generateSecureToken(length: number = 32): string {
  return crypto.randomBytes(length).toString('hex');
}

/**
 * Mask sensitive data for display (show first 4 and last 4 chars)
 * Example: "sk_live_abc123def456ghi789" -> "sk_l...i789"
 */
export function maskSensitiveData(data: string | null, visibleChars: number = 4): string {
  if (!data) return '***';

  if (data.length <= visibleChars * 2) {
    return '*'.repeat(Math.max(3, data.length - visibleChars * 2)) + data.slice(-visibleChars);
  }

  return data.slice(0, visibleChars) + '*'.repeat(data.length - visibleChars * 2) + data.slice(-visibleChars);
}

/**
 * Validate if encrypted data is in correct format (without decrypting)
 */
export function isValidEncryptedFormat(data: string): boolean {
  const parts = data.split(':');
  return (
    parts.length === 3 &&
    parts[0].length === 32 && // IV (16 bytes = 32 hex chars)
    parts[2].length === 32 // Auth tag (16 bytes = 32 hex chars)
  );
}

/**
 * Generate encryption key (run once and store in .env)
 */
export function generateEncryptionKey(): string {
  return crypto.randomBytes(32).toString('hex');
}

/**
 * Verify a hashed password using bcrypt
 * (For user passwords, use bcrypt instead of SHA256)
 */
export async function verifyPassword(plainPassword: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(plainPassword, hashedPassword);
}

/**
 * Hash a password using bcrypt
 */
export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

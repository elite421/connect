import crypto from 'crypto';
import axios from 'axios';
import prisma from '@/lib/prisma';

export interface KgipayPayoutResponse {
    success: boolean;
    status: 'processing' | 'success' | 'failed' | 'pending';
    message?: string;
    utrNumber?: string;
    externalTransactionId?: string;
    raw: any;
}

interface PayoutApiResponse {
    apiUsed?: any;
    response: KgipayPayoutResponse;
}

function safeJsonParse<T = any>(val?: string | null): T | undefined {
    if (!val) return undefined;
    try {
        return JSON.parse(val) as T;
    } catch {
        return undefined;
    }
}

/**
 * Generate HMAC SHA256 Signature
 */
function sign(secret: string, body: any): string {
    return crypto
        .createHmac("sha256", secret)
        .update(JSON.stringify(body))
        .digest("hex");
}

/**
 * Resolve KGIPay API configuration for user or admin fallback
 */
async function resolveKgipayApiForUser(userId: string): Promise<any> {
    try {
        // Try user-level KGIPay API first (CustomPaymentApi or UserApi)
        // We look for name 'kgipay' or baseUrl containing 'kgipay'
        let api = await prisma.userApi.findFirst({
            where: {
                userId,
                isActive: true,
                AND: [
                    { OR: [{ name: { contains: 'kgipay', mode: 'insensitive' } }, { baseUrl: { contains: 'kgipay', mode: 'insensitive' } }] }
                ]
            },
            orderBy: { createdAt: 'desc' },
        });

        if (api) return api;

        // Fallback to Admin API
        // Checks CustomPaymentApi provided by admin
        const adminCustomApi = await prisma.customPaymentApi.findFirst({
            where: {
                adminProvided: true,
                isActive: true,
                isDefault: true,
                apiBaseUrl: { contains: 'kgipay', mode: 'insensitive' }
            }
        });

        if (adminCustomApi) {
            return {
                id: adminCustomApi.id,
                userId: adminCustomApi.userId,
                name: adminCustomApi.apiName,
                baseUrl: adminCustomApi.apiBaseUrl,
                apiKey: adminCustomApi.apiKey, // Client Key
                apiToken: null,
                apiSecret: adminCustomApi.apiSecret, // Secret for signing
                authHeader: adminCustomApi.authHeader,
                isActive: adminCustomApi.isActive,
                customPaymentApiSecret: adminCustomApi.apiSecret
            };
        }

        return null;
    } catch (error) {
        console.error('Error resolving KGIPay API:', error);
        return null;
    }
}

export async function callKgipayPayoutApi(
    userId: string,
    request: {
        amount: number;
        beneficiaryName: string;
        beneficiaryAccount?: string;
        beneficiaryIfsc?: string;
        transferMode: string;
        merchantTransactionId: string;
        // ... any other fields
    }
): Promise<PayoutApiResponse> {
    // Note: This function might be called from payout-integration which already resolved an API. 
    // If so, we might need a way to pass that API. 
    // However, to stick to the pattern, we'll implement resolution here or assume the caller handles generic resolution 
    // and this function helps if we need specific KGIPay logic.
    // BUT, if `payout-integration` detects KGIPay, it might pass the `api` object directly. 
    // Since I can't easily change `payout-integration` signature for just one integration without refactoring, 
    // I will allow passing `api` object optionally or resolve it.

    // Actually, `payout-integration` calls `callPayAtMePayoutApi(userId, api, request)`. 
    // I should probably follow that signature. 
    // But `callFingrowPayoutApi` takes `(userId, request)`.
    // I'll stick to `(userId, request)` and resolve inside, OR overload it.
    // Let's resolve inside for now to be safe.

    const api = await resolveKgipayApiForUser(userId);

    if (!api) {
        return {
            response: {
                success: false,
                status: 'failed',
                message: 'KGIPay API not configured.',
                raw: { error: 'NO_API_CONFIGURED' }
            }
        };
    }

    return executeKgipayTransaction(api, request);
}

export async function executeKgipayTransaction(api: any, request: any): Promise<PayoutApiResponse> {
    const conf = safeJsonParse<any>(api.apiSecret);

    // Mapping credentials
    // User code: "x-api-key": "YOUR_CLIENT_KEY" -> api.apiKey
    // User code: "Authorization": "Bearer <access_token>" -> api.apiToken (or conf.accessToken)
    // User code: signature secret -> api.apiSecret (or conf.secret)

    const clientKey = api.apiKey || conf?.clientKey || conf?.apiKey;
    // If apiSecret was parsed as JSON (conf exists), use conf.secret. Otherwise use raw apiSecret.
    const signingSecret = conf?.secret || api.customPaymentApiSecret || (conf ? undefined : api.apiSecret);
    const accessToken = api.apiToken || conf?.accessToken || conf?.token || conf?.bearerToken;

    const baseUrl = (api.baseUrl || 'https://api.kgipay.com/api/v1/transaction/payout/request-payout').replace(/\s+/g, '');

    if (!clientKey || !signingSecret || !accessToken) {
        return {
            response: {
                success: false,
                status: 'failed',
                message: 'Missing KGIPay credentials (Client Key, Secret, or Access Token).',
                raw: { error: 'MISSING_CREDENTIALS' }
            }
        };
    }

    // Construct Body
    // Assuming standard fields if not provided in a template.
    // User said "const body = payload;". 
    // We'll construct a standard payload.
    const payload = {
        amount: request.amount,
        accountNumber: request.beneficiaryAccount,
        accountName: request.beneficiaryName,
        ifscCode: request.beneficiaryIfsc,
        transactionId: request.merchantTransactionId,
        transferMode: request.transferMode,
        ...request // Merge any other fields
    };

    try {
        const signature = sign(signingSecret, payload);

        console.log(`[KGIPay] Executing payout to ${baseUrl}`);

        const res = await axios.post(baseUrl, payload, {
            headers: {
                "x-api-key": clientKey,
                "x-signature": signature,
                "Content-Type": "application/json",
                "Authorization": `Bearer ${accessToken}`
            }
        });

        const data = res.data;
        console.log('[KGIPay] Response:', data);

        const isSuccess = data?.success === true || data?.status === 'SUCCESS' || data?.status === 'COMPLETED';

        return {
            apiUsed: api,
            response: {
                success: isSuccess,
                status: isSuccess ? 'success' : 'failed', // Map appropriately
                message: data?.message || (isSuccess ? 'Transaction successful' : 'Transaction failed'),
                utrNumber: data?.utr || data?.data?.utr,
                externalTransactionId: data?.transactionId || data?.data?.transactionId,
                raw: data
            }
        };

    } catch (error: any) {
        console.error('[KGIPay] Request failed:', error.message);
        return {
            apiUsed: api,
            response: {
                success: false,
                status: 'failed',
                message: error?.response?.data?.message || error.message || 'KGIPay request failed',
                raw: error?.response?.data || { error: error.message, stack: error.stack }
            }
        };
    }
}

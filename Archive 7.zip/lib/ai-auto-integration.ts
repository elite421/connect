import ApiDocumentationParser from './ai-documentation-parser';

interface AutoIntegrationResult {
  success: boolean;
  fieldMappings?: Record<string, string>;
  endpoints?: any[];
  authentication?: any;
  webhooks?: any[];
  error?: string;
}

interface FieldMapping {
  utrNumber: string[];
  transactionId: string[];
  status: string[];
  statusValues?: {
    success: string[];
    failed: string[];
    pending: string[];
  };
  amount: string[];
  customerEmail: string[];
  customerPhone: string[];
  customerName: string[];
  message?: string[];
}

export class AutoIntegrationService {
  private parser: ApiDocumentationParser;

  constructor() {
    this.parser = new ApiDocumentationParser();
  }

  async analyzeAndIntegrate(
    schema: any,
    documentType: string,
    gatewayName: string
  ): Promise<AutoIntegrationResult> {
    try {
      // Extract potential field mappings based on common naming patterns
      const fieldMappings = this.extractFieldMappings(schema);
      
      // Identify key endpoints
      const endpoints = this.identifyKeyEndpoints(schema);
      
      // Extract authentication config
      const authentication = schema.authentication || {};
      
      // Extract webhooks
      const webhooks = schema.webhooks || [];

      // Validate the mappings
      const validatedMappings = await this.validateMappings(fieldMappings, schema);

      return {
        success: true,
        fieldMappings: validatedMappings,
        endpoints,
        authentication,
        webhooks,
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Failed to analyze API for integration',
      };
    }
  }

  private extractFieldMappings(schema: any): Record<string, string> {
    const mappings: Record<string, string> = {};
    
    // Analyze response examples from endpoints
    if (schema.endpoints && Array.isArray(schema.endpoints)) {
      const sampleResponses = this.collectSampleResponses(schema.endpoints);
      const fieldPatterns = this.detectFieldPatterns(sampleResponses);
      
      // Map standard payment gateway fields
      mappings['utrNumber'] = this.findBestMatch(fieldPatterns.utrPatterns, [
        'utr', 'utr_number', 'utrnumber', 'reference_number', 'reference_id',
        'refNo', 'ref_no', 'vpa', 'transaction_reference'
      ]);
      
      mappings['transactionId'] = this.findBestMatch(fieldPatterns.idPatterns, [
        'id', 'transaction_id', 'transactionid', 'txid', 'txId', 'ref', 'reference'
      ]);
      
      mappings['status'] = this.findBestMatch(fieldPatterns.statusPatterns, [
        'status', 'state', 'transaction_status', 'state'
      ]);
      
      mappings['amount'] = this.findBestMatch(fieldPatterns.amountPatterns, [
        'amount', 'total', 'total_amount', 'value', 'price'
      ]);
      
      mappings['customerEmail'] = this.findBestMatch(fieldPatterns.emailPatterns, [
        'email', 'customer_email', 'payer_email', 'buyer_email'
      ]);
      
      mappings['customerPhone'] = this.findBestMatch(fieldPatterns.phonePatterns, [
        'phone', 'mobile', 'customer_phone', 'payer_phone', 'contact'
      ]);
      
      mappings['customerName'] = this.findBestMatch(fieldPatterns.namePatterns, [
        'name', 'customer_name', 'payer_name', 'buyer_name', 'customer'
      ]);
      
      mappings['message'] = this.findBestMatch(fieldPatterns.messagePatterns, [
        'message', 'description', 'reason', 'response_message', 'error_message'
      ]);
    }
    
    return mappings;
  }

  private collectSampleResponses(endpoints: any[]): any[] {
    const responses: any[] = [];
    
    endpoints.forEach((endpoint) => {
      if (endpoint.responses) {
        Object.values(endpoint.responses).forEach((response: any) => {
          if (response.schema) {
            responses.push(response.schema);
          }
          if (response.content?.['application/json']?.schema) {
            responses.push(response.content['application/json'].schema);
          }
        });
      }
    });
    
    return responses;
  }

  private detectFieldPatterns(responses: any[]): {
    utrPatterns: string[];
    idPatterns: string[];
    statusPatterns: string[];
    amountPatterns: string[];
    emailPatterns: string[];
    phonePatterns: string[];
    namePatterns: string[];
    messagePatterns: string[];
  } {
    const patterns = {
      utrPatterns: [] as string[],
      idPatterns: [] as string[],
      statusPatterns: [] as string[],
      amountPatterns: [] as string[],
      emailPatterns: [] as string[],
      phonePatterns: [] as string[],
      namePatterns: [] as string[],
      messagePatterns: [] as string[],
    };

    responses.forEach((schema) => {
      const fields = this.extractFieldNames(schema);
      fields.forEach((field) => {
        const lowerField = field.toLowerCase();
        
        if (this.matchesPattern(lowerField, ['utr', 'reference', 'refno'])) {
          patterns.utrPatterns.push(field);
        }
        if (this.matchesPattern(lowerField, ['id', 'transactionid', 'txid'])) {
          patterns.idPatterns.push(field);
        }
        if (this.matchesPattern(lowerField, ['status', 'state'])) {
          patterns.statusPatterns.push(field);
        }
        if (this.matchesPattern(lowerField, ['amount', 'total', 'value'])) {
          patterns.amountPatterns.push(field);
        }
        if (this.matchesPattern(lowerField, ['email'])) {
          patterns.emailPatterns.push(field);
        }
        if (this.matchesPattern(lowerField, ['phone', 'mobile', 'contact'])) {
          patterns.phonePatterns.push(field);
        }
        if (this.matchesPattern(lowerField, ['name', 'customer'])) {
          patterns.namePatterns.push(field);
        }
        if (this.matchesPattern(lowerField, ['message', 'description', 'reason'])) {
          patterns.messagePatterns.push(field);
        }
      });
    });

    return patterns;
  }

  private extractFieldNames(schema: any, prefix = ''): string[] {
    const fields: string[] = [];

    if (schema && typeof schema === 'object') {
      if (schema.properties) {
        Object.keys(schema.properties).forEach((key) => {
          fields.push(prefix ? `${prefix}.${key}` : key);
        });
      } else if (Array.isArray(schema)) {
        schema.forEach((item) => {
          fields.push(...this.extractFieldNames(item, prefix));
        });
      }
    }

    return fields;
  }

  private matchesPattern(field: string, patterns: string[]): boolean {
    return patterns.some((pattern) => field.includes(pattern.toLowerCase()));
  }

  private findBestMatch(detectedFields: string[], commonNames: string[]): string {
    // Prefer exact matches first
    for (const name of commonNames) {
      const exact = detectedFields.find((f) => f.toLowerCase() === name.toLowerCase());
      if (exact) return exact;
    }

    // Then look for contains matches
    for (const name of commonNames) {
      const contains = detectedFields.find((f) =>
        f.toLowerCase().includes(name.toLowerCase())
      );
      if (contains) return contains;
    }

    // Return first detected field if available
    return detectedFields[0] || '';
  }

  private identifyKeyEndpoints(schema: any): any[] {
    const keyEndpoints: any[] = [];

    if (!schema.endpoints || !Array.isArray(schema.endpoints)) {
      return keyEndpoints;
    }

    schema.endpoints.forEach((endpoint: any) => {
      const opId = (endpoint.operationId || '').toLowerCase();
      const desc = (endpoint.description || '').toLowerCase();
      const path = (endpoint.path || '').toLowerCase();

      // Identify payment initiation endpoint
      if (
        opId.includes('initiate') ||
        opId.includes('payment') ||
        desc.includes('create') ||
        desc.includes('initiate') ||
        path.includes('payment') ||
        path.includes('initiate')
      ) {
        keyEndpoints.push({
          ...endpoint,
          type: 'initiate',
          priority: 1,
        });
      }

      // Identify verification/check endpoint
      if (
        opId.includes('verify') ||
        opId.includes('check') ||
        opId.includes('status') ||
        desc.includes('verify') ||
        desc.includes('check') ||
        path.includes('verify') ||
        path.includes('check')
      ) {
        keyEndpoints.push({
          ...endpoint,
          type: 'verify',
          priority: 2,
        });
      }
    });

    return keyEndpoints.sort((a, b) => a.priority - b.priority);
  }

  private async validateMappings(
    mappings: Record<string, string>,
    schema: any
  ): Promise<Record<string, string>> {
    const validated: Record<string, string> = {};

    // Filter out empty mappings
    Object.entries(mappings).forEach(([key, value]) => {
      if (value && value.trim()) {
        validated[key] = value;
      }
    });

    return validated;
  }

  async generateAutomationScript(
    schema: any,
    fieldMappings: Record<string, string>
  ): Promise<string> {
    const script = `
// Auto-generated payment gateway integration script
// Generated for: ${schema.title || 'API'}

const GatewayAdapter = {
  // Field mapping configuration
  fieldMappings: ${JSON.stringify(fieldMappings, null, 2)},

  // Extract response fields based on mappings
  extractFields(response) {
    const extracted = {};
    Object.entries(this.fieldMappings).forEach(([field, path]) => {
      extracted[field] = this.getNestedValue(response, path);
    });
    return extracted;
  },

  // Helper to get nested object values
  getNestedValue(obj, path) {
    return path.split('.').reduce((current, part) => current?.[part], obj);
  },

  // Map transaction status to standard values
  normalizeStatus(status) {
    const lowerStatus = (status || '').toLowerCase();
    if (['success', 'completed', 'approved'].includes(lowerStatus)) return 'success';
    if (['failed', 'declined', 'error', 'rejected'].includes(lowerStatus)) return 'failed';
    if (['pending', 'processing', 'initiated'].includes(lowerStatus)) return 'pending';
    return 'unknown';
  },

  // Process gateway response
  processResponse(gatewayResponse) {
    const fields = this.extractFields(gatewayResponse);
    return {
      success: this.normalizeStatus(fields.status) === 'success',
      transactionId: fields.transactionId,
      utrNumber: fields.utrNumber,
      status: this.normalizeStatus(fields.status),
      amount: fields.amount,
      customerEmail: fields.customerEmail,
      customerPhone: fields.customerPhone,
      customerName: fields.customerName,
      message: fields.message,
      raw: gatewayResponse,
    };
  },
};

module.exports = GatewayAdapter;
`;

    return script;
  }
}

export default AutoIntegrationService;

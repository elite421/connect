import prisma from './prisma';
// import { toPaise } from './money';

export interface FeeCalculation {
  feeAmount: number;
  feeType: string;
  originalAmount: number;
  netAmount: number;
  scheme: {
    id: string;
    feeValue: string;
    minimumFee: string | null;
    maximumFee: string | null;
  } | null;
}

export async function calculateTransactionFee(
  amount: number,
  userRole: 'USER' | 'SUBUSER',
  serviceId?: string
): Promise<FeeCalculation> {
  const schemes = await prisma.adminFeeScheme.findMany({
    where: {
      isActive: true,
      AND: [
        {
          OR: [
            { serviceId: serviceId || null },
            { serviceId: null },
          ],
        },
        {
          OR: [
            { applicableRole: 'ALL' },
            { applicableRole: userRole },
          ],
        },
      ],
    },
    orderBy: [
      { serviceId: 'desc' },
      { createdAt: 'desc' },
    ],
  });

  const scheme = schemes[0];

  if (!scheme) {
    return {
      feeAmount: 0,
      feeType: 'none',
      originalAmount: amount,
      netAmount: amount,
      scheme: null,
    };
  }

  let feeAmount = 0;

  if (scheme.feeType === 'percentage') {
    const percentageValue = Number(scheme.feeValue);
    // amount is in Rupees. fee = amount * percentage / 100
    feeAmount = Math.ceil((amount * percentageValue) / 100);
  } else if (scheme.feeType === 'fixed') {
    // Fixed fee in Rupees.
    feeAmount = Number(scheme.feeValue);
  }

  if (scheme.minimumFee) {
    const minFee = Number(scheme.minimumFee);
    if (feeAmount < minFee) {
      feeAmount = minFee;
    }
  }

  if (scheme.maximumFee) {
    const maxFee = Number(scheme.maximumFee);
    if (feeAmount > maxFee) {
      feeAmount = maxFee;
    }
  }

  return {
    feeAmount,
    feeType: scheme.feeType,
    originalAmount: amount,
    netAmount: amount - feeAmount,
    scheme: {
      id: scheme.id,
      feeValue: scheme.feeValue.toString(),
      minimumFee: scheme.minimumFee?.toString() || null,
      maximumFee: scheme.maximumFee?.toString() || null,
    },
  };
}

export async function deductFeeFromWallet(
  userId: string,
  subUserId: string | null,
  feeAmount: number,
  transactionId: string,
  transactionType: string,
  serviceId?: string
): Promise<{ success: boolean; error?: string; feeLogId?: string }> {
  try {
    const walletId = subUserId
      ? (await prisma.$queryRaw<{ id: string }[]>`
          SELECT id FROM "Wallet" WHERE "userId" = (SELECT "userId" FROM "SubUser" WHERE id = ${subUserId}) LIMIT 1
        `)[0]?.id
      : (await prisma.wallet.findUnique({ where: { userId }, select: { id: true } }))?.id;

    if (!walletId) {
      return { success: false, error: 'Wallet not found' };
    }

    const wallet = await prisma.wallet.findUnique({
      where: { id: walletId },
    });

    // wallet.balance is number
    if (!wallet || wallet.balance < feeAmount) {
      return { success: false, error: 'Insufficient wallet balance for transaction fee' };
    }

    const adminWalletAddress = process.env.ADMIN_WALLET_ADDRESS || 'admin-default-wallet';
    let adminWallet = await prisma.adminWallet.findUnique({
      where: { walletAddress: adminWalletAddress },
    });

    if (!adminWallet) {
      adminWallet = await prisma.adminWallet.create({
        data: {
          walletAddress: adminWalletAddress,
          balance: 0,
          currency: 'INR',
          description: 'Admin transaction fee wallet',
        },
      });
    }

    await prisma.$transaction(async (tx) => {
      await tx.wallet.update({
        where: { id: walletId },
        data: { balance: { decrement: feeAmount } },
      });

      await tx.adminWallet.update({
        where: { id: adminWallet!.id },
        data: { balance: { increment: feeAmount } },
      });
    });

    const feeLog = await prisma.transactionFeeLog.create({
      data: {
        userId: subUserId ? null : userId,
        subUserId: subUserId,
        transactionId,
        transactionType,
        serviceId: serviceId || null,
        feeAmount,
        feeType: 'deducted',
        originalAmount: feeAmount,
        netAmount: feeAmount,
        adminWalletId: adminWallet.id,
        status: 'completed',
      },
    });

    return { success: true, feeLogId: feeLog.id };
  } catch (error) {
    console.error('Fee deduction error:', error);
    return { success: false, error: 'Failed to deduct fee from wallet' };
  }
}

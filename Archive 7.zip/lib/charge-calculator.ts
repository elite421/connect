import prisma from '@/lib/prisma';
import { logActivity } from '@/lib/audit';

export async function calculateTransactionCharge(
  userServiceId: string,
  transactionAmount: number,
  serviceId?: string,
): Promise<{
  charge: number;
  chargeType: string;
  gst: number;
  total: number;
}> {
  try {
    const userService = await prisma.userService.findUnique({
      where: { id: userServiceId },
      select: {
        transactionCharge: true,
        transactionChargeType: true,
        service: { select: { id: true } }
      },
    });

    if (!userService) {
      return { charge: 0, chargeType: 'none', gst: 0, total: 0 };
    }

    const svcId = serviceId || userService.service?.id;

    let chargeVal = Number(userService.transactionCharge) || 0;
    let chargeType = userService.transactionChargeType || 'fixed';

    if (chargeVal === 0 && svcId) {
      const config = await prisma.systemConfiguration.findFirst();
      if (config?.globalTransactionCharge) {
        chargeVal = Number(config.globalTransactionCharge);
        chargeType = config.globalTransactionChargeType || 'fixed';
      }
    }

    let calculatedCharge = 0;

    if (chargeType === 'percentage') {
      // (Amount * Percentage) / 100
      calculatedCharge = (transactionAmount * chargeVal) / 100;
    } else {
      // Fixed charge is already in Rupees.
      calculatedCharge = chargeVal;
    }

    if (calculatedCharge < 0) calculatedCharge = 0;

    const config = await prisma.systemConfiguration.findFirst();
    const gstPercentage = config?.enableGst ? Number(config.globalGstPercentage || 18) : 0;

    // Calculate GST on the charge
    const gst = gstPercentage > 0 ? (calculatedCharge * gstPercentage) / 100 : 0;

    return {
      charge: calculatedCharge,
      chargeType,
      gst,
      total: calculatedCharge + gst,
    };
  } catch (error) {
    console.error('Error calculating transaction charge:', error);
    return { charge: 0, chargeType: 'none', gst: 0, total: 0 };
  }
}

export async function deductChargeFromWallet(
  userId: string,
  walletAccountId: string,
  chargeAmount: number, // In Rupees
  transactionId: string,
  chargeType: string,
  user?: any,
  ipAddress?: string,
  userAgent?: string,
): Promise<{ success: boolean; error?: string }> {
  try {
    const virtualAccount = await prisma.virtualAccount.findUnique({
      where: { id: walletAccountId },
    });

    if (!virtualAccount) {
      return { success: false, error: 'Virtual account not found' };
    }

    const currentBalance = virtualAccount.balance; // Now Float

    if (currentBalance < chargeAmount) {
      return {
        success: false,
        error: 'Insufficient wallet balance to cover transaction charges',
      };
    }

    await prisma.virtualAccount.update({
      where: { id: walletAccountId },
      data: {
        balance: {
          decrement: chargeAmount,
        },
      },
    });

    if (user) {
      await logActivity({
        user,
        action: 'deduct_transaction_charge',
        resource: 'wallet',
        resourceId: walletAccountId,
        metadata: {
          chargeAmount: chargeAmount,
          chargeType,
          transactionId,
          previousBalance: currentBalance,
          newBalance: currentBalance - chargeAmount,
        },
        ipAddress: ipAddress || '0.0.0.0',
        userAgent: userAgent || 'unknown',
      });
    }

    return { success: true };
  } catch (error) {
    console.error('Error deducting charge from wallet:', error);
    return { success: false, error: 'Failed to deduct charge from wallet' };
  }
}

export async function getWalletForService(
  userId: string,
  serviceCode: string,
): Promise<string | null> {
  try {
    const virtualAccount = await prisma.virtualAccount.findFirst({
      where: {
        userId,
        status: 'active',
        linkedServices: {
          has: serviceCode,
        },
      },
    });

    return virtualAccount?.id || null;
  } catch (error) {
    console.error('Error getting wallet for service:', error);
    return null;
  }
}

import prisma from '@/lib/prisma';

export interface RudraxPayinRequest {
    userid: string;
    token: string;
    amount: string; // e.g. "31"
    mobile: string;
    name: string;
    orderid: string;
    callback_url: string;
}

export interface RudraxPayinResponse {
    status: boolean;
    message: string;
    url?: string; // upi://...
}

export interface RudraxPayinStatusResponse {
    status: string; // "success" or "failed"
    message: string;
    utr?: string;
    client_txn_id?: string;
}

export interface RudraxPayoutRequest {
    token: string;
    userid: string;
    amount: string;
    mobile: string;
    name: string;
    number: string; // Account Number or UPI ID
    ifsc: string;
    orderid: string;
}

export interface RudraxPayoutResponse {
    status: boolean;
    message: string;
    id?: string;
    dataByBank?: boolean;
}

export interface RudraxPayoutStatusResponse {
    status: string; // "success" or "failed"
    message: string;
    utr?: string;
    client_txn_id?: string;
}

export interface RudraxWalletResponse {
    status: boolean;
    message: string;
    aeps?: string;
    payin?: string;
    payout?: string;
}

const DEFAULT_BASE_URL = 'https://merchant.rudraxpay.com/api';

/**
 * Initiate RudraxPay Payin
 */
export async function initiateRudraxPayPayin(
    baseUrl: string,
    credentials: { userid: string; token: string },
    data: {
        amount: number;
        name: string;
        mobile: string;
        orderid: string;
        callbackUrl: string;
    }
): Promise<{ success: boolean; url?: string; message?: string; raw?: any }> {
    try {
        const url = `${baseUrl.replace(/\/$/, '')}/pg/phonepe/initiate`;

        const payload: RudraxPayinRequest = {
            token: credentials.token,
            userid: credentials.userid,
            amount: String(data.amount),
            mobile: data.mobile,
            name: data.name,
            orderid: data.orderid,
            callback_url: data.callbackUrl
        };

        console.log('[RudraxPay] Initiating Payin:', { url, orderid: data.orderid });

        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });

        const responseText = await res.text();
        let response: RudraxPayinResponse;
        try {
            response = JSON.parse(responseText);
        } catch {
            return { success: false, message: 'Invalid JSON response from gateway', raw: responseText };
        }

        if (response.status === true) {
            return { success: true, url: response.url, message: response.message, raw: response };
        } else {
            return { success: false, message: response.message || 'Failed', raw: response };
        }
    } catch (error: any) {
        console.error('[RudraxPay] Payin Error:', error);
        return { success: false, message: error.message };
    }
}

/**
 * Check RudraxPay Payin Status
 */
export async function checkRudraxPayPayinStatus(
    baseUrl: string,
    userid: string,
    orderid: string
): Promise<RudraxPayinStatusResponse> {
    try {
        const url = `${baseUrl.replace(/\/$/, '')}/pg/phonepe/checkstatus`;
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userid, orderid }),
        });

        const data = await res.json();
        return data;
    } catch (error: any) {
        return { status: 'failed', message: error.message };
    }
}

/**
 * Initiate RudraxPay Payout
 */
export async function initiateRudraxPayPayout(
    baseUrl: string,
    credentials: { userid: string; token: string },
    data: {
        amount: number;
        name: string;
        mobile: string;
        accountNumber: string;
        ifsc: string;
        orderid: string;
    }
): Promise<{ success: boolean; message: string; transactionId?: string; raw?: any }> {
    try {
        const url = `${baseUrl.replace(/\/$/, '')}/payout/initiate`;

        const payload: RudraxPayoutRequest = {
            userid: credentials.userid,
            token: credentials.token,
            amount: String(data.amount),
            name: data.name,
            mobile: data.mobile,
            number: data.accountNumber,
            ifsc: data.ifsc,
            orderid: data.orderid
        };

        console.log('[RudraxPay] Initiating Payout:', { url, orderid: data.orderid, amount: data.amount });

        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });

        const responseText = await res.text();
        let response: RudraxPayoutResponse;
        try {
            response = JSON.parse(responseText);
        } catch {
            // RudraxPay might return error like { status: false, message: "..." }
            return { success: false, message: 'Invalid JSON response', raw: responseText };
        }

        if (response.status === true) {
            return {
                success: true,
                message: response.message,
                transactionId: response.id,
                raw: response
            };
        } else {
            return {
                success: false,
                message: response.message || 'Failed',
                raw: response
            };
        }
    } catch (error: any) {
        console.error('[RudraxPay] Payout Error:', error);
        return { success: false, message: error.message };
    }
}

/**
 * Check RudraxPay Payout Status
 */
export async function checkRudraxPayPayoutStatus(
    baseUrl: string,
    userid: string,
    orderid: string
): Promise<RudraxPayoutStatusResponse> {
    try {
        const url = `${baseUrl.replace(/\/$/, '')}/payout/checkstatus`;
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userid, orderid }),
        });

        const data = await res.json();
        return data;
    } catch (error: any) {
        return { status: 'failed', message: error.message };
    }
}

/**
 * Check RudraxPay Wallet Balance
 */
export async function checkRudraxPayWallet(
    baseUrl: string,
    credentials: { userid: string; token: string }
): Promise<{ success: boolean; balances?: { payin: number; payout: number; aeps: number }; message?: string }> {
    try {
        const url = `${baseUrl.replace(/\/$/, '')}/wallet`;
        const res = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(credentials),
        });

        const data: RudraxWalletResponse = await res.json();

        if (data.status === true) {
            return {
                success: true,
                balances: {
                    payin: parseFloat(data.payin || '0'),
                    payout: parseFloat(data.payout || '0'),
                    aeps: parseFloat(data.aeps || '0')
                }
            };
        } else {
            return { success: false, message: data.message };
        }
    } catch (error: any) {
        return { success: false, message: error.message };
    }
}


export interface ChargeRule {
    minAmount: number;
    maxAmount?: number | null; // null means infinity
    fee: number;
    type: 'fixed' | 'percentage';
    gst?: boolean; // Apply GST on top of fee?
}

export function calculateTransactionFee(amount: number, rules?: ChargeRule[] | null, defaultFee?: number, defaultType?: 'fixed' | 'percentage'): { fee: number; gst: number; totalFee: number } {
    let fee = 0;
    let gst = 0;

    // 1. Check for Slab Rules
    if (rules && Array.isArray(rules) && rules.length > 0) {
        // Find matching rule
        const rule = rules.find(r => {
            const min = Number(r.minAmount) || 0;
            const max = r.maxAmount ? Number(r.maxAmount) : Number.MAX_SAFE_INTEGER;
            return amount >= min && amount <= max;
        });

        if (rule) {
            if (rule.type === 'percentage') {
                fee = (amount * rule.fee) / 100;
            } else {
                fee = rule.fee;
            }

            if (rule.gst) {
                gst = fee * 0.18; // Assuming 18% GST
            }
        } else {
            // Fallback to default if no slab matches? Or 0?
            // Usually if slabs defined but none match, fee matches last slab or default?
            // Let's fallback to default structure if provided
            if (defaultFee) {
                if (defaultType === 'percentage') {
                    fee = (amount * defaultFee) / 100;
                } else {
                    fee = defaultFee;
                }
            }
        }
    } else if (defaultFee) {
        // 2. Fallback to Simple Fee
        if (defaultType === 'percentage') {
            fee = (amount * defaultFee) / 100;
        } else {
            fee = defaultFee;
        }
    }

    // Ensure precision
    fee = Number(fee.toFixed(2));
    gst = Number(gst.toFixed(2));

    return { fee, gst, totalFee: fee + gst };
}

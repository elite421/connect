
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

/**
 * Extracts the real client IP from request headers.
 * Handles various proxy scenarios (Nginx, Cloudflare, AWS ELB, etc.)
 */
export function extractClientIp(req: NextRequest): string {
    // Cloudflare
    const cfIp = req.headers.get('cf-connecting-ip');
    if (cfIp) return cfIp.split(',')[0].trim();

    // Standard proxy headers
    const forwardedFor = req.headers.get('x-forwarded-for');
    if (forwardedFor) return forwardedFor.split(',')[0].trim();

    const realIp = req.headers.get('x-real-ip');
    if (realIp) return realIp.trim();

    // Fallback (development)
    return '127.0.0.1';
}

/**
 * Validates an API key and returns the associated user and key record.
 * Returns null if the key is invalid, inactive, or expired.
 */
export async function validateApiKey(req: NextRequest) {
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return null;
    }

    const apiKey = authHeader.split(' ')[1];

    const keyRecord = await prisma.apiKey.findUnique({
        where: { keyValue: apiKey },
        include: { user: true }
    });

    if (!keyRecord || !keyRecord.isActive) {
        return null;
    }

    if (keyRecord.expiresAt && new Date(keyRecord.expiresAt) < new Date()) {
        return null;
    }

    // Update stats async
    try {
        await prisma.apiKey.update({
            where: { id: keyRecord.id },
            data: {
                lastUsedAt: new Date(),
                requestCount: { increment: 1 }
            }
        });
    } catch (e) {
        console.error('Failed to update API key stats', e);
    }

    return { user: keyRecord.user, apiKey: keyRecord };
}

/**
 * Checks if a given IP is whitelisted for a user.
 * Returns true if whitelisted, false otherwise.
 * Note: Localhost IPs (127.0.0.1, ::1) are auto-allowed for development.
 */
export async function isIpWhitelisted(userId: string, ip: string): Promise<boolean> {
    // Auto-allow localhost for development (remove in strict production)
    const localhostIps = ['127.0.0.1', '::1', 'localhost', '::ffff:127.0.0.1'];
    if (localhostIps.includes(ip)) {
        return true;
    }

    const whitelist = await prisma.ipWhitelist.findMany({
        where: {
            userId,
            isActive: true
        },
        select: { ipAddress: true }
    });

    // If no whitelist entries exist, IP check is bypassed (user hasn't set up whitelisting yet)
    // This is optional behavior - change to `return false` to enforce strict whitelisting
    if (whitelist.length === 0) {
        return false; // Enforce: User MUST add at least one IP
    }

    // Check exact match or CIDR range
    for (const entry of whitelist) {
        if (matchIp(ip, entry.ipAddress)) {
            return true;
        }
    }

    return false;
}

/**
 * Matches an IP against a pattern (exact match or CIDR notation).
 */
function matchIp(clientIp: string, pattern: string): boolean {
    // Exact match
    if (clientIp === pattern) return true;

    // CIDR match (e.g., 192.168.1.0/24)
    if (pattern.includes('/')) {
        const [subnet, bits] = pattern.split('/');
        const mask = ~(2 ** (32 - parseInt(bits)) - 1);
        const clientInt = ipToInt(clientIp);
        const subnetInt = ipToInt(subnet);
        return (clientInt & mask) === (subnetInt & mask);
    }

    return false;
}

function ipToInt(ip: string): number {
    const parts = ip.split('.').map(Number);
    return ((parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]) >>> 0;
}

/**
 * Complete API auth validation including IP whitelisting.
 * Returns { user, apiKey, clientIp } on success, or { error, clientIp } on failure.
 */
export async function validateApiKeyWithIp(req: NextRequest): Promise<
    | { success: true; user: any; apiKey: any; clientIp: string }
    | { success: false; error: 'INVALID_KEY' | 'IP_NOT_WHITELISTED'; clientIp: string }
> {
    const clientIp = extractClientIp(req);

    // Validate API Key first
    const auth = await validateApiKey(req);
    if (!auth) {
        return { success: false, error: 'INVALID_KEY', clientIp };
    }

    // Check IP whitelist
    const isWhitelisted = await isIpWhitelisted(auth.user.id, clientIp);
    if (!isWhitelisted) {
        return { success: false, error: 'IP_NOT_WHITELISTED', clientIp };
    }

    return { success: true, user: auth.user, apiKey: auth.apiKey, clientIp };
}

/**
 * Logs an API request to the database for audit purposes.
 */
export async function logApiRequest(
    apiKeyId: string,
    userId: string,
    req: NextRequest,
    statusCode: number,
    responseTime: number,
    error: string | null = null
) {
    try {
        const ip = extractClientIp(req);

        await prisma.apiRequestLog.create({
            data: {
                apiKeyId,
                userId,
                method: req.method,
                endpoint: req.nextUrl.pathname,
                statusCode,
                responseTime,
                ipAddress: ip,
                error
            }
        });
    } catch (e) {
        console.error('Failed to log API request', e);
    }
}

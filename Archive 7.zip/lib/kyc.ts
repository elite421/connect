import prisma from './prisma';

export async function getKYCStatus(userId: string, isSubUser: boolean = false) {
  if (isSubUser) {
    const kycSubmission = await prisma.kycSubmission.findFirst({
      where: { subUserId: userId },
    });
    return kycSubmission;
  } else {
    const kycSubmission = await prisma.kycSubmission.findUnique({
      where: { userId },
    });
    return kycSubmission;
  }
}

export async function isKYCApproved(userId: string, isSubUser: boolean = false) {
  const kycSubmission = await getKYCStatus(userId, isSubUser);
  return kycSubmission?.kycStatus === 'approved';
}

export async function isKYCPending(userId: string, isSubUser: boolean = false) {
  const kycSubmission = await getKYCStatus(userId, isSubUser);
  return kycSubmission?.kycStatus === 'pending';
}

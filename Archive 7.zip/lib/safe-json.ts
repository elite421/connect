import { NextResponse } from 'next/server';
import { serializeBigInt } from '@/lib/bigint-serializer';

/**
 * Wrap NextResponse.json with a sanitizer that converts BigInt/Decimal/Date to JSON-safe values.
 * Use this for all API responses that may contain Prisma BigInt or Decimal types.
 */
export function safeJson(data: any, init?: ResponseInit) {
  const sanitized = serializeBigInt(data);
  return NextResponse.json(sanitized, init);
}

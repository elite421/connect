import { type NextAuthOptions, getServerSession } from "next-auth";
import type { User } from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { prisma } from "@/lib/prisma";
import { compare } from "bcryptjs";

export const authOptions: NextAuthOptions = {
  session: { strategy: "jwt" },
  pages: {
    signIn: '/login',
    signOut: '/login',
    error: '/login',
  },
  providers: [
    Credentials({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(creds) {
        if (!creds?.email || !creds?.password) return null;

        const user = await prisma.user.findUnique({ where: { email: creds.email } });
        if (user) {
          const ok = await compare(creds.password, user.password);
          if (!ok) return null;
          return { id: user.id, name: user.name, email: user.email, role: user.role } as User & { role: string };
        }

        const subUser = await prisma.subUser.findFirst({
          where: { email: creds.email },
          include: { user: true },
        });
        if (subUser) {
          const ok = await compare(creds.password, subUser.password);
          if (!ok) return null;
          return {
            id: subUser.id,
            name: subUser.name,
            email: subUser.email,
            role: 'SUBUSER',
            parentUserId: subUser.userId,
            isApiEnabled: subUser.isApiEnabled,
          } as User & { role: string; parentUserId?: string; isApiEnabled?: boolean };
        }

        return null;
      },
    }),
  ],
  callbacks: {
    async redirect({ url, baseUrl }) {
      // Always redirect to login page after signout or for auth errors
      if (url.includes('/api/auth/signout') || url.includes('signout')) {
        return `${baseUrl}/login`;
      }
      // Allows relative callback URLs
      if (url.startsWith('/')) return `${baseUrl}${url}`;
      // Allows callback URLs on the same origin
      if (new URL(url).origin === baseUrl) return url;
      return `${baseUrl}/login`;
    },
    async jwt({ token, user }) {
      if (user) {
        const u = user as { id: string; role: string; parentUserId?: string; isApiEnabled?: boolean };
        (token as Record<string, unknown>).id = u.id;
        (token as Record<string, unknown>).role = u.role;
        if (u.parentUserId) {
          (token as Record<string, unknown>).parentUserId = u.parentUserId;
        }
        if (u.isApiEnabled !== undefined) {
          (token as Record<string, unknown>).isApiEnabled = u.isApiEnabled;
        }
      }
      return token;
    },
    async session({ session, token }) {
      const id = (token as Record<string, unknown>).id;
      const role = (token as Record<string, unknown>).role;
      const parentUserId = (token as Record<string, unknown>).parentUserId;
      const isApiEnabled = (token as Record<string, unknown>).isApiEnabled;
      const idStr = typeof id === "string" ? id : "";
      const roleStr = typeof role === "string" ? role : "";
      const parentUserIdStr = typeof parentUserId === "string" ? parentUserId : undefined;
      (session.user as unknown as { id: string }).id = idStr;
      (session.user as unknown as { role: string }).role = roleStr;
      if (parentUserIdStr) {
        (session.user as unknown as { parentUserId: string }).parentUserId = parentUserIdStr;
      }
      if (typeof isApiEnabled === 'boolean') {
        (session.user as unknown as { isApiEnabled: boolean }).isApiEnabled = isApiEnabled;
      }
      return session;
    },
  },
};

export function auth() {
  return getServerSession(authOptions);
}

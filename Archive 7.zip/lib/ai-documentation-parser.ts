type AnthropicClient = any;

const createAnthropicClient = (): AnthropicClient => {
  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const Anthropic = require('@anthropic-ai/sdk').default;
    return new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });
  } catch (error) {
    console.warn('Anthropic SDK not installed. Install with: npm install @anthropic-ai/sdk');
    return null;
  }
};

interface ParsedEndpoint {
  path: string;
  method: string;
  description?: string;
  operationId?: string;
  parameters?: Record<string, any>;
  requestBody?: Record<string, any>;
  responses?: Record<string, any>;
  authentication?: string;
}

interface ParsedApiSchema {
  title?: string;
  version?: string;
  description?: string;
  baseUrl?: string;
  authentication?: {
    type: string;
    location?: string;
    key?: string;
  };
  endpoints: ParsedEndpoint[];
  webhooks?: Array<{
    event: string;
    description?: string;
    payload?: Record<string, any>;
  }>;
}

interface DocumentParsingResult {
  success: boolean;
  schema?: ParsedApiSchema;
  error?: string;
  rawContent?: string;
}

export class ApiDocumentationParser {
  private client: AnthropicClient;

  constructor() {
    this.client = createAnthropicClient();
  }

  async parseOpenAPISpec(specContent: string): Promise<DocumentParsingResult> {
    try {
      const spec = JSON.parse(specContent);
      const endpoints: ParsedEndpoint[] = [];

      if (spec.paths) {
        Object.entries(spec.paths).forEach(([path, pathItem]: [string, any]) => {
          Object.entries(pathItem).forEach(([method, operation]: [string, any]) => {
            if (['get', 'post', 'put', 'delete', 'patch'].includes(method.toLowerCase())) {
              endpoints.push({
                path,
                method: method.toUpperCase(),
                description: operation.description || operation.summary,
                operationId: operation.operationId,
                parameters: operation.parameters,
                requestBody: operation.requestBody,
                responses: operation.responses,
                authentication: this.extractAuth(operation),
              });
            }
          });
        });
      }

      const schema: ParsedApiSchema = {
        title: spec.info?.title,
        version: spec.info?.version,
        description: spec.info?.description,
        baseUrl: this.getBaseUrl(spec),
        authentication: this.extractSecurityScheme(spec),
        endpoints,
        webhooks: spec['x-webhooks'] ? Object.entries(spec['x-webhooks']).map(([event, webhook]: [string, any]) => ({
          event,
          description: webhook.description,
          payload: webhook.content?.['application/json']?.schema,
        })) : undefined,
      };

      return { success: true, schema };
    } catch (error) {
      return { success: false, error: `Failed to parse OpenAPI spec: ${error}` };
    }
  }

  async parseJsonSchema(jsonContent: string): Promise<DocumentParsingResult> {
    try {
      const schema = JSON.parse(jsonContent);

      if (!schema.endpoints || !Array.isArray(schema.endpoints)) {
        return {
          success: false,
          error: 'Invalid JSON schema: must have endpoints array',
        };
      }

      const parsedSchema: ParsedApiSchema = {
        title: schema.title || 'API Schema',
        version: schema.version || '1.0',
        description: schema.description,
        baseUrl: schema.baseUrl,
        authentication: schema.authentication,
        endpoints: schema.endpoints,
        webhooks: schema.webhooks,
      };

      return { success: true, schema: parsedSchema };
    } catch (error) {
      return { success: false, error: `Failed to parse JSON schema: ${error}` };
    }
  }

  async parseMarkdownDocumentation(markdownContent: string): Promise<DocumentParsingResult> {
    if (!this.client) {
      return {
        success: false,
        error: 'AI documentation parser not configured. Please install @anthropic-ai/sdk and set ANTHROPIC_API_KEY environment variable.',
      };
    }

    const prompt = `Analyze this API documentation in Markdown format and extract structured information about all API endpoints, their methods, parameters, responses, authentication, and webhooks. Return a JSON object with this structure:
{
  "title": "API Name",
  "version": "1.0",
  "description": "Description",
  "baseUrl": "https://api.example.com",
  "authentication": {
    "type": "bearer|apikey|basic|oauth2",
    "key": "Authorization",
    "location": "header|query"
  },
  "endpoints": [
    {
      "path": "/endpoint/path",
      "method": "GET|POST|PUT|DELETE|PATCH",
      "description": "What this endpoint does",
      "parameters": { parameter definitions },
      "requestBody": { body schema },
      "responses": { response definitions }
    }
  ],
  "webhooks": [
    {
      "event": "transaction.success",
      "description": "Fired when transaction succeeds",
      "payload": { webhook payload structure }
    }
  ]
}

Extract ONLY valid JSON structure. Here's the documentation:

${markdownContent}`;

    try {
      const message = await this.client.messages.create({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 4096,
        messages: [
          {
            role: 'user',
            content: prompt,
          },
        ],
      });

      const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);

      if (!jsonMatch) {
        return {
          success: false,
          error: 'Could not extract JSON from AI response',
          rawContent: responseText,
        };
      }

      const schema = JSON.parse(jsonMatch[0]) as ParsedApiSchema;
      return { success: true, schema };
    } catch (error) {
      return { success: false, error: `Failed to parse markdown documentation: ${error}` };
    }
  }

  async generateIntegrationCode(schema: ParsedApiSchema, gatewayName: string): Promise<string> {
    if (!this.client) {
      throw new Error('AI documentation parser not configured. Please install @anthropic-ai/sdk and set ANTHROPIC_API_KEY environment variable.');
    }

    const prompt = `Generate a TypeScript Node.js service class for integrating with the "${gatewayName}" payment gateway. The API schema is:

${JSON.stringify(schema, null, 2)}

Requirements:
1. Create a class named ${this.toPascalCase(gatewayName)}Service
2. Constructor should accept baseUrl and credentials (apiKey, apiSecret, etc.)
3. Implement methods for each endpoint mapped to payment operations
4. Map gateway responses to this interface:
   interface PaymentResponse {
     success: boolean;
     transactionId?: string;
     utrNumber?: string;
     status?: 'pending' | 'success' | 'failed';
     message?: string;
     raw?: any;
   }
5. Include error handling and logging
6. Make the class compatible with the existing PayInTransaction model

Return only valid TypeScript code, no markdown.`;

    try {
      const message = await this.client.messages.create({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 4096,
        messages: [
          {
            role: 'user',
            content: prompt,
          },
        ],
      });

      return message.content[0].type === 'text' ? message.content[0].text : '';
    } catch (error) {
      throw new Error(`Failed to generate integration code: ${error}`);
    }
  }

  async extractFieldMappings(schema: ParsedApiSchema, transactionFields: string[]): Promise<Record<string, string>> {
    const prompt = `Given this API schema:
${JSON.stringify(schema, null, 2)}

And these transaction fields that need to be mapped: ${transactionFields.join(', ')}

Create a mapping object that shows which API response fields should be mapped to each transaction field. For example:
{
  "utrNumber": "reference_id or transaction_id or utr_number",
  "amount": "amount field name in response",
  "status": "status field name in response"
}

Return only valid JSON.`;

    try {
      const message = await this.client.messages.create({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 2048,
        messages: [
          {
            role: 'user',
            content: prompt,
          },
        ],
      });

      const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);

      if (!jsonMatch) {
        return {};
      }

      return JSON.parse(jsonMatch[0]);
    } catch (error) {
      console.error('Failed to extract field mappings:', error);
      return {};
    }
  }

  private getBaseUrl(spec: any): string {
    if (spec.servers && spec.servers.length > 0) {
      return spec.servers[0].url;
    }
    if (spec.host) {
      return `${spec.schemes?.[0] || 'https'}://${spec.host}${spec.basePath || ''}`;
    }
    return '';
  }

  private extractSecurityScheme(spec: any): any {
    const security = spec.securityDefinitions || spec.components?.securitySchemes;
    if (!security) return undefined;

    const firstScheme = Object.entries(security)[0];
    if (!firstScheme) return undefined;

    const [key, value]: [string, any] = firstScheme as any;
    return {
      type: value.type || 'apiKey',
      key,
      location: value.in || 'header',
    };
  }

  private extractAuth(operation: any): string | undefined {
    if (operation.security && Array.isArray(operation.security)) {
      return JSON.stringify(operation.security[0]);
    }
    return undefined;
  }

  private toPascalCase(str: string): string {
    return str
      .split(/[-_\s]+/)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join('');
  }

  async validateAndEnhanceSchema(schema: ParsedApiSchema): Promise<ParsedApiSchema> {
    const prompt = `Review and enhance this API schema:
${JSON.stringify(schema, null, 2)}

1. Add any missing standard payment endpoints if implied (initiate, verify, webhook)
2. Ensure all endpoints have consistent response structures
3. Add missing webhook events if not present
4. Validate the authentication configuration

Return the enhanced schema as valid JSON only.`;

    try {
      const message = await this.client.messages.create({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 4096,
        messages: [
          {
            role: 'user',
            content: prompt,
          },
        ],
      });

      const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);

      if (!jsonMatch) {
        return schema;
      }

      return JSON.parse(jsonMatch[0]);
    } catch (error) {
      console.error('Failed to validate schema:', error);
      return schema;
    }
  }
}

export default ApiDocumentationParser;

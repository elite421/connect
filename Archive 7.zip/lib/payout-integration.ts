import prisma from '@/lib/prisma';
import { executeFingrowTransaction } from './fingrow-integration';
import { callPayAtMePayoutApi } from './payatme-integration';
import { executeZyonticTransaction } from './zyontic-integration';
import { initiateRudraxPayPayout } from './rudraxpay-integration';

export type PayoutRequest = {
  amount: number;
  beneficiaryName?: string;
  beneficiaryAccount?: string;
  beneficiaryIfsc?: string;
  beneficiaryVpa?: string;
  transferMode: string; // upi, neft, imps
  merchantTransactionId?: string;
  metadata?: Record<string, any>;
  userEmail?: string;
  userPhone?: string;
};

export type PayoutResponse = {
  success: boolean;
  status: 'pending' | 'processing' | 'success' | 'failed';
  message?: string;
  utrNumber?: string;
  externalTransactionId?: string;
  raw?: any;
};

export type PaymentApi = {
  id: string;
  userId: string | null;
  name: string | null;
  baseUrl: string | null;
  scopes: string | null;
  apiKey: string | null;
  apiToken: string | null;
  apiSecret: string | null;
  authHeader: string | null;
  assignedServices: string[];
  isDefault: boolean;
  isActive: boolean;
  // Custom Payment API fields
  customPaymentApiEndpoint?: string | null;
  customPaymentApiMethod?: string | null;
  customPaymentApiAuthType?: string | null;
  customPaymentApiSecret?: string | null;
  transactionCharge?: number | null;
  transactionChargeType?: string | null;
};

function safeJsonParse<T = any>(val?: string | null): T | undefined {
  if (!val) return undefined;
  try {
    return JSON.parse(val) as T;
  } catch {
    return undefined;
  }
}

function getNested(obj: any, path: string): any {
  return path.split('.').reduce((acc, key) => (acc == null ? acc : acc[key]), obj);
}

function firstOf(obj: any, keys: string[]): any {
  for (const k of keys) {
    const v = getNested(obj, k);
    if (v !== undefined && v !== null) return v;
  }
  return undefined;
}

function mapStatus(input?: string): 'pending' | 'processing' | 'success' | 'failed' {
  if (!input) return 'processing';
  const s = String(input).toLowerCase();
  if (['success', 'succeeded', 'completed', 'approved'].includes(s)) return 'success';
  if (['failed', 'declined', 'error', 'cancelled'].includes(s)) return 'failed';
  if (['pending', 'processing', 'initiated'].includes(s)) return 'processing';
  return 'processing';
}

export async function resolvePayoutApiForUser(userId: string, transferMode?: string): Promise<PaymentApi | null> {
  try {
    const mode = transferMode?.toUpperCase();

    // Helper to map Prisma result to PaymentApi
    const mapToPaymentApi = (api: any): PaymentApi => ({
      id: api.id,
      userId: api.userId,
      name: api.apiName,
      baseUrl: api.apiBaseUrl,
      scopes: null,
      apiKey: api.apiKey,
      apiToken: null,
      apiSecret: null,
      authHeader: api.authHeader,
      assignedServices: api.assignedServices || [],
      isDefault: api.isDefault,
      isActive: api.isActive,
      customPaymentApiEndpoint: api.apiEndpoint,
      customPaymentApiMethod: api.apiMethod,
      customPaymentApiAuthType: api.authType,
      customPaymentApiSecret: api.apiSecret,
      transactionCharge: api.transactionCharge ? Number(api.transactionCharge) : 0,
      transactionChargeType: api.transactionChargeType
    });

    // 1. Try to find USER defined API for this specific mode
    if (mode) {
      const userModeApi = await prisma.customPaymentApi.findFirst({
        where: {
          userId,
          adminProvided: false,
          isActive: true,
          // @ts-ignore
          apiType: 'PAYOUT',
          // @ts-ignore
          allowedModes: { has: mode }
        },
        orderBy: { isDefault: 'desc' },
      });
      if (userModeApi) return mapToPaymentApi(userModeApi);
    }

    // 2. Fallback: User Default API (regardless of mode, but must be PAYOUT)
    const userDefaultApi = await prisma.customPaymentApi.findFirst({
      where: {
        userId,
        adminProvided: false,
        isActive: true,
        // @ts-ignore
        apiType: 'PAYOUT',
        isDefault: true,
      },
    });
    if (userDefaultApi) return mapToPaymentApi(userDefaultApi);

    // 3. Try to find ADMIN defined API for this specific mode
    if (mode) {
      const adminModeApi = await prisma.customPaymentApi.findFirst({
        where: {
          adminProvided: true,
          isActive: true,
          // @ts-ignore
          apiType: 'PAYOUT',
          // @ts-ignore
          allowedModes: { has: mode }
        },
        orderBy: { isDefault: 'desc' },
      });
      if (adminModeApi) return mapToPaymentApi(adminModeApi);
    }

    // 4. Fallback: Admin Default API
    const adminDefaultApi = await prisma.customPaymentApi.findFirst({
      where: {
        adminProvided: true,
        isActive: true,
        // @ts-ignore
        apiType: 'PAYOUT',
        isDefault: true,
      },
    });

    if (adminDefaultApi) {
      const apiResult = mapToPaymentApi(adminDefaultApi);
      // FINGROW INTEGRATION BRIDGE check
      const apiName = apiResult.name || adminDefaultApi.apiName;
      if (
        apiResult.customPaymentApiAuthType &&
        ((apiName && apiName.toLowerCase().includes('fingrow')) ||
          (apiResult.baseUrl && apiResult.baseUrl.toLowerCase().includes('fingrow')))
      ) {
        // console.log(`[Payout] Detected Fingrow configuration in Admin Custom API "${apiName}".`);
      }
      return apiResult;
    }

  } catch (error) {
    console.error('Error resolving custom payment API:', error);
  }


  // 2) If user has an explicit defaultApiId from UserApi, use that if active
  const userRecord = await prisma.user.findUnique({ where: { id: userId } });
  if (userRecord?.defaultApiId) {
    const explicitDefault = await prisma.userApi.findFirst({
      where: { id: userRecord.defaultApiId, isActive: true },
      select: {
        id: true,
        userId: true,
        name: true,
        baseUrl: true,
        scopes: true,
        apiKey: true,
        apiToken: true,
        apiSecret: true,
        authHeader: true,
        assignedServices: true,
        isDefault: true,
        isActive: true,
      },
    });
    if (explicitDefault) return explicitDefault;
  }

  // 3) Prefer a UserApi assigned to the user for the payout service.
  // We try to use the Service with code "payout" if it exists, otherwise we skip service filter.
  const payoutService = await prisma.service.findFirst({
    where: {
      code: { in: ['payout', 'PAYOUT'] },
    },
    select: { id: true },
  }).catch(() => null);

  // Prefer user's API explicitly assigned to payout service (if such service exists)
  const userApi = await prisma.userApi.findFirst({
    where: {
      userId,
      isActive: true,
      ...(payoutService?.id
        ? { assignedServices: { has: payoutService.id } }
        : {}),
    },
    select: {
      id: true,
      userId: true,
      name: true,
      baseUrl: true,
      scopes: true,
      apiKey: true,
      apiToken: true,
      apiSecret: true,
      authHeader: true,
      assignedServices: true,
      isDefault: true,
      isActive: true,
    },
    orderBy: { createdAt: 'desc' },
  });
  if (userApi) return userApi;

  // If none assigned specifically, try user's explicitly marked default
  const userDefaultApi = await prisma.userApi.findFirst({
    where: { userId, isActive: true, isDefault: true },
    select: {
      id: true,
      userId: true,
      name: true,
      baseUrl: true,
      scopes: true,
      apiKey: true,
      apiToken: true,
      apiSecret: true,
      authHeader: true,
      assignedServices: true,
      isDefault: true,
      isActive: true,
    },
    orderBy: { createdAt: 'desc' },
  });
  if (userDefaultApi) return userDefaultApi;

  // If still none, fallback to any active API for the user
  const anyUserApi = await prisma.userApi.findFirst({
    where: { userId, isActive: true },
    select: {
      id: true,
      userId: true,
      name: true,
      baseUrl: true,
      scopes: true,
      apiKey: true,
      apiToken: true,
      apiSecret: true,
      authHeader: true,
      assignedServices: true,
      isDefault: true,
      isActive: true,
    },
    orderBy: { createdAt: 'desc' },
  });
  if (anyUserApi) return anyUserApi;

  // 4) Fallback to an ADMIN-owned default API if available (global default)
  const adminDefault = await prisma.userApi.findFirst({
    where: {
      isDefault: true,
      isActive: true,
      user: { role: 'ADMIN' as any },
      ...(payoutService?.id
        ? { assignedServices: { has: payoutService.id } }
        : {}),
    },
    select: {
      id: true,
      userId: true,
      name: true,
      baseUrl: true,
      scopes: true,
      apiKey: true,
      apiToken: true,
      apiSecret: true,
      authHeader: true,
      assignedServices: true,
      isDefault: true,
      isActive: true,
    },
    orderBy: { createdAt: 'desc' },
  });
  if (adminDefault) return adminDefault;

  // 5) As a last resort, pick any default active API
  const defaultApi = await prisma.userApi.findFirst({
    where: { isDefault: true, isActive: true },
    select: {
      id: true,
      userId: true,
      name: true,
      baseUrl: true,
      scopes: true,
      apiKey: true,
      apiToken: true,
      apiSecret: true,
      authHeader: true,
      assignedServices: true,
      isDefault: true,
      isActive: true,
    },
    orderBy: { createdAt: 'desc' },
  });
  return defaultApi;
}

function buildAuthHeadersFromApi(api: any): Record<string, string> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  // Check if this is a custom payment API (has customPaymentApiAuthType)
  const isCustomPaymentApi = !!api.customPaymentApiAuthType;

  if (isCustomPaymentApi) {
    // Handle custom payment API authentication
    const authType = api.customPaymentApiAuthType;
    const apiKey = api.apiKey;
    const apiSecret = api.customPaymentApiSecret;
    const customAuthHeader = api.authHeader;

    if (authType === 'bearer') {
      if (apiSecret) {
        headers['Authorization'] = `Bearer ${apiSecret}`;
      } else if (apiKey) {
        headers['Authorization'] = `Bearer ${apiKey}`;
      }
    } else if (authType === 'basic') {
      if (apiKey && apiSecret) {
        const basic = Buffer.from(`${apiKey}:${apiSecret}`).toString('base64');
        headers['Authorization'] = `Basic ${basic}`;
      }
    } else if (authType === 'custom-header' || authType === 'customheader') {
      if (customAuthHeader && apiSecret) {
        headers[customAuthHeader] = apiSecret;
      } else if (apiKey) {
        headers['X-API-Key'] = apiKey;
      }
    } else if (authType === 'gammingpay') {
      if (apiKey) headers['secretkey'] = apiKey;
      if (apiSecret) headers['saltkey'] = apiSecret;
    } else {
      // Default: try API key
      if (apiSecret) {
        headers['X-API-Key'] = apiSecret;
      } else if (apiKey) {
        headers['X-API-Key'] = apiKey;
      }
    }
    return headers;
  }

  // Handle UserApi (non-custom) authentication
  const conf = safeJsonParse<any>(api.apiSecret);

  // Merge static headers from config first
  if (conf?.headers && typeof conf.headers === 'object') {
    for (const [k, v] of Object.entries(conf.headers)) {
      if (typeof v === 'string') headers[k] = v;
    }
  }

  const authType = conf?.authType;
  const explicitAuthHeader = api.authHeader || conf?.authHeader;
  const tokenCandidate = api.apiToken || api.apiKey || conf?.apiToken || conf?.apiKey;

  if (explicitAuthHeader && tokenCandidate) {
    headers[String(explicitAuthHeader)] = String(tokenCandidate);
    return headers;
  }

  // Common fallbacks
  if (authType === 'bearer') {
    const t = tokenCandidate;
    if (t) headers['Authorization'] = `Bearer ${t}`;
  } else if (authType === 'basic') {
    const key = api.apiKey || conf?.apiKey;
    const secret = conf?.apiSecret;
    if (key && secret) {
      const basic = Buffer.from(`${key}:${secret}`).toString('base64');
      headers['Authorization'] = `Basic ${basic}`;
    }
  } else {
    if (api.apiToken || conf?.apiToken) headers['Authorization'] = `Bearer ${api.apiToken || conf?.apiToken}`;
    else if (api.apiKey || conf?.apiKey) {
      headers['X-API-Key'] = String(api.apiKey || conf?.apiKey);
    }
  }

  return headers;
}

// Add import at the top


// Update signature to accept overrides
export async function callPayoutApi(userId: string, request: PayoutRequest, overrides?: { rudraxUserId?: string }): Promise<{ apiUsed?: any; response: PayoutResponse }> {
  const api = await resolvePayoutApiForUser(userId, request.transferMode);

  if (!api) {
    console.warn(`[Payout] No API configured for user ${userId}. Returning failure.`);
    return {
      response: {
        success: false,
        status: 'failed',
        message: 'No Payment Gateway configured. Please contact support or administrator.',
        raw: { error: 'NO_GATEWAY_CONFIGURED' }
      }
    };
  }

  // Check if this is a custom payment API
  const isCustomPaymentApi = !!api.customPaymentApiAuthType;
  // console.log(`[Payout] Using API: ${api.name} (type: ${isCustomPaymentApi ? 'custom' : 'userApi'}, userId: ${userId})`);

  // Validation - check for required endpoint
  let hasEndpoint = !!api.baseUrl || !!api.customPaymentApiEndpoint;
  if (!hasEndpoint) {
    const scopes = safeJsonParse<any>(api.scopes);
    const secretConf = safeJsonParse<any>(api.apiSecret);
    hasEndpoint = !!scopes?.payoutEndpoint || !!secretConf?.endpoint;
  }

  if (!hasEndpoint) {
    return {
      response: {
        success: false,
        status: 'failed',
        message: `API "${api.name}" is missing base URL. Please configure the endpoint URL.`,
        raw: {
          error: 'MISSING_ENDPOINT',
          apiName: api.name,
          help: 'Add the gateway endpoint URL in API configuration',
        },
      },
    };
  }

  // Validation - check for required credentials
  const hasCredentials = !!api.apiKey || !!api.apiToken || !!api.customPaymentApiSecret;
  if (!hasCredentials) {
    const secretConf = safeJsonParse<any>(api.apiSecret);
    if (!secretConf?.apiToken) {
      return {
        response: {
          success: false,
          status: 'failed',
          message: `API "${api.name}" is missing authentication credentials. Please add API Key or Token.`,
          raw: {
            error: 'MISSING_CREDENTIALS',
            apiName: api.name,
            help: 'Add API Key/Token in API configuration',
          },
        },
      };
    }
  }

  const authHeaders = buildAuthHeadersFromApi(api);

  // Try to read optional configuration stored in api.scopes as JSON
  const scopes = safeJsonParse<any>(api.scopes);
  const secretConf = safeJsonParse<any>(api.apiSecret);

  // STRICT URL CLEANING: Remove ALL whitespace
  let baseUrl: string | null | undefined = isCustomPaymentApi
    ? api.customPaymentApiEndpoint?.replace(/\s+/g, '')
    : (api.baseUrl as string)?.replace(/\s+/g, '');

  // If scopes has a dedicated payoutEndpoint, prefer it
  if (!isCustomPaymentApi && scopes?.payoutEndpoint) baseUrl = String(scopes.payoutEndpoint).replace(/\s+/g, '');
  if (!baseUrl && secretConf?.endpoint) baseUrl = String(secretConf.endpoint).replace(/\s+/g, '');

  // Ensure baseUrl starts with http/https for custom payment APIs that only have endpoint path
  if (isCustomPaymentApi && baseUrl && !baseUrl.startsWith('http')) {
    const rootUrl = api.baseUrl ? api.baseUrl.replace(/\s+/g, '') : '';
    // Handle slashed clean up
    const cleanRoot = rootUrl.endsWith('/') ? rootUrl.slice(0, -1) : rootUrl;
    const cleanPath = baseUrl.startsWith('/') ? baseUrl.slice(1) : baseUrl;
    baseUrl = cleanRoot ? `${cleanRoot}/${cleanPath}` : baseUrl;
  }

  // Final validation - ensure baseUrl is now set
  if (!baseUrl) {
    return {
      response: {
        success: false,
        status: 'failed',
        message: `API "${api.name}" endpoint URL could not be determined. Please configure the endpoint properly.`,
        raw: {
          error: 'INVALID_ENDPOINT',
          apiName: api.name,
        },
      },
    };
  }

  const finalBaseUrl: string = baseUrl;

  // ------------------------------------------------------------------
  // FINGROW DETECTION BRIDGE
  // If the user is using Generic Custom API but pointing to Fingrow,
  // we must switch to Encrypted Payload + Merchant ID header logic.
  // ------------------------------------------------------------------
  if (finalBaseUrl.includes('fingrow') || finalBaseUrl.includes('pay.fingrowaitech.com')) {
    // console.log('[Payout] Detected Fingrow configuration via Custom API. Switching to Encrypted Flow.');

    // Extract Merchant ID: Try apiKey first (standard mapping), then secret, then token
    const merchantId = api.apiKey || api.customPaymentApiSecret || api.apiToken;

    if (!merchantId) {
      return {
        response: {
          success: false,
          status: 'failed',
          message: `Fingrow API detected but Merchant ID (API Key) is missing.`,
          raw: { error: 'MISSING_MERCHANT_ID', help: 'Enter Merchant ID in API Key field' },
        },
      };
    }

    const fingrowResponse = await executeFingrowTransaction(merchantId, finalBaseUrl, {
      amount: request.amount,
      beneficiaryName: request.beneficiaryName || '',
      beneficiaryAccount: request.beneficiaryAccount,
      beneficiaryIfsc: request.beneficiaryIfsc,
      beneficiaryVpa: request.beneficiaryVpa,
      transferMode: request.transferMode,
      merchantTransactionId: request.merchantTransactionId || `txn_${Date.now()}`,
      ipAddress: '0.0.0.0', // Standard fallback logic
      userAgent: 'Node/CustomAPI'
    });

    // Map Fingrow status 'completed' -> 'success'
    let mappedStatus: 'pending' | 'processing' | 'success' | 'failed' = 'processing';
    if (fingrowResponse.status === 'completed' || fingrowResponse.status === 'success' as any) mappedStatus = 'success';
    else if (fingrowResponse.status === 'failed') mappedStatus = 'failed';
    else if (fingrowResponse.status === 'pending') mappedStatus = 'pending';

    return {
      apiUsed: api,
      response: {
        ...fingrowResponse,
        status: mappedStatus
      }
    };
  }
  // ------------------------------------------------------------------

  // ------------------------------------------------------------------
  // PAYATME DETECTION BRIDGE
  // If the user configures "api.payatme.com", we route to the PayAtMe integration
  // which handles the Login -> Token -> Payout flow.
  // ------------------------------------------------------------------
  if (finalBaseUrl.includes('payatme.com')) {
    // console.log('[Payout] Detected PayAtMe configuration via Custom API. Switching to PayAtMe Flow.');
    return callPayAtMePayoutApi(userId, api, request);
  }
  // ------------------------------------------------------------------

  // ------------------------------------------------------------------
  // KGIPAY DETECTION BRIDGE
  // If the user configures "api.kgipay.com", we route to the KGIPay integration
  // ------------------------------------------------------------------
  if (finalBaseUrl.includes('kgipay.com') || (api.name && api.name.toLowerCase().includes('kgipay'))) {
    // console.log('[Payout] Detected KGIPay configuration. Switching to KGIPay Flow.');
    try {
      const { executeKgipayTransaction } = await import('./kgipay-integration');
      return await executeKgipayTransaction(api, request);
    } catch (e: any) {
      console.error('Failed to import/execute KGIPay integration:', e);
      return {
        apiUsed: api,
        response: {
          success: false,
          status: 'failed',
          message: 'Internal System Error: Failed to load KGIPay integration.',
          raw: { error: e.message, stack: e.stack }
        }
      };
    }
  }
  // ------------------------------------------------------------------


  // ------------------------------------------------------------------
  // ZYONTIC DETECTION BRIDGE
  // ------------------------------------------------------------------
  if (finalBaseUrl.includes('zyontic.in') || (api.name && api.name.toLowerCase().includes('zyontic'))) {
    // console.log('[Payout] Detected Zyontic configuration. Switching to Zyontic Flow.');
    try {
      return await executeZyonticTransaction(api, request);
    } catch (e: any) {
      console.error('Failed to execute Zyontic integration:', e);
      return {
        apiUsed: api,
        response: {
          success: false,
          status: 'failed',
          message: 'Internal System Error: Failed to execute Zyontic integration.',
          raw: { error: e.message }
        }
      };
    }
  }
  // ------------------------------------------------------------------


  // ------------------------------------------------------------------
  // RUDRAXPAY DETECTION BRIDGE
  // ------------------------------------------------------------------
  if (finalBaseUrl.includes('rudraxpay.com') || (api.name && api.name.toLowerCase().includes('rudrax'))) {
    // console.log('[Payout] Detected RudraxPay configuration. Switching to RudraxPay Flow.');

    const merchantId = overrides?.rudraxUserId || api.apiKey || secretConf?.userid; // Map userid with override support
    const token = api.apiToken || api.apiSecret || secretConf?.token; // Map token

    if (!merchantId || !token) {
      return {
        response: {
          success: false,
          status: 'failed',
          message: 'RudraxPay API missing userid or token.',
          raw: { error: 'MISSING_CREDENTIALS', help: 'Set API Key as UserID and API Secret as Token' }
        }
      };
    }

    try {
      const result = await initiateRudraxPayPayout(finalBaseUrl, { userid: merchantId, token }, {
        amount: request.amount,
        name: request.beneficiaryName || 'Beneficiary',
        mobile: request.userPhone || '9999999999',
        accountNumber: request.beneficiaryAccount || '',
        ifsc: request.beneficiaryIfsc || '',
        orderid: request.merchantTransactionId || `payout_${Date.now()}`
      });

      // Map status
      let status: 'pending' | 'processing' | 'success' | 'failed' = 'processing';
      if (result.success) status = 'processing'; // Rudrax returns success=true on initiation, assume processing until callback
      // Or if message says "success", maybe completed? Usually payout initiation is async processing.
      // Documentation says "Funds successfully disbursed" in callback. So initiate is just "accepted".

      return {
        apiUsed: api,
        response: {
          success: result.success,
          status,
          message: result.message,
          externalTransactionId: result.transactionId,
          raw: result.raw
        }
      };

    } catch (e: any) {
      console.error('Failed to execute RudraxPay integration:', e);
      return {
        apiUsed: api,
        response: {
          success: false,
          status: 'failed',
          message: 'Internal System Error: RudraxPay integration failed.',
          raw: { error: e.message }
        }
      };
    }
  }
  // ------------------------------------------------------------------


  // Merge user-provided request with an optional request template
  let payload: Record<string, any> = { ...request };
  // Prefer payoutRequestTemplate if provided, else fallback to requestTemplate (from scopes)
  const payoutTemplate = scopes?.payoutRequestTemplate ?? scopes?.requestTemplate;
  if (payoutTemplate) {
    const templateObj = safeJsonParse<any>(payoutTemplate) || {};
    payload = { ...templateObj, ...payload };
  }
  // Also merge bodyTemplate from apiSecret JSON (admin UI stores it here)
  if (secretConf?.bodyTemplate) {
    let tpl = secretConf.bodyTemplate;
    if (typeof tpl === 'string') {
      tpl = safeJsonParse<any>(tpl) || {};
    }
    if (typeof tpl === 'object') {
      payload = { ...tpl, ...payload };
    }
  }
  // Add callback if provided in scopes
  if (scopes?.callbackUrl) {
    payload.callback_url = scopes.callbackUrl;
    payload.callbackUrl = scopes.callbackUrl;
  }

  // Apply optional field mapping for payout payload
  const maps: Array<Record<string, string>> = [];
  if (scopes?.payoutFieldMap && typeof scopes.payoutFieldMap === 'object') maps.push(scopes.payoutFieldMap);
  if (secretConf?.payoutFieldMap && typeof secretConf.payoutFieldMap === 'object') maps.push(secretConf.payoutFieldMap);
  if (secretConf?.fieldMap && typeof secretConf.fieldMap === 'object') maps.push(secretConf.fieldMap);
  if (maps.length) {
    const mapped: Record<string, any> = {};
    for (const key of Object.keys(payload)) {
      let mappedKey = key;
      for (const m of maps) {
        if (m[key]) { mappedKey = m[key]; break; }
      }
      mapped[mappedKey] = (payload as any)[key];
    }
    payload = mapped;
  }

  // GAMMINGPAY SPECIFIC PAYLOAD TRANSFORMATION
  if (isCustomPaymentApi && api.customPaymentApiAuthType === 'gammingpay') {
    payload = {
      externalTransactionId: payload.merchantTransactionId || `gp_${Date.now()}`,
      Amount: String(payload.amount),
      FirstName: payload.beneficiaryName || 'User',
      LastName: ".",
      Email: payload.userEmail || "customer@example.com",
      Mobile: payload.userPhone || "9999999999",
      mode: (payload.transferMode || 'imps').toLowerCase(),
      accountNumber: payload.beneficiaryAccount,
      Ifsc: payload.beneficiaryIfsc,
      Bank: "NA"
    };
  }

  try {
    const method = String((isCustomPaymentApi ? api.customPaymentApiMethod : secretConf?.method) || 'POST').toUpperCase();

    // CONSTRUCT CURL COMMAND
    // Removed -v to prevent maxBuffer issues with large debug output
    let curlCmd = `curl -s -X ${method}`;

    // Add headers
    for (const [key, value] of Object.entries(authHeaders)) {
      curlCmd += ` -H '${key}: ${value}'`;
    }

    // Add body if not GET
    if (!['GET', 'HEAD'].includes(method)) {
      const jsonBody = JSON.stringify(payload);
      // Escape single quotes for shell safety
      const escapedBody = jsonBody.replace(/'/g, "'\\''");
      curlCmd += ` --data '${escapedBody}'`;
    }

    curlCmd += ` '${finalBaseUrl}'`;

    console.log(`[Payout API] Executing CURL: ${curlCmd.replace(/Bearer [a-zA-Z0-9\-_]+/, 'Bearer ***').replace(/--data '.*'/, '--data [HIDDEN]')}`);

    const { exec } = await import('child_process');
    const { promisify } = await import('util');
    const execAsync = promisify(exec);

    let output = '';

    try {
      // Increase buffer to 10MB to avoid "Killed" errors on large responses
      const { stdout, stderr } = await execAsync(curlCmd, { maxBuffer: 10 * 1024 * 1024 });
      output = stdout;
      if (stderr) {
        // Optional: console.log('[Payout API DEBUG] stderr:', stderr);
      }
    } catch (e: any) {
      console.error('[Payout API] Curl execution error:', e);
      // If curl returns non-zero exit code, it might still have output
      output = e.stdout || '';
      if (!output) {
        throw e;
      }
    }

    // console.log(`[Payout API] Response raw verified:`, output.substring(0, 200));

    let data: any;
    try {
      data = JSON.parse(output);
    } catch {
      data = { raw: output };
    }

    // Heuristics for success
    const success = (data?.success === true || data?.success === 'true') ||
      (String(data?.status || '').toLowerCase() === 'success') ||
      (String(data?.status || '').toLowerCase() === 'completed') ||
      (data?.responseCode === '200');

    const utrNumber = firstOf(data, ['utr', 'utrNumber', 'UTRNumber', 'reference_number', 'refNo', 'reference', 'rrn', 'trxId']) ||
      (data?.data?.utr || data?.data?.utrNumber || data?.data?.refNo);
    const externalId = firstOf(data, ['transaction_id', 'transactionId', 'id', 'txnId', 'trxId']) ||
      (data?.data?.id || data?.data?.transaction_id);

    // Map 405/404 explicitly if found in raw HTML response
    let finalStatus: 'pending' | 'processing' | 'success' | 'failed' = success ? mapStatus(String(data?.status || 'processing')) : 'failed';
    let finalMessage = firstOf(data, ['message', 'description', 'reason', 'msg']);

    if (typeof data?.raw === 'string' && data.raw.includes('405 Not Allowed')) {
      finalMessage = 'Method Not Allowed (405). Check API URL and method.';
    }

    const response: PayoutResponse = {
      success,
      status: finalStatus,
      message: finalMessage,
      utrNumber: utrNumber ? String(utrNumber) : undefined,
      externalTransactionId: externalId ? String(externalId) : undefined,
      raw: data,
    };

    return { apiUsed: api, response };
  } catch (error: any) {
    console.error('Payout API call error:', error);


    let errorMessage = 'Payout request failed. Please try again.';
    let errorCode = 'UNKNOWN_ERROR';

    if (error.code === 127) { // Command not found
      errorMessage = 'Server configuration error: curl not found.';
    }

    return {
      apiUsed: api,
      response: {
        success: false,
        status: 'failed',
        message: errorMessage,
        raw: {
          error: errorCode,
          details: error?.message,
          troubleshoot: [
            'Curl command failed',
            'Check server logs',
            'Verify endpoint compatibility'
          ],
        },
      },
    };
  }
}

/**
 * Mock API Call for testing/demo purposes when no real API is configured
 */
async function callMockPayoutApi(userId: string, request: PayoutRequest): Promise<{ apiUsed?: any; response: PayoutResponse }> {
  // console.log(`[Mock Payout] Simulating payout for user ${userId}`, request);

  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1500));

  const isSuccess = request.amount < 100000; // Fail for amounts >= 100000 for testing failure scenarios

  const mockResponse = {
    success: isSuccess,
    status: isSuccess ? 'success' : 'failed',
    message: isSuccess ? 'Transaction processed successfully (Mock)' : 'Transaction limit exceeded (Mock)',
    utrNumber: isSuccess ? `MOCK${Date.now()}UTR` : undefined,
    externalTransactionId: `TXN${Date.now()}`,
    raw: {
      mode: 'mock_simulator',
      timestamp: new Date().toISOString(),
      note: 'This is a simulated response because no actual payment API is configured.',
      request_amount: request.amount
    }
  };

  return {
    apiUsed: {
      id: 'mock-api-id',
      name: 'System Mock Gateway',
      isDefault: true,
      isActive: true,
      userId: null
    },
    response: mockResponse as any as PayoutResponse
  };
}

import crypto from 'crypto';

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'your-32-char-encryption-key-here';
const ALGORITHM = 'aes-256-cbc';

export function encryptSensitive(data: string): string {
  const iv = crypto.randomBytes(16);
  const key = crypto.scryptSync(ENCRYPTION_KEY, 'salt', 32);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  
  let encrypted = cipher.update(data, 'utf-8', 'hex');
  encrypted += cipher.final('hex');
  
  return iv.toString('hex') + ':' + encrypted;
}

export function decryptSensitive(encrypted: string): string {
  const [ivHex, encryptedData] = encrypted.split(':');
  const iv = Buffer.from(ivHex, 'hex');
  const key = crypto.scryptSync(ENCRYPTION_KEY, 'salt', 32);
  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  
  let decrypted = decipher.update(encryptedData, 'hex', 'utf-8');
  decrypted += decipher.final('utf-8');
  
  return decrypted;
}

export function generateApiKey(): string {
  return crypto.randomBytes(32).toString('hex');
}

export function generateApiSecret(): string {
  return crypto.randomBytes(32).toString('hex');
}

export function maskAccountNumber(accountNumber: string): string {
  if (accountNumber.length <= 4) return accountNumber;
  const masked = '*'.repeat(accountNumber.length - 4) + accountNumber.slice(-4);
  return masked;
}

export function maskUPI(upi: string): string {
  const [name] = upi.split('@');
  if (name.length <= 2) return upi;
  const masked = name[0] + '*'.repeat(name.length - 2) + name.slice(-1) + '@' + upi.split('@')[1];
  return masked;
}

export function validateAccountNumber(accountNumber: string): boolean {
  return /^\d{9,18}$/.test(accountNumber);
}

export function validateIfscCode(ifsc: string): boolean {
  return /^[A-Z]{4}0[A-Z0-9]{6}$/.test(ifsc);
}

export function validateUPI(upi: string): boolean {
  return /^[a-zA-Z0-9._-]+@[a-zA-Z]{3,}$/.test(upi);
}

export function generateTransactionReference(): string {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 8);
  return `TXN${timestamp}${random}`.toUpperCase();
}

export function hashAccountDetails(
  accountNumber: string,
  ifscCode: string
): string {
  const combined = `${accountNumber}:${ifscCode}`;
  return crypto.createHash('sha256').update(combined).digest('hex');
}

export function validatePermissions(
  userPermissions: Record<string, boolean>,
  requiredPermission: string
): boolean {
  return userPermissions[requiredPermission] === true;
}

export interface FinTechSecurityHeaders {
  'X-Content-Type-Options': string;
  'X-Frame-Options': string;
  'X-XSS-Protection': string;
  'Strict-Transport-Security': string;
  'Content-Security-Policy': string;
}

export function getSecurityHeaders(): FinTechSecurityHeaders {
  return {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
    'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'",
  };
}

export function rateLimitKey(identifier: string, period: string): string {
  return `ratelimit:${identifier}:${period}`;
}

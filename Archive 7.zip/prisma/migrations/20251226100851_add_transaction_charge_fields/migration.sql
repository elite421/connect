/*
  Warnings:

  - A unique constraint covering the columns `[apiNumber]` on the table `CustomPaymentApi` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "CustomPaymentApi" ADD COLUMN     "apiNumber" TEXT,
ADD COLUMN     "callbackToken" TEXT,
ADD COLUMN     "statusCheckUrl" TEXT,
ADD COLUMN     "transactionCharge" DECIMAL(10,4) DEFAULT 0,
ADD COLUMN     "transactionChargeType" TEXT DEFAULT 'fixed';

-- AlterTable
ALTER TABLE "SubUser" ADD COLUMN     "isApiEnabled" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "active" BOOLEAN NOT NULL DEFAULT true;

-- CreateTable
CREATE TABLE "Dispute" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "transactionId" TEXT,
    "type" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'OPEN',
    "description" TEXT NOT NULL,
    "adminComment" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Dispute_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Dispute_userId_idx" ON "Dispute"("userId");

-- CreateIndex
CREATE INDEX "Dispute_status_idx" ON "Dispute"("status");

-- CreateIndex
CREATE UNIQUE INDEX "CustomPaymentApi_apiNumber_key" ON "CustomPaymentApi"("apiNumber");

-- AddForeignKey
ALTER TABLE "Dispute" ADD CONSTRAINT "Dispute_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CustomPaymentApi" ADD CONSTRAINT "CustomPaymentApi_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

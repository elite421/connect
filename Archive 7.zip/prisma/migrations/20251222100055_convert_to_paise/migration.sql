-- AlterTable
ALTER TABLE "CustomPaymentApi" ADD COLUMN     "allowedModes" TEXT[] DEFAULT ARRAY['IMPS', 'NEFT', 'UPI', 'RTGS']::TEXT[],
ADD COLUMN     "apiType" TEXT NOT NULL DEFAULT 'PAYOUT';

-- AlterTable
ALTER TABLE "PaymentLink" ALTER COLUMN "amount" SET DEFAULT 0;

-- AlterTable
ALTER TABLE "PaymentScheme" ADD COLUMN     "apiId" TEXT,
ADD COLUMN     "applyGst" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "gstPercentage" DECIMAL(5,2) DEFAULT 18,
ADD COLUMN     "maxTransactionAmount" BIGINT DEFAULT 10000000,
ADD COLUMN     "minTransactionAmount" BIGINT DEFAULT 100,
ADD COLUMN     "schemeType" TEXT NOT NULL DEFAULT 'BOTH',
ADD COLUMN     "serviceId" TEXT;

-- CreateIndex
CREATE INDEX "CustomPaymentApi_apiType_idx" ON "CustomPaymentApi"("apiType");

-- CreateIndex
CREATE INDEX "PayInTransaction_utrNumber_idx" ON "PayInTransaction"("utrNumber");

-- CreateIndex
CREATE INDEX "PaymentScheme_apiId_idx" ON "PaymentScheme"("apiId");

-- CreateIndex
CREATE INDEX "PaymentScheme_serviceId_idx" ON "PaymentScheme"("serviceId");

-- AlterTable
ALTER TABLE "PayOutTransaction" ADD COLUMN "subUserId" TEXT;

-- CreateIndex
CREATE INDEX "PayOutTransaction_subUserId_idx" ON "PayOutTransaction"("subUserId");

-- AddForeignKey
ALTER TABLE "PayOutTransaction" ADD CONSTRAINT "PayOutTransaction_subUserId_fkey" FOREIGN KEY ("subUserId") REFERENCES "SubUser"("id") ON DELETE CASCADE ON UPDATE CASCADE;

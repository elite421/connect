/*
  Warnings:

  - A unique constraint covering the columns `[keyValue]` on the table `ApiKey` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[subUserId]` on the table `KycSubmission` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `keyValue` to the `ApiKey` table without a default value. This is not possible if the table is not empty.
  - Added the required column `name` to the `ApiKey` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updatedAt` to the `ApiKey` table without a default value. This is not possible if the table is not empty.
  - Added the required column `apiKeyId` to the `ApiRequestLog` table without a default value. This is not possible if the table is not empty.
  - Added the required column `endpoint` to the `ApiRequestLog` table without a default value. This is not possible if the table is not empty.
  - Added the required column `method` to the `ApiRequestLog` table without a default value. This is not possible if the table is not empty.
  - Added the required column `updatedAt` to the `KycSubmission` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "ApiKey" DROP CONSTRAINT "ApiKey_userId_fkey";

-- DropForeignKey
ALTER TABLE "ApiRequestLog" DROP CONSTRAINT "ApiRequestLog_userId_fkey";

-- DropForeignKey
ALTER TABLE "KycSubmission" DROP CONSTRAINT "KycSubmission_userId_fkey";

-- DropForeignKey
ALTER TABLE "Wallet" DROP CONSTRAINT "Wallet_userId_fkey";

-- DropIndex
DROP INDEX "PayOutTransaction_externalTransactionId_idx";

-- DropIndex
DROP INDEX "PayOutTransaction_utrNumber_idx";

-- AlterTable
ALTER TABLE "AdminApi" ALTER COLUMN "updatedAt" DROP DEFAULT;

-- AlterTable
ALTER TABLE "ApiKey" ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "expiresAt" TIMESTAMP(3),
ADD COLUMN     "isActive" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "keyValue" TEXT NOT NULL,
ADD COLUMN     "lastUsedAt" TIMESTAMP(3),
ADD COLUMN     "lastUsedIp" TEXT,
ADD COLUMN     "name" TEXT NOT NULL,
ADD COLUMN     "permissions" TEXT[] DEFAULT ARRAY['read', 'write']::TEXT[],
ADD COLUMN     "requestCount" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL;

-- AlterTable
ALTER TABLE "ApiRequestLog" ADD COLUMN     "apiKeyId" TEXT NOT NULL,
ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "endpoint" TEXT NOT NULL,
ADD COLUMN     "error" TEXT,
ADD COLUMN     "ipAddress" TEXT,
ADD COLUMN     "method" TEXT NOT NULL,
ADD COLUMN     "requestBody" JSONB,
ADD COLUMN     "responseBody" JSONB,
ADD COLUMN     "responseTime" INTEGER,
ADD COLUMN     "statusCode" INTEGER,
ADD COLUMN     "userAgent" TEXT;

-- AlterTable
ALTER TABLE "KycSubmission" ADD COLUMN     "aadharNumber" TEXT,
ADD COLUMN     "aadharPhotoUrl" TEXT,
ADD COLUMN     "aadharVerified" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "addressLine1" TEXT,
ADD COLUMN     "addressLine2" TEXT,
ADD COLUMN     "city" TEXT,
ADD COLUMN     "country" TEXT,
ADD COLUMN     "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "dateOfBirth" TIMESTAMP(3),
ADD COLUMN     "email" TEXT,
ADD COLUMN     "expiryDate" TIMESTAMP(3),
ADD COLUMN     "firstName" TEXT,
ADD COLUMN     "idNumber" TEXT,
ADD COLUMN     "idPhotoUrl" TEXT,
ADD COLUMN     "idPhotoVerified" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "idType" TEXT,
ADD COLUMN     "kycStatus" TEXT NOT NULL DEFAULT 'pending',
ADD COLUMN     "lastName" TEXT,
ADD COLUMN     "panNumber" TEXT,
ADD COLUMN     "panPhotoUrl" TEXT,
ADD COLUMN     "panPhotoVerified" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "phone" TEXT,
ADD COLUMN     "postalCode" TEXT,
ADD COLUMN     "rejectionReason" TEXT,
ADD COLUMN     "state" TEXT,
ADD COLUMN     "subUserId" TEXT,
ADD COLUMN     "submittedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "verifiedAt" TIMESTAMP(3);

-- AlterTable
ALTER TABLE "PayInTransaction" ADD COLUMN     "externalTransactionId" TEXT,
ADD COLUMN     "gatewayId" TEXT,
ADD COLUMN     "responseData" JSONB,
ADD COLUMN     "utrNumber" TEXT;

-- AlterTable
ALTER TABLE "PayOutTransaction" ADD COLUMN     "responseData" JSONB;

-- AlterTable
ALTER TABLE "SubUserService" ADD COLUMN     "transactionCharge" DECIMAL(10,2) DEFAULT 0,
ADD COLUMN     "transactionChargeType" TEXT DEFAULT 'fixed';

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "defaultApiId" TEXT,
ADD COLUMN     "transactionCharge" DECIMAL(10,4) DEFAULT 0;

-- AlterTable
ALTER TABLE "UserApi" ADD COLUMN     "apiKey" TEXT,
ADD COLUMN     "apiSecret" TEXT,
ADD COLUMN     "apiToken" TEXT,
ADD COLUMN     "assignedServices" TEXT[] DEFAULT ARRAY[]::TEXT[],
ADD COLUMN     "authHeader" TEXT,
ADD COLUMN     "baseUrl" TEXT,
ADD COLUMN     "isShared" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "Wallet" ADD COLUMN     "frozenBalance" BIGINT NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "wallets" ALTER COLUMN "owner_id" SET DATA TYPE TEXT;

-- CreateTable
CREATE TABLE "SubUserIpWhitelist" (
    "id" TEXT NOT NULL,
    "subUserId" TEXT NOT NULL,
    "ipAddress" TEXT NOT NULL,
    "label" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SubUserIpWhitelist_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ApiKeyAccess" (
    "id" TEXT NOT NULL,
    "apiKeyId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "action" TEXT NOT NULL,
    "reason" TEXT,
    "revokedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ApiKeyAccess_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WalletTransactionLocal" (
    "id" TEXT NOT NULL,
    "walletId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "amount" BIGINT NOT NULL,
    "balanceAfter" BIGINT NOT NULL,
    "chargeAmount" BIGINT NOT NULL DEFAULT 0,
    "referenceType" TEXT,
    "referenceId" TEXT,
    "description" TEXT,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "WalletTransactionLocal_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PaymentScheme" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "code" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "payoutCharge" DECIMAL(10,4) DEFAULT 0,
    "payinCharge" DECIMAL(10,4) DEFAULT 0,
    "settlementCharge" DECIMAL(10,4) DEFAULT 0,
    "chargeType" TEXT NOT NULL DEFAULT 'fixed',
    "minCharge" DECIMAL(10,4) DEFAULT 0,
    "maxCharge" DECIMAL(10,4) DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PaymentScheme_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PaymentGateway" (
    "id" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "provider" TEXT NOT NULL,
    "apiEndpoint" TEXT NOT NULL,
    "apiKey" TEXT,
    "apiSecret" TEXT,
    "authType" TEXT NOT NULL DEFAULT 'bearer',
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "configuration" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PaymentGateway_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ServiceApi" (
    "id" TEXT NOT NULL,
    "serviceId" TEXT NOT NULL,
    "apiId" TEXT NOT NULL,
    "isDefault" BOOLEAN NOT NULL DEFAULT false,
    "priority" INTEGER NOT NULL DEFAULT 1,
    "config" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ServiceApi_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SystemConfiguration" (
    "id" TEXT NOT NULL,
    "globalTransactionCharge" DECIMAL(10,4) DEFAULT 0,
    "globalTransactionChargeType" TEXT DEFAULT 'fixed',
    "globalGstPercentage" DECIMAL(5,2) DEFAULT 18,
    "enableGst" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SystemConfiguration_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ApiDocumentation" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "documentType" TEXT NOT NULL,
    "documentContent" TEXT,
    "fileUrl" TEXT,
    "fileName" TEXT,
    "parsedSchema" JSONB,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "approvedBy" TEXT,
    "rejectionReason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "approvedAt" TIMESTAMP(3),

    CONSTRAINT "ApiDocumentation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GatewayIntegration" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "gatewayName" TEXT NOT NULL,
    "gatewayCode" TEXT NOT NULL,
    "documentationId" TEXT,
    "baseUrl" TEXT NOT NULL,
    "credentialsEncrypted" TEXT NOT NULL,
    "webhookSecret" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "isPrimary" BOOLEAN NOT NULL DEFAULT false,
    "config" JSONB,
    "apiSchema" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "GatewayIntegration_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GatewayEndpointConfig" (
    "id" TEXT NOT NULL,
    "integrationId" TEXT NOT NULL,
    "endpoint" TEXT NOT NULL,
    "method" TEXT NOT NULL,
    "description" TEXT,
    "requestSchema" JSONB,
    "responseSchema" JSONB,
    "mappings" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "GatewayEndpointConfig_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "WebhookApproval" (
    "id" TEXT NOT NULL,
    "integrationId" TEXT NOT NULL,
    "webhookUrl" TEXT NOT NULL,
    "webhookSecret" TEXT,
    "events" TEXT[],
    "payload" JSONB,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "approvedBy" TEXT,
    "rejectionReason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "approvedAt" TIMESTAMP(3),

    CONSTRAINT "WebhookApproval_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "gateway_transaction_logs" (
    "id" TEXT NOT NULL,
    "integrationId" TEXT NOT NULL,
    "transactionId" TEXT NOT NULL,
    "externalTxId" TEXT,
    "requestPayload" JSONB NOT NULL,
    "responsePayload" JSONB,
    "utrNumber" TEXT,
    "status" TEXT NOT NULL,
    "errorMessage" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "gateway_transaction_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AdminFeeScheme" (
    "id" TEXT NOT NULL,
    "serviceId" TEXT,
    "feeType" TEXT NOT NULL DEFAULT 'percentage',
    "feeValue" DECIMAL(10,4) NOT NULL,
    "minimumFee" DECIMAL(10,2),
    "maximumFee" DECIMAL(10,2),
    "applicableRole" TEXT NOT NULL DEFAULT 'ALL',
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "description" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AdminFeeScheme_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TransactionFeeLog" (
    "id" TEXT NOT NULL,
    "userId" TEXT,
    "subUserId" TEXT,
    "transactionId" TEXT NOT NULL,
    "transactionType" TEXT NOT NULL,
    "serviceId" TEXT,
    "feeAmount" BIGINT NOT NULL,
    "feeType" TEXT NOT NULL,
    "originalAmount" BIGINT NOT NULL,
    "netAmount" BIGINT NOT NULL,
    "adminWalletId" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "TransactionFeeLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AdminWallet" (
    "id" TEXT NOT NULL,
    "walletAddress" TEXT NOT NULL,
    "balance" BIGINT NOT NULL DEFAULT 0,
    "currency" TEXT NOT NULL DEFAULT 'INR',
    "description" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AdminWallet_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CustomPaymentApi" (
    "id" TEXT NOT NULL,
    "userId" TEXT,
    "adminProvided" BOOLEAN NOT NULL DEFAULT false,
    "apiName" TEXT NOT NULL,
    "apiBaseUrl" TEXT NOT NULL,
    "apiEndpoint" TEXT NOT NULL,
    "apiMethod" TEXT NOT NULL DEFAULT 'POST',
    "authType" TEXT NOT NULL DEFAULT 'bearer',
    "apiKey" TEXT,
    "apiSecret" TEXT,
    "authHeader" TEXT,
    "requestFormat" JSONB,
    "responseFormat" JSONB,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "isDefault" BOOLEAN NOT NULL DEFAULT false,
    "assignedServices" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "CustomPaymentApi_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "SubUserIpWhitelist_subUserId_idx" ON "SubUserIpWhitelist"("subUserId");

-- CreateIndex
CREATE UNIQUE INDEX "SubUserIpWhitelist_subUserId_ipAddress_key" ON "SubUserIpWhitelist"("subUserId", "ipAddress");

-- CreateIndex
CREATE INDEX "ApiKeyAccess_apiKeyId_idx" ON "ApiKeyAccess"("apiKeyId");

-- CreateIndex
CREATE INDEX "ApiKeyAccess_userId_idx" ON "ApiKeyAccess"("userId");

-- CreateIndex
CREATE INDEX "WalletTransactionLocal_walletId_idx" ON "WalletTransactionLocal"("walletId");

-- CreateIndex
CREATE INDEX "WalletTransactionLocal_userId_idx" ON "WalletTransactionLocal"("userId");

-- CreateIndex
CREATE INDEX "WalletTransactionLocal_createdAt_idx" ON "WalletTransactionLocal"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "PaymentScheme_code_key" ON "PaymentScheme"("code");

-- CreateIndex
CREATE INDEX "PaymentScheme_isActive_idx" ON "PaymentScheme"("isActive");

-- CreateIndex
CREATE UNIQUE INDEX "PaymentGateway_code_key" ON "PaymentGateway"("code");

-- CreateIndex
CREATE INDEX "PaymentGateway_isActive_idx" ON "PaymentGateway"("isActive");

-- CreateIndex
CREATE INDEX "ServiceApi_serviceId_idx" ON "ServiceApi"("serviceId");

-- CreateIndex
CREATE INDEX "ServiceApi_apiId_idx" ON "ServiceApi"("apiId");

-- CreateIndex
CREATE UNIQUE INDEX "ServiceApi_serviceId_apiId_key" ON "ServiceApi"("serviceId", "apiId");

-- CreateIndex
CREATE UNIQUE INDEX "SystemConfiguration_id_key" ON "SystemConfiguration"("id");

-- CreateIndex
CREATE INDEX "ApiDocumentation_status_idx" ON "ApiDocumentation"("status");

-- CreateIndex
CREATE INDEX "GatewayIntegration_userId_idx" ON "GatewayIntegration"("userId");

-- CreateIndex
CREATE INDEX "GatewayIntegration_isActive_idx" ON "GatewayIntegration"("isActive");

-- CreateIndex
CREATE UNIQUE INDEX "GatewayIntegration_userId_gatewayCode_key" ON "GatewayIntegration"("userId", "gatewayCode");

-- CreateIndex
CREATE INDEX "GatewayEndpointConfig_integrationId_idx" ON "GatewayEndpointConfig"("integrationId");

-- CreateIndex
CREATE UNIQUE INDEX "GatewayEndpointConfig_integrationId_endpoint_key" ON "GatewayEndpointConfig"("integrationId", "endpoint");

-- CreateIndex
CREATE INDEX "WebhookApproval_integrationId_status_idx" ON "WebhookApproval"("integrationId", "status");

-- CreateIndex
CREATE INDEX "gateway_transaction_logs_integrationId_transactionId_idx" ON "gateway_transaction_logs"("integrationId", "transactionId");

-- CreateIndex
CREATE INDEX "gateway_transaction_logs_externalTxId_idx" ON "gateway_transaction_logs"("externalTxId");

-- CreateIndex
CREATE INDEX "AdminFeeScheme_serviceId_idx" ON "AdminFeeScheme"("serviceId");

-- CreateIndex
CREATE INDEX "AdminFeeScheme_isActive_idx" ON "AdminFeeScheme"("isActive");

-- CreateIndex
CREATE INDEX "TransactionFeeLog_userId_idx" ON "TransactionFeeLog"("userId");

-- CreateIndex
CREATE INDEX "TransactionFeeLog_subUserId_idx" ON "TransactionFeeLog"("subUserId");

-- CreateIndex
CREATE INDEX "TransactionFeeLog_transactionId_idx" ON "TransactionFeeLog"("transactionId");

-- CreateIndex
CREATE INDEX "TransactionFeeLog_status_idx" ON "TransactionFeeLog"("status");

-- CreateIndex
CREATE UNIQUE INDEX "AdminWallet_walletAddress_key" ON "AdminWallet"("walletAddress");

-- CreateIndex
CREATE INDEX "CustomPaymentApi_userId_idx" ON "CustomPaymentApi"("userId");

-- CreateIndex
CREATE INDEX "CustomPaymentApi_adminProvided_idx" ON "CustomPaymentApi"("adminProvided");

-- CreateIndex
CREATE INDEX "CustomPaymentApi_isActive_idx" ON "CustomPaymentApi"("isActive");

-- CreateIndex
CREATE UNIQUE INDEX "ApiKey_keyValue_key" ON "ApiKey"("keyValue");

-- CreateIndex
CREATE INDEX "ApiKey_userId_idx" ON "ApiKey"("userId");

-- CreateIndex
CREATE INDEX "ApiKey_keyValue_idx" ON "ApiKey"("keyValue");

-- CreateIndex
CREATE INDEX "ApiRequestLog_userId_idx" ON "ApiRequestLog"("userId");

-- CreateIndex
CREATE INDEX "ApiRequestLog_apiKeyId_idx" ON "ApiRequestLog"("apiKeyId");

-- CreateIndex
CREATE INDEX "ApiRequestLog_createdAt_idx" ON "ApiRequestLog"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "KycSubmission_subUserId_key" ON "KycSubmission"("subUserId");

-- CreateIndex
CREATE INDEX "KycSubmission_userId_idx" ON "KycSubmission"("userId");

-- CreateIndex
CREATE INDEX "KycSubmission_subUserId_idx" ON "KycSubmission"("subUserId");

-- CreateIndex
CREATE INDEX "KycSubmission_kycStatus_idx" ON "KycSubmission"("kycStatus");

-- CreateIndex
CREATE INDEX "PayInTransaction_gatewayId_idx" ON "PayInTransaction"("gatewayId");

-- CreateIndex
CREATE INDEX "UserApi_isShared_idx" ON "UserApi"("isShared");

-- AddForeignKey
ALTER TABLE "PayInTransaction" ADD CONSTRAINT "PayInTransaction_gatewayId_fkey" FOREIGN KEY ("gatewayId") REFERENCES "GatewayIntegration"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SubUserIpWhitelist" ADD CONSTRAINT "SubUserIpWhitelist_subUserId_fkey" FOREIGN KEY ("subUserId") REFERENCES "SubUser"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApiKey" ADD CONSTRAINT "ApiKey_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "KycSubmission" ADD CONSTRAINT "KycSubmission_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "KycSubmission" ADD CONSTRAINT "KycSubmission_subUserId_fkey" FOREIGN KEY ("subUserId") REFERENCES "SubUser"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApiRequestLog" ADD CONSTRAINT "ApiRequestLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApiRequestLog" ADD CONSTRAINT "ApiRequestLog_apiKeyId_fkey" FOREIGN KEY ("apiKeyId") REFERENCES "ApiKey"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApiKeyAccess" ADD CONSTRAINT "ApiKeyAccess_apiKeyId_fkey" FOREIGN KEY ("apiKeyId") REFERENCES "ApiKey"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ApiKeyAccess" ADD CONSTRAINT "ApiKeyAccess_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Wallet" ADD CONSTRAINT "Wallet_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WalletTransactionLocal" ADD CONSTRAINT "WalletTransactionLocal_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES "Wallet"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ServiceApi" ADD CONSTRAINT "ServiceApi_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ServiceApi" ADD CONSTRAINT "ServiceApi_apiId_fkey" FOREIGN KEY ("apiId") REFERENCES "PaymentGateway"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GatewayIntegration" ADD CONSTRAINT "GatewayIntegration_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GatewayIntegration" ADD CONSTRAINT "GatewayIntegration_documentationId_fkey" FOREIGN KEY ("documentationId") REFERENCES "ApiDocumentation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GatewayEndpointConfig" ADD CONSTRAINT "GatewayEndpointConfig_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES "GatewayIntegration"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "WebhookApproval" ADD CONSTRAINT "WebhookApproval_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES "GatewayIntegration"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "gateway_transaction_logs" ADD CONSTRAINT "gateway_transaction_logs_integrationId_fkey" FOREIGN KEY ("integrationId") REFERENCES "GatewayIntegration"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AdminFeeScheme" ADD CONSTRAINT "AdminFeeScheme_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE SET NULL ON UPDATE CASCADE;

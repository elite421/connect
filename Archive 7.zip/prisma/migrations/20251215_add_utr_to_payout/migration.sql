-- Add UTR and external transaction ID to PayOutTransaction
ALTER TABLE "PayOutTransaction" ADD COLUMN "utrNumber" TEXT;
ALTER TABLE "PayOutTransaction" ADD COLUMN "externalTransactionId" TEXT;

-- Create indexes for better query performance
CREATE INDEX "PayOutTransaction_utrNumber_idx" ON "PayOutTransaction"("utrNumber");
CREATE INDEX "PayOutTransaction_externalTransactionId_idx" ON "PayOutTransaction"("externalTransactionId");

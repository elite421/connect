-- Seed Services for the platform
-- This script ensures all payment services are available in the database

INSERT INTO "Service" (id, code, name, description, "isActive", "createdAt") VALUES 
('svc_wallet_001', 'WALLET', 'Virtual Account / Wallet', 'Create and manage virtual accounts for fund management', true, NOW()),
('svc_neft_001', 'NEFT', 'NEFT Transfer', 'National Electronic Funds Transfer for bank-to-bank payments', true, NOW()),
('svc_imps_001', 'IMPS', 'IMPS Transfer', 'Immediate Payment Service for instant money transfers', true, NOW()),
('svc_upi_001', 'UPI', 'UPI Payment', 'Unified Payments Interface for instant digital payments', true, NOW()),
('svc_card_001', 'CREDIT_CARD', 'Credit Card Bill Payment', 'Pay credit card bills instantly and securely', true, NOW()),
('svc_bill_001', 'BILL_PAY', 'Bill Payments', 'Pay utility bills, phone recharge, DTH, and more', true, NOW()),
('svc_report_001', 'REPORTS', 'Reports & Analytics', 'View detailed transaction reports and analytics dashboards', true, NOW())
ON CONFLICT (code) DO UPDATE SET
  name = EXCLUDED.name,
  description = EXCLUDED.description,
  "isActive" = EXCLUDED."isActive";

import { test, expect } from '@playwright/test';

test.describe('Analytics API Endpoint', () => {
  let authToken: string;

  test.beforeEach(async ({ page }) => {
    await page.goto('/login');
    
    await page.fill('input[type="email"]', 'admin@fintech.com');
    await page.fill('input[type="password"]', 'Admin@123');
    await page.click('button[type="submit"]');
    
    await page.waitForURL('**/account/dashboard', { timeout: 10000 });
  });

  test('should fetch analytics data without BigInt serialization errors', async ({ request, page }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const response = await request.get('/api/user/analytics', {
      headers: {
        'Cookie': cookieHeader,
        'Content-Type': 'application/json',
      },
    });

    expect(response.status()).toBe(200);
    
    const body = await response.json();
    expect(body).toHaveProperty('success', true);
    expect(body).toHaveProperty('data');

    const data = body.data;
    expect(data).toHaveProperty('subUsers');
    expect(data).toHaveProperty('payments');
    expect(data).toHaveProperty('revenue');
    expect(data).toHaveProperty('services');
    expect(data).toHaveProperty('subUserActivity');
  });

  test('should have properly serialized numeric values in analytics data', async ({ request, page }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const response = await request.get('/api/user/analytics', {
      headers: {
        'Cookie': cookieHeader,
        'Content-Type': 'application/json',
      },
    });

    expect(response.status()).toBe(200);
    
    const body = await response.json();
    const data = body.data;

    expect(typeof data.subUsers.total).toBe('number');
    expect(typeof data.subUsers.active).toBe('number');
    expect(typeof data.subUsers.inactive).toBe('number');

    expect(typeof data.payments.total).toBe('number');
    expect(typeof data.payments.completed).toBe('number');
    expect(typeof data.payments.failed).toBe('number');
    expect(typeof data.payments.pending).toBe('number');
    expect(typeof data.payments.successRate).toBe('string');

    expect(typeof data.revenue.total).toBe('number');
    expect(typeof data.revenue.averageTransaction).toBe('number');

    expect(typeof data.services.total).toBe('number');
    expect(typeof data.services.active).toBe('number');
    expect(typeof data.services.inactive).toBe('number');

    expect(Array.isArray(data.subUserActivity)).toBe(true);
  });

  test('should return valid JSON response without BigInt errors', async ({ request, page }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const response = await request.get('/api/user/analytics', {
      headers: {
        'Cookie': cookieHeader,
        'Content-Type': 'application/json',
      },
    });

    expect(response.status()).toBe(200);
    
    const contentType = response.headers()['content-type'];
    expect(contentType).toContain('application/json');
    
    const body = await response.json();
    const jsonString = JSON.stringify(body);
    expect(jsonString).toBeTruthy();
    expect(() => JSON.parse(jsonString)).not.toThrow();
  });

  test('should have non-negative numeric values', async ({ request, page }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const response = await request.get('/api/user/analytics', {
      headers: {
        'Cookie': cookieHeader,
        'Content-Type': 'application/json',
      },
    });

    expect(response.status()).toBe(200);
    
    const body = await response.json();
    const data = body.data;

    expect(data.subUsers.total).toBeGreaterThanOrEqual(0);
    expect(data.subUsers.active).toBeGreaterThanOrEqual(0);
    expect(data.subUsers.inactive).toBeGreaterThanOrEqual(0);

    expect(data.payments.total).toBeGreaterThanOrEqual(0);
    expect(data.payments.completed).toBeGreaterThanOrEqual(0);
    expect(data.payments.failed).toBeGreaterThanOrEqual(0);
    expect(data.payments.pending).toBeGreaterThanOrEqual(0);

    expect(data.revenue.total).toBeGreaterThanOrEqual(0);
    expect(data.revenue.averageTransaction).toBeGreaterThanOrEqual(0);

    expect(data.services.total).toBeGreaterThanOrEqual(0);
    expect(data.services.active).toBeGreaterThanOrEqual(0);
    expect(data.services.inactive).toBeGreaterThanOrEqual(0);
  });

  test('should require authentication', async ({ request }) => {
    const response = await request.get('/api/user/analytics');

    expect(response.status()).toBe(401);
    const body = await response.json();
    expect(body).toHaveProperty('error');
  });
});

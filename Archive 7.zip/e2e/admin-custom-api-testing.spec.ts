import { test, expect } from '@playwright/test';

test.describe('Admin Custom API Testing Feature', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[type="email"]', 'admin@fintech.com');
    await page.fill('input[type="password"]', 'Admin@123');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/account/dashboard', { timeout: 10000 });
  });

  test('should display Test button on each API card', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await expect(testButtons.first()).toBeVisible();
    }
  });

  test('should open test modal when Test button is clicked', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      await expect(page.locator('text=Test API:')).toBeVisible();
      await expect(page.locator('text=API Configuration')).toBeVisible();
      await expect(page.locator('text=Health Status')).toBeVisible();
      await expect(page.locator('text=Test Payload')).toBeVisible();
    }
  });

  test('should display API configuration in test modal', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      await expect(page.locator('text=Base URL:')).toBeVisible();
      await expect(page.locator('text=Endpoint:')).toBeVisible();
      await expect(page.locator('text=Method:')).toBeVisible();
      await expect(page.locator('text=Auth Type:')).toBeVisible();
    }
  });

  test('should display test payload with transaction data', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      const payloadText = page.locator('text=beneficiaryName');
      await expect(payloadText).toBeVisible();

      await expect(page.locator('text=Test User')).toBeVisible();
      await expect(page.locator('text=10')).toBeVisible();
      await expect(page.locator('text=neft')).toBeVisible();
    }
  });

  test('should display health check status in test modal', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      await expect(page.locator('text=Health Status')).toBeVisible();

      const healthIndicators = page.locator('text=/✅ Online|⏳ Checking|❌ Offline/');
      const visible = await healthIndicators.isVisible().catch(() => false);
      if (visible) {
        await expect(healthIndicators).toBeVisible();
      }
    }
  });

  test('should have Send Test Request button in test modal', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      const sendButton = page.locator('button:has-text("Send Test Request")');
      await expect(sendButton).toBeVisible();
      await expect(sendButton).toBeEnabled();
    }
  });

  test('should open requirements documentation modal', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      const requirementsButton = page.locator('button:has-text("View Requirements")');
      await expect(requirementsButton).toBeVisible();
      await requirementsButton.click();
      await page.waitForTimeout(500);

      await expect(page.locator('text=API Requirements & Documentation')).toBeVisible();
    }
  });

  test('should display required request fields in requirements doc', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      const requirementsButton = page.locator('button:has-text("View Requirements")');
      await requirementsButton.click();
      await page.waitForTimeout(500);

      await expect(page.locator('text=Required Request Fields')).toBeVisible();
      await expect(page.locator('text=amount')).toBeVisible();
      await expect(page.locator('text=beneficiaryName')).toBeVisible();
      await expect(page.locator('text=transferMode')).toBeVisible();
      await expect(page.locator('text=beneficiaryAccount')).toBeVisible();
      await expect(page.locator('text=beneficiaryIfsc')).toBeVisible();
      await expect(page.locator('text=beneficiaryVpa')).toBeVisible();
    }
  });

  test('should display success response format in requirements doc', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      const requirementsButton = page.locator('button:has-text("View Requirements")');
      await requirementsButton.click();
      await page.waitForTimeout(500);

      await expect(page.locator('text=Expected Success Response Format')).toBeVisible();
      await expect(page.locator('text=transactionId')).toBeVisible();
      await expect(page.locator('text=utrNumber')).toBeVisible();
    }
  });

  test('should display error response format in requirements doc', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      const requirementsButton = page.locator('button:has-text("View Requirements")');
      await requirementsButton.click();
      await page.waitForTimeout(500);

      await expect(page.locator('text=Expected Error Response Format')).toBeVisible();
      await expect(page.locator('text=INSUFFICIENT_FUNDS')).toBeVisible();
    }
  });

  test('should display authentication methods in requirements doc', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      const requirementsButton = page.locator('button:has-text("View Requirements")');
      await requirementsButton.click();
      await page.waitForTimeout(500);

      await expect(page.locator('text=Authentication Methods')).toBeVisible();
      await expect(page.locator('text=Bearer Token')).toBeVisible();
      await expect(page.locator('text=API Key Header')).toBeVisible();
      await expect(page.locator('text=Basic Auth')).toBeVisible();
    }
  });

  test('should display HTTP status codes in requirements doc', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      const requirementsButton = page.locator('button:has-text("View Requirements")');
      await requirementsButton.click();
      await page.waitForTimeout(500);

      await expect(page.locator('text=HTTP Status Codes')).toBeVisible();
      await expect(page.locator('text=200')).toBeVisible();
      await expect(page.locator('text=400')).toBeVisible();
      await expect(page.locator('text=401')).toBeVisible();
      await expect(page.locator('text=500')).toBeVisible();
    }
  });

  test('should close test modal when Close button is clicked', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      const closeButton = page.locator('button:has-text("Close"):last-of-type');
      await closeButton.click();
      await page.waitForTimeout(300);

      const testModal = page.locator('text=Test API:');
      const isVisible = await testModal.isVisible().catch(() => false);
      expect(isVisible).toBe(false);
    }
  });

  test('should close requirements doc modal when Close button is clicked', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      const requirementsButton = page.locator('button:has-text("View Requirements")');
      await requirementsButton.click();
      await page.waitForTimeout(500);

      const closeButton = page.locator('button:has-text("Close")');
      const lastCloseButton = closeButton.last();
      await lastCloseButton.click();
      await page.waitForTimeout(300);

      const docModal = page.locator('text=API Requirements & Documentation');
      const isVisible = await docModal.isVisible().catch(() => false);
      expect(isVisible).toBe(false);
    }
  });

  test('should close test modal when X button is clicked', async ({ page }) => {
    await page.goto('/account/admin/custom-apis');
    await page.waitForLoadState('networkidle');

    const testButtons = page.locator('button:has-text("🧪 Test")');
    const count = await testButtons.count();

    if (count > 0) {
      await testButtons.first().click();
      await page.waitForTimeout(500);

      const xButton = page.locator('button:has-text("×")').first();
      await xButton.click();
      await page.waitForTimeout(300);

      const testModal = page.locator('text=Test API:');
      const isVisible = await testModal.isVisible().catch(() => false);
      expect(isVisible).toBe(false);
    }
  });
});

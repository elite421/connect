import { test, expect } from '@playwright/test';

test.describe('Admin Transaction Management API', () => {
  let authToken: string;

  test.beforeEach(async ({ page }) => {
    await page.goto('/login');

    await page.fill('input[type="email"]', 'admin@fintech.com');
    await page.fill('input[type="password"]', 'Admin@123');
    await page.click('button[type="submit"]');

    await page.waitForURL('**/account/dashboard', { timeout: 10000 });
  });

  test.describe('GET /api/admin/transactions', () => {
    test('should fetch all transactions with full details', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const response = await request.get('/api/admin/transactions', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      expect(response.status()).toBe(200);

      const body = await response.json();
      expect(body).toHaveProperty('success', true);
      expect(body).toHaveProperty('data');
      expect(Array.isArray(body.data)).toBe(true);
      expect(body).toHaveProperty('summary');
      expect(body).toHaveProperty('pagination');
    });

    test('should support pagination', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const response = await request.get('/api/admin/transactions?limit=10&offset=0', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      expect(response.status()).toBe(200);

      const body = await response.json();
      expect(body.pagination.limit).toBe(10);
      expect(body.pagination.offset).toBe(0);
      expect(typeof body.pagination.total).toBe('number');
      expect(typeof body.pagination.hasMore).toBe('boolean');
    });

    test('should filter transactions by status', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const response = await request.get('/api/admin/transactions?status=completed', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      expect(response.status()).toBe(200);

      const body = await response.json();
      if (body.data.length > 0) {
        body.data.forEach((transaction: any) => {
          expect(transaction.status).toBe('completed');
        });
      }
    });

    test('should filter transactions by service type', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const response = await request.get('/api/admin/transactions?serviceType=upi', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      expect(response.status()).toBe(200);

      const body = await response.json();
      if (body.data.length > 0) {
        body.data.forEach((transaction: any) => {
          expect(transaction.serviceType.toLowerCase()).toBe('upi');
        });
      }
    });

    test('should filter transactions by date range', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
      const endDate = new Date().toISOString();

      const response = await request.get(
        `/api/admin/transactions?startDate=${startDate}&endDate=${endDate}`,
        {
          headers: {
            'Cookie': cookieHeader,
            'Content-Type': 'application/json',
          },
        }
      );

      expect(response.status()).toBe(200);

      const body = await response.json();
      if (body.data.length > 0) {
        body.data.forEach((transaction: any) => {
          const txDate = new Date(transaction.createdAt).getTime();
          expect(txDate).toBeGreaterThanOrEqual(new Date(startDate).getTime());
          expect(txDate).toBeLessThanOrEqual(new Date(endDate).getTime());
        });
      }
    });

    test('should include transaction details in response', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const response = await request.get('/api/admin/transactions?limit=1', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      expect(response.status()).toBe(200);

      const body = await response.json();
      if (body.data.length > 0) {
        const transaction = body.data[0];
        expect(transaction).toHaveProperty('id');
        expect(transaction).toHaveProperty('subUserId');
        expect(transaction).toHaveProperty('subUser');
        expect(transaction).toHaveProperty('userId');
        expect(transaction).toHaveProperty('serviceType');
        expect(transaction).toHaveProperty('amount');
        expect(transaction).toHaveProperty('currency');
        expect(transaction).toHaveProperty('status');
        expect(transaction).toHaveProperty('referenceId');
        expect(transaction).toHaveProperty('createdAt');
        expect(transaction).toHaveProperty('updatedAt');
      }
    });

    test('should require authentication', async ({ request }) => {
      const response = await request.get('/api/admin/transactions');

      expect(response.status()).toBe(401);
      const body = await response.json();
      expect(body).toHaveProperty('error');
    });

    test('should serialize BigInt values correctly', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const response = await request.get('/api/admin/transactions?limit=1', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      expect(response.status()).toBe(200);

      const body = await response.json();
      if (body.data.length > 0) {
        const transaction = body.data[0];
        expect(typeof transaction.amount).toBe('number');
      }
    });
  });

  test.describe('PATCH /api/admin/transactions/[id]', () => {
    test('should update transaction status to completed', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const listResponse = await request.get('/api/admin/transactions?status=pending&limit=1', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      if (listResponse.status() !== 200) {
        test.skip();
        return;
      }

      const listBody = await listResponse.json();
      if (listBody.data.length === 0) {
        test.skip();
        return;
      }

      const transactionId = listBody.data[0].id;

      const updateResponse = await request.patch(`/api/admin/transactions/${transactionId}`, {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
        data: {
          status: 'completed',
        },
      });

      expect(updateResponse.status()).toBe(200);

      const updateBody = await updateResponse.json();
      expect(updateBody).toHaveProperty('success', true);
      expect(updateBody.data.status).toBe('completed');
    });

    test('should update transaction createdAt timestamp', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const listResponse = await request.get('/api/admin/transactions?limit=1', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      if (listResponse.status() !== 200) {
        test.skip();
        return;
      }

      const listBody = await listResponse.json();
      if (listBody.data.length === 0) {
        test.skip();
        return;
      }

      const transactionId = listBody.data[0].id;
      const newDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

      const updateResponse = await request.patch(`/api/admin/transactions/${transactionId}`, {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
        data: {
          createdAt: newDate,
        },
      });

      expect(updateResponse.status()).toBe(200);

      const updateBody = await updateResponse.json();
      expect(updateBody.success).toBe(true);
      const returnedDate = new Date(updateBody.data.createdAt).toISOString();
      const expectedDate = new Date(newDate).toISOString();
      expect(returnedDate).toBe(expectedDate);
    });

    test('should update transaction updatedAt timestamp', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const listResponse = await request.get('/api/admin/transactions?limit=1', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      if (listResponse.status() !== 200) {
        test.skip();
        return;
      }

      const listBody = await listResponse.json();
      if (listBody.data.length === 0) {
        test.skip();
        return;
      }

      const transactionId = listBody.data[0].id;
      const newDate = new Date().toISOString();

      const updateResponse = await request.patch(`/api/admin/transactions/${transactionId}`, {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
        data: {
          updatedAt: newDate,
        },
      });

      expect(updateResponse.status()).toBe(200);

      const updateBody = await updateResponse.json();
      expect(updateBody.success).toBe(true);
    });

    test('should update failure reason', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const listResponse = await request.get('/api/admin/transactions?status=failed&limit=1', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      if (listResponse.status() !== 200 || (await listResponse.json()).data.length === 0) {
        test.skip();
        return;
      }

      const listBody = await listResponse.json();
      const transactionId = listBody.data[0].id;

      const updateResponse = await request.patch(`/api/admin/transactions/${transactionId}`, {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
        data: {
          failureReason: 'Invalid beneficiary account',
        },
      });

      expect(updateResponse.status()).toBe(200);

      const updateBody = await updateResponse.json();
      expect(updateBody.data.failureReason).toBe('Invalid beneficiary account');
    });

    test('should reject invalid status', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const listResponse = await request.get('/api/admin/transactions?limit=1', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      if (listResponse.status() !== 200) {
        test.skip();
        return;
      }

      const listBody = await listResponse.json();
      if (listBody.data.length === 0) {
        test.skip();
        return;
      }

      const transactionId = listBody.data[0].id;

      const updateResponse = await request.patch(`/api/admin/transactions/${transactionId}`, {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
        data: {
          status: 'invalid_status',
        },
      });

      expect(updateResponse.status()).toBe(400);

      const updateBody = await updateResponse.json();
      expect(updateBody).toHaveProperty('error');
    });

    test('should reject invalid date format', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const listResponse = await request.get('/api/admin/transactions?limit=1', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      if (listResponse.status() !== 200) {
        test.skip();
        return;
      }

      const listBody = await listResponse.json();
      if (listBody.data.length === 0) {
        test.skip();
        return;
      }

      const transactionId = listBody.data[0].id;

      const updateResponse = await request.patch(`/api/admin/transactions/${transactionId}`, {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
        data: {
          createdAt: 'invalid-date',
        },
      });

      expect(updateResponse.status()).toBe(400);

      const updateBody = await updateResponse.json();
      expect(updateBody).toHaveProperty('error');
    });

    test('should require admin role to update transactions', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const listResponse = await request.get('/api/admin/transactions?limit=1', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      if (listResponse.status() !== 200) {
        test.skip();
        return;
      }

      const listBody = await listResponse.json();
      if (listBody.data.length === 0) {
        test.skip();
        return;
      }

      const transactionId = listBody.data[0].id;

      const updateResponse = await request.patch(`/api/admin/transactions/${transactionId}`, {
        headers: {
          'Content-Type': 'application/json',
        },
        data: {
          status: 'completed',
        },
      });

      expect(updateResponse.status()).toBe(401);
    });
  });

  test.describe('GET /api/admin/transactions/[id]', () => {
    test('should fetch transaction details by ID', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const listResponse = await request.get('/api/admin/transactions?limit=1', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      if (listResponse.status() !== 200) {
        test.skip();
        return;
      }

      const listBody = await listResponse.json();
      if (listBody.data.length === 0) {
        test.skip();
        return;
      }

      const transactionId = listBody.data[0].id;

      const response = await request.get(`/api/admin/transactions/${transactionId}`, {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      expect(response.status()).toBe(200);

      const body = await response.json();
      expect(body).toHaveProperty('success', true);
      expect(body.data.id).toBe(transactionId);
      expect(body.data).toHaveProperty('subUser');
      expect(body.data).toHaveProperty('beneficiary');
    });

    test('should return 404 for non-existent transaction', async ({ request, page }) => {
      const cookies = await page.context().cookies();
      const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

      const response = await request.get('/api/admin/transactions/non-existent-id-12345', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
      });

      expect(response.status()).toBe(404);

      const body = await response.json();
      expect(body).toHaveProperty('error');
    });
  });
});

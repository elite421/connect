import { Pool } from 'pg';

test('idempotent debit executes once', async () => {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(`INSERT INTO wallets(owner_type, owner_id, currency, balance) VALUES ('user', gen_random_uuid(), 'USD', 1000) RETURNING id, balance`);
    const walletId = rows[0].id;
    const idk = 'test-key-123';

    const up1 = await client.query(`UPDATE wallets SET balance = balance - $1 WHERE id = $2 AND balance >= $1 RETURNING balance`, [500, walletId]);
    expect(up1.rowCount).toBe(1);
    await client.query(`INSERT INTO wallet_transactions(wallet_id, tx_type, amount, balance_after, currency, idempotency_key) VALUES ($1,'debit',500,$2,'USD',$3)`,
      [walletId, up1.rows[0].balance, idk]);

    // replay
    await client.query(`UPDATE wallets SET balance = balance - $1 WHERE id = $2 AND balance >= $1 RETURNING balance`, [500, walletId]);
    const ins2 = await client.query(`INSERT INTO wallet_transactions(wallet_id, tx_type, amount, balance_after, currency, idempotency_key) VALUES ($1,'debit',500,$2,'USD',$3) ON CONFLICT (wallet_id, idempotency_key) DO NOTHING`,
      [walletId, up1.rows[0].balance - 500, idk]);
    // Should not allow second insert; if UPDATE succeeded erroneously, this reveals bug
    expect(ins2.rowCount).toBe(0);
  } finally {
    await client.query('ROLLBACK');
    client.release();
  }
});

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

/**
 * Payout Callback Webhook
 * Receives status updates from external payment gateways.
 * Updates transaction status and refunds wallet on failure.
 */
export async function POST(
    req: NextRequest,
    { params }: { params: Promise<{ apiId: string }> }
) {
    try {
        const { apiId } = await params;
        const body = await req.json();

        console.log(`[Payout Callback] Received for API ${apiId}:`, JSON.stringify(body, null, 2));

        // Find the custom API
        const customApi = await prisma.customPaymentApi.findUnique({
            where: { id: apiId }
        });

        if (!customApi) {
            console.error(`[Payout Callback] API not found: ${apiId}`);
            return NextResponse.json({ success: false, error: 'API not found' }, { status: 404 });
        }

        // Parse response format to extract fields
        let responseMapping: any = {};
        try {
            responseMapping = customApi.responseFormat ?
                (typeof customApi.responseFormat === 'string' ? JSON.parse(customApi.responseFormat) : customApi.responseFormat)
                : {};
        } catch {
            responseMapping = {};
        }

        // Extract transaction identifier (try common field names)
        const transactionId = body.merchantTransactionId
            || body.transaction_id
            || body.transactionId
            || body.order_id
            || body.orderId
            || body.report_id
            || body.reference_id;

        if (!transactionId) {
            console.error('[Payout Callback] No transaction ID found in callback');
            return NextResponse.json({
                success: false,
                error: 'Transaction ID not found in callback',
                receivedFields: Object.keys(body)
            }, { status: 400 });
        }

        // Find the transaction
        const transaction = await prisma.payOutTransaction.findFirst({
            where: {
                OR: [
                    { id: transactionId },
                    { externalTransactionId: transactionId }
                ]
            },
            include: { user: true }
        });

        if (!transaction) {
            console.error(`[Payout Callback] Transaction not found: ${transactionId}`);
            return NextResponse.json({ success: false, error: 'Transaction not found' }, { status: 404 });
        }

        // Determine status from response
        const statusField = responseMapping.statusField || 'status';
        const successValue = responseMapping.successValue || 'success';
        const failureValue = responseMapping.failureValue || 'failed';
        const utrField = responseMapping.utrField || 'utr';
        const messageField = responseMapping.messageField || 'message';

        const rawStatus = body[statusField] || body.status || body.status_id;
        let newStatus: 'success' | 'failed' | 'processing' = 'processing';

        // Map status
        if (rawStatus === successValue || rawStatus === 'success' || rawStatus === 'SUCCESS' || rawStatus === 1 || rawStatus === '1') {
            newStatus = 'success';
        } else if (rawStatus === failureValue || rawStatus === 'failed' || rawStatus === 'FAILED' || rawStatus === 2 || rawStatus === '2') {
            newStatus = 'failed';
        }

        const utr = body[utrField] || body.utr || body.UTR || body.utr_number;
        const message = body[messageField] || body.message || body.remark;

        // Update transaction
        await prisma.payOutTransaction.update({
            where: { id: transaction.id },
            data: {
                status: newStatus,
                utrNumber: utr || transaction.utrNumber,
                responseData: {
                    ...(transaction.responseData as object || {}),
                    callbackReceived: true,
                    callbackData: body,
                    callbackStatus: newStatus,
                    callbackMessage: message
                }
            }
        });

        // If failed, refund wallet
        if (newStatus === 'failed' && transaction.status !== 'failed') {
            const wallet = await prisma.wallet.findUnique({
                where: { userId: transaction.userId }
            });

            if (wallet) {
                // Get original debit amount from responseData
                const chargeInfo = (transaction.responseData as any)?.chargeInfo;
                const totalDebit = chargeInfo?.totalDebit
                    ? Number(chargeInfo.totalDebit)
                    : Number(transaction.amount);

                // Refund
                await prisma.wallet.update({
                    where: { userId: transaction.userId },
                    data: {
                        balance: { increment: Number(totalDebit) }
                    }
                });

                // Get updated balance
                const updatedWallet = await prisma.wallet.findUnique({ where: { userId: transaction.userId } });

                // Log refund
                await prisma.walletTransactionLocal.create({
                    data: {
                        walletId: wallet.id,
                        userId: transaction.userId,
                        type: 'PAYOUT_REFUND',
                        amount: totalDebit,
                        balanceAfter: updatedWallet?.balance || 0,
                        chargeAmount: chargeInfo?.totalCharge ? Number(chargeInfo.totalCharge) : 0,
                        referenceType: 'payout',
                        referenceId: transaction.id,
                        description: `Callback Refund: ${message || 'Transaction failed'}`,
                        metadata: {
                            reason: 'callback_failed',
                            callbackMessage: message,
                            apiId
                        }
                    }
                });

                console.log(`[Payout Callback] Refunded transaction ${transaction.id}`);
            }
        }

        console.log(`[Payout Callback] Updated transaction ${transaction.id} to ${newStatus}`);

        return NextResponse.json({
            success: true,
            transactionId: transaction.id,
            status: newStatus,
            message: 'Callback processed successfully'
        });

    } catch (error: any) {
        console.error('[Payout Callback] Error:', error);
        return NextResponse.json({
            success: false,
            error: 'Internal server error',
            details: error.message
        }, { status: 500 });
    }
}

// Also support GET for health check
export async function GET(
    req: NextRequest,
    { params }: { params: Promise<{ apiId: string }> }
) {
    const { apiId } = await params;
    return NextResponse.json({
        success: true,
        message: 'Payout callback webhook is active',
        apiId,
        endpoint: `/api/webhooks/payout/${apiId}`,
        method: 'POST',
        expectedFields: ['merchantTransactionId', 'status', 'utr', 'message']
    });
}

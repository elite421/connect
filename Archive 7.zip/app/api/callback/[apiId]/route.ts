import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { toRupees } from '@/lib/money';

// This route handles callbacks from payment gateways for specific APIs
// URL: /api/callback/[apiId]/route.ts where [apiId] is the apiNumber

interface CallbackPayload {
    transactionId?: string;
    status?: string;
    utr?: string;
    utrNumber?: string;
    message?: string;
    amount?: number | string;
    // Gateway-specific fields
    report_id?: string;
    status_id?: number | string;
    txn_id?: string;
    reference_id?: string;
}

export async function POST(
    req: NextRequest,
    { params }: { params: Promise<{ apiId: string }> }
) {
    try {
        const { apiId } = await params;

        // Find the API by apiNumber
        const api = await prisma.customPaymentApi.findFirst({
            where: {
                OR: [
                    { apiNumber: apiId },
                    { id: apiId },
                ],
            },
        });

        if (!api) {
            return NextResponse.json(
                { success: false, error: 'Invalid API identifier' },
                { status: 404 }
            );
        }

        // Validate callback token if present in headers
        const authHeader = req.headers.get('authorization');
        const callbackToken = req.headers.get('x-callback-token');

        if (api.callbackToken) {
            const providedToken = callbackToken || authHeader?.replace('Bearer ', '');
            if (providedToken !== api.callbackToken) {
                console.warn(`Invalid callback token for API ${api.apiNumber}`);
                // Continue processing but log the warning (some gateways don't support tokens)
            }
        }

        // Parse the callback payload
        const body: CallbackPayload = await req.json();

        // Normalize the transaction ID from various possible fields
        const transactionId = body.transactionId || body.txn_id || body.reference_id || body.report_id;

        // Normalize status
        let normalizedStatus = 'pending';
        const statusValue = body.status || body.status_id;

        if (typeof statusValue === 'string') {
            const statusLower = statusValue.toLowerCase();
            if (['success', 'completed', 'done', '1', 'true'].includes(statusLower)) {
                normalizedStatus = 'completed';
            } else if (['failed', 'failure', 'error', '2', 'false'].includes(statusLower)) {
                normalizedStatus = 'failed';
            } else if (['pending', 'processing', '3'].includes(statusLower)) {
                normalizedStatus = 'processing';
            }
        } else if (typeof statusValue === 'number') {
            if (statusValue === 1) normalizedStatus = 'completed';
            else if (statusValue === 2) normalizedStatus = 'failed';
            else if (statusValue === 3) normalizedStatus = 'processing';
        }

        // Normalize UTR
        const utrNumber = body.utr || body.utrNumber || null;

        console.log(`Callback received for API ${api.apiNumber}:`, {
            transactionId,
            normalizedStatus,
            utrNumber,
            rawPayload: body,
        });

        if (!transactionId) {
            return NextResponse.json(
                { success: false, error: 'Transaction ID is required' },
                { status: 400 }
            );
        }

        // Determine if this is a PayIn or PayOut based on API type
        let transaction = null;
        let transactionType = api.apiType;

        if (transactionType === 'PAYOUT') {
            // Look up the PayOut transaction
            transaction = await prisma.payOutTransaction.findFirst({
                where: {
                    OR: [
                        { id: transactionId },
                        { externalTransactionId: transactionId },
                    ],
                },
                include: {
                    user: {
                        include: {
                            wallet: true,
                        },
                    },
                },
            });

            if (transaction) {
                // Update the transaction
                await prisma.payOutTransaction.update({
                    where: { id: transaction.id },
                    data: {
                        status: normalizedStatus,
                        utrNumber: utrNumber || transaction.utrNumber,
                        responseData: body as any,
                    },
                });

                // If transaction completed and was previously frozen, unfreeze the wallet
                if (normalizedStatus === 'completed' && transaction.user?.wallet) {
                    // Transaction charges should already be deducted, just update frozen balance
                    await prisma.wallet.update({
                        where: { id: transaction.user.wallet.id },
                        data: {
                            frozenBalance: {
                                decrement: toRupees(transaction.amount),
                            },
                        },
                    });
                }

                // If transaction failed, refund the frozen amount
                if (normalizedStatus === 'failed' && transaction.user?.wallet) {
                    await prisma.$transaction([
                        // Unfreeze and restore balance
                        prisma.wallet.update({
                            where: { id: transaction.user.wallet.id },
                            data: {
                                balance: { increment: toRupees(transaction.amount) },
                                frozenBalance: { decrement: toRupees(transaction.amount) },
                            },
                        }),
                        // Create wallet ledger entry for refund
                        prisma.walletTransactionLocal.create({
                            data: {
                                walletId: transaction.user.wallet.id,
                                userId: transaction.userId,
                                type: 'PAYOUT_REFUND',
                                amount: toRupees(transaction.amount),
                                balanceAfter: toRupees(transaction.user.wallet.balance) + toRupees(transaction.amount),
                                chargeAmount: 0,
                                referenceType: 'payout',
                                referenceId: transaction.id,
                                description: `Payout refund - Transaction failed`,
                            },
                        }),
                    ]);
                }
            }
        } else if (transactionType === 'PAYIN') {
            // Look up the PayIn transaction
            transaction = await prisma.payInTransaction.findFirst({
                where: {
                    OR: [
                        { id: transactionId },
                        { externalTransactionId: transactionId },
                        { merchantTransactionId: transactionId },
                    ],
                },
                include: {
                    user: {
                        include: {
                            wallet: true,
                        },
                    },
                },
            });

            if (transaction) {
                // Update the transaction
                await prisma.payInTransaction.update({
                    where: { id: transaction.id },
                    data: {
                        status: normalizedStatus,
                        utrNumber: utrNumber || transaction.utrNumber,
                        responseData: body as any,
                    },
                });

                // If PayIn completed, credit the user's wallet and apply charges
                if (normalizedStatus === 'completed' && transaction.user?.wallet) {
                    // Get user's transaction charge if configured
                    const userCharge = transaction.user.transactionCharge
                        ? Number(transaction.user.transactionCharge)
                        : 0;

                    // Calculate charge amount (assuming percentage-based for PayIn)
                    const chargeAmount = toRupees(transaction.amount) * (userCharge / 100);
                    const netAmount = toRupees(transaction.amount) - chargeAmount;

                    await prisma.$transaction([
                        // Credit wallet with net amount
                        prisma.wallet.update({
                            where: { id: transaction.user.wallet.id },
                            data: {
                                balance: { increment: netAmount },
                            },
                        }),
                        // Create wallet ledger entry
                        prisma.walletTransactionLocal.create({
                            data: {
                                walletId: transaction.user.wallet.id,
                                userId: transaction.userId,
                                type: 'PAYIN_CREDIT',
                                amount: netAmount,
                                balanceAfter: toRupees(transaction.user.wallet.balance) + netAmount,
                                chargeAmount: chargeAmount,
                                referenceType: 'payin',
                                referenceId: transaction.id,
                                description: `PayIn credit via ${api.apiName}${chargeAmount > 0 ? ` (Charge: ₹${toRupees(chargeAmount)})` : ''}`,
                            },
                        }),
                    ]);
                }
            }
        }

        if (!transaction) {
            console.warn(`Transaction not found for ID: ${transactionId}`);
            return NextResponse.json(
                { success: false, error: 'Transaction not found' },
                { status: 404 }
            );
        }

        return NextResponse.json({
            success: true,
            message: 'Callback processed successfully',
            transactionId: transaction.id,
            status: normalizedStatus,
        });
    } catch (error) {
        console.error('Callback processing error:', error);
        return NextResponse.json(
            { success: false, error: 'Internal server error' },
            { status: 500 }
        );
    }
}

// GET: For gateways that send status via GET
export async function GET(
    req: NextRequest,
    { params }: { params: Promise<{ apiId: string }> }
) {
    const { searchParams } = new URL(req.url);
    const transactionId = searchParams.get('transactionId') || searchParams.get('txn_id');
    const status = searchParams.get('status');
    const utr = searchParams.get('utr');

    // Convert to POST-style payload and process
    const mockReq = new NextRequest(req.url, {
        method: 'POST',
        headers: req.headers,
        body: JSON.stringify({ transactionId, status, utr }),
    });

    return POST(mockReq, { params });
}


import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function POST(req: NextRequest) {
    try {
        const body = await req.json();
        console.log('[RudraxPay] Callback received:', body);

        const { status, client_txn_id, utr, amount } = body;

        // "status": "success" | "failed"
        // "client_txn_id": "ORDER_ID"

        if (!client_txn_id) {
            return NextResponse.json({ status: false, message: 'Missing client_txn_id' }, { status: 400 });
        }

        // Find transaction
        const transaction = await prisma.payInTransaction.findFirst({
            where: {
                OR: [
                    { id: client_txn_id },
                    { merchantTransactionId: client_txn_id }
                ]
            }
        });

        if (!transaction) {
            return NextResponse.json({ status: false, message: 'Transaction not found' }, { status: 404 });
        }

        if (transaction.status === 'completed') {
            return NextResponse.json({ status: true, message: 'Transaction already completed' });
        }

        // Determine status
        let newStatus = 'processing';
        if (status === 'success') {
            newStatus = 'completed';
        } else if (status === 'failed') {
            newStatus = 'failed';
        }

        // Update transaction
        await prisma.payInTransaction.update({
            where: { id: transaction.id },
            data: {
                status: newStatus,
                utrNumber: utr || transaction.utrNumber,
                amount: amount ? Number(amount) : transaction.amount, // Be careful here, but often useful to store actual amount received
                responseData: {
                    ...(transaction.responseData as object || {}),
                    callbackData: body,
                    callbackReceivedAt: new Date().toISOString()
                }
            }
        });

        // Credit Wallet if Success
        if (newStatus === 'completed' && transaction.status !== 'completed') {
            const wallet = await prisma.wallet.findUnique({ where: { userId: transaction.userId } });

            if (wallet) {
                // FETCH FEE RULES
                let customApi;

                // 1. Try fetching the specific API used for this transaction
                if (transaction.customApiId) {
                    customApi = await prisma.customPaymentApi.findUnique({ where: { id: transaction.customApiId } });
                }

                // 2. Fallback: Find active PayIn API for the user
                if (!customApi) {
                    customApi = await prisma.customPaymentApi.findFirst({
                        where: { userId: transaction.userId, isActive: true, apiType: 'PAYIN' },
                        orderBy: { isDefault: 'desc' }
                    }) || await prisma.customPaymentApi.findFirst({
                        where: { adminProvided: true, isActive: true, apiType: 'PAYIN', isDefault: true }
                    });
                }

                // Calculate Fee
                const { calculateTransactionFee } = require('@/lib/fee-calculation');
                const feeData = calculateTransactionFee(
                    amount ? Number(amount) : transaction.amount,
                    customApi?.chargeRules as any,
                    Number(customApi?.transactionCharge) || 0,
                    customApi?.transactionChargeType as any
                );

                const creditAmount = (amount ? Number(amount) : transaction.amount) - feeData.totalFee;

                // Update Wallet Balance
                await prisma.wallet.update({
                    where: { userId: transaction.userId },
                    data: {
                        balance: { increment: creditAmount }
                    }
                });

                // Create Ledger Entry
                await prisma.walletTransactionLocal.create({
                    data: {
                        userId: transaction.userId,
                        walletId: wallet.id,
                        amount: amount ? Number(amount) : transaction.amount,
                        balanceAfter: 0,
                        type: 'PAYIN_CREDIT',
                        description: `PayIn Success #${transaction.id}`,
                        referenceId: transaction.id,
                        referenceType: 'PAYIN',
                        chargeAmount: feeData.totalFee, // Store total fee deducted
                        metadata: {
                            source: 'CALLBACK',
                            provider: 'RUDRAXPAY',
                            utr: utr,
                            feeDetails: feeData
                        }
                    }
                });
            }
        }

        return NextResponse.json({ status: true, message: 'Callback processed' });

    } catch (error) {
        console.error('[RudraxPay] Callback Error:', error);
        return NextResponse.json({ status: false, message: 'Internal Server Error' }, { status: 500 });
    }
}

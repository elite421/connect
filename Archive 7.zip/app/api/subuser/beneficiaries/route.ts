import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';
import {
  validateAccountNumber,
  validateIfscCode,
  validateUPI,
} from '@/lib/security';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const [beneficiaries, total] = await Promise.all([
      prisma.beneficiary.findMany({
        where: { subUserId: user.id },
        select: {
          id: true,
          accountName: true,
          accountNumber: true,
          bankName: true,
          ifscCode: true,
          upiId: true,
          beneficiaryType: true,
          isVerified: true,
          createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.beneficiary.count({ where: { subUserId: user.id } }),
    ]);

    return NextResponse.json({
      success: true,
      data: beneficiaries,
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/subuser/beneficiaries error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch beneficiaries' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      accountName,
      accountNumber,
      bankName,
      bankCode,
      ifscCode,
      upiId,
      beneficiaryType,
    } = body;

    if (!accountName || !beneficiaryType) {
      return NextResponse.json(
        { error: 'Account name and beneficiary type required' },
        { status: 400 }
      );
    }

    if (beneficiaryType === 'bank') {
      if (!accountNumber || !ifscCode) {
        return NextResponse.json(
          { error: 'Account number and IFSC code required for bank transfers' },
          { status: 400 }
        );
      }
      if (!validateAccountNumber(accountNumber)) {
        return NextResponse.json(
          { error: 'Invalid account number' },
          { status: 400 }
        );
      }
      if (!validateIfscCode(ifscCode)) {
        return NextResponse.json(
          { error: 'Invalid IFSC code' },
          { status: 400 }
        );
      }
    }

    if (beneficiaryType === 'upi') {
      if (!upiId || !validateUPI(upiId)) {
        return NextResponse.json(
          { error: 'Invalid UPI ID' },
          { status: 400 }
        );
      }
    }

    const beneficiary = await prisma.beneficiary.create({
      data: {
        subUserId: user.id,
        accountName,
        accountNumber: accountNumber || '',
        bankName: bankName || '',
        bankCode: bankCode || null,
        ifscCode: ifscCode || null,
        upiId: upiId || null,
        beneficiaryType,
        isVerified: true,
      },
    });

    await logActivity({
      user,
      action: 'add_beneficiary',
      resource: 'beneficiary',
      resourceId: beneficiary.id,
      metadata: { accountName, beneficiaryType },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: user.id,
    });

    return NextResponse.json({ success: true, data: serializeBigInt(beneficiary) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/subuser/beneficiaries error:', error);
    return NextResponse.json(
      { error: 'Failed to add beneficiary' },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { beneficiaryId, accountName, isVerified } = body;

    if (!beneficiaryId) {
      return NextResponse.json(
        { error: 'Beneficiary ID required' },
        { status: 400 }
      );
    }

    const beneficiary = await prisma.beneficiary.update({
      where: { id: beneficiaryId, subUserId: user.id },
      data: {
        ...(accountName && { accountName }),
        ...(isVerified !== undefined && { isVerified }),
      },
    });

    await logActivity({
      user,
      action: 'update_beneficiary',
      resource: 'beneficiary',
      resourceId: beneficiaryId,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: user.id,
    });

    return NextResponse.json({ success: true, data: serializeBigInt(beneficiary) });
  } catch (error) {
    console.error('PATCH /api/subuser/beneficiaries error:', error);
    return NextResponse.json(
      { error: 'Failed to update beneficiary' },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const beneficiaryId = searchParams.get('beneficiaryId');

    if (!beneficiaryId) {
      return NextResponse.json(
        { error: 'Beneficiary ID required' },
        { status: 400 }
      );
    }

    await prisma.beneficiary.delete({
      where: { id: beneficiaryId, subUserId: user.id },
    });

    await logActivity({
      user,
      action: 'delete_beneficiary',
      resource: 'beneficiary',
      resourceId: beneficiaryId,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: user.id,
    });

    return NextResponse.json({ success: true, message: 'Beneficiary deleted' });
  } catch (error) {
    console.error('DELETE /api/subuser/beneficiaries error:', error);
    return NextResponse.json(
      { error: 'Failed to delete beneficiary' },
      { status: 500 }
    );
  }
}

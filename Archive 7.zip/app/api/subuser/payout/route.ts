import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { applyPaymentScheme } from '@/lib/payment-scheme';
import { logActivity } from '@/lib/audit';
import { callPayoutApi } from '@/lib/payout-integration';
import { callFingrowPayoutApi } from '@/lib/fingrow-integration';
import { toPaise, toRupees } from '@/lib/money';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const transactions = await prisma.payOutTransaction.findMany({
      where: { subUserId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 100
    });

    const normalizedTransactions = transactions.map((t: any) => ({
      ...t,
      amount: t.amount,
    }));

    return safeJson({ success: true, data: normalizedTransactions });
  } catch (error) {
    console.error('GET /api/subuser/payout error:', error);
    return safeJson({ error: 'Failed to fetch payouts' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { amount, beneficiaryName, beneficiaryAccount, beneficiaryIfsc, beneficiaryVpa, transferMode } = body;

    if (!amount || amount <= 0) {
      return safeJson({ error: 'Invalid amount' }, { status: 400 });
    }

    if (!beneficiaryName || !transferMode) {
      return safeJson({ error: 'Missing required fields' }, { status: 400 });
    }

    if (transferMode === 'upi' && !beneficiaryVpa) {
      return safeJson({ error: 'VPA required for UPI transfers' }, { status: 400 });
    }

    if (transferMode !== 'upi' && (!beneficiaryAccount || !beneficiaryIfsc)) {
      return safeJson({ error: 'Account number and IFSC required' }, { status: 400 });
    }

    // Get parent user ID
    const subUser = await prisma.subUser.findUnique({
      where: { id: user.id },
      select: { userId: true, name: true }
    });

    if (!subUser) {
      return safeJson({ error: 'SubUser not found' }, { status: 404 });
    }

    const ipAddress = extractIpAddress(req);

    // Parent User Check
    const parentUser = await prisma.user.findUnique({ where: { id: subUser.userId } });
    if (!parentUser) {
      return safeJson({ error: 'Parent user not found' }, { status: 404 });
    }

    // Calculate Charges (admin scheme + user-specific charge)
    const schemeInfo = await applyPaymentScheme(subUser.userId, 'payout');
    const userCharge = parentUser.transactionCharge ? Math.abs(Number(parentUser.transactionCharge)) : 0;
    const schemeCharge = Math.abs(schemeInfo.schemeCharge || 0);
    // Total Charge (Rupees)
    const totalCharge = userCharge + schemeCharge;

    // Total Debit (Rupees)
    const totalDebit = Number(amount) + totalCharge;

    // Wallet Check (parent user's wallet)
    let wallet = await prisma.wallet.findUnique({ where: { userId: subUser.userId } });

    if (!wallet) {
      wallet = await prisma.wallet.create({
        data: {
          userId: subUser.userId,
          balance: 0,
          frozenBalance: 0,
        },
      });
    }

    // Check available balance
    // wallet.balance and frozenBalance are Float now
    const balance = toRupees(wallet.balance);
    const frozen = toRupees(wallet.frozenBalance);
    const availableBalance = balance - frozen;

    if (availableBalance < totalDebit) {
      return safeJson({
        error: 'Insufficient wallet balance',
        requiredBalance: totalDebit,
        currentBalance: availableBalance,
      }, { status: 400 });
    }

    // DEDUCT the amount immediately
    const newBalance = toRupees(wallet.balance) - totalDebit;
    wallet = await prisma.wallet.update({
      where: { userId: subUser.userId },
      data: {
        balance: newBalance,
      },
    });

    // Create Transaction with 'processing' status
    const transaction = await prisma.payOutTransaction.create({
      data: {
        userId: subUser.userId,
        subUserId: user.id,
        amount: Number(amount),
        beneficiaryName,
        beneficiaryAccount: beneficiaryAccount || null,
        beneficiaryIfsc: beneficiaryIfsc || null,
        beneficiaryVpa: beneficiaryVpa || null,
        transferMode,
        ipAddress,
        status: 'processing',
        responseData: {
          chargeInfo: {
            userCharge,
            schemeCharge,
            totalCharge: totalCharge,
            totalDebit: String(totalDebit),
          },
          message: 'Processing payout...',
          subUserName: subUser.name,
        },
      }
    });

    // Record wallet debit transaction
    await prisma.walletTransactionLocal.create({
      data: {
        walletId: wallet.id,
        userId: subUser.userId,
        type: 'PAYOUT_DEBIT',
        amount: totalDebit,
        balanceAfter: newBalance,
        chargeAmount: totalCharge,
        referenceType: 'payout',
        referenceId: transaction.id,
        description: `Payout by ${subUser.name} to ${beneficiaryName} via ${transferMode.toUpperCase()}`,
        metadata: {
          subUserId: user.id,
          subUserName: subUser.name,
          beneficiaryName,
          beneficiaryAccount,
          beneficiaryVpa,
          transferMode,
        },
      },
    });

    // Call payment gateway API automatically
    const payoutAmountMajor = Number(amount);
    let gatewayResponse: any;
    let usedGateway = 'custom';

    try {
      // Try custom payment APIs
      let customApi = await prisma.customPaymentApi.findFirst({
        where: {
          userId: subUser.userId,
          adminProvided: false,
          isActive: true,
        },
        orderBy: { isDefault: 'desc' },
      });

      if (!customApi) {
        customApi = await prisma.customPaymentApi.findFirst({
          where: {
            adminProvided: true,
            isDefault: true,
            isActive: true,
          },
          orderBy: { createdAt: 'desc' },
        });
      }

      if (customApi) {
        const result = await callPayoutApi(subUser.userId, {
          amount: payoutAmountMajor,
          beneficiaryName: beneficiaryName || '',
          beneficiaryAccount: beneficiaryAccount ?? undefined,
          beneficiaryIfsc: beneficiaryIfsc ?? undefined,
          beneficiaryVpa: beneficiaryVpa ?? undefined,
          transferMode,
          merchantTransactionId: String(transaction.id),
          metadata: { localTransactionId: transaction.id, subUserId: user.id },
        });
        gatewayResponse = result.response;
        usedGateway = `custom (${customApi.apiName})`;
      } else {
        // Try Fingrow API
        const fingrowResult = await callFingrowPayoutApi(subUser.userId, {
          amount: payoutAmountMajor,
          beneficiaryName: beneficiaryName || '',
          beneficiaryAccount: beneficiaryAccount ?? undefined,
          beneficiaryIfsc: beneficiaryIfsc ?? undefined,
          beneficiaryVpa: beneficiaryVpa ?? undefined,
          transferMode,
          merchantTransactionId: String(transaction.id),
          ipAddress: ipAddress ?? undefined,
        });

        gatewayResponse = fingrowResult.response;
        usedGateway = 'fingrow';

        if (!fingrowResult.response.success && fingrowResult.response.raw?.error === 'NO_API_CONFIGURED') {
          const result = await callPayoutApi(subUser.userId, {
            amount: payoutAmountMajor,
            beneficiaryName: beneficiaryName || '',
            beneficiaryAccount: beneficiaryAccount ?? undefined,
            beneficiaryIfsc: beneficiaryIfsc ?? undefined,
            beneficiaryVpa: beneficiaryVpa ?? undefined,
            transferMode,
            merchantTransactionId: String(transaction.id),
            metadata: { localTransactionId: transaction.id, subUserId: user.id },
          });
          gatewayResponse = result.response;
          usedGateway = 'default';
        }
      }
    } catch (apiError: any) {
      console.error('Gateway API error:', apiError);
      gatewayResponse = {
        success: false,
        status: 'failed',
        message: apiError?.message || 'Gateway connection failed',
        raw: { error: apiError?.message }
      };
    }

    // Handle gateway failure - REFUND
    if (!gatewayResponse.success && gatewayResponse.status === 'failed') {

      // Refund
      await prisma.wallet.update({
        where: { userId: subUser.userId },
        data: {
          balance: { increment: totalDebit },
        },
      });

      const updatedWallet = await prisma.wallet.findUnique({ where: { userId: subUser.userId } });
      const refundedBalance = toRupees(updatedWallet?.balance);

      // Record refund transaction
      await prisma.walletTransactionLocal.create({
        data: {
          walletId: wallet.id,
          userId: subUser.userId,
          type: 'PAYOUT_REFUND',
          amount: totalDebit,
          balanceAfter: refundedBalance,
          chargeAmount: totalCharge,
          referenceType: 'payout',
          referenceId: transaction.id,
          description: `Refund: Payout failed - ${gatewayResponse.message || 'Gateway error'}`,
          metadata: {
            subUserId: user.id,
            subUserName: subUser.name,
            reason: 'gateway_failed',
            gatewayMessage: gatewayResponse.message,
            gateway: usedGateway,
          },
        },
      });

      // Update transaction to failed
      const failedTransaction = await prisma.payOutTransaction.update({
        where: { id: transaction.id },
        data: {
          status: 'failed',
          responseData: {
            success: false,
            message: gatewayResponse.message || 'Gateway rejected the payout request',
            error: gatewayResponse.message,
            raw: gatewayResponse.raw,
            gateway: usedGateway,
            refunded: true,
            subUserName: subUser.name,
            chargeInfo: {
              totalCharge: totalCharge,
              totalDebit: String(totalDebit),
            },
          },
        },
      });

      // Log Activity
      await logActivity({
        user,
        action: 'payout_failed',
        resource: 'payout',
        resourceId: transaction.id,
        metadata: {
          amount,
          transferMode,
          gateway: usedGateway,
          error: gatewayResponse.message,
          refunded: true,
        },
        ipAddress,
        userAgent: getUserAgent(req)
      });

      return safeJson({
        success: false,
        error: gatewayResponse.message || 'Payout failed',
        totalCharge: totalCharge,
        chargeAmount: totalCharge,
        totalDebit: totalDebit,
      }, { status: 400 });
    }

    // SUCCESS: Update transaction
    const updatedTransaction = await prisma.payOutTransaction.update({
      where: { id: transaction.id },
      data: {
        status: gatewayResponse.status || 'processing',
        utrNumber: gatewayResponse.utrNumber ? String(gatewayResponse.utrNumber) : null,
        externalTransactionId: gatewayResponse.externalTransactionId ? String(gatewayResponse.externalTransactionId) : null,
        responseData: {
          success: gatewayResponse.success,
          message: gatewayResponse.message,
          utr: gatewayResponse.utrNumber,
          externalTransactionId: gatewayResponse.externalTransactionId,
          raw: gatewayResponse.raw,
          gateway: usedGateway,
          subUserName: subUser.name,
          chargeInfo: {
            userCharge,
            schemeCharge,
            totalCharge: totalCharge,
            totalDebit: String(totalDebit),
          },
        },
      },
    });

    // Log Activity
    await logActivity({
      user,
      action: 'create_payment',
      resource: 'payout',
      resourceId: transaction.id,
      metadata: {
        amount,
        transferMode,
        beneficiaryAccount,
        beneficiaryIfsc,
        beneficiaryVpa,
        totalCharge: totalCharge,
        totalDebit: String(totalDebit),
        status: gatewayResponse.status,
        gateway: usedGateway,
      },
      ipAddress,
      userAgent: getUserAgent(req)
    });

    return safeJson({
      success: true,
      message: 'Payout processed successfully.',
      data: updatedTransaction,
      totalCharge: totalCharge,
      chargeAmount: totalCharge,
      totalDebit: totalDebit,
    }, { status: 201 });

  } catch (error) {
    console.error('POST /api/subuser/payout error:', error);
    return safeJson({ error: 'Failed to create payout' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const type = searchParams.get('type');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const subUserId = searchParams.get('subUserId');

    const targetSubUserId = user.role === 'ADMIN' ? (subUserId || user.id) : user.id;
    const where: any = { subUserId: targetSubUserId };
    if (type) where.transferMode = type; // Map type to transferMode
    if (startDate && endDate) {
      where.createdAt = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      };
    }

    const [transactions, total] = await Promise.all([
      prisma.payOutTransaction.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.payOutTransaction.count({ where }),
    ]);

    const summary = await prisma.payOutTransaction.aggregate({
      _sum: { amount: true },
      _count: true,
      where: { subUserId: targetSubUserId }, // Use targetSubUserId here too
    });

    await logActivity({
      user,
      action: 'view_transactions',
      resource: 'transaction',
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: targetSubUserId,
    });

    return safeJson({
      success: true,
      data: transactions.map(t => ({
        ...t,
        amount: Number(t.amount),
        type: t.transferMode, // Map transferMode to type for frontend
        txType: 'PAYOUT', // Explicitly set txType
      })),
      summary: {
        totalTransactions: summary._count,
        totalAmount: Number(summary._sum.amount || 0),
      },
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/subuser/transactions error:', error);
    return safeJson(
      { error: 'Failed to fetch transactions' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { type, amount, description, relatedPaymentId } = body;

    if (!type || !amount) {
      return safeJson(
        { error: 'Type and amount required' },
        { status: 400 }
      );
    }

    const subUser = await prisma.subUser.findUnique({
      where: { id: user.id },
    });

    if (!subUser) {
      return safeJson({ error: 'SubUser not found' }, { status: 404 });
    }

    const transaction = await prisma.subUserTransaction.create({
      data: {
        subUserId: user.id,
        userId: subUser.userId,
        type,
        amount: amount,
        currency: 'INR',
        description: description || '',
        relatedPaymentId: relatedPaymentId || null,
        status: 'completed',
      },
    });

    await logActivity({
      user,
      action: 'view_transactions',
      resource: 'transaction',
      resourceId: transaction.id,
      metadata: { type, amount },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: user.id,
    });

    return safeJson({ success: true, data: serializeBigInt(transaction) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/subuser/transactions error:', error);
    return safeJson(
      { error: 'Failed to create transaction' },
      { status: 500 }
    );
  }
}

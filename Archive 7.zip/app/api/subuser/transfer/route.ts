import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { requireRole } from '@/lib/roles';
import { toPaise } from '@/lib/money';

export async function POST(req: NextRequest) {
  // allow SUBUSER role
  const rc = await requireRole(req, ['ADMIN', 'USER']);
  if (rc instanceof NextResponse) return rc;

  // enforce subuser usage: check x-subuser-id header
  const subId = req.headers.get('x-subuser-id') || null;
  if (!subId) return NextResponse.json({ error: 'subuser id required' }, { status: 400 });

  const sub = await prisma.subUser.findUnique({ where: { id: subId } });
  if (!sub || !sub.isActive) return NextResponse.json({ error: 'subuser not allowed' }, { status: 403 });

  const { amount, beneficiary } = await req.json().catch(() => ({}));
  if (!amount || !beneficiary) return NextResponse.json({ error: 'invalid payload' }, { status: 400 });

  // create a payout row (queued) - amount in Paise (BigInt)
  const amountInPaise = toPaise(amount);
  const p = await prisma.payout.create({ data: { userId: sub.userId, beneficiary: beneficiary.name ?? String(beneficiary), account: beneficiary.account ?? '', amount: amountInPaise, currency: 'INR' } });

  // Serialize BigInt for JSON response
  const responsePayout = {
    ...p,
    amount: p.amount.toString(),
  };

  return NextResponse.json({ success: true, payout: responsePayout });
}

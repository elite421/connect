import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const subUserId = searchParams.get('subUserId');
    const targetSubUserId = user.role === 'ADMIN' ? (subUserId || user.id) : user.id;

    const ips = await prisma.subUserIpWhitelist.findMany({
      where: { subUserId: targetSubUserId },
      orderBy: { createdAt: 'desc' },
    });

    await logActivity({
      user,
      action: 'view_transactions',
      resource: 'ip_whitelist',
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: targetSubUserId,
    });

    return NextResponse.json({ success: true, data: serializeBigInt(ips) });
  } catch (error) {
    console.error('GET /api/subuser/ip-whitelist error:', error);
    return NextResponse.json({ error: 'Failed to fetch IP whitelist' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const subUserId = searchParams.get('subUserId');
    const targetSubUserId = user.role === 'ADMIN' ? (subUserId || user.id) : user.id;

    const body = await req.json();
    const { ipAddress, label } = body;

    if (!ipAddress) {
      return NextResponse.json({ error: 'IP address is required' }, { status: 400 });
    }

    const ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    const cidrRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\/(?:[0-9]|[1-2][0-9]|3[0-2])$/;
    
    if (!ipRegex.test(ipAddress) && !cidrRegex.test(ipAddress)) {
      return NextResponse.json({ error: 'Invalid IP address format' }, { status: 400 });
    }

    const subUser = await prisma.subUser.findUnique({
      where: { id: targetSubUserId },
    });

    if (!subUser) {
      return NextResponse.json({ error: 'SubUser not found' }, { status: 404 });
    }

    const ip = await prisma.subUserIpWhitelist.create({
      data: {
        subUserId: targetSubUserId,
        ipAddress,
        label: label || null,
        isActive: true,
      },
    });

    await logActivity({
      user,
      action: 'view_transactions',
      resource: 'ip_whitelist',
      resourceId: ip.id,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: targetSubUserId,
    });

    return NextResponse.json({ success: true, data: serializeBigInt(ip) }, { status: 201 });
  } catch (error: any) {
    console.error('POST /api/subuser/ip-whitelist error:', error);
    if (error.code === '23505') {
      return NextResponse.json({ error: 'IP address already whitelisted' }, { status: 400 });
    }
    return NextResponse.json({ error: 'Failed to add IP to whitelist' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { id, label, isActive } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID is required' }, { status: 400 });
    }

    const updateData: any = {};
    if (label !== undefined) updateData.label = label;
    if (isActive !== undefined) updateData.isActive = isActive;

    await prisma.subUserIpWhitelist.update({
      where: { id },
      data: serializeBigInt(updateData),
    });

    await logActivity({
      user,
      action: 'view_transactions',
      resource: 'ip_whitelist',
      resourceId: id,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ success: true, message: 'IP updated' });
  } catch (error) {
    console.error('PATCH /api/subuser/ip-whitelist error:', error);
    return NextResponse.json({ error: 'Failed to update IP' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    const subUserId = searchParams.get('subUserId');
    const targetSubUserId = user.role === 'ADMIN' ? (subUserId || user.id) : user.id;

    if (!id) {
      return NextResponse.json({ error: 'ID is required' }, { status: 400 });
    }

    await prisma.subUserIpWhitelist.deleteMany({
      where: { id, subUserId: targetSubUserId },
    });

    await logActivity({
      user,
      action: 'view_transactions',
      resource: 'ip_whitelist',
      resourceId: id,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: targetSubUserId,
    });

    return NextResponse.json({ success: true, message: 'IP removed from whitelist' });
  } catch (error) {
    console.error('DELETE /api/subuser/ip-whitelist error:', error);
    return NextResponse.json({ error: 'Failed to delete IP' }, { status: 500 });
  }
}

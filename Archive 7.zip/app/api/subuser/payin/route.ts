import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { toPaise, toRupees } from '@/lib/money';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const subuser = await prisma.subUser.findUnique({
      where: { id: user.id },
      select: { userId: true }
    });

    if (!subuser) {
      return safeJson({ error: 'SubUser not found' }, { status: 404 });
    }

    const transactions = await prisma.payInTransaction.findMany({
      where: { userId: subuser.userId },
      orderBy: { createdAt: 'desc' },
      take: 100
    });

    const serializedTransactions = transactions.map(tx => ({
      ...tx,
      amount: toRupees(tx.amount), // Display Rupees
      amountPaise: tx.amount.toString(),
    }));

    return safeJson({ success: true, data: serializeBigInt(serializedTransactions) });
  } catch (error) {
    console.error('GET /api/subuser/payin error:', error);
    return safeJson({ error: 'Failed to fetch payins' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const subuser = await prisma.subUser.findUnique({
      where: { id: user.id },
      select: { userId: true }
    });

    if (!subuser) {
      return safeJson({ error: 'SubUser not found' }, { status: 404 });
    }

    const body = await req.json();
    const { amount, customerName, customerEmail, customerPhone } = body;

    if (!amount || amount <= 0) {
      return safeJson({ error: 'Valid amount is required' }, { status: 400 });
    }

    const transaction = await prisma.payInTransaction.create({
      data: {
        userId: subuser.userId,
        amount: toPaise(amount),
        status: 'pending',
        paymentMethod: 'upi',
        customerName: customerName || null,
        customerEmail: customerEmail || null,
        customerPhone: customerPhone || null,
        merchantTransactionId: `PAYIN_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`,
      }
    });

    return safeJson({
      success: true,
      data: {
        ...transaction,
        amount: toRupees(transaction.amount),
        amountPaise: transaction.amount.toString(),
      }
    }, { status: 201 });
  } catch (error) {
    console.error('POST /api/subuser/payin error:', error);
    return safeJson({ error: 'Failed to create payin' }, { status: 500 });
  }
}


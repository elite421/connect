import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { toPaise } from '@/lib/money';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  let timeoutId: NodeJS.Timeout | null = null;

  try {
    const body = await req.json();
    const {
      amount, // Assuming Rupees
      customerName,
      customerEmail,
      customerPhone,
      paymentMethod = 'upi',
      merchantTransactionId,
      serviceId,
    } = body;

    if (!amount || !paymentMethod) {
      return NextResponse.json(
        { error: 'Amount and payment method required' },
        { status: 400 }
      );
    }

    const ipAddress = extractIpAddress(req);

    const subuser = await prisma.subUser.findUnique({
      where: { id: user.id },
      include: { user: true },
    });

    if (!subuser) {
      return NextResponse.json({ error: 'SubUser not found' }, { status: 404 });
    }

    const transaction = await prisma.payInTransaction.create({
      data: {
        userId: subuser.userId,
        amount: toPaise(amount),
        customerName: customerName || null,
        customerEmail: customerEmail || null,
        customerPhone: customerPhone || null,
        paymentMethod,
        merchantTransactionId: merchantTransactionId || null,
        ipAddress,
        status: 'pending',
      },
    });

    let apiData: any = null;
    let gatewayResponse: any = null;
    let gatewayError: string | null = null;

    try {
      if (serviceId) {
        const subUserService = await prisma.subUserService.findUnique({
          where: {
            subUserId_serviceId: {
              subUserId: user.id,
              serviceId: serviceId,
            },
          },
        });

        if (!subUserService || !subUserService.isActive) {
          return NextResponse.json(
            { error: 'Service not available for this subuser' },
            { status: 400 }
          );
        }
      }

      // Resolve API with admin default fallback
      async function resolvePayinApiForUser(userId: string) {
        const account = await prisma.user.findUnique({ where: { id: userId } });
        if (account?.defaultApiId) {
          const explicit = await prisma.userApi.findFirst({ where: { id: account.defaultApiId, isActive: true } });
          if (explicit) return explicit;
        }
        const userDefault = await prisma.userApi.findFirst({ where: { userId, isActive: true, isDefault: true }, orderBy: { createdAt: 'desc' } });
        if (userDefault) return userDefault;
        const anyUserApi = await prisma.userApi.findFirst({ where: { userId, isActive: true }, orderBy: { createdAt: 'desc' } });
        if (anyUserApi) return anyUserApi;
        const adminDefault = await prisma.userApi.findFirst({ where: { isDefault: true, isActive: true, user: { role: 'ADMIN' as any } }, orderBy: { createdAt: 'desc' } });
        if (adminDefault) return adminDefault;
        const systemDefault = await prisma.userApi.findFirst({ where: { isDefault: true, isActive: true }, orderBy: { createdAt: 'desc' } });
        return systemDefault;
      }

      const resolvedApi = await resolvePayinApiForUser(subuser.userId);
      if (!resolvedApi || !resolvedApi.baseUrl) {
        return NextResponse.json(
          { error: 'No payment API configured. Contact admin to set a default API.' },
          { status: 400 }
        );
      }
      apiData = resolvedApi;

      const scopes = (() => { try { return apiData.scopes ? JSON.parse(apiData.scopes) : {}; } catch { return {}; } })();
      const callbackUrl = scopes?.callbackUrl || `${process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/payin`;

      // Build headers generically
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (apiData.authHeader && (apiData.apiToken || apiData.apiKey)) {
        headers[String(apiData.authHeader)] = String(apiData.apiToken || apiData.apiKey);
      } else if (apiData.apiToken) {
        headers['Authorization'] = `Bearer ${apiData.apiToken}`;
      } else if (apiData.apiKey && apiData.apiSecret) {
        const basic = Buffer.from(`${apiData.apiKey}:${apiData.apiSecret}`).toString('base64');
        headers['Authorization'] = `Basic ${basic}`;
      } else if (apiData.apiKey) {
        headers['X-API-Key'] = String(apiData.apiKey);
      }

      // Determine endpoint
      let endpoint = apiData.baseUrl as string;
      if (scopes?.payinEndpoint) endpoint = String(scopes.payinEndpoint);

      // Build request payload
      let requestPayload: Record<string, any> = {
        memberId: apiData.apiKey?.substring(0, 10) || subuser.userId.substring(0, 10),
        amount: Number(amount).toString(), // Gateway usually expects Rupees
        mobile: customerPhone || '9000000000',
        orderid: merchantTransactionId || transaction.id,
      };
      if (scopes?.requestTemplate) {
        try {
          const template = JSON.parse(scopes.requestTemplate);
          requestPayload = { ...template, ...requestPayload };
        } catch { }
      }
      if (callbackUrl) {
        requestPayload.callback_url = callbackUrl;
        requestPayload.callbackUrl = callbackUrl;
      }

      const controller = new AbortController();
      timeoutId = setTimeout(() => controller.abort(), 30000);

      const gatewayCall = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify(requestPayload),
        signal: controller.signal,
      });

      if (timeoutId) clearTimeout(timeoutId);

      const responseText = await gatewayCall.text();
      try {
        gatewayResponse = JSON.parse(responseText);
      } catch {
        gatewayResponse = { raw: responseText };
      }

      await prisma.payInTransaction.update({
        where: { id: transaction.id },
        data: {
          status: gatewayCall.ok ? 'processing' : 'failed',
          merchantTransactionId: gatewayResponse?.orderId || gatewayResponse?.trxId || merchantTransactionId || transaction.id,
        },
      });

      await logActivity({
        user: subuser.user,
        action: 'create_payment',
        resource: 'payin',
        resourceId: transaction.id,
        metadata: {
          amount,
          paymentMethod,
          gateway: apiData.name || 'Default Gateway',
          status: gatewayCall.ok ? 'success' : 'failed',
          subuserId: user.id,
        },
        ipAddress,
        userAgent: getUserAgent(req),
      });

      if (!gatewayCall.ok) {
        return NextResponse.json({
          success: false,
          error: 'Gateway API error',
          transaction: serializeBigInt(transaction),
          gatewayError: gatewayResponse?.message || 'Unknown error',
        });
      }

      return NextResponse.json({
        success: true,
        transaction: serializeBigInt(transaction),
        gatewayResponse,
        paymentLink: gatewayResponse?.url || null,
      });
    } catch (error: any) {
      if (timeoutId) clearTimeout(timeoutId);

      let errorMsg = 'Failed to initiate payment';
      if (error.code === 'ECONNREFUSED') {
        errorMsg = 'Gateway unreachable';
      } else if (error.code === 'ENOTFOUND') {
        errorMsg = 'Gateway endpoint not found';
      } else if (error.name === 'AbortError') {
        errorMsg = 'Gateway request timeout';
      }

      gatewayError = errorMsg;

      await prisma.payInTransaction.update({
        where: { id: transaction.id },
        data: {
          status: 'failed',
        },
      });

      return NextResponse.json({
        success: false,
        error: errorMsg,
        transaction: serializeBigInt(transaction),
      });
    }
  } catch (error: any) {
    console.error('POST /api/subuser/payin/initiate error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to initiate payment' },
      { status: 500 }
    );
  }
}

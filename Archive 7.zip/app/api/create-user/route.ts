import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { hash } from "bcryptjs";
export async function POST(req: Request) {
    const body = await req.json().catch(() => ({}));
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const email = typeof body.email === "string" ? body.email.trim() : "";
    const password = typeof body.password === "string" ? body.password.trim() : "";
    const phone = typeof body.phone === "string" ? body.phone.trim() : "";
    const passwordHash = await hash(password, 10);
    if (!name || !email || !phone || !password) {
        return NextResponse.json({ success: false, message: "All field is required" }, { status: 400 });
    }

    // Check if user already exists
    const existing = await prisma.user.findUnique({ where: { email } });

    if (existing) {
        return NextResponse.json({ success: false, message: "User already exists" }, { status: 409 });
    }

    await prisma.user.create({
        data: {
            username: name, // Assuming 'username' corresponds to 'name'
            name,
            email,
            phone,
            password: passwordHash,
            publicId: `${Math.random().toString(36).substring(2, 6).toUpperCase()}${Math.floor(1000 + Math.random() * 9000)}`, // 4 letters + 4 digits
        },
    });

    return NextResponse.json({ success: true });
}

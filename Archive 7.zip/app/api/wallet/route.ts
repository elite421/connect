import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { toRupees } from "@/lib/money";

export async function GET() {
  const session = await auth();
  const userId = (session?.user as { id?: string })?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  // Find or create wallet
  let wallet = await prisma.walletsDb.findFirst({
    where: { ownerType: "user", ownerId: userId },
  });

  if (!wallet) {
    wallet = await prisma.walletsDb.create({
      data: { ownerType: "user", ownerId: userId, currency: "INR", balance: 0 },
    });
  }

  const transactions = await prisma.walletTransaction.findMany({
    where: { walletId: wallet.id },
    orderBy: { createdAt: "desc" },
    take: 10,
  });

  return NextResponse.json({
    id: wallet.id,
    currency: wallet.currency,
    balance: toRupees(wallet.balance), // Display Rupees
    transactions: transactions.map((t) => ({
      id: t.id,
      txType: t.txType,
      amount: toRupees(t.amount),
      balanceAfter: toRupees(t.balanceAfter),
      currency: t.currency,
      createdAt: t.createdAt,
      referenceType: t.referenceType,
      referenceId: t.referenceId,
    })),
  });
}

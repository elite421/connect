import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import prisma from "@/lib/prisma";
import crypto from "crypto";

function encryptSecret(secret: Record<string, string>, keyB64: string) {
  const key = Buffer.from(keyB64, "base64");
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const ct = Buffer.concat([cipher.update(JSON.stringify(secret), "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return JSON.stringify({ iv: iv.toString("base64"), tag: tag.toString("base64"), ct: ct.toString("base64") });
}

export async function GET() {
  const session = await auth();
  const userId = (session as { user?: { id?: string } }).user?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const items = await prisma.userIntegration.findMany({ where: { userId }, orderBy: { createdAt: "desc" } });
  return NextResponse.json(items.map(i => ({ id: i.id, code: i.code, baseUrl: i.baseUrl, createdAt: i.createdAt })));
}

export async function POST(req: Request) {
  const session = await auth();
  const userId = (session as { user?: { id?: string } }).user?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const code = typeof body.code === "string" ? body.code.trim() : "";
  const baseUrl = typeof body.baseUrl === "string" ? body.baseUrl.trim() : "";
  const apiKey = typeof body.apiKey === "string" ? body.apiKey.trim() : "";
  const apiSalt = typeof body.apiSalt === "string" ? body.apiSalt.trim() : "";
  const credentials = typeof body.credentials === "string" ? body.credentials.trim() : "";
  const tokenSelector = typeof body.tokenSelector === "string" ? body.tokenSelector.trim() : "";
  if (!code || !baseUrl) return NextResponse.json({ error: "Code and baseUrl are required" }, { status: 400 });
  if (!(apiKey || apiSalt || credentials || tokenSelector)) return NextResponse.json({ error: "At least one secret field is required" }, { status: 400 });
  const kmsKey = process.env.CRYPTO_KEY || "";
  if (!kmsKey) return NextResponse.json({ error: "Missing CRYPTO_KEY" }, { status: 500 });
  const secret: Record<string, string> = {};
  if (apiKey) secret.apiKey = apiKey;
  if (apiSalt) secret.apiSalt = apiSalt;
  if (credentials) secret.credentials = credentials;
  if (tokenSelector) secret.tokenSelector = tokenSelector;
  const encrypted = encryptSecret(secret, kmsKey);
  const existing = await prisma.userIntegration.findFirst({ where: { userId, code } });
  if (existing) {
    const updated = await prisma.userIntegration.update({ where: { id: existing.id }, data: { baseUrl, apiKeyEncrypted: encrypted } });
    return NextResponse.json({ id: updated.id });
  }
  const created = await prisma.userIntegration.create({ data: { userId, code, baseUrl, apiKeyEncrypted: encrypted } });
  return NextResponse.json({ id: created.id }, { status: 201 });
}

export async function DELETE(req: Request) {
  const session = await auth();
  const userId = (session as { user?: { id?: string } }).user?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id") || "";
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
  const item = await prisma.userIntegration.findFirst({ where: { id, userId } });
  if (!item) return NextResponse.json({ error: "Not found" }, { status: 404 });
  await prisma.userIntegration.delete({ where: { id } });
  return NextResponse.json({ success: true });
}

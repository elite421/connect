import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { initiateRudraxPayPayin } from '@/lib/rudraxpay-integration';


export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  let timeoutId: NodeJS.Timeout | null = null;

  try {
    const body = await req.json();
    const {
      amount,
      customerName,
      customerEmail,
      customerPhone,
      paymentMethod = 'upi',
      merchantTransactionId,
      serviceId,
    } = body;

    if (!amount || !paymentMethod) {
      return NextResponse.json(
        { error: 'Amount and payment method required' },
        { status: 400 }
      );
    }

    const ipAddress = extractIpAddress(req);

    // Store in Paise
    const transaction = await prisma.payInTransaction.create({
      data: {
        userId: user.id,
        amount: Number(amount),
        customerName: customerName || null,
        customerEmail: customerEmail || null,
        customerPhone: customerPhone || null,
        paymentMethod,
        merchantTransactionId: merchantTransactionId || null,
        ipAddress,
        status: 'pending',
      },
    });

    let apiData: any = null;
    let gatewayResponse: any = null;
    let gatewayError: string | null = null;

    try {
      // Helper: resolve the API to use for pay-in, with admin default fallback
      async function resolvePayinApiForUser(userId: string) {
        // 0) Check CustomPaymentApi for User (Modern System)
        // We check for user-defined or admin-provided generic APIs assigned to this user
        // Filter by apiType = 'PAYIN'
        const customApi = await prisma.customPaymentApi.findFirst({
          where: {
            userId,
            isActive: true,
            apiType: 'PAYIN' // Only pick PayIn APIs
          },
          orderBy: { isDefault: 'desc' } // Prefer default
        });

        if (customApi) {
          // Map CustomPaymentApi to the structure expected below (similar to UserApi)
          return {
            id: customApi.id,
            name: customApi.apiName,
            baseUrl: customApi.apiBaseUrl,
            apiKey: customApi.apiKey, // bearer token or api key
            apiSecret: customApi.apiSecret,
            authHeader: customApi.authHeader,
            scopes: JSON.stringify({
              payinEndpoint: customApi.apiEndpoint,
              requestTemplate: customApi.requestFormat ? JSON.stringify(customApi.requestFormat) : null,
              // custom apis might not have callbackUrl in scopes, handle gracefully
            })
          };
        }


        // 1) If user has explicit defaultApiId and it's active (Legacy UserApi)
        const account = await prisma.user.findUnique({ where: { id: userId } });
        if (account?.defaultApiId) {
          const explicit = await prisma.userApi.findFirst({ where: { id: account.defaultApiId, isActive: true } });
          if (explicit) return explicit;
        }

        // 2) User's explicitly marked default (Legacy UserApi)
        const userDefault = await prisma.userApi.findFirst({ where: { userId, isActive: true, isDefault: true }, orderBy: { createdAt: 'desc' } });
        if (userDefault) return userDefault;

        // 3) Any active API for the user (Legacy UserApi)
        const anyUserApi = await prisma.userApi.findFirst({ where: { userId, isActive: true }, orderBy: { createdAt: 'desc' } });
        if (anyUserApi) return anyUserApi;

        // 4) Check for Global/Admin CustomPaymentApi (Modern System Fallback)
        const adminCustomApi = await prisma.customPaymentApi.findFirst({
          where: {
            adminProvided: true,
            isActive: true,
            apiType: 'PAYIN'
          },
          orderBy: { isDefault: 'desc' }
        });

        if (adminCustomApi) {
          return {
            id: adminCustomApi.id,
            name: adminCustomApi.apiName,
            baseUrl: adminCustomApi.apiBaseUrl,
            apiKey: adminCustomApi.apiKey,
            apiSecret: adminCustomApi.apiSecret,
            authHeader: adminCustomApi.authHeader,
            scopes: JSON.stringify({
              payinEndpoint: adminCustomApi.apiEndpoint,
              requestTemplate: adminCustomApi.requestFormat ? JSON.stringify(adminCustomApi.requestFormat) : null,
            })
          };
        }

        // 5) Admin-owned default (global) (Legacy UserApi Fallback)
        const adminDefault = await prisma.userApi.findFirst({ where: { isDefault: true, isActive: true, user: { role: 'ADMIN' as any } }, orderBy: { createdAt: 'desc' } });
        if (adminDefault) return adminDefault;

        // 6) Any default active API in system (Legacy UserApi Fallback)
        const systemDefault = await prisma.userApi.findFirst({ where: { isDefault: true, isActive: true }, orderBy: { createdAt: 'desc' } });
        return systemDefault;
      }

      // Resolve API
      const resolvedApi = await resolvePayinApiForUser(user.id);
      if (!resolvedApi) {
        return NextResponse.json(
          { error: 'No payment API configured. Contact admin to set a default API.' },
          { status: 400 }
        );
      }
      apiData = resolvedApi;

      // RUDRAXPAY BRIDGE
      if ((apiData.baseUrl && apiData.baseUrl.includes('rudraxpay.com')) || (apiData.name && apiData.name.toLowerCase().includes('rudrax'))) {
        // Allow overriding userid from headers (User Request)
        const headerUserId = req.headers.get('userid');
        const userid = headerUserId || apiData.apiKey;
        const token = apiData.apiSecret || apiData.apiToken;

        if (!userid || !token) {
          return NextResponse.json({ error: 'RudraxPay configuration missing UserID (API Key) or Token (API Secret)' }, { status: 400 });
        }

        const rudraxRes = await initiateRudraxPayPayin(
          apiData.baseUrl || 'https://merchant.rudraxpay.com/api',
          { userid, token },
          {
            amount: Number(amount),
            name: customerName || 'Customer',
            mobile: customerPhone || '9999999999',
            orderid: merchantTransactionId || transaction.id,
            callbackUrl: `${process.env.NEXT_PUBLIC_APP_URL}/api/callback/rudraxpay/payin`
          }
        );

        await prisma.payInTransaction.update({
          where: { id: transaction.id },
          data: {
            status: rudraxRes.success ? 'processing' : 'failed',
            merchantTransactionId: merchantTransactionId || transaction.id,
            responseData: rudraxRes.raw
          }
        });

        if (rudraxRes.success && rudraxRes.url) {
          return NextResponse.json({
            success: true,
            transaction,
            gatewayResponse: rudraxRes.raw,
            paymentLink: rudraxRes.url
          });
        } else {
          return NextResponse.json({
            success: false,
            error: rudraxRes.message || 'Payment initiation failed',
            transaction,
            gatewayResponse: rudraxRes.raw
          });
        }
      }
      // END RUDRAXPAY BRIDGE

      const scopes = (() => { try { return apiData.scopes ? JSON.parse(apiData.scopes) : {}; } catch { return {}; } })();
      const callbackUrl = scopes?.callbackUrl || `${process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/payin`;

      // Build headers similar to payout integration
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (apiData.authHeader && (apiData.apiToken || apiData.apiKey)) {
        headers[String(apiData.authHeader)] = String(apiData.apiToken || apiData.apiKey);
      } else if (apiData.apiToken) {
        headers['Authorization'] = `Bearer ${apiData.apiToken}`;
      } else if (apiData.apiKey && apiData.apiSecret) {
        const basic = Buffer.from(`${apiData.apiKey}:${apiData.apiSecret}`).toString('base64');
        headers['Authorization'] = `Basic ${basic}`;
      } else if (apiData.apiKey) {
        // Bearer fallback if no authHeader specified but apiKey exists? 
        // Or if legacy used apiKey as Bearer token? 
        // Legacy code usually put apiKey in generic header or Bearer if authHeader missing. 
        // Let's stick to existing logic for consistency or improve.
        // Existing logic:
        if (!headers['Authorization'] && !headers['X-API-Key']) {
          headers['Authorization'] = `Bearer ${apiData.apiKey}`;
        }
      }

      // Determine endpoint
      let endpoint = apiData.baseUrl as string;
      if (scopes?.payinEndpoint) endpoint = String(scopes.payinEndpoint);
      if (!endpoint) {
        return NextResponse.json(
          { error: 'Payment API endpoint not configured' },
          { status: 400 }
        );
      }

      // If endpoint is relative, append to baseUrl
      if (endpoint.startsWith('/') && apiData.baseUrl) {
        endpoint = `${apiData.baseUrl.replace(/\/$/, '')}${endpoint}`;
      }

      // Build request payload
      // Send Rupees to Gateway
      let requestPayload: Record<string, any> = {
        memberId: apiData.apiKey?.substring(0, 10) || user.id.substring(0, 10),
        amount: Number(amount).toString(),
        mobile: customerPhone || '9000000000',
        orderid: merchantTransactionId || transaction.id,
      };
      if (scopes?.requestTemplate) {
        try {
          const template = typeof scopes.requestTemplate === 'string' ? JSON.parse(scopes.requestTemplate) : scopes.requestTemplate;
          // Replace placeholders
          const rawTemplate = JSON.stringify(template);
          const replacedTemplate = rawTemplate
            .replace(/{{amount}}/g, String(amount))
            .replace(/{{transactionId}}/g, transaction.id)
            .replace(/{{customerName}}/g, customerName || '')
            .replace(/{{customerEmail}}/g, customerEmail || '')
            .replace(/{{customerPhone}}/g, customerPhone || '');

          requestPayload = JSON.parse(replacedTemplate);

          // Merge with defaults if needed, or just use payload? 
          // Usually strict template is better.
        } catch { }
      }

      if (callbackUrl) {
        // Some APIs expect specific keys for callback
        if (!requestPayload.callback_url && !requestPayload.callbackUrl) {
          requestPayload.callback_url = callbackUrl;
        }
      }

      const controller = new AbortController();
      timeoutId = setTimeout(() => controller.abort(), 30000);

      const gatewayCall = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify(requestPayload),
        signal: controller.signal,
      });

      if (timeoutId) clearTimeout(timeoutId);

      const responseText = await gatewayCall.text();
      try {
        gatewayResponse = JSON.parse(responseText);
      } catch {
        gatewayResponse = { raw: responseText };
      }

      await prisma.payInTransaction.update({
        where: { id: transaction.id },
        data: {
          status: gatewayCall.ok ? 'processing' : 'failed',
          // Use gateway response ID or fallback
          merchantTransactionId: gatewayResponse?.orderId || gatewayResponse?.trxId || merchantTransactionId || transaction.id,
          responseData: gatewayResponse
        },
      });

      await logActivity({
        user,
        action: 'create_payment',
        resource: 'payin',
        resourceId: transaction.id,
        metadata: {
          amount,
          paymentMethod,
          gateway: apiData.name || 'Default Gateway',
          status: gatewayCall.ok ? 'success' : 'failed',
        },
        ipAddress,
        userAgent: getUserAgent(req),
      });

      // Response transaction needs amount in Rupees
      const responseTransaction = transaction;

      if (!gatewayCall.ok) {
        return NextResponse.json({
          success: false,
          error: 'Gateway API error',
          transaction: responseTransaction,
          gatewayError: gatewayResponse?.message || 'Unknown error',
        });
      }

      return NextResponse.json({
        success: true,
        transaction: responseTransaction,
        gatewayResponse,
        paymentLink: gatewayResponse?.url || gatewayResponse?.payment_url || null,
      });
    } catch (error: any) {
      if (timeoutId) clearTimeout(timeoutId);

      let errorMsg = 'Failed to initiate payment';
      if (error.code === 'ECONNREFUSED') {
        errorMsg = 'Gateway unreachable';
      } else if (error.code === 'ENOTFOUND') {
        errorMsg = 'Gateway endpoint not found';
      } else if (error.name === 'AbortError') {
        errorMsg = 'Gateway request timeout';
      }

      gatewayError = errorMsg;

      await prisma.payInTransaction.update({
        where: { id: transaction.id },
        data: {
          status: 'failed',
          responseData: { error: errorMsg }
        },
      });

      return NextResponse.json({
        success: false,
        error: errorMsg,
        transaction: transaction,
      });
    }
  } catch (error: any) {
    console.error('POST /api/user/payin/initiate error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to initiate payment' },
      { status: 500 }
    );
  }
}

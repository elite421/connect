import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';
import GatewayIntegrationService from '@/lib/gateway-integration';
import { toPaise } from '@/lib/money';

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const userId = (session.user as any).id;
    const {
      amount,
      customerName,
      customerEmail,
      customerPhone,
      paymentMethod,
      merchantTransactionId,
      gatewayId,
    } = await req.json();

    if (!amount || !gatewayId) {
      return NextResponse.json(
        { error: 'Amount and gateway are required' },
        { status: 400 }
      );
    }

    // 1. Try finding in GatewayIntegration (User Defined)
    const integration = await prisma.gatewayIntegration.findUnique({
      where: { id: gatewayId },
      include: { endpointConfigs: true },
    });

    // 2. If not found, Try finding in CustomPaymentApi (Admin/User Assigned)
    if (!integration) {
      const customApi = await prisma.customPaymentApi.findUnique({
        where: { id: gatewayId },
      });

      if (customApi && (customApi.userId === userId || customApi.adminProvided) && customApi.apiType === 'PAYIN') {
        // HANDLE CUSTOM API (RudraxPay or Generic)

        const transactionRecord = await prisma.payInTransaction.create({
          data: {
            userId,
            amount: toPaise(amount),
            customerName,
            customerEmail,
            customerPhone,
            paymentMethod: paymentMethod || 'upi',
            merchantTransactionId,
            customApiId: gatewayId,
            gatewayId: null, // Ensure we don't try to link to GatewayIntegration
            status: 'pending',
          },
        });

        // RUDRAXPAY Logic (from initiate/route.ts)
        if ((customApi.apiBaseUrl && customApi.apiBaseUrl.includes('rudraxpay.com')) || (customApi.apiName && customApi.apiName.toLowerCase().includes('rudrax'))) {
          const { initiateRudraxPayPayin } = await import('@/lib/rudraxpay-integration');

          // Allow overriding userid from headers
          const headerUserId = req.headers.get('userid');
          const userid = headerUserId || customApi.apiKey;
          const token = customApi.apiSecret;
          // Note: In schema it might be apiToken, need check. Assuming keys map to our convention.

          if (!userid || !token) {
            return NextResponse.json({ error: 'Configuration missing Credentials' }, { status: 400 });
          }

          const rudraxRes = await initiateRudraxPayPayin(
            customApi.apiBaseUrl || 'https://merchant.rudraxpay.com/api',
            { userid, token },
            {
              amount: Number(amount),
              name: customerName || 'Customer',
              mobile: customerPhone || '9999999999',
              orderid: merchantTransactionId || transactionRecord.id,
              callbackUrl: `${process.env.NEXT_PUBLIC_APP_URL}/api/callback/rudraxpay/payin`
            }
          );

          await prisma.payInTransaction.update({
            where: { id: transactionRecord.id },
            data: {
              status: rudraxRes.success ? 'processing' : 'failed',
              merchantTransactionId: merchantTransactionId || transactionRecord.id, // Ensure we keep track
              responseData: rudraxRes.raw
            }
          });

          if (rudraxRes.success && rudraxRes.url) {
            return NextResponse.json({
              success: true,
              transactionId: transactionRecord.id,
              paymentLink: rudraxRes.url,
              status: 'processing'
            });
          } else {
            return NextResponse.json({
              success: false,
              error: rudraxRes.message || 'Payment initiation failed',
              gatewayError: rudraxRes.message
            }, { status: 400 });
          }
        }

        // Generic Custom API Handling (Placeholder for now, or copy generic logic)
        return NextResponse.json({ error: 'Generic Custom API execution not fully ported to this route yet' }, { status: 501 });

      }
    }

    if (!integration || integration.userId !== userId) {
      return NextResponse.json(
        { error: 'Gateway not found or unauthorized' },
        { status: 404 }
      );
    }

    const integrationService = new GatewayIntegrationService(prisma);

    const transactionRecord = await prisma.payInTransaction.create({
      data: {
        userId,
        amount: toPaise(amount), // Store as Paise
        customerName,
        customerEmail,
        customerPhone,
        paymentMethod: paymentMethod || 'upi',
        merchantTransactionId,
        gatewayId,
        status: 'pending',
      },
    });

    const response = await integrationService.initiatePayment(
      gatewayId,
      {
        amount,
        customerName,
        customerEmail,
        customerPhone,
        paymentMethod,
        metadata: {
          transactionId: transactionRecord.id,
          merchantTransactionId,
        },
      },
      (integration.apiSchema as any)?.fieldMappings
    );

    if (response.success) {
      await prisma.payInTransaction.update({
        where: { id: transactionRecord.id },
        data: {
          externalTransactionId: response.transactionId,
          utrNumber: response.utrNumber,
          responseData: response.raw,
          status: response.status || 'pending',
        },
      });

      await integrationService.logTransaction(
        gatewayId,
        transactionRecord.id,
        {
          amount,
          customerName,
          customerEmail,
          customerPhone,
          paymentMethod,
        },
        response.raw,
        response.utrNumber,
        response.status
      );

      return NextResponse.json({
        success: true,
        transactionId: transactionRecord.id,
        paymentLink: response.paymentLink,
        externalTransactionId: response.transactionId,
        utrNumber: response.utrNumber,
        status: response.status,
      });
    } else {
      await prisma.payInTransaction.update({
        where: { id: transactionRecord.id },
        data: {
          status: 'failed',
          responseData: { error: response.message },
        },
      });

      return NextResponse.json(
        {
          success: false,
          error: response.message,
          gatewayError: response.message,
        },
        { status: 400 }
      );
    }
  } catch (error: any) {
    console.error('Payment initiation error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to initiate payment' },
      { status: 500 }
    );
  }
}

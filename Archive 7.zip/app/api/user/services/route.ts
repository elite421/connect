import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const allServices = await prisma.service.findMany({
      where: { isActive: true },
      orderBy: { createdAt: 'asc' },
    });

    const userServices = await prisma.userService.findMany({
      where: { userId: user.id },
      select: { serviceId: true, isActive: true, id: true, config: true },
    });

    const userServiceMap = new Map(
      userServices.map((us) => [us.serviceId, { id: us.id, isActive: us.isActive, config: us.config }])
    );

    const servicesWithActivation = allServices.map((service) => {
      const userService = userServiceMap.get(service.id);
      return {
        id: userService?.id || null,
        serviceId: service.id,
        service,
        isActive: userService?.isActive || false,
        config: userService?.config || null,
      };
    });

    return safeJson({ success: true, data: serializeBigInt(servicesWithActivation) });
  } catch (error) {
    console.error('GET /api/user/services error:', error);
    return safeJson({ error: 'Failed to fetch services' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { serviceId, config, isActive } = body;

    if (!serviceId) {
      return safeJson({ error: 'Service ID required' }, { status: 400 });
    }

    const existingService = await prisma.userService.findFirst({
      where: {
        userId: user.id,
        serviceId,
      },
    });

    let userService;
    if (existingService) {
      userService = await prisma.userService.update({
        where: { id: existingService.id },
        data: { 
          ...(config && { config }),
          ...(isActive !== undefined && { isActive }),
        },
        include: { service: true },
      });
    } else {
      userService = await prisma.userService.create({
        data: {
          userId: user.id,
          serviceId,
          config: config || null,
          isActive: isActive === true,
        },
        include: { service: true },
      });
    }

    await logActivity({
      user,
      action: 'activate_service',
      resource: 'service',
      resourceId: serviceId,
      metadata: { config, isActive },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return safeJson({ success: true, data: serializeBigInt(userService) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/services error:', error);
    return safeJson({ error: 'Failed to activate service' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { userServiceId, isActive, config, transactionCharge, transactionChargeType } = body;

    if (!userServiceId) {
      return safeJson({ error: 'User Service ID required' }, { status: 400 });
    }

    const updateData: any = {};
    if (isActive !== undefined) updateData.isActive = isActive;
    if (config !== undefined) updateData.config = config;
    if (transactionCharge !== undefined) updateData.transactionCharge = transactionCharge;
    if (transactionChargeType !== undefined) updateData.transactionChargeType = transactionChargeType;

    const userService = await prisma.userService.update({
      where: { id: userServiceId },
      data: serializeBigInt(updateData),
      include: { service: true },
    });

    const action = isActive !== undefined ? (isActive ? 'activate_service' : 'deactivate_service') : 'update_service_charges';
    await logActivity({
      user,
      action: action as any,
      resource: 'service',
      resourceId: userService.serviceId,
      metadata: { transactionCharge, transactionChargeType },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return safeJson({ success: true, data: serializeBigInt(userService) });
  } catch (error) {
    console.error('PATCH /api/user/services error:', error);
    return safeJson({ error: 'Failed to update service' }, { status: 500 });
  }
}

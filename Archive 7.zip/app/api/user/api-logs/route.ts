import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const apiKeyId = searchParams.get('apiKeyId');
    const status = searchParams.get('status');

    const whereClause: any = { userId: user.id };

    if (apiKeyId) {
      whereClause.apiKeyId = apiKeyId;
    }

    if (status) {
      if (status === 'error') {
        whereClause.error = { not: null };
      } else if (status === 'success') {
        whereClause.statusCode = { gte: 200, lt: 300 };
      }
    }

    const logs = await prisma.apiRequestLog.findMany({
      where: whereClause,
      skip: offset,
      take: limit,
      select: {
        id: true,
        method: true,
        endpoint: true,
        statusCode: true,
        responseTime: true,
        ipAddress: true,
        error: true,
        createdAt: true,
        apiKey: { select: { name: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    const total = await prisma.apiRequestLog.count({
      where: whereClause,
    });

    return NextResponse.json({
      success: true,
      data: logs,
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/user/api-logs error:', error);
    return NextResponse.json({ error: 'Failed to fetch API logs' }, { status: 500 });
  }
}

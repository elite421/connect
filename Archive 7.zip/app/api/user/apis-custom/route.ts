import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const [apis, total] = await Promise.all([
      prisma.userApi.findMany({
        where: {
          OR: [
            { userId: user.id },
            { isShared: true }
          ]
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.userApi.count({
        where: {
          OR: [
            { userId: user.id },
            { isShared: true }
          ]
        }
      }),
    ]);

    return NextResponse.json({
      success: true,
      data: serializeBigInt(apis),
      pagination: { limit, offset, total },
    });
  } catch (error) {
    console.error('GET /api/user/apis-custom error:', error);
    return NextResponse.json({ error: 'Failed to fetch APIs' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { name, baseUrl, method, authType, apiKey, authHeader, headers, bodyTemplate, description } = body;

    if (!name || !baseUrl || !method) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const api = await prisma.userApi.create({
      data: {
        userId: user.id,
        key: `api_${Math.random().toString(36).substring(2, 15)}`,
        name,
        baseUrl,
        apiKey: apiKey || null,
        apiSecret: JSON.stringify({
          method,
          authType,
          authHeader,
          headers,
          bodyTemplate,
          description,
        }),
        isActive: true,
      },
    });

    await logActivity({
      user,
      action: 'add_api',
      resource: 'custom_api',
      resourceId: api.id,
      metadata: { name },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ success: true, data: serializeBigInt(api) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/apis-custom error:', error);
    return NextResponse.json({ error: 'Failed to create API' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { id, name, baseUrl, method, authType, apiKey, authHeader, headers, bodyTemplate, description } = body;

    if (!id) {
      return NextResponse.json({ error: 'API ID required' }, { status: 400 });
    }

    const existingApi = await prisma.userApi.findFirst({
      where: { id },
    });

    if (!existingApi) {
      return NextResponse.json({ error: 'API not found' }, { status: 404 });
    }

    if (existingApi.userId !== user.id) {
      return NextResponse.json({ error: 'Cannot modify shared APIs created by other users' }, { status: 403 });
    }

    const api = await prisma.userApi.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(baseUrl && { baseUrl }),
        ...(apiKey && { apiKey }),
        ...(method || authType || headers || bodyTemplate ? {
          apiSecret: JSON.stringify({
            method,
            authType,
            authHeader,
            headers,
            bodyTemplate,
            description,
          }),
        } : {}),
      },
    });

    await logActivity({
      user,
      action: 'update_api',
      resource: 'custom_api',
      resourceId: id,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ success: true, data: serializeBigInt(api) });
  } catch (error) {
    console.error('PATCH /api/user/apis-custom error:', error);
    return NextResponse.json({ error: 'Failed to update API' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'API ID required' }, { status: 400 });
    }

    const existingApi = await prisma.userApi.findFirst({
      where: { id },
    });

    if (!existingApi) {
      return NextResponse.json({ error: 'API not found' }, { status: 404 });
    }

    if (existingApi.userId !== user.id) {
      return NextResponse.json({ error: 'Cannot delete shared APIs created by other users' }, { status: 403 });
    }

    await prisma.userApi.delete({ where: { id } });

    await logActivity({
      user,
      action: 'delete_api',
      resource: 'custom_api',
      resourceId: id,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ success: true, message: 'API deleted' });
  } catch (error) {
    console.error('DELETE /api/user/apis-custom error:', error);
    return NextResponse.json({ error: 'Failed to delete API' }, { status: 500 });
  }
}

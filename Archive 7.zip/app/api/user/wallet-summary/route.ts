import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Get transaction statistics
    const [totalTransactions, successTransactions, failedTransactions, pendingTransactions] =
      await Promise.all([
        prisma.payInTransaction.count({
          where: { userId: user.id },
        }),
        prisma.payInTransaction.count({
          where: { userId: user.id, status: { in: ['success', 'completed'] } },
        }),
        prisma.payInTransaction.count({
          where: { userId: user.id, status: 'failed' },
        }),
        prisma.payInTransaction.count({
          where: { userId: user.id, status: 'pending' },
        }),
      ]);

    // Get total amount transacted
    const totalAmountResult = await prisma.payInTransaction.aggregate({
      where: { userId: user.id, status: { in: ['success', 'completed'] } },
      _sum: { amount: true },
    });

    const successRateResult = await prisma.payInTransaction.aggregate({
      where: { userId: user.id },
      _count: { id: true },
    });

    const successRate = successRateResult._count.id > 0
      ? Math.round((successTransactions / successRateResult._count.id) * 100)
      : 0;

    // Get active gateways
    const gateways = await prisma.gatewayIntegration.findMany({
      where: { userId: user.id, isActive: true },
      select: {
        id: true,
        gatewayName: true,
        gatewayCode: true,
        isPrimary: true,
      },
    });

    // Get recent transactions
    const recentTransactions = await prisma.payInTransaction.findMany({
      where: { userId: user.id },
      select: {
        id: true,
        amount: true,
        status: true,
        utrNumber: true,
        createdAt: true,
        gateway: {
          select: {
            gatewayName: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 5,
    });

    return NextResponse.json({
      success: true,
      summary: {
        totalTransactions,
        successTransactions,
        failedTransactions,
        pendingTransactions,
        successRate,
        totalAmountTransacted: Number(totalAmountResult._sum.amount || 0),
      },
      gateways: gateways.map((gw) => ({
        id: gw.id,
        name: gw.gatewayName,
        code: gw.gatewayCode,
        isPrimary: gw.isPrimary,
      })),
      recentTransactions: recentTransactions.map((tx) => ({
        id: tx.id,
        amount: Number(tx.amount),
        status: tx.status,
        utrNumber: tx.utrNumber,
        gatewayName: tx.gateway?.gatewayName,
        createdAt: tx.createdAt,
      })),
    });
  } catch (error: any) {
    console.error('Failed to fetch wallet summary:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to fetch wallet summary' },
      { status: 500 }
    );
  }
}

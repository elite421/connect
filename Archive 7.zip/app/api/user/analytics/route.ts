import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

import { toRupees } from '@/lib/money';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const timeRange = searchParams.get('range') || '30d';

    let startDate = new Date(0); // Default to beginning of time
    const now = new Date();

    if (timeRange === 'today') {
      startDate = new Date(now.setHours(0, 0, 0, 0));
    } else if (timeRange === '7d') {
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else if (timeRange === '30d') {
      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    }

    const [
      totalSubUsers,
      activeSubUsers,
      totalPayments,
      completedPayments,
      failedPayments,
      totalRevenue,
      usedServices,
      activeServices,
    ] = await Promise.all([
      prisma.subUser.count({
        where: {
          userId: user.id,
          createdAt: { gte: startDate }
        }
      }),
      prisma.subUser.count({
        where: {
          userId: user.id,
          isActive: true,
        },
      }),
      prisma.payOutTransaction.count({
        where: {
          userId: user.id,
          createdAt: { gte: startDate }
        },
      }),
      prisma.payOutTransaction.count({
        where: {
          userId: user.id,
          status: { in: ['completed', 'success'] },
          createdAt: { gte: startDate }
        },
      }),
      prisma.payOutTransaction.count({
        where: {
          userId: user.id,
          status: { in: ['failed', 'rejected'] },
          createdAt: { gte: startDate }
        },
      }),
      prisma.payOutTransaction.aggregate({
        _sum: { amount: true },
        where: {
          userId: user.id,
          status: { in: ['completed', 'success'] },
          createdAt: { gte: startDate }
        },
      }),
      prisma.userService.count({
        where: { userId: user.id },
      }),
      prisma.userService.count({
        where: {
          userId: user.id,
          isActive: true,
        },
      }),
    ]);

    const subUserPaymentStats = await prisma.payOutTransaction.groupBy({
      by: ['subUserId'],
      _sum: { amount: true },
      _count: true,
      where: {
        userId: user.id,
        subUserId: { not: null },
        createdAt: { gte: startDate },
      },
    });

    const normalizedRevenue = toRupees(totalRevenue._sum.amount || 0);

    const analyticsData = {
      subUsers: {
        total: totalSubUsers,
        active: activeSubUsers,
        inactive: totalSubUsers - activeSubUsers,
      },
      payments: {
        total: totalPayments,
        completed: completedPayments,
        failed: failedPayments,
        pending: totalPayments - completedPayments - failedPayments,
        successRate: totalPayments > 0 ? ((completedPayments / totalPayments) * 100).toFixed(2) : '0',
      },
      revenue: {
        total: normalizedRevenue,
        averageTransaction: totalPayments > 0 ? normalizedRevenue / totalPayments : 0,
      },
      services: {
        total: usedServices,
        active: activeServices,
        inactive: usedServices - activeServices,
      },
      subUserActivity: subUserPaymentStats.map(stat => ({
        ...stat,
        _sum: { amount: toRupees(stat._sum.amount || 0) }
      })).slice(0, 5),
    };

    await logActivity({
      user,
      action: 'view_analytics',
      resource: 'analytics',
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return safeJson({ success: true, data: serializeBigInt(analyticsData) });
  } catch (error) {
    console.error('GET /api/user/analytics error:', error);
    return safeJson({ error: 'Failed to fetch analytics' }, { status: 500 });
  }
}

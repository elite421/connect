import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
    const user = await authMiddleware(req, ['USER']);
    if (user instanceof NextResponse) return user;

    try {
        const { searchParams } = new URL(req.url);
        const limit = Math.min(parseInt(searchParams.get('limit') || '50'), 100);
        const offset = parseInt(searchParams.get('offset') || '0');
        const type = searchParams.get('type'); // PAYOUT_DEBIT, PAYOUT_REFUND, PAYIN_CREDIT, etc.

        // Get wallet
        const wallet = await prisma.wallet.findUnique({
            where: { userId: user.id },
        });

        if (!wallet) {
            return safeJson({
                success: true,
                data: [],
                pagination: { limit, offset, total: 0, hasMore: false },
            });
        }

        // Build where clause
        const whereClause: any = { walletId: wallet.id };
        if (type) {
            whereClause.type = type;
        }

        // Get transactions
        const [transactions, total] = await Promise.all([
            prisma.walletTransactionLocal.findMany({
                where: whereClause,
                orderBy: { createdAt: 'desc' },
                take: limit,
                skip: offset,
            }),
            prisma.walletTransactionLocal.count({ where: whereClause }),
        ]);

        // Format transactions for display
        const formattedTransactions = transactions.map(tx => ({
            id: tx.id,
            type: tx.type,
            amount: String(tx.amount),
            amountDisplay: `₹${(Number(tx.amount)).toLocaleString('en-IN', { minimumFractionDigits: 5, maximumFractionDigits: 5 })}`,
            chargeAmount: String(tx.chargeAmount),
            chargeDisplay: `₹${(Number(tx.chargeAmount)).toLocaleString('en-IN', { minimumFractionDigits: 5, maximumFractionDigits: 5 })}`,
            balanceAfter: String(tx.balanceAfter),
            balanceAfterDisplay: `₹${(Number(tx.balanceAfter)).toLocaleString('en-IN', { minimumFractionDigits: 5, maximumFractionDigits: 5 })}`,
            referenceType: tx.referenceType,
            referenceId: tx.referenceId,
            description: tx.description,
            metadata: tx.metadata,
            createdAt: tx.createdAt.toISOString(),
        }));

        return safeJson({
            success: true,
            data: formattedTransactions,
            wallet: {
                id: wallet.id,
                balance: String(wallet.balance),
                balanceDisplay: `₹${(Number(wallet.balance)).toLocaleString('en-IN', { minimumFractionDigits: 5, maximumFractionDigits: 5 })}`,
                currency: wallet.currency,
            },
            pagination: {
                limit,
                offset,
                total,
                hasMore: offset + limit < total,
            },
        });
    } catch (error) {
        console.error('GET /api/user/wallet/transactions error:', error);
        return safeJson({ error: 'Failed to fetch transactions' }, { status: 500 });
    }
}

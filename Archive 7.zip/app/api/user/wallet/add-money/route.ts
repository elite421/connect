
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import prisma from '@/lib/prisma';
import { initiateRudraxPayPayin } from '@/lib/rudraxpay-integration';
import { logApiRequest } from '@/lib/api-auth'; // We might need a session-based logger or skip

export async function POST(req: NextRequest) {
    const session = await getServerSession(authOptions);
    if (!session || !session.user) {
        return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }
    const user = session.user as any;
    // Fetch fresh user data to get defaultApiId
    const dbUser = await prisma.user.findUnique({ where: { id: user.id } });
    if (!dbUser) return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });

    try {
        const body = await req.json();
        const { amount } = body;

        if (!amount || Number(amount) <= 0) {
            return NextResponse.json({ success: false, error: 'Invalid amount' }, { status: 400 });
        }

        // 1. Create Transaction (Pending)
        const transaction = await prisma.payInTransaction.create({
            data: {
                userId: user.id,
                amount: Number(amount),
                customerName: user.name || 'User',
                customerEmail: user.email || '',
                customerPhone: user.phone || '9999999999',
                paymentMethod: 'upi',
                status: 'pending',
                merchantTransactionId: `TOPUP-${Date.now()}`,
                ipAddress: '127.0.0.1',
                responseData: {
                    source: 'DASHBOARD'
                }
            }
        });

        // 2. Resolve Payin API (Logic ported from v1/payin)
        async function resolvePayinApiForUser(userId: string) {
            // Check CustomPaymentApi
            const customApi = await prisma.customPaymentApi.findFirst({
                where: { userId, isActive: true, apiType: 'PAYIN' },
                orderBy: { isDefault: 'desc' }
            });
            if (customApi) {
                return {
                    ...customApi,
                    scopes: JSON.stringify({
                        payinEndpoint: customApi.apiEndpoint,
                        requestTemplate: customApi.requestFormat ? JSON.stringify(customApi.requestFormat) : null,
                    })
                };
            }

            // Check Default API (Linked Admin API)
            if (dbUser!.defaultApiId) {
                const linkedApi = await prisma.customPaymentApi.findUnique({
                    where: { id: dbUser!.defaultApiId }
                });
                if (linkedApi && linkedApi.apiType === 'PAYIN' && linkedApi.isActive) {
                    return {
                        ...linkedApi,
                        scopes: JSON.stringify({
                            payinEndpoint: linkedApi.apiEndpoint,
                            requestTemplate: linkedApi.requestFormat ? JSON.stringify(linkedApi.requestFormat) : null,
                        })
                    };
                }
            }

            // Check Admin CustomPaymentApi
            const adminCustomApi = await prisma.customPaymentApi.findFirst({
                where: { adminProvided: true, isActive: true, apiType: 'PAYIN' },
                orderBy: { isDefault: 'desc' }
            });
            if (adminCustomApi) {
                return {
                    ...adminCustomApi,
                    scopes: JSON.stringify({
                        payinEndpoint: adminCustomApi.apiEndpoint,
                        requestTemplate: adminCustomApi.requestFormat ? JSON.stringify(adminCustomApi.requestFormat) : null,
                    })
                };
            }

            return null;
        }

        const apiData: any = await resolvePayinApiForUser(user.id);
        if (!apiData) {
            return NextResponse.json({ success: false, error: 'No PayIn Gateway configured. Please contact support.' }, { status: 400 });
        }

        // 3. Update Gateway ID
        await prisma.payInTransaction.update({
            where: { id: transaction.id },
            data: {
                customApiId: apiData.id,
                gatewayId: null
            }
        });

        // 4. RUDRAXPAY BRIDGE
        if ((apiData.apiBaseUrl && apiData.apiBaseUrl.includes('rudraxpay.com')) || (apiData.apiName && apiData.apiName.toLowerCase().includes('rudrax'))) {
            const userid = apiData.apiKey;
            const token = apiData.apiSecret;

            if (!userid || !token) {
                throw new Error('RudraxPay configuration missing Credentials');
            }

            const rudraxRes = await initiateRudraxPayPayin(
                apiData.apiBaseUrl || 'https://merchant.rudraxpay.com/api',
                { userid, token },
                {
                    amount: Number(amount),
                    name: user.name || 'User',
                    mobile: user.phone || '9999999999',
                    orderid: transaction.merchantTransactionId || transaction.id,
                    callbackUrl: `${process.env.NEXT_PUBLIC_APP_URL}/api/callback/rudraxpay/payin`
                }
            );

            await prisma.payInTransaction.update({
                where: { id: transaction.id },
                data: {
                    status: rudraxRes.success ? 'processing' : 'failed',
                    responseData: rudraxRes.raw
                }
            });

            if (rudraxRes.success && rudraxRes.url) {
                return NextResponse.json({
                    success: true,
                    transactionId: transaction.id,
                    paymentLink: rudraxRes.url
                });
            } else {
                return NextResponse.json({
                    success: false,
                    error: rudraxRes.message || 'Payment initiation failed',
                }, { status: 400 });
            }
        }

        // 5. Generic API (Basic support)
        // For now, only RudraxPay is fully tested for topup 
        return NextResponse.json({ success: false, error: 'Gateway not supported for automatic topup yet' }, { status: 501 });

    } catch (error: any) {
        console.error('Wallet Add Money Error:', error);
        return NextResponse.json({ success: false, error: error.message || 'Internal Server Error' }, { status: 500 });
    }
}

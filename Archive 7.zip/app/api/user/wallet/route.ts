import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { toRupees, toPaise } from '@/lib/money';

const serializeWallet = (wallet: any) => ({
  ...serializeBigInt(wallet),
  balance: toRupees(wallet.balance),
  frozenBalance: wallet.frozenBalance ? toRupees(wallet.frozenBalance) : 0,
});

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    let wallet = await prisma.wallet.findUnique({
      where: { userId: user.id },
    });

    if (!wallet) {
      wallet = await prisma.wallet.create({
        data: {
          userId: user.id,
          balance: 0,
        },
      });
    }

    return NextResponse.json({
      success: true,
      data: serializeWallet(wallet),
    });
  } catch (error) {
    console.error('GET /api/user/wallet error:', error);
    return NextResponse.json({ error: 'Failed to fetch wallet' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { action, amount } = body;

    if (!action || !amount) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    if (!['add', 'deduct'].includes(action)) {
      return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }

    let wallet = await prisma.wallet.findUnique({
      where: { userId: user.id },
    });

    if (!wallet) {
      wallet = await prisma.wallet.create({
        data: {
          userId: user.id,
          balance: 0,
        },
      });
    }

    const amountInRupees = Number(amount);
    let newBalance = wallet.balance;

    if (action === 'add') {
      newBalance = wallet.balance + amountInRupees;
    } else if (action === 'deduct') {
      if (wallet.balance < amountInRupees) {
        return NextResponse.json({ error: 'Insufficient wallet balance' }, { status: 400 });
      }
      newBalance = wallet.balance - amountInRupees;
    }

    const updatedWallet = await prisma.wallet.update({
      where: { userId: user.id },
      data: { balance: newBalance },
    });

    return NextResponse.json({
      success: true,
      data: serializeWallet(updatedWallet),
    });
  } catch (error) {
    console.error('POST /api/user/wallet error:', error);
    return NextResponse.json({ error: 'Failed to update wallet' }, { status: 500 });
  }
}

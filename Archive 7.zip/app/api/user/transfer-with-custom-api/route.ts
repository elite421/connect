import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { calculateTransactionFee, deductFeeFromWallet } from '@/lib/fee-calculator';
import crypto from 'crypto';
import { toRupees } from '@/lib/money';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { amount, beneficiaryId, serviceId, customApiId } = body;

    if (!amount || !beneficiaryId) {
      return NextResponse.json({ error: 'Amount and beneficiary are required' }, { status: 400 });
    }

    const amountInRupees = Number(amount);

    const feeCalc = await calculateTransactionFee(
      amountInRupees,
      user.role as 'USER' | 'SUBUSER',
      serviceId
    );

    let customApi = null;
    if (customApiId) {
      customApi = await prisma.customPaymentApi.findFirst({
        where: {
          id: customApiId,
          OR: [
            { userId: user.id, adminProvided: false },
            { adminProvided: true },
          ],
          isActive: true,
        },
      });
    } else {
      customApi = await prisma.customPaymentApi.findFirst({
        where: {
          userId: user.id,
          adminProvided: false,
          isActive: true,
          isDefault: true,
        },
      });

      if (!customApi) {
        customApi = await prisma.customPaymentApi.findFirst({
          where: {
            adminProvided: true,
            isActive: true,
            isDefault: true,
          },
        });
      }
    }

    if (!customApi) {
      return NextResponse.json({
        error: 'No payment API configured. Please add a custom API or contact admin.',
      }, { status: 400 });
    }

    const transactionId = `TXN-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;

    const feeDeduction = await deductFeeFromWallet(
      user.id,
      user.role === 'SUBUSER' ? user.id : null,
      feeCalc.feeAmount,
      transactionId,
      'transfer',
      serviceId
    );

    if (!feeDeduction.success) {
      return NextResponse.json({
        error: feeDeduction.error || 'Insufficient wallet balance for transaction fee',
        feeRequired: toRupees(feeCalc.feeAmount),
      }, { status: 402 });
    }

    const beneficiary = user.role === 'USER'
      ? await prisma.userBeneficiary.findFirst({ where: { id: beneficiaryId, userId: user.id } })
      : await prisma.beneficiary.findFirst({ where: { id: beneficiaryId, subUserId: user.id } });

    if (!beneficiary) {
      return NextResponse.json({ error: 'Beneficiary not found' }, { status: 404 });
    }

    const requestPayload = {
      transactionId,
      amount: Number(amount), // Assuming external API expects Rupees
      beneficiaryName: beneficiary.accountName,
      accountNumber: beneficiary.accountNumber,
      ifscCode: beneficiary.ifscCode || beneficiary.bankCode,
      bankName: beneficiary.bankName,
      timestamp: new Date().toISOString(),
    };

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (customApi.authType === 'bearer' && customApi.apiKey) {
      headers['Authorization'] = `Bearer ${customApi.apiKey}`;
    } else if (customApi.authType === 'basic' && customApi.apiKey && customApi.apiSecret) {
      const credentials = Buffer.from(`${customApi.apiKey}:${customApi.apiSecret}`).toString('base64');
      headers['Authorization'] = `Basic ${credentials}`;
    } else if (customApi.authType === 'apikey' && customApi.authHeader && customApi.apiKey) {
      headers[customApi.authHeader] = customApi.apiKey;
    }

    const apiUrl = `${customApi.apiBaseUrl}${customApi.apiEndpoint}`;

    let apiResponse;
    let apiSuccess = false;
    let apiError = null;

    try {
      const response = await fetch(apiUrl, {
        method: customApi.apiMethod,
        headers,
        body: JSON.stringify(requestPayload),
      });

      apiSuccess = response.ok;
      try {
        apiResponse = await response.json();
      } catch {
        const text = await response.text();
        apiResponse = { raw: text };
      }
    } catch (error: any) {
      apiError = error.message;
      apiResponse = { error: apiError };
    }

    const transaction = user.role === 'USER'
      ? await prisma.payOutTransaction.create({
        data: {
          userId: user.id,
          amount: amountInRupees,
          status: apiSuccess ? 'completed' : 'failed',
          beneficiaryName: beneficiary.accountName,
          beneficiaryAccount: beneficiary.accountNumber,
          beneficiaryIfsc: beneficiary.ifscCode || beneficiary.bankCode || '',
          transferMode: 'imps',
        },
      })
      : await prisma.payOutTransaction.create({
        data: {
          userId: user.id,
          subUserId: user.id,
          amount: amountInRupees,
          status: apiSuccess ? 'completed' : 'failed',
          beneficiaryName: beneficiary.accountName,
          beneficiaryAccount: beneficiary.accountNumber,
          beneficiaryIfsc: beneficiary.ifscCode || beneficiary.bankCode || '',
          transferMode: 'imps',
        },
      });

    if (apiSuccess) {
      return NextResponse.json({
        success: true,
        message: 'Transfer completed successfully',
        transactionId: transaction.id,
        amount: toRupees(amountInRupees),
        fee: toRupees(feeCalc.feeAmount),
        netAmount: toRupees(feeCalc.netAmount),
        apiUsed: customApi.apiName,
      });
    } else {
      return NextResponse.json({
        success: false,
        error: 'Transfer failed at payment gateway',
        transactionId: transaction.id,
        fee: toRupees(feeCalc.feeAmount),
        apiResponse,
      }, { status: 400 });
    }
  } catch (error) {
    console.error('POST /api/user/transfer-with-custom-api error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { safeJson } from '@/lib/safe-json';

function generateAccountNumber(): string {
  const prefix = '9999';
  const random = Math.random().toString().substring(2, 12);
  return prefix + random;
}

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const virtualAccounts = await prisma.virtualAccount.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
    });

    return safeJson({ success: true, data: serializeBigInt(virtualAccounts) });
  } catch (error) {
    console.error('GET /api/user/virtual-accounts error:', error);
    return safeJson({ error: 'Failed to fetch virtual accounts' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { accountHolderName, bankName, linkedServices } = body;

    if (!accountHolderName) {
      return safeJson({ error: 'Account holder name required' }, { status: 400 });
    }

    const accountNumber = generateAccountNumber();
    const ifscCode = 'VIRT0001';

    const virtualAccount = await prisma.virtualAccount.create({
      data: {
        userId: user.id,
        accountNumber,
        accountHolderName,
        bankName: bankName || 'Virtual Bank',
        ifscCode,
        linkedServices: linkedServices || [],
      },
    });

    await logActivity({
      user,
      action: 'create_virtual_account',
      resource: 'virtual_account',
      resourceId: virtualAccount.id,
      metadata: { accountNumber, accountHolderName },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return safeJson({ success: true, data: serializeBigInt(virtualAccount) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/virtual-accounts error:', error);
    return safeJson({ error: 'Failed to create virtual account' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { accountId, linkedServices, status } = body;

    if (!accountId) {
      return safeJson({ error: 'Account ID required' }, { status: 400 });
    }

    const virtualAccount = await prisma.virtualAccount.update({
      where: { id: accountId },
      data: {
        ...(linkedServices && { linkedServices }),
        ...(status && { status }),
      },
    });

    await logActivity({
      user,
      action: 'update_virtual_account',
      resource: 'virtual_account',
      resourceId: accountId,
      metadata: { linkedServices, status },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return safeJson({ success: true, data: serializeBigInt(virtualAccount) });
  } catch (error) {
    console.error('PATCH /api/user/virtual-accounts error:', error);
    return safeJson({ error: 'Failed to update virtual account' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const accountId = searchParams.get('id');

    if (!accountId) {
      return safeJson({ error: 'Account ID required' }, { status: 400 });
    }

    await prisma.virtualAccount.delete({
      where: { id: accountId },
    });

    await logActivity({
      user,
      action: 'delete_virtual_account',
      resource: 'virtual_account',
      resourceId: accountId,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return safeJson({ success: true, message: 'Virtual account deleted' });
  } catch (error) {
    console.error('DELETE /api/user/virtual-accounts error:', error);
    return safeJson({ error: 'Failed to delete virtual account' }, { status: 500 });
  }
}

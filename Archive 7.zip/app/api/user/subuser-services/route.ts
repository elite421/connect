import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const subUserId = searchParams.get('subUserId');

    if (!subUserId) {
      return safeJson({ error: 'SubUser ID required' }, { status: 400 });
    }

    const subUser = await prisma.subUser.findUnique({
      where: { id: subUserId },
    });

    if (!subUser || subUser.userId !== user.id) {
      return safeJson({ error: 'Forbidden' }, { status: 403 });
    }

    const services = await prisma.subUserService.findMany({
      where: { subUserId },
      include: { service: true },
      orderBy: { createdAt: 'desc' },
    });

    return safeJson({ success: true, data: serializeBigInt(services) });
  } catch (error) {
    console.error('GET /api/user/subuser-services error:', error);
    return safeJson({ error: 'Failed to fetch services' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { subUserId, serviceId, config } = body;

    if (!subUserId || !serviceId) {
      return safeJson({ error: 'SubUser ID and Service ID required' }, { status: 400 });
    }

    const subUser = await prisma.subUser.findUnique({
      where: { id: subUserId },
    });

    if (!subUser || subUser.userId !== user.id) {
      return safeJson({ error: 'Forbidden' }, { status: 403 });
    }

    const subUserService = await prisma.subUserService.create({
      data: {
        subUserId,
        serviceId,
        config: config || {},
        isActive: false,
      },
      include: { service: true },
    });

    await logActivity({
      user,
      action: 'activate_service',
      resource: 'service',
      resourceId: serviceId,
      metadata: { subUserId, config },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return safeJson({ success: true, data: serializeBigInt(subUserService) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/subuser-services error:', error);
    return safeJson({ error: 'Failed to assign service' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { subUserServiceId, isActive, config, transactionCharge, transactionChargeType } = body;

    if (!subUserServiceId) {
      return safeJson({ error: 'SubUser Service ID required' }, { status: 400 });
    }

    const subUserService = await prisma.subUserService.findUnique({
      where: { id: subUserServiceId },
      include: { subUser: true },
    });

    if (!subUserService || subUserService.subUser.userId !== user.id) {
      return safeJson({ error: 'Forbidden' }, { status: 403 });
    }

    const updateData: any = {};
    if (isActive !== undefined) updateData.isActive = isActive;
    if (config !== undefined) updateData.config = config;
    if (transactionCharge !== undefined) updateData.transactionCharge = transactionCharge;
    if (transactionChargeType !== undefined) updateData.transactionChargeType = transactionChargeType;

    const updated = await prisma.subUserService.update({
      where: { id: subUserServiceId },
      data: serializeBigInt(updateData),
      include: { service: true },
    });

    await logActivity({
      user,
      action: 'activate_service',
      resource: 'service',
      resourceId: updated.serviceId,
      metadata: { isActive, transactionCharge, transactionChargeType },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return safeJson({ success: true, data: serializeBigInt(updated) });
  } catch (error) {
    console.error('PATCH /api/user/subuser-services error:', error);
    return safeJson({ error: 'Failed to update service' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const subUserServiceId = searchParams.get('subUserServiceId');

    if (!subUserServiceId) {
      return safeJson({ error: 'SubUser Service ID required' }, { status: 400 });
    }

    const subUserService = await prisma.subUserService.findUnique({
      where: { id: subUserServiceId },
      include: { subUser: true },
    });

    if (!subUserService || subUserService.subUser.userId !== user.id) {
      return safeJson({ error: 'Forbidden' }, { status: 403 });
    }

    await prisma.subUserService.delete({
      where: { id: subUserServiceId },
    });

    await logActivity({
      user,
      action: 'deactivate_service',
      resource: 'service',
      resourceId: subUserService.serviceId,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return safeJson({ success: true, message: 'Service removed' });
  } catch (error) {
    console.error('DELETE /api/user/subuser-services error:', error);
    return safeJson({ error: 'Failed to remove service' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const userId = (session.user as any).id;

    // 1. Fetch User Defined Gateways
    const gatewaysPromise = prisma.gatewayIntegration.findMany({
      where: {
        userId,
        isActive: true,
      },
      select: {
        id: true,
        gatewayName: true,
        gatewayCode: true,
        isPrimary: true,
        isActive: true,
        createdAt: true,
      },
      orderBy: [
        { isPrimary: 'desc' },
        { createdAt: 'desc' },
      ],
    });

    // 2. Fetch Assigned Custom Payment APIs (Admin Assigned or User Specific)
    // We fetch those assigned explicitly to user, or global ones if we want to expose them?
    // User request: "api that admin set to user". So fetch where userId = userId.
    const customApisPromise = prisma.customPaymentApi.findMany({
      where: {
        userId,
        isActive: true,
        apiType: 'PAYIN'
      },
      select: {
        id: true,
        apiName: true,
        isDefault: true,
        isActive: true,
        createdAt: true,
        // map/transform later
      },
      orderBy: { isDefault: 'desc' }
    });

    const [userGateways, customApis] = await Promise.all([gatewaysPromise, customApisPromise]);

    // Transform Custom APIs to Gateway format
    const mappedCustomApis = customApis.map(api => ({
      id: api.id,
      gatewayName: api.apiName,
      gatewayCode: 'custom_api', // specific code to identify source
      isPrimary: api.isDefault, // Map default to primary
      isActive: api.isActive,
      createdAt: api.createdAt,
      type: 'CUSTOM_API' // Helper flag
    }));

    // Merge. Prefer Custom APIs if default? 
    // Sorting: Primary first.
    const allGateways = [...userGateways, ...mappedCustomApis].sort((a, b) => {
      if (a.isPrimary === b.isPrimary) {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      return a.isPrimary ? -1 : 1;
    });

    return NextResponse.json({
      success: true,
      gateways: allGateways,
    });
  } catch (error: any) {
    console.error('Failed to fetch gateways:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to fetch gateways' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import crypto from 'crypto';
import { safeJson } from '@/lib/safe-json';

function generateApiKey(): string {
  return 'sk_' + crypto.randomBytes(32).toString('hex');
}

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  const targetUserId = user.role === 'SUBUSER' ? user.userId : user.id;

  // Safety check: if subuser has no userId (should not happen due to schema), handle it
  if (!targetUserId) {
    return safeJson({ error: 'Invalid user context' }, { status: 400 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const apiKeys = await prisma.apiKey.findMany({
      where: { userId: targetUserId },
      skip: offset,
      take: limit,
      select: {
        id: true,
        name: true,
        keyValue: true,
        isActive: true,
        permissions: true,
        expiresAt: true,
        lastUsedAt: true,
        requestCount: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    const total = await prisma.apiKey.count({
      where: { userId: targetUserId },
    });

    return safeJson({
      success: true,
      data: apiKeys.map(key => ({
        ...key,
        keyValue: key.keyValue.substring(0, 10) + '...',
      })),
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/user/api-keys error:', error);
    return safeJson({ error: 'Failed to fetch API keys' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  const targetUserId = user.role === 'SUBUSER' ? user.userId : user.id;
  if (!targetUserId) {
    return safeJson({ error: 'Invalid user context' }, { status: 400 });
  }

  try {
    const body = await req.json();
    const { name, permissions = ['read', 'write'], expiresAt } = body;

    if (!name) {
      return safeJson({ error: 'API key name required' }, { status: 400 });
    }

    const keyValue = generateApiKey();

    const apiKey = await prisma.apiKey.create({
      data: {
        userId: targetUserId,
        name,
        keyValue,
        permissions,
        expiresAt: expiresAt ? new Date(expiresAt) : null,
      },
      select: {
        id: true,
        name: true,
        keyValue: true,
        isActive: true,
        permissions: true,
        expiresAt: true,
        createdAt: true,
      },
    });

    return safeJson(
      {
        success: true,
        data: apiKey,
        message: 'Save this API key safely. You won\'t be able to see it again.',
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('POST /api/user/api-keys error:', error);
    return safeJson({ error: 'Failed to create API key' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  const targetUserId = user.role === 'SUBUSER' ? user.userId : user.id;
  if (!targetUserId) {
    return safeJson({ error: 'Invalid user context' }, { status: 400 });
  }

  try {
    const body = await req.json();
    const { id, name, isActive } = body;

    if (!id) {
      return safeJson({ error: 'API key ID required' }, { status: 400 });
    }

    const apiKey = await prisma.apiKey.findUnique({
      where: { id },
    });

    if (!apiKey || apiKey.userId !== targetUserId) {
      return safeJson({ error: 'API key not found' }, { status: 404 });
    }

    const updatedKey = await prisma.apiKey.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(isActive !== undefined && { isActive }),
      },
      select: {
        id: true,
        name: true,
        isActive: true,
        permissions: true,
        lastUsedAt: true,
        requestCount: true,
        createdAt: true,
      },
    });

    return safeJson({
      success: true,
      data: updatedKey,
    });
  } catch (error) {
    console.error('PATCH /api/user/api-keys error:', error);
    return safeJson({ error: 'Failed to update API key' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  const targetUserId = user.role === 'SUBUSER' ? user.userId : user.id;
  if (!targetUserId) {
    return safeJson({ error: 'Invalid user context' }, { status: 400 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return safeJson({ error: 'API key ID required' }, { status: 400 });
    }

    const apiKey = await prisma.apiKey.findUnique({
      where: { id },
    });

    if (!apiKey || apiKey.userId !== targetUserId) {
      return safeJson({ error: 'API key not found' }, { status: 404 });
    }

    await prisma.apiKey.delete({
      where: { id },
    });

    return safeJson({
      success: true,
      message: 'API key deleted',
    });
  } catch (error) {
    console.error('DELETE /api/user/api-keys error:', error);
    return safeJson({ error: 'Failed to delete API key' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { callFingrowPayoutApi } from '@/lib/fingrow-integration';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      amount,
      beneficiaryName,
      beneficiaryAccount,
      beneficiaryIfsc,
      beneficiaryVpa,
      transferMode,
    } = body;

    if (!amount || !beneficiaryName || !transferMode) {
      return NextResponse.json(
        { error: 'Missing required fields: amount, beneficiaryName, transferMode' },
        { status: 400 },
      );
    }

    if (transferMode === 'upi' && !beneficiaryVpa) {
      return NextResponse.json(
        { error: 'VPA required for UPI transfers' },
        { status: 400 },
      );
    }

    if (transferMode !== 'upi' && (!beneficiaryAccount || !beneficiaryIfsc)) {
      return NextResponse.json(
        { error: 'Account number and IFSC required for bank transfers' },
        { status: 400 },
      );
    }

    const testResponse = await callFingrowPayoutApi(user.id, {
      amount: Number(amount) / 100,
      beneficiaryName,
      beneficiaryAccount,
      beneficiaryIfsc,
      beneficiaryVpa,
      transferMode,
      merchantTransactionId: `TEST_${Date.now()}`,
    });

    const suggestions = [];

    if (!testResponse.response.success) {
      const errorCode = testResponse.response.raw?.error || '';

      if (errorCode === 'NO_API_CONFIGURED') {
        suggestions.push(
          'Configure a Fingrow API in your account settings',
          'Go to Account > Settings > Payment APIs > Add Fingrow API',
          'Ensure the Merchant ID is correct',
        );
      } else if (errorCode === 'ENCRYPTION_FAILED') {
        suggestions.push(
          'Verify Merchant ID is correct',
          'Check encryption credentials',
          'Contact support if issue persists',
        );
      } else if (errorCode === 'TIMEOUT') {
        suggestions.push(
          'Check internet connection',
          'Verify Fingrow API is online',
          'Try again in a moment',
        );
      } else if (errorCode === 'CONNECTION_REFUSED') {
        suggestions.push(
          'Verify API endpoint URL is correct',
          'Check if Fingrow server is running',
          'Verify IP whitelist settings',
        );
      } else if (errorCode === 'URL_NOT_FOUND') {
        suggestions.push(
          'Verify API endpoint URL is correct',
          'Check for typos in the URL',
          'Ensure HTTPS URL is used',
        );
      }
    }

    return NextResponse.json({
      success: true,
      status: 'test_completed',
      testRequest: {
        amount,
        beneficiaryName,
        beneficiaryAccount,
        beneficiaryIfsc,
        beneficiaryVpa,
        transferMode,
        merchantTransactionId: `TEST_${Date.now()}`,
      },
      testResponse: {
        success: testResponse.response.success,
        status: testResponse.response.status,
        message: testResponse.response.message,
        utrNumber: testResponse.response.utrNumber,
        externalTransactionId: testResponse.response.externalTransactionId,
      },
      suggestions,
      fullResponse: testResponse.response.raw,
    });
  } catch (error) {
    console.error('POST /api/user/test-fingrow-api error:', error);
    return NextResponse.json(
      {
        error: 'Test failed',
        message: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 500 },
    );
  }
}

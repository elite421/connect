import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { executeFingrowTransaction } from '@/lib/fingrow-integration';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { apiId, testPayload: initialTestPayload } = body;
    let testPayload = initialTestPayload ? { ...initialTestPayload } : undefined;

    if (!apiId) {
      return NextResponse.json({ error: 'API ID required' }, { status: 400 });
    }

    const customApi = await prisma.customPaymentApi.findUnique({
      where: { id: apiId },
    });

    if (!customApi) {
      return NextResponse.json({ error: 'API not found' }, { status: 404 });
    }

    // Allow override of apiKey (userid) from headers
    const overrideUserId = req.headers.get('userid');
    const effectiveApiKey = overrideUserId || customApi.apiKey;
    const effectiveApi = { ...customApi, apiKey: effectiveApiKey };

    if (customApi.userId && customApi.userId !== user.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    if (!testPayload) {
      const fullUrl = `${customApi.apiBaseUrl}${customApi.apiEndpoint}`.replace(/\s+/g, '');

      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);

        const healthCheckResponse = await fetch(fullUrl, {
          method: 'HEAD',
          signal: controller.signal,
        }).catch(() =>
          fetch(fullUrl, {
            method: customApi.apiMethod as 'GET' | 'POST' | 'PUT',
            signal: controller.signal,
          })
        );

        clearTimeout(timeout);
        const isOnline = healthCheckResponse?.ok || healthCheckResponse?.status !== 0;
        return NextResponse.json({ isOnline, message: 'Health check completed' });
      } catch {
        return NextResponse.json({ isOnline: false, message: 'API unreachable' });
      }
    }

    const fullUrl = `${customApi.apiBaseUrl}${customApi.apiEndpoint}`.replace(/\s+/g, '');

    // Check if this is a Fingrow API
    if (fullUrl.includes('fingrow') || fullUrl.includes('pay.fingrowaitech.com')) {
      const merchantId = customApi.apiKey;
      if (!merchantId) {
        return NextResponse.json({
          success: false,
          statusCode: 400,
          message: 'Fingrow API detected but Merchant ID (API Key) is missing',
          error: 'MISSING_MERCHANT_ID'
        }, { status: 400 });
      }

      // Extract channel from apiSecret JSON config (e.g., {"channel": "FNZ"})
      let channel = 'FNZ';
      try {
        if (customApi.apiSecret) {
          const config = JSON.parse(customApi.apiSecret);
          channel = config.channel || 'FNZ';
        }
      } catch (e) {
        // Keep default FNZ if parsing fails
      }

      try {
        const fingrowResponse = await executeFingrowTransaction(merchantId, fullUrl, {
          amount: testPayload?.amount ? Math.round(Number(testPayload.amount)) : 100,
          beneficiaryName: testPayload?.beneficiaryName || 'Test User',
          beneficiaryAccount: testPayload?.beneficiaryAccount || '2029001700058769',
          beneficiaryIfsc: testPayload?.beneficiaryIfsc || 'PUNB0202900',
          beneficiaryVpa: testPayload?.beneficiaryVpa || 'amansingh9532@okicici',
          transferMode: testPayload?.transferMode || 'IMPS',
          merchantTransactionId: `TEST_${Date.now()}`,
          ipAddress: '127.0.0.1',
          userAgent: 'API Test Tool',
          channel
        });

        return NextResponse.json({
          success: fingrowResponse.success,
          statusCode: fingrowResponse.success ? 200 : 400,
          response: fingrowResponse.raw,
          message: fingrowResponse.message,
        });
      } catch (error) {
        return NextResponse.json({
          success: false,
          statusCode: 500,
          message: 'Fingrow API test failed',
          error: String(error)
        }, { status: 500 });
      }
    }

    // CHECK FOR RUDRAXPAY - Special handling for userid in body
    if (fullUrl.includes('rudraxpay.com') || (customApi.apiName && customApi.apiName.toLowerCase().includes('rudrax'))) {
      const secretConf = customApi.apiSecret ? JSON.parse(customApi.apiSecret) : {};
      const merchantId = effectiveApi.apiKey || secretConf.userid;
      // 'apiToken' not in type, get from secret or if exists on generic object
      const token = secretConf.token || secretConf.apiToken || effectiveApi.apiSecret;

      if (!testPayload) testPayload = {};
      if (merchantId && !testPayload.userid) testPayload.userid = merchantId;
      if (token && !testPayload.token) testPayload.token = token;

      // Ensure standard fields are mapped for RudraxPay
      if (!testPayload.ifsc && (testPayload.beneficiaryIfsc || testPayload.ifscCode)) {
        testPayload.ifsc = testPayload.beneficiaryIfsc || testPayload.ifscCode;
      }
      if (!testPayload.number && (testPayload.beneficiaryAccount || testPayload.accountNumber)) {
        testPayload.number = testPayload.beneficiaryAccount || testPayload.accountNumber;
      }
      if (!testPayload.name && (testPayload.beneficiaryName || testPayload.accountName)) {
        testPayload.name = testPayload.beneficiaryName || testPayload.accountName;
      }
      if (!testPayload.mobile) {
        testPayload.mobile = testPayload.beneficiaryMobile || '9876543210';
      }

      // Ensure orderid exists
      if (!testPayload.orderid) {
        testPayload.orderid = testPayload.merchantTransactionId || `test_${Date.now()}`;
      }
    }

    // Standard custom API request
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (effectiveApi.authType === 'bearer' && effectiveApi.apiKey) {
      headers['Authorization'] = `Bearer ${effectiveApi.apiKey}`;
    } else if (effectiveApi.authType === 'basic' && effectiveApi.apiKey && effectiveApi.apiSecret) {
      const credentials = Buffer.from(`${effectiveApi.apiKey}:${effectiveApi.apiSecret}`).toString('base64');
      headers['Authorization'] = `Basic ${credentials}`;
    } else if (effectiveApi.authType === 'apikey' && effectiveApi.authHeader && effectiveApi.apiKey) {
      headers[effectiveApi.authHeader] = effectiveApi.apiKey;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);

    const response = await fetch(fullUrl, {
      method: customApi.apiMethod as 'GET' | 'POST' | 'PUT',
      headers,
      body: testPayload ? JSON.stringify(testPayload) : undefined,
      signal: controller.signal,
    });

    clearTimeout(timeout);
    const responseText = await response.text();
    let responseData;
    try {
      responseData = JSON.parse(responseText);
    } catch {
      responseData = responseText;
    }

    return NextResponse.json({
      success: response.ok,
      statusCode: response.status,
      response: responseData,
      message: response.ok ? 'API test successful' : 'API returned error',
    });
  } catch (error) {
    console.error('POST /api/user/test-api error:', error);
    return NextResponse.json(
      {
        success: false,
        error: String(error),
        message: 'Failed to test API',
      },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';
import crypto from 'crypto';
import { safeJson } from '@/lib/safe-json';

// Generate callback token
function generateCallbackToken(): string {
    return crypto.randomBytes(32).toString('hex');
}

// GET: Fetch user's custom APIs (submitted for admin configuration)
export async function GET(req: NextRequest) {
    const user = await authMiddleware(req, ['USER', 'SUBUSER']);
    if (user instanceof NextResponse) return user;

    try {
        const apis = await prisma.customPaymentApi.findMany({
            where: {
                userId: user.id,
                adminProvided: false,
            },
            orderBy: { createdAt: 'desc' },
        });

        return safeJson({ success: true, data: serializeBigInt(apis) });
    } catch (error) {
        console.error('GET /api/user/custom-apis error:', error);
        return safeJson({ error: 'Failed to fetch APIs' }, { status: 500 });
    }
}

// POST: User submits API details for admin to configure
export async function POST(req: NextRequest) {
    const user = await authMiddleware(req, ['USER']);
    if (user instanceof NextResponse) return user;

    try {
        const body = await req.json();
        const {
            apiName,
            apiBaseUrl,
            apiEndpoint,
            apiMethod,
            authType,
            apiKey,
            apiSecret,
            authHeader,
            requestFormat,
            responseFormat,
            apiType,
            allowedModes,
            statusCheckUrl,
        } = body;

        if (!apiName || !apiBaseUrl || !apiEndpoint) {
            return safeJson(
                { error: 'API name, base URL, and endpoint are required' },
                { status: 400 }
            );
        }

        // Generate unique API number using independent transaction to ensure no gaps or locks
        // Note: For high concurrency, this might need refinement, but sufficient for this scale
        let apiNumber = "1";

        try {
            const counter = await prisma.counter.upsert({
                where: { name: 'custom_api_number' },
                update: { count: { increment: 1 } },
                create: { name: 'custom_api_number', count: 1 },
            });
            apiNumber = counter.count.toString();
        } catch (error) {
            console.error("Failed to generate API number, falling back to timestamp", error);
            apiNumber = Date.now().toString();
        }

        const callbackToken = generateCallbackToken();

        const api = await prisma.customPaymentApi.create({
            data: {
                userId: user.id,
                adminProvided: false, // User-submitted, needs admin configuration
                apiName,
                apiBaseUrl,
                apiEndpoint,
                apiMethod: apiMethod || 'POST',
                authType: authType || 'bearer',
                apiKey: apiKey || null,
                apiSecret: apiSecret || null,
                authHeader: authHeader || null,
                requestFormat: requestFormat || null,
                responseFormat: responseFormat || null,
                isActive: false, // Inactive until admin configures
                isDefault: false,
                apiType: apiType || 'PAYOUT',
                allowedModes: allowedModes || ['IMPS', 'NEFT', 'UPI', 'RTGS'],
                statusCheckUrl: statusCheckUrl || null,
                apiNumber,
                callbackToken,
            },
        });

        return safeJson(
            {
                success: true,
                data: api,
                message: 'API submitted for admin configuration. You will be notified once it is activated.',
            },
            { status: 201 }
        );
    } catch (error) {
        console.error('POST /api/user/custom-apis error:', error);
        return safeJson({ error: 'Failed to submit API' }, { status: 500 });
    }
}

// PATCH: User updates their submitted API details (only if not yet activated)
export async function PATCH(req: NextRequest) {
    const user = await authMiddleware(req, ['USER']);
    if (user instanceof NextResponse) return user;

    try {
        const body = await req.json();
        const {
            id,
            apiName,
            apiBaseUrl,
            apiEndpoint,
            apiMethod,
            authType,
            apiKey,
            apiSecret,
            authHeader,
            requestFormat,
            responseFormat,
            apiType,
            allowedModes,
            statusCheckUrl,
        } = body;

        if (!id) {
            return safeJson({ error: 'API ID is required' }, { status: 400 });
        }

        // Check if API belongs to user and is not yet activated
        const existingApi = await prisma.customPaymentApi.findFirst({
            where: { id, userId: user.id },
        });

        if (!existingApi) {
            return safeJson({ error: 'API not found' }, { status: 404 });
        }

        if (existingApi.isActive) {
            return safeJson(
                { error: 'Cannot modify an active API. Contact admin to deactivate first.' },
                { status: 400 }
            );
        }

        const api = await prisma.customPaymentApi.update({
            where: { id },
            data: {
                apiName,
                apiBaseUrl,
                apiEndpoint,
                apiMethod,
                authType,
                apiKey: apiKey || null,
                apiSecret: apiSecret || null,
                authHeader: authHeader || null,
                requestFormat: requestFormat || null,
                responseFormat: responseFormat || null,
                apiType,
                allowedModes,
                statusCheckUrl: statusCheckUrl || null,
            },
        });

        return safeJson({ success: true, data: serializeBigInt(api) });
    } catch (error) {
        console.error('PATCH /api/user/custom-apis error:', error);
        return safeJson({ error: 'Failed to update API' }, { status: 500 });
    }
}

// DELETE: User deletes their submitted API (only if not yet activated)
export async function DELETE(req: NextRequest) {
    const user = await authMiddleware(req, ['USER']);
    if (user instanceof NextResponse) return user;

    try {
        const { searchParams } = new URL(req.url);
        const id = searchParams.get('id');

        if (!id) {
            return safeJson({ error: 'API ID is required' }, { status: 400 });
        }

        // Check if API belongs to user and is not yet activated
        const existingApi = await prisma.customPaymentApi.findFirst({
            where: { id, userId: user.id },
        });

        if (!existingApi) {
            return safeJson({ error: 'API not found' }, { status: 404 });
        }

        if (existingApi.isActive) {
            return safeJson(
                { error: 'Cannot delete an active API. Contact admin to deactivate first.' },
                { status: 400 }
            );
        }

        await prisma.customPaymentApi.delete({ where: { id } });

        return safeJson({ success: true, message: 'API deleted' });
    } catch (error) {
        console.error('DELETE /api/user/custom-apis error:', error);
        return safeJson({ error: 'Failed to delete API' }, { status: 500 });
    }
}

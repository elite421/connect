import { NextRequest, NextResponse } from 'next/server';
import { authMiddleware } from '@/lib/middleware';
import { isKYCApproved } from '@/lib/kyc';
import prisma from '@/lib/prisma';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const isSubUser = (user as any).role === 'SUBUSER';
    const kycSubmission = await prisma.kycSubmission.findFirst({
      where: isSubUser ? { subUserId: user.id } : { userId: user.id },
    });

    return safeJson({
      success: true,
      status: kycSubmission?.kycStatus || 'pending',
      data: kycSubmission,
    });
  } catch (error) {
    console.error('GET /api/user/kyc-status error:', error);
    return safeJson({ error: 'Failed to fetch KYC status' }, { status: 500 });
  }
}

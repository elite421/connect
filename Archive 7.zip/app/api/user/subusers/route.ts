import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { hash } from 'bcryptjs';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const [subUsers, total] = await Promise.all([
      prisma.subUser.findMany({
        where: { userId: user.id },
        select: {
          id: true,
          username: true,
          name: true,
          email: true,
          phone: true,
          isActive: true,
          isApiEnabled: true,
          permissions: true,
          createdAt: true,
          _count: {
            select: { payments: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.subUser.count({ where: { userId: user.id } }),
    ]);

    return NextResponse.json({
      success: true,
      data: serializeBigInt(subUsers),
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/user/subusers error:', error);
    return NextResponse.json({ error: 'Failed to fetch subusers' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { username, name, email, password, phone, permissions } = body;

    if (!username || !name || !email || !password) {
      return NextResponse.json(
        { error: 'Username, name, email, and password required' },
        { status: 400 }
      );
    }

    const existingSubUser = await prisma.subUser.findUnique({
      where: { username },
    });

    if (existingSubUser) {
      return NextResponse.json(
        { error: 'Username already exists' },
        { status: 409 }
      );
    }

    const hashedPassword = await hash(password, 10);

    const subUser = await prisma.subUser.create({
      data: {
        userId: user.id,
        username,
        name,
        email,
        password: hashedPassword,
        phone: phone || null,
        permissions: permissions || { transfer: false, add_beneficiary: false, pay_bills: false },
      },
    });

    await logActivity({
      user,
      action: 'create_subuser',
      resource: 'subuser',
      resourceId: subUser.id,
      metadata: { username, email },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ success: true, data: serializeBigInt(subUser) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/subusers error:', error);
    return NextResponse.json({ error: 'Failed to create subuser' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { subUserId, name, email, phone, isActive, isApiEnabled, permissions } = body;

    if (!subUserId) {
      return NextResponse.json({ error: 'SubUser ID required' }, { status: 400 });
    }

    const subUser = await prisma.subUser.update({
      where: { id: subUserId, userId: user.id },
      data: {
        ...(name && { name }),
        ...(email && { email }),
        ...(phone && { phone }),
        ...(isActive !== undefined && { isActive }),
        ...(isApiEnabled !== undefined && { isApiEnabled }),
        ...(permissions && { permissions }),
      },
    });

    await logActivity({
      user,
      action: 'update_subuser',
      resource: 'subuser',
      resourceId: subUserId,
      metadata: { name, email, permissions, isApiEnabled },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ success: true, data: serializeBigInt(subUser) });
  } catch (error) {
    console.error('PATCH /api/user/subusers error:', error);
    return NextResponse.json({ error: 'Failed to update subuser' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const subUserId = searchParams.get('subUserId');

    if (!subUserId) {
      return NextResponse.json({ error: 'SubUser ID required' }, { status: 400 });
    }

    await prisma.subUser.delete({
      where: { id: subUserId, userId: user.id },
    });

    await logActivity({
      user,
      action: 'delete_subuser',
      resource: 'subuser',
      resourceId: subUserId,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ success: true, message: 'SubUser deleted' });
  } catch (error) {
    console.error('DELETE /api/user/subusers error:', error);
    return NextResponse.json({ error: 'Failed to delete subuser' }, { status: 500 });
  }
}

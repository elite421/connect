import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const accounts: any[] = await prisma.$queryRaw`
      SELECT * FROM "BankAccount" 
      WHERE "userId" = ${user.id} 
      ORDER BY "isPrimary" DESC, "createdAt" DESC
    `;

    return safeJson({ success: true, data: serializeBigInt(accounts) });
  } catch (error) {
    console.error('GET /api/user/bank-accounts error:', error);
    return safeJson({ error: 'Failed to fetch bank accounts' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { accountHolderName, accountNumber, ifscCode, bankName, branchName, accountType, isPrimary } = body;

    if (!accountHolderName || !accountNumber || !ifscCode || !bankName) {
      return safeJson({ error: 'All required fields must be provided' }, { status: 400 });
    }

    if (isPrimary) {
      await prisma.bankAccount.updateMany({
        where: { userId: user.id },
        data: { isPrimary: false },
      });
    }

    await prisma.bankAccount.create({
      data: {
        userId: user.id,
        accountHolderName,
        accountNumber,
        ifscCode,
        bankName,
        branchName: branchName || null,
        accountType: accountType || 'current',
        isPrimary: isPrimary || false,
        isVerified: false,
        isActive: true,
      },
    });

    return safeJson({ success: true, message: 'Bank account added' }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/bank-accounts error:', error);
    return safeJson({ error: 'Failed to add bank account' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { id, isPrimary, isActive } = body;

    if (!id) return safeJson({ error: 'Account ID required' }, { status: 400 });

    if (isPrimary) {
      await prisma.bankAccount.updateMany({
        where: { userId: user.id },
        data: { isPrimary: false },
      });
    }

    await prisma.bankAccount.update({
      where: { id },
      data: {
        ...(isPrimary !== undefined && { isPrimary }),
        ...(isActive !== undefined && { isActive }),
      },
    });

    return safeJson({ success: true, message: 'Bank account updated' });
  } catch (error) {
    console.error('PATCH /api/user/bank-accounts error:', error);
    return safeJson({ error: 'Failed to update bank account' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) return safeJson({ error: 'Account ID required' }, { status: 400 });

    await prisma.bankAccount.deleteMany({
      where: { id, userId: user.id },
    });

    return safeJson({ success: true, message: 'Bank account deleted' });
  } catch (error) {
    console.error('DELETE /api/user/bank-accounts error:', error);
    return safeJson({ error: 'Failed to delete bank account' }, { status: 500 });
  }
}

import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { toPaise, toRupees } from "@/lib/money";
import { safeJson } from "@/lib/safe-json";

export async function GET() {
  const session = await auth();
  const userId = (session as { user?: { id?: string } }).user?.id;
  if (!userId) return safeJson({ error: "Unauthorized" }, { status: 401 });
  const items = await prisma.payout.findMany({ where: { userId }, orderBy: { createdAt: "desc" } });
  return safeJson(items.map(i => ({ id: i.id, beneficiary: i.beneficiary, account: i.account, amount: toRupees(i.amount).toString(), currency: i.currency, status: i.status, createdAt: i.createdAt })));
}

export async function POST(req: Request) {
  const session = await auth();
  const userId = (session as { user?: { id?: string } }).user?.id;
  if (!userId) return safeJson({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const beneficiary = typeof body.beneficiary === "string" ? body.beneficiary.trim() : "";
  const account = typeof body.account === "string" ? body.account.trim() : "";
  const amount = Number(body.amount);
  const currency = body.currency === "USD" ? "USD" : "INR";
  if (!beneficiary || !account || !amount) return safeJson({ error: "Invalid" }, { status: 400 });
  const created = await prisma.payout.create({ data: { userId, beneficiary, account, amount: toPaise(amount), currency, status: "queued" } });
  return safeJson({ id: created.id }, { status: 201 });
}

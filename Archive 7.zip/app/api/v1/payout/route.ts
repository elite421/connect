
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { validateApiKeyWithIp, logApiRequest } from '@/lib/api-auth';
import { toRupees } from '@/lib/money';
import { applyPaymentScheme, validateTransactionAmount } from '@/lib/payment-scheme';
import { callPayoutApi } from '@/lib/payout-integration';

export async function POST(req: NextRequest) {
    const startTime = Date.now();

    // Authenticate with IP validation
    const auth = await validateApiKeyWithIp(req);

    if (!auth.success) {
        if (auth.error === 'INVALID_KEY') {
            return NextResponse.json(
                { success: false, error: 'Unauthorized: Invalid or expired API Key' },
                { status: 401 }
            );
        }
        if (auth.error === 'IP_NOT_WHITELISTED') {
            return NextResponse.json(
                {
                    success: false,
                    error: 'Unauthorized IP. Please add your IP address to the whitelist in Developer Portal.',
                    clientIp: auth.clientIp
                },
                { status: 403 }
            );
        }
    }

    const { user, apiKey } = auth as { success: true; user: any; apiKey: any; clientIp: string };

    // Permissions check (simple implementation)
    if (!apiKey.permissions.includes('write')) {
        await logApiRequest(apiKey.id, user.id, req, 403, Date.now() - startTime, 'Insufficient permissions');
        return NextResponse.json(
            { success: false, error: 'Forbidden: Write permission required' },
            { status: 403 }
        );
    }

    try {
        const body = await req.json();
        const {
            amount,
            beneficiaryName,
            beneficiaryAccount,
            beneficiaryIfsc,
            beneficiaryVpa,
            transferMode,
            metadata
        } = body;

        // Validation
        if (!amount || amount <= 0 || !beneficiaryName || !transferMode) {
            return NextResponse.json({ success: false, error: 'Missing required fields' }, { status: 400 });
        }

        if (transferMode === 'upi' && !beneficiaryVpa) {
            return NextResponse.json({ success: false, error: 'VPA required for UPI' }, { status: 400 });
        }

        if (transferMode !== 'upi' && (!beneficiaryAccount || !beneficiaryIfsc)) {
            return NextResponse.json({ success: false, error: 'Account/IFSC required' }, { status: 400 });
        }

        const amountInRupees = Number(amount);

        // Apply Payment Scheme & Charges
        const schemeResult = await applyPaymentScheme(user.id, 'payout');

        // Validate limits
        const validation = validateTransactionAmount(
            amountInRupees,
            schemeResult.minTransactionAmount,
            schemeResult.maxTransactionAmount
        );
        if (!validation.valid) {
            return NextResponse.json({ success: false, error: validation.error }, { status: 400 });
        }

        // Calculate Charges
        // Calculate Charges
        const totalChargeRupees = (schemeResult.totalChargeWithGst || 0);
        const totalDebit = amountInRupees + totalChargeRupees;

        // Check Wallet
        const wallet = await prisma.wallet.findUnique({ where: { userId: user.id } });
        if (!wallet) {
            return NextResponse.json({ success: false, error: 'Wallet not found' }, { status: 404 });
        }

        // Handle BigInt balance
        // Handle Balance
        const balance = Number(wallet.balance);
        const frozen = wallet.frozenBalance ? Number(wallet.frozenBalance) : 0;
        const available = balance - frozen;

        if (available < totalDebit) {
            return NextResponse.json({
                success: false,
                error: 'Insufficient balance',
                data: {
                    required: totalDebit,
                    available: available
                }
            }, { status: 400 });
        }

        // Deduct Balance
        await prisma.wallet.update({
            where: { userId: user.id },
            data: {
                balance: (balance - totalDebit)
            }
        });

        // Create Transaction Record
        const transaction = await prisma.payOutTransaction.create({
            data: {
                userId: user.id,
                amount: amountInRupees,
                beneficiaryName,
                beneficiaryAccount: beneficiaryAccount || null,
                beneficiaryIfsc: beneficiaryIfsc || null,
                beneficiaryVpa: beneficiaryVpa || null,
                transferMode,
                status: 'processing', // Initial status
                // description: `API Payout to ${beneficiaryName}`,
                // chargeAmount: chargeAmountInPaise, 
                // taxAmount: toPaise(schemeResult.gstAmount || 0), 
                // metadata: metadata || {},
                // source: 'API'
                responseData: {
                    description: `API Payout to ${beneficiaryName}`,
                    chargeAmount: totalChargeRupees,
                    taxAmount: Number(schemeResult.gstAmount || 0),
                    metadata: metadata || {},
                    source: 'API'
                }
            }
        });

        // Log Wallet Transaction
        await prisma.walletTransactionLocal.create({
            data: {
                userId: user.id,
                walletId: wallet.id,
                amount: totalDebit,
                // balanceBefore removed as not in schema
                balanceAfter: (balance - totalDebit),
                type: 'DEBIT',
                description: `Payout #${transaction.id}`,
                referenceId: transaction.id,
                referenceType: 'PAYOUT',
                chargeAmount: totalChargeRupees,
                metadata: { source: 'API' }
            }
        });

        // Call Provider API
        const payoutRequest = {
            amount,
            beneficiaryName,
            beneficiaryAccount,
            beneficiaryIfsc,
            beneficiaryVpa,
            transferMode,
            merchantTransactionId: transaction.id,
            userEmail: user.email,
            userPhone: user.phone || undefined
        };

        // Use integration library to send request
        const rudraxUserId = req.headers.get('userid') || undefined;
        const apiResult = await callPayoutApi(user.id, payoutRequest, { rudraxUserId });

        // Update transaction with result
        const finalStatus = apiResult.response.success ? (apiResult.response.status || 'processing') : 'failed';

        await prisma.payOutTransaction.update({
            where: { id: transaction.id },
            data: {
                status: finalStatus,
                utrNumber: apiResult.response.utrNumber ? String(apiResult.response.utrNumber) : null,
                externalTransactionId: apiResult.response.externalTransactionId ? String(apiResult.response.externalTransactionId) : null,
                responseData: apiResult.response.raw || {}
            }
        });

        // If failed immediately, refund the wallet
        if (finalStatus === 'failed') {
            // Refund wallet
            await prisma.wallet.update({
                where: { userId: user.id },
                data: {
                    balance: { increment: totalDebit }
                }
            });

            // Log refund transaction
            const newBalance = balance; // Restored to original
            await prisma.walletTransactionLocal.create({
                data: {
                    userId: user.id,
                    walletId: wallet.id,
                    amount: totalDebit,
                    balanceAfter: newBalance,
                    type: 'PAYOUT_REFUND',
                    description: `Refund for failed payout #${transaction.id}`,
                    referenceId: transaction.id,
                    referenceType: 'PAYOUT_REFUND',
                    chargeAmount: totalChargeRupees,
                    metadata: {
                        source: 'API',
                        reason: apiResult.response.message || 'API call failed'
                    }
                }
            });

            const response = {
                success: false,
                error: 'Payout failed',
                message: apiResult.response.message || 'Gateway rejected the transaction',
                transactionId: transaction.id,
                status: 'failed',
                refunded: true
            };

            await logApiRequest(apiKey.id, user.id, req, 200, Date.now() - startTime);
            return NextResponse.json(response);
        }

        const response = {
            success: true,
            transactionId: transaction.id,
            status: finalStatus,
            utr: apiResult.response.utrNumber,
            amount: amount,
            charge: totalChargeRupees
        };



        await logApiRequest(apiKey.id, user.id, req, 200, Date.now() - startTime);
        return NextResponse.json(response);

    } catch (error: any) {
        console.error('Payout API Error:', error);
        await logApiRequest(apiKey.id, user.id, req, 500, Date.now() - startTime, error.message);
        return NextResponse.json({ success: false, error: 'Internal Server Error' }, { status: 500 });
    }
}

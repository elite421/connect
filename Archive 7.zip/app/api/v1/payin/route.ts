
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { validateApiKeyWithIp, logApiRequest } from '@/lib/api-auth';
import { initiateRudraxPayPayin } from '@/lib/rudraxpay-integration';

// Helper to extract IP from request (duplicate from middleware to avoid circular deps or complex imports if any)
function extractIpAddress(req: NextRequest): string {
    const forwarded = req.headers.get('x-forwarded-for');
    return forwarded ? forwarded.split(',')[0].trim() : '127.0.0.1';
}

export async function POST(req: NextRequest) {
    const startTime = Date.now();

    // 1. Authenticate
    const auth = await validateApiKeyWithIp(req);

    if (!auth.success) {
        if (auth.error === 'INVALID_KEY') {
            return NextResponse.json(
                { success: false, error: 'Unauthorized: Invalid or expired API Key' },
                { status: 401 }
            );
        }
        if (auth.error === 'IP_NOT_WHITELISTED') {
            return NextResponse.json(
                {
                    success: false,
                    error: 'Unauthorized IP. Please add your IP address to the whitelist in Developer Portal.',
                    clientIp: auth.clientIp
                },
                { status: 403 }
            );
        }
    }

    const { user, apiKey } = auth as { success: true; user: any; apiKey: any; clientIp: string };

    // 2. Permission Check
    if (!apiKey.permissions.includes('write')) {
        await logApiRequest(apiKey.id, user.id, req, 403, Date.now() - startTime, 'Insufficient permissions');
        return NextResponse.json(
            { success: false, error: 'Forbidden: Write permission required' },
            { status: 403 }
        );
    }

    try {
        const body = await req.json();
        const {
            amount,
            customerName,
            customerEmail,
            customerPhone,
            paymentMethod = 'upi',
            merchantTransactionId,
            metadata // Optional metadata from user
        } = body;

        // 3. Validation
        if (!amount || Number(amount) <= 0) {
            return NextResponse.json({ success: false, error: 'Invalid amount' }, { status: 400 });
        }
        if (!customerName || !customerPhone || !customerEmail) {
            return NextResponse.json({ success: false, error: 'Customer details (name, email, phone) required' }, { status: 400 });
        }

        const ipAddress = auth.clientIp || extractIpAddress(req);

        // 4. Create Transaction Record
        const transaction = await prisma.payInTransaction.create({
            data: {
                userId: user.id,
                amount: Number(amount),
                customerName,
                customerEmail,
                customerPhone,
                paymentMethod,
                merchantTransactionId: merchantTransactionId || null,
                ipAddress,
                status: 'pending',
                responseData: {
                    metadata: metadata || {},
                    source: 'API'
                }
            },
        });

        let apiData: any = null;
        let gatewayResponse: any = null;

        // 5. Resolve Payin API
        async function resolvePayinApiForUser(userId: string) {
            // 0) Check CustomPaymentApi for User (Modern System)
            const customApi = await prisma.customPaymentApi.findFirst({
                where: {
                    userId,
                    isActive: true,
                    apiType: 'PAYIN'
                },
                orderBy: { isDefault: 'desc' }
            });

            if (customApi) {
                return {
                    id: customApi.id,
                    name: customApi.apiName,
                    baseUrl: customApi.apiBaseUrl,
                    apiKey: customApi.apiKey,
                    apiSecret: customApi.apiSecret,
                    authHeader: customApi.authHeader,
                    scopes: JSON.stringify({
                        payinEndpoint: customApi.apiEndpoint,
                        requestTemplate: customApi.requestFormat ? JSON.stringify(customApi.requestFormat) : null,
                    })
                };
            }

            // 1) Fallbacks (Legacy UserApi)
            const account = await prisma.user.findUnique({ where: { id: userId } });
            if (account?.defaultApiId) {
                const explicit = await prisma.userApi.findFirst({ where: { id: account.defaultApiId, isActive: true } });
                if (explicit) return explicit;
            }

            const userDefault = await prisma.userApi.findFirst({ where: { userId, isActive: true, isDefault: true }, orderBy: { createdAt: 'desc' } });
            if (userDefault) return userDefault;

            const anyUserApi = await prisma.userApi.findFirst({ where: { userId, isActive: true }, orderBy: { createdAt: 'desc' } });
            if (anyUserApi) return anyUserApi;

            // 4) Check for Global/Admin CustomPaymentApi
            const adminCustomApi = await prisma.customPaymentApi.findFirst({
                where: {
                    adminProvided: true,
                    isActive: true,
                    apiType: 'PAYIN'
                },
                orderBy: { isDefault: 'desc' }
            });

            if (adminCustomApi) {
                return {
                    id: adminCustomApi.id,
                    name: adminCustomApi.apiName,
                    baseUrl: adminCustomApi.apiBaseUrl,
                    apiKey: adminCustomApi.apiKey,
                    apiSecret: adminCustomApi.apiSecret,
                    authHeader: adminCustomApi.authHeader,
                    scopes: JSON.stringify({
                        payinEndpoint: adminCustomApi.apiEndpoint,
                        requestTemplate: adminCustomApi.requestFormat ? JSON.stringify(adminCustomApi.requestFormat) : null,
                    })
                };
            }

            // 5) Legacy Admin Defaults
            const adminDefault = await prisma.userApi.findFirst({ where: { isDefault: true, isActive: true, user: { role: 'ADMIN' as any } }, orderBy: { createdAt: 'desc' } });
            if (adminDefault) return adminDefault;

            const systemDefault = await prisma.userApi.findFirst({ where: { isDefault: true, isActive: true }, orderBy: { createdAt: 'desc' } });
            return systemDefault;
        }

        const resolvedApi = await resolvePayinApiForUser(user.id);
        if (!resolvedApi) {
            return NextResponse.json({ success: false, error: 'No PayIn API configured' }, { status: 400 });
        }
        apiData = resolvedApi;

        // 6. RUDRAXPAY BRIDGE (Special Integration)
        if ((apiData.baseUrl && apiData.baseUrl.includes('rudraxpay.com')) || (apiData.name && apiData.name.toLowerCase().includes('rudrax'))) {
            const userid = apiData.apiKey;
            const token = apiData.apiSecret || apiData.apiToken;

            if (!userid || !token) {
                throw new Error('RudraxPay configuration missing UserID (API Key) or Token (API Secret)');
            }

            const rudraxRes = await initiateRudraxPayPayin(
                apiData.baseUrl || 'https://merchant.rudraxpay.com/api',
                { userid, token },
                {
                    amount: Number(amount),
                    name: customerName,
                    mobile: customerPhone,
                    orderid: merchantTransactionId || transaction.id,
                    callbackUrl: `${process.env.NEXT_PUBLIC_APP_URL}/api/callback/rudraxpay/payin` // Or standard callback
                }
            );

            await prisma.payInTransaction.update({
                where: { id: transaction.id },
                data: {
                    status: rudraxRes.success ? 'processing' : 'failed',
                    merchantTransactionId: merchantTransactionId || transaction.id,
                    responseData: rudraxRes.raw
                }
            });

            if (rudraxRes.success && rudraxRes.url) {
                await logApiRequest(apiKey.id, user.id, req, 200, Date.now() - startTime);
                return NextResponse.json({
                    success: true,
                    transactionId: transaction.id,
                    status: 'processing',
                    paymentLink: rudraxRes.url,
                    amount: Number(amount)
                });
            } else {
                // Remove/Fail transaction? Kept as failed.
                await logApiRequest(apiKey.id, user.id, req, 400, Date.now() - startTime, rudraxRes.message);
                return NextResponse.json({
                    success: false,
                    error: rudraxRes.message || 'Payment initiation failed',
                    transactionId: transaction.id
                }, { status: 400 });
            }
        }
        // END RUDRAXPAY BRIDGE

        // 7. Generic API Call
        const scopes = (() => { try { return apiData.scopes ? JSON.parse(apiData.scopes) : {}; } catch { return {}; } })();
        const callbackUrl = scopes?.callbackUrl || `${process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/payin`; // Internal webhook handler

        const headers: Record<string, string> = { 'Content-Type': 'application/json' };
        if (apiData.authHeader && (apiData.apiToken || apiData.apiKey)) {
            headers[String(apiData.authHeader)] = String(apiData.apiToken || apiData.apiKey);
        } else if (apiData.apiToken) {
            headers['Authorization'] = `Bearer ${apiData.apiToken}`;
        } else if (apiData.apiKey && apiData.apiSecret) {
            const basic = Buffer.from(`${apiData.apiKey}:${apiData.apiSecret}`).toString('base64');
            headers['Authorization'] = `Basic ${basic}`;
        } else if (apiData.apiKey) {
            if (!headers['Authorization']) {
                headers['Authorization'] = `Bearer ${apiData.apiKey}`;
            }
        }

        let endpoint = apiData.baseUrl as string;
        if (scopes?.payinEndpoint) endpoint = String(scopes.payinEndpoint);
        if (!endpoint) throw new Error('Payment API endpoint not configured');

        if (endpoint.startsWith('/') && apiData.baseUrl) {
            endpoint = `${apiData.baseUrl.replace(/\/$/, '')}${endpoint}`;
        }

        // Default Payload
        let requestPayload: Record<string, any> = {
            amount: Number(amount).toString(),
            customerName,
            customerEmail,
            customerPhone,
            orderId: merchantTransactionId || transaction.id,
            callbackUrl
        };

        // Template processing
        if (scopes?.requestTemplate) {
            try {
                const template = typeof scopes.requestTemplate === 'string' ? JSON.parse(scopes.requestTemplate) : scopes.requestTemplate;
                const rawTemplate = JSON.stringify(template);
                const replacedTemplate = rawTemplate
                    .replace(/{{amount}}/g, String(amount))
                    .replace(/{{transactionId}}/g, transaction.id) // Internal ID
                    .replace(/{{orderId}}/g, merchantTransactionId || transaction.id) // Merchant ID
                    .replace(/{{customerName}}/g, customerName || '')
                    .replace(/{{customerEmail}}/g, customerEmail || '')
                    .replace(/{{customerPhone}}/g, customerPhone || '');
                requestPayload = JSON.parse(replacedTemplate);
            } catch { }
        }

        // Attempt Request
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 30000);

        const gatewayCall = await fetch(endpoint, {
            method: 'POST',
            headers,
            body: JSON.stringify(requestPayload),
            signal: controller.signal,
        });
        if (timeoutId) clearTimeout(timeoutId);

        const responseText = await gatewayCall.text();
        try {
            gatewayResponse = JSON.parse(responseText);
        } catch {
            gatewayResponse = { raw: responseText };
        }

        await prisma.payInTransaction.update({
            where: { id: transaction.id },
            data: {
                status: gatewayCall.ok ? 'processing' : 'failed',
                merchantTransactionId: gatewayResponse?.orderId || gatewayResponse?.trxId || merchantTransactionId || transaction.id,
                responseData: gatewayResponse
            },
        });

        if (!gatewayCall.ok) {
            await logApiRequest(apiKey.id, user.id, req, 502, Date.now() - startTime, 'Gateway Error');
            return NextResponse.json({
                success: false,
                error: 'Gateway reported an error',
                gatewayMessage: gatewayResponse?.message || gatewayResponse?.error
            }, { status: 502 });
        }

        // Extract payment link if possible (generic attempt)
        const paymentLink = gatewayResponse?.url || gatewayResponse?.payment_url || gatewayResponse?.link || gatewayResponse?.data?.url || null;

        await logApiRequest(apiKey.id, user.id, req, 200, Date.now() - startTime);

        return NextResponse.json({
            success: true,
            transactionId: transaction.id,
            status: 'processing',
            paymentLink: paymentLink,
            amount: Number(amount),
            gatewayResponse // Pass through for debugging/custom handling by user
        });

    } catch (error: any) {
        console.error('API v1/payin Error:', error);
        if (apiKey) await logApiRequest(apiKey.id, user.id, req, 500, Date.now() - startTime, error.message);
        return NextResponse.json({ success: false, error: 'Internal Server Error' }, { status: 500 });
    }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

// Helper to safely handle BigInt in JSON serialization if needed, though here we return simple JSON
// We use 'any' casting for some Prisma inputs to avoid BigInt/Number strict type conflicts in this specific setup

export async function POST(req: NextRequest) {
    try {
        const body = await req.json();
        // Support various common field names
        const transactionId = body.transactionId || body.referenceId || body.txId;
        const status = body.status || body.stat;
        const utr = body.utr || body.utrNumber || body.rrn;
        const externalId = body.externalId || body.gatewayId || body.id;
        const failureReason = body.failureReason || body.message || body.error;

        if (!transactionId || !status) {
            return NextResponse.json({ success: false, error: 'Missing transactionId or status' }, { status: 400 });
        }

        const normalizedStatus = String(status).toLowerCase();

        let dbStatus = 'processing'; // Default fallback

        if (['success', 'completed', 'paid', 'credited'].includes(normalizedStatus)) {
            dbStatus = 'completed';
        } else if (['failed', 'rejected', 'error', 'declined', 'reversed'].includes(normalizedStatus)) {
            dbStatus = 'failed';
        } else if (['pending', 'processing', 'queued', 'initiated'].includes(normalizedStatus)) {
            dbStatus = 'processing';
        }

        // 1. Try PayOutTransaction
        const payout = await prisma.payOutTransaction.findUnique({
            where: { id: transactionId },
            include: { user: true }
        });

        if (payout) {
            // Avoid duplicate updates for final states
            if (['completed', 'failed'].includes(payout.status)) {
                return NextResponse.json({ success: true, message: 'Transaction already finalized', status: payout.status });
            }

            // Handle Refund if failing a previously non-failed transaction
            if (dbStatus === 'failed' && payout.status !== 'failed') {

                const debitTx = await prisma.walletTransactionLocal.findFirst({
                    where: {
                        referenceId: payout.id,
                        type: 'DEBIT'
                    }
                });

                if (debitTx) {
                    // Force BigInt conversion for safety
                    const refundAmount = BigInt(debitTx.amount);

                    // Update Wallet
                    await prisma.wallet.update({
                        where: { userId: payout.userId },
                        data: {
                            balance: { increment: refundAmount as any }
                        }
                    });

                    // Log Refund
                    await prisma.walletTransactionLocal.create({
                        data: {
                            userId: payout.userId,
                            walletId: debitTx.walletId,
                            amount: refundAmount as any,
                            balanceAfter: 0 as any, // Placeholder as we don't refetch
                            type: 'PAYOUT_REFUND',
                            description: `Refund for failed payout #${payout.id} (Callback)`,
                            referenceId: payout.id,
                            referenceType: 'PAYOUT_REFUND',
                            chargeAmount: BigInt(0) as any,
                            metadata: {
                                source: 'CALLBACK',
                                reason: failureReason || 'External callback reported failure'
                            }
                        }
                    });
                }
            }

            // Update Payout Status
            const updatedPayout = await prisma.payOutTransaction.update({
                where: { id: transactionId },
                data: {
                    status: dbStatus,
                    utrNumber: utr || payout.utrNumber,
                    externalTransactionId: externalId || payout.externalTransactionId,
                    updatedAt: new Date(),
                    responseData: {
                        ...(payout.responseData as object || {}),
                        callbackReceivedAt: new Date().toISOString(),
                        callbackBody: body
                    }
                }
            });

            return NextResponse.json({
                success: true,
                message: `Payout updated to ${dbStatus}`,
                id: updatedPayout.id
            });
        }

        // 2. Try PayInTransaction
        const payin = await prisma.payInTransaction.findUnique({
            where: { id: transactionId }
        });

        if (payin) {
            if (['completed', 'failed'].includes(payin.status)) {
                return NextResponse.json({ success: true, message: 'Transaction already finalized', status: payin.status });
            }

            // If PayIn succeeds, credit wallet
            if (dbStatus === 'completed' && payin.status !== 'completed') {
                // Add to wallet
                const wallet = await prisma.wallet.findUnique({ where: { userId: payin.userId } });
                if (wallet) {
                    await prisma.wallet.update({
                        where: { userId: payin.userId },
                        data: { balance: { increment: payin.amount as any } }
                    });

                    await prisma.walletTransactionLocal.create({
                        data: {
                            userId: payin.userId,
                            walletId: wallet.id,
                            amount: payin.amount as any,
                            balanceAfter: BigInt(0) as any,
                            type: 'PAYIN_CREDIT',
                            description: `PayIn Success #${payin.id}`,
                            referenceId: payin.id,
                            referenceType: 'PAYIN',
                            chargeAmount: BigInt(0) as any,
                            metadata: { source: 'CALLBACK' }
                        }
                    });
                }
            }

            const updatedPayin = await prisma.payInTransaction.update({
                where: { id: transactionId },
                data: {
                    status: dbStatus,
                    utrNumber: utr || payin.utrNumber,
                    externalTransactionId: externalId || payin.externalTransactionId,
                    updatedAt: new Date(),
                    responseData: {
                        ...(payin.responseData as object || {}),
                        callbackReceivedAt: new Date().toISOString(),
                        callbackBody: body
                    }
                }
            });

            return NextResponse.json({
                success: true,
                message: `PayIn updated to ${dbStatus}`,
                id: updatedPayin.id
            });
        }

        return NextResponse.json({ success: false, error: 'Transaction ID not found' }, { status: 404 });

    } catch (error) {
        console.error('Callback API Error:', error);
        return NextResponse.json({ success: false, error: 'Internal Server Error' }, { status: 500 });
    }
}

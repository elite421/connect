import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';

function serializeBigInt(obj: unknown): unknown {
    if (obj === null || obj === undefined) return obj;
    if (typeof obj === 'bigint') return obj.toString();
    if (obj instanceof Date) return obj.toISOString();
    if (typeof obj === 'object') {
        if (Array.isArray(obj)) return obj.map(serializeBigInt);
        const result: Record<string, unknown> = {};
        for (const [key, value] of Object.entries(obj)) {
            result[key] = serializeBigInt(value);
        }
        return result;
    }
    return obj;
}

export async function GET(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN', 'USER', 'SUBUSER']);
    if (user instanceof NextResponse) return user;

    try {
        const userRole = user.role;
        let userId = user.id;

        // For subusers, get parent user ID for visibility if needed, or just their own?
        // Usually disputes are per user. Subusers can see their own.

        const where = userRole === 'ADMIN' ? {} : { userId: user.id };

        const disputes = await prisma.dispute.findMany({
            where,
            include: {
                user: { select: { name: true, email: true } }
            },
            orderBy: { createdAt: 'desc' }
        });

        return NextResponse.json({ success: true, data: serializeBigInt(disputes) });
    } catch (error) {
        console.error('GET /api/disputes error:', error);
        return NextResponse.json({ error: 'Failed to fetch disputes' }, { status: 500 });
    }
}

export async function POST(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN', 'USER', 'SUBUSER']);
    if (user instanceof NextResponse) return user;

    try {
        const body = await req.json();
        const { type, transactionId, description } = body;

        if (!type || !description) {
            return NextResponse.json({ error: 'Type and description are required' }, { status: 400 });
        }

        const dispute = await prisma.dispute.create({
            data: {
                userId: user.id,
                type,
                transactionId,
                description,
                status: 'OPEN'
            }
        });

        return NextResponse.json({ success: true, data: serializeBigInt(dispute) });
    } catch (error) {
        console.error('POST /api/disputes error:', error);
        return NextResponse.json({ error: 'Failed to create dispute' }, { status: 500 });
    }
}

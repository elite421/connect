import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';

function serializeBigInt(obj: unknown): unknown {
  if (obj === null || obj === undefined) return obj;
  if (typeof obj === 'bigint') return obj.toString();
  if (obj instanceof Date) return obj.toISOString();
  if (typeof obj === 'object') {
    if (Array.isArray(obj)) return obj.map(serializeBigInt);
    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(obj)) {
      result[key] = serializeBigInt(value);
    }
    return result;
  }
  return obj;
}

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const payouts: unknown[] = await prisma.$queryRaw`
      SELECT 
        p."id", p."userId", p."amount", 
        p."beneficiaryName", p."beneficiaryAccount", p."beneficiaryIfsc", p."beneficiaryVpa",
        p."transferMode", p."utrNumber", p."status", p."ipAddress",
        p."externalTransactionId", p."responseData", p."subUserId",
        p."createdAt", p."updatedAt",
        u."name" as "userName", u."email" as "userEmail"
      FROM "PayOutTransaction" p
      LEFT JOIN "User" u ON p."userId" = u."id"
      ORDER BY p."createdAt" DESC
      LIMIT 500
    `;

    const stats: unknown[] = await prisma.$queryRaw`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'success' THEN 1 END) as success,
        COUNT(CASE WHEN status = 'pending' OR status = 'processing' THEN 1 END) as pending,
        COALESCE(SUM(amount), 0) as "totalAmount"
      FROM "PayOutTransaction"
    `;

    const statsData = stats[0] as Record<string, unknown>;

    // Normalize amounts to Rupees (divide by 100)
    const payoutsData = (payouts as any[]).map(p => ({
      ...p,
      amount: p.amount,
    }));

    return NextResponse.json({
      success: true,
      data: serializeBigInt(payoutsData),
      stats: {
        total: Number(statsData?.total || 0),
        success: Number(statsData?.success || 0),
        pending: Number(statsData?.pending || 0),
        totalAmount: Number(statsData?.totalAmount || 0),
      }
    });
  } catch (error) {
    console.error('GET /api/admin/payouts error:', error);
    return NextResponse.json({ error: 'Failed to fetch payouts' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { id, status } = body;

    if (!id || !status) {
      return NextResponse.json({ error: 'ID and status required' }, { status: 400 });
    }

    // 1. Get current transaction state
    const transaction = await prisma.payOutTransaction.findUnique({
      where: { id },
    });

    if (!transaction) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
    }

    // 2. Check if we need to process a refund (fail transition)
    const isFailing = status === 'failed' && transaction.status !== 'failed';

    if (isFailing) {
      // Calculate refund amount
      const responseData = transaction.responseData as any || {};
      const chargeInfo = responseData.chargeInfo;

      let totalDebit = 0;

      if (chargeInfo?.totalDebit) {
        totalDebit = Number(chargeInfo.totalDebit);
      } else {
        // Fallback: mostly for older transactions without chargeInfo
        // We can only reliably refund the base amount. 
        // Better to be conservative than refund too much/little without data.
        totalDebit = Number(transaction.amount);
      }

      // Execute Refund
      await prisma.$transaction(async (tx) => {
        // Credit Wallet
        await tx.wallet.update({
          where: { userId: transaction.userId },
          data: {
            balance: { increment: totalDebit }
          }
        });

        // Get Wallet ID for logging
        const wallet = await tx.wallet.findUnique({ where: { userId: transaction.userId } });

        if (wallet) {
          // Log Transaction
          await tx.walletTransactionLocal.create({
            data: {
              walletId: wallet.id,
              userId: transaction.userId,
              type: 'PAYOUT_REFUND',
              amount: totalDebit,
              balanceAfter: wallet.balance,
              chargeAmount: chargeInfo?.totalCharge ? Number(chargeInfo.totalCharge) : 0,
              referenceType: 'payout',
              referenceId: transaction.id,
              description: `Admin Refund: Transaction marked as failed`,
              metadata: {
                reason: 'admin_forced_status_update',
                adminId: user.id
              }
            }
          });
        }

        // Update Transaction Status
        await tx.payOutTransaction.update({
          where: { id },
          data: {
            status: status,
            responseData: {
              ...(typeof transaction.responseData === 'object' ? transaction.responseData : {}),
              manualUpdate: true,
              updatedBy: user.id,
              updatedAt: new Date().toISOString(),
              refunded: true,
              refundAmount: String(totalDebit)
            }
          }
        });
      });

      return NextResponse.json({
        success: true,
        message: 'Payout updated to failed and amount refunded',
        refunded: true
      });
    }

    // 3. Normal update for other status changes (no refund)
    await prisma.payOutTransaction.update({
      where: { id },
      data: {
        status: status,
        // If it was already failed and we're just updating metadata, we don't refund again
        // unless we strictly track "refunded" flag, but strictly "isFailing" covers the transition.
        responseData: {
          ...(typeof transaction.responseData === 'object' ? transaction.responseData : {}),
          manualUpdate: true,
          updatedBy: user.id,
          updatedAt: new Date().toISOString()
        }
      }
    });

    return NextResponse.json({ success: true, message: 'Payout status updated' });
  } catch (error) {
    console.error('PATCH /api/admin/payouts error:', error);
    return NextResponse.json({ error: 'Failed to update payout' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { extractIpAddress, getUserAgent } from '@/lib/middleware';
import { formatINR, toRupees } from '@/lib/money';
import { safeJson } from '@/lib/safe-json';

export async function POST(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN']);
    if (user instanceof NextResponse) return user;

    try {
        const body = await req.json();
        const { transactionId, subUserId } = body;

        if (!transactionId) {
            return safeJson({ error: 'Transaction ID required' }, { status: 400 });
        }

        // Find the transaction
        const transaction = await prisma.payOutTransaction.findUnique({
            where: { id: transactionId },
            include: { subUser: true },
        });

        if (!transaction) {
            return safeJson({ error: 'Transaction not found' }, { status: 404 });
        }

        if (transaction.status !== 'FAILED' && transaction.status !== 'failed') {
            return safeJson({ error: 'Only failed transactions can be refunded' }, { status: 400 });
        }

        // Find or create wallet for the subuser
        const effectiveSubUserId = subUserId || transaction.subUserId;

        let wallet = await prisma.walletsDb.findFirst({
            where: {
                ownerType: 'child' as any,
                ownerId: effectiveSubUserId,
            },
        });

        if (!wallet) {
            wallet = await prisma.walletsDb.create({
                data: {
                    ownerType: 'child' as any,
                    ownerId: effectiveSubUserId,
                    currency: 'INR',
                    balance: 0,
                },
            });
        }

        // Process refund - add amount back to wallet
        const refundAmount = transaction.amount;

        await prisma.$transaction([
            // Update wallet balance
            prisma.walletsDb.update({
                where: { id: wallet.id },
                data: {
                    balance: { increment: refundAmount },
                },
            }),
            // Update transaction status to REFUNDED
            prisma.payOutTransaction.update({
                where: { id: transactionId },
                data: {
                    status: 'REFUNDED',
                    responseData: {
                        ...(transaction.responseData as object || {}),
                        refundedAt: new Date().toISOString(),
                        refundedBy: user.id,
                    },
                },
            }),
        ]);

        await logActivity({
            user,
            action: 'refund_transaction',
            resource: 'transaction',
            resourceId: transactionId,
            ipAddress: extractIpAddress(req),
            userAgent: getUserAgent(req),
            metadata: {
                amount: transaction.amount.toString(), // Store raw BigInt string in metadata or Rupee? Let's store raw for audit fidelity or Rupee for readability. Using existing pattern of amount string.
                subUserId: effectiveSubUserId,
            },
        });

        return safeJson({
            success: true,
            message: `Refund of ${formatINR(toRupees(transaction.amount))} processed successfully`,
        });
    } catch (error: any) {
        console.error('POST /api/admin/refund error:', error);
        return safeJson(
            { error: error.message || 'Failed to process refund' },
            { status: 500 }
        );
    }
}

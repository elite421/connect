import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const offset = parseInt(searchParams.get('offset') || '0');
    const limit = parseInt(searchParams.get('limit') || '50');
    const search = searchParams.get('search') || '';
    const showInactive = searchParams.get('showInactive') === 'true';

    const whereClause = {
      ...(search && {
        OR: [
          { name: { contains: search, mode: 'insensitive' as const } },
          { code: { contains: search, mode: 'insensitive' as const } },
          { provider: { contains: search, mode: 'insensitive' as const } },
        ],
      }),
      ...(showInactive ? {} : { isActive: true }),
    };

    const [gateways, total] = await Promise.all([
      prisma.paymentGateway.findMany({
        where: whereClause,
        include: {
          _count: { select: { serviceApis: true } },
        },
        orderBy: { name: 'asc' },
        skip: offset,
        take: limit,
      }),
      prisma.paymentGateway.count({ where: whereClause }),
    ]);

    return NextResponse.json({
      success: true,
      data: gateways,
      pagination: { offset, limit, total },
    });
  } catch (error) {
    console.error('GET /api/admin/gateways error:', error);
    return NextResponse.json({ error: 'Failed to fetch gateways' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { code, name, description, provider, apiEndpoint, apiKey, apiSecret, authType } = await req.json();

    if (!code || !name || !provider || !apiEndpoint) {
      return NextResponse.json(
        { error: 'Code, name, provider, and apiEndpoint are required' },
        { status: 400 }
      );
    }

    const existingGateway = await prisma.paymentGateway.findUnique({
      where: { code },
    });

    if (existingGateway) {
      return NextResponse.json(
        { error: 'Gateway with this code already exists' },
        { status: 400 }
      );
    }

    const gateway = await prisma.paymentGateway.create({
      data: {
        code,
        name,
        description,
        provider,
        apiEndpoint,
        apiKey,
        apiSecret,
        authType: authType || 'bearer',
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(gateway) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/admin/gateways error:', error);
    return NextResponse.json({ error: 'Failed to create gateway' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { gatewayId, code, name, description, provider, apiEndpoint, apiKey, apiSecret, authType, isActive } = await req.json();

    if (!gatewayId) {
      return NextResponse.json({ error: 'Gateway ID is required' }, { status: 400 });
    }

    const gateway = await prisma.paymentGateway.update({
      where: { id: gatewayId },
      data: {
        ...(code && { code }),
        ...(name && { name }),
        ...(description !== undefined && { description }),
        ...(provider && { provider }),
        ...(apiEndpoint && { apiEndpoint }),
        ...(apiKey && { apiKey }),
        ...(apiSecret && { apiSecret }),
        ...(authType && { authType }),
        ...(isActive !== undefined && { isActive }),
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(gateway) });
  } catch (error: any) {
    if (error.code === 'P2002') {
      return NextResponse.json({ error: 'Code already exists' }, { status: 400 });
    }
    console.error('PATCH /api/admin/gateways error:', error);
    return NextResponse.json({ error: 'Failed to update gateway' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const gatewayId = searchParams.get('gatewayId');

    if (!gatewayId) {
      return NextResponse.json({ error: 'Gateway ID is required' }, { status: 400 });
    }

    await prisma.paymentGateway.delete({
      where: { id: gatewayId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/admin/gateways error:', error);
    return NextResponse.json({ error: 'Failed to delete gateway' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const settlements: any[] = await prisma.$queryRaw`
      SELECT s.*, u."name" as "userName", u."email" as "userEmail", b."bankName", b."accountNumber"
      FROM "Settlement" s
      LEFT JOIN "User" u ON s."userId" = u."id"
      LEFT JOIN "BankAccount" b ON s."bankAccountId" = b."id"
      ORDER BY s."createdAt" DESC
      LIMIT 500
    `;

    const stats: any = await prisma.$queryRaw`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
        COUNT(CASE WHEN status = 'pending' OR status = 'processing' THEN 1 END) as pending,
        COALESCE(SUM(CASE WHEN status = 'completed' THEN "netAmount" ELSE 0 END), 0) as "totalAmount"
      FROM "Settlement"
    `;

    return safeJson({ 
      success: true, 
      data: settlements,
      stats: {
        total: Number(stats[0]?.total || 0),
        completed: Number(stats[0]?.completed || 0),
        pending: Number(stats[0]?.pending || 0),
        totalAmount: Number(stats[0]?.totalAmount || 0),
      }
    });
  } catch (error) {
    console.error('GET /api/admin/settlements error:', error);
    return safeJson({ error: 'Failed to fetch settlements' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { id, status, utrNumber } = body;

    if (!id || !status) {
      return safeJson({ error: 'ID and status required' }, { status: 400 });
    }

    await prisma.$executeRaw`
      UPDATE "Settlement" 
      SET "status" = ${status},
          "utrNumber" = COALESCE(${utrNumber}, "utrNumber"),
          "settledAt" = CASE WHEN ${status} = 'completed' THEN NOW() ELSE "settledAt" END,
          "updatedAt" = NOW()
      WHERE "id" = ${id}
    `;

    return safeJson({ success: true, message: 'Settlement updated' });
  } catch (error) {
    console.error('PATCH /api/admin/settlements error:', error);
    return safeJson({ error: 'Failed to update settlement' }, { status: 500 });
  }
}

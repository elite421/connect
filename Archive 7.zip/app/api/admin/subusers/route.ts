import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { extractIpAddress, getUserAgent } from '@/lib/middleware';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const search = searchParams.get('search');

    const where: any = {};
    if (search) {
      where.OR = [
        { email: { contains: search, mode: 'insensitive' } },
        { name: { contains: search, mode: 'insensitive' } },
        { username: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [subUsers, total] = await Promise.all([
      prisma.subUser.findMany({
        where,
        select: {
          id: true,
          email: true,
          name: true,
          username: true,
          phone: true,
          isActive: true,
          isApiEnabled: true,
          createdAt: true,
          userId: true,
          user: {
            select: {
              id: true,
              email: true,
              name: true,
            },
          },
          _count: {
            select: {
              subUserServices: true,
              beneficiaries: true,
              payOuts: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.subUser.count({ where }),
    ]);

    // Fetch wallet balances for each subuser
    const subUserIds = subUsers.map(s => s.id);
    const wallets = await prisma.walletsDb.findMany({
      where: {
        ownerType: 'child' as any,
        ownerId: { in: subUserIds },
      },
      select: {
        ownerId: true,
        balance: true,
      },
    });

    const walletMap = new Map(wallets.map(w => [w.ownerId, Number(w.balance) / 100]));

    const enrichedSubUsers = subUsers.map(su => ({
      ...su,
      parentUser: su.user,
      wallet: {
        balance: walletMap.get(su.id) || 0,
      },
      _count: {
        ...su._count,
        transactions: su._count.payOuts,
      },
    }));

    await logActivity({
      user,
      action: 'view_subusers',
      resource: 'subuser',
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: enrichedSubUsers,
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/admin/subusers error:', error);
    return NextResponse.json({ error: 'Failed to fetch subusers' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { subUserId, name, isActive, isApiEnabled } = body;

    if (!subUserId) {
      return NextResponse.json({ error: 'SubUser ID required' }, { status: 400 });
    }

    const updateData: any = {};
    if (name !== undefined) updateData.name = name;
    if (isActive !== undefined) updateData.isActive = isActive;
    if (isApiEnabled !== undefined) updateData.isApiEnabled = isApiEnabled;

    const subUser = await prisma.subUser.update({
      where: { id: subUserId },
      data: updateData,
    });

    await logActivity({
      user,
      action: 'update_subuser',
      resource: 'subuser',
      resourceId: subUserId,
      metadata: { changes: updateData },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: subUser,
    });
  } catch (error) {
    console.error('PATCH /api/admin/subusers error:', error);
    return NextResponse.json({ error: 'Failed to update subuser' }, { status: 500 });
  }
}

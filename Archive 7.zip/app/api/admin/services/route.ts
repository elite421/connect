import { NextRequest, NextResponse } from 'next/server';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';
import prisma from '@/lib/prisma';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const offset = parseInt(searchParams.get('offset') || '0');
    const limit = parseInt(searchParams.get('limit') || '50');
    const search = searchParams.get('search') || '';
    const showInactive = searchParams.get('showInactive') === 'true';

    const whereClause = {
      ...(search && {
        OR: [
          { name: { contains: search, mode: 'insensitive' as const } },
          { code: { contains: search, mode: 'insensitive' as const } },
          { description: { contains: search, mode: 'insensitive' as const } },
        ],
      }),
      ...(showInactive ? {} : { isActive: true }),
    };

    const [services, total] = await Promise.all([
      prisma.service.findMany({
        where: whereClause,
        orderBy: { name: 'asc' },
        skip: offset,
        take: limit,
      }),
      prisma.service.count({ where: whereClause }),
    ]);

    return NextResponse.json({
      success: true,
      data: services,
      pagination: { offset, limit, total },
    });
  } catch (error) {
    console.error('GET /api/admin/services error:', error);
    return NextResponse.json({ error: 'Failed to fetch services' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { name, code, description, isActive } = await req.json();

    if (!name || !code) {
      return NextResponse.json(
        { error: 'Name and code are required' },
        { status: 400 }
      );
    }

    const existingService = await prisma.service.findUnique({
      where: { code },
    });

    if (existingService) {
      return NextResponse.json(
        { error: 'Service with this code already exists' },
        { status: 400 }
      );
    }

    const service = await prisma.service.create({
      data: {
        name,
        code,
        description,
        isActive: isActive !== false,
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(service) });
  } catch (error) {
    console.error('POST /api/admin/services error:', error);
    return NextResponse.json({ error: 'Failed to create service' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { id, name, code, description, isActive } = await req.json();

    if (!id) {
      return NextResponse.json({ error: 'Service ID required' }, { status: 400 });
    }

    const service = await prisma.service.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(code && { code }),
        ...(description !== undefined && { description }),
        ...(isActive !== undefined && { isActive }),
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(service) });
  } catch (error) {
    console.error('PATCH /api/admin/services error:', error);
    return NextResponse.json({ error: 'Failed to update service' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Service ID required' }, { status: 400 });
    }

    await prisma.service.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: 'Service deleted' });
  } catch (error) {
    console.error('DELETE /api/admin/services error:', error);
    return NextResponse.json({ error: 'Failed to delete service' }, { status: 500 });
  }
}

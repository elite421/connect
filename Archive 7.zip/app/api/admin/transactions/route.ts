import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN', 'USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const status = searchParams.get('status');
    const serviceType = searchParams.get('serviceType');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const subUserId = searchParams.get('subUserId');
    const userId = searchParams.get('userId');
    const searchQuery = searchParams.get('search'); // Search by referenceId or transactionId

    const where: any = {};

    if (user.role === 'USER') {
      where.userId = user.id;
    } else if (subUserId) {
      where.subUserId = subUserId;
    }

    if (status) where.status = status;
    if (serviceType) where.serviceType = serviceType;
    if (userId) where.userId = userId;

    if (startDate && endDate) {
      where.createdAt = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      };
    }

    if (searchQuery) {
      where.OR = [
        { referenceId: { contains: searchQuery, mode: 'insensitive' } },
        { transactionId: { contains: searchQuery, mode: 'insensitive' } },
      ];
    }

    const [transactions, total] = await Promise.all([
      prisma.payment.findMany({
        where,
        include: {
          subUser: true,
          beneficiary: true,
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.payment.count({ where }),
    ]);

    const summary = await prisma.payment.aggregate({
      _sum: { amount: true },
      _count: true,
      where,
    });

    await logActivity({
      user,
      action: 'view_transactions',
      resource: 'transaction',
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      metadata: { limit, offset, filters: { status, serviceType, startDate, endDate } },
    });

    const serializedTransactions = transactions.map((t) => ({
      ...t,
      amount: t.amount,
    }));

    return NextResponse.json({
      success: true,
      data: serializedTransactions,
      summary: {
        totalTransactions: summary._count,
        totalAmount: summary._sum.amount ? Number(summary._sum.amount) : 0,
      },
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/admin/transactions error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch transactions' },
      { status: 500 }
    );
  }
}

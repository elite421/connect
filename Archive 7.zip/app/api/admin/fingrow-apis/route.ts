import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const apis = await prisma.adminApi.findMany({
      where: { type: 'fingrow' },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(apis) });
  } catch (error) {
    console.error('GET /api/admin/fingrow-apis error:', error);
    return NextResponse.json({ error: 'Failed to fetch Fingrow APIs' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { name, description, baseUrl, apiKey, authHeader, scopes, isActive, isDefault } = body;

    if (!name || !apiKey) {
      return NextResponse.json(
        { error: 'Name and Merchant ID (apiKey) are required' },
        { status: 400 },
      );
    }

    const api = await prisma.adminApi.create({
      data: {
        type: 'fingrow',
        name,
        description: description || null,
        baseUrl: baseUrl || 'https://pay.fingrowaitech.com/transaction/transactions/api/initiate',
        apiKey, // Merchant ID
        authHeader: authHeader || 'merchantId',
        scopes: typeof scopes === 'string' ? scopes : JSON.stringify(scopes || {}),
        isActive: isActive !== false,
        isDefault: isDefault === true,
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(api) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/admin/fingrow-apis error:', error);
    return NextResponse.json({ error: 'Failed to create Fingrow API' }, { status: 500 });
  }
}

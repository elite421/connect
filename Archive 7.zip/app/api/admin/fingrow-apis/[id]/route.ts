import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { id } = await params;
    const api = await prisma.adminApi.findUnique({
      where: { id },
    });

    if (!api || api.type !== 'fingrow') {
      return NextResponse.json({ error: 'API not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: serializeBigInt(api) });
  } catch (error) {
    console.error('GET /api/admin/fingrow-apis/[id] error:', error);
    return NextResponse.json({ error: 'Failed to fetch API' }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { id } = await params;
    const body = await req.json();
    const { name, description, baseUrl, apiKey, authHeader, scopes, isActive, isDefault } = body;

    const api = await prisma.adminApi.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(description !== undefined && { description }),
        ...(baseUrl && { baseUrl }),
        ...(apiKey && { apiKey }),
        ...(authHeader && { authHeader }),
        ...(scopes && { scopes: typeof scopes === 'string' ? scopes : JSON.stringify(scopes) }),
        ...(isActive !== undefined && { isActive }),
        ...(isDefault !== undefined && { isDefault }),
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(api) });
  } catch (error) {
    console.error('PATCH /api/admin/fingrow-apis/[id] error:', error);
    return NextResponse.json({ error: 'Failed to update API' }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { id } = await params;
    await prisma.adminApi.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: 'API deleted successfully' });
  } catch (error) {
    console.error('DELETE /api/admin/fingrow-apis/[id] error:', error);
    return NextResponse.json({ error: 'Failed to delete API' }, { status: 500 });
  }
}

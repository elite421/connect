import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      name = 'Fingrow Default',
      description = 'Default Fingrow payment gateway for all users',
      merchantId,
      baseUrl = 'https://pay.fingrowaitech.com/transaction/transactions/api/initiate',
      statusCheckUrl = 'https://pay.fingrowaitech.com/transaction/transactions/chkTxnstatus',
    } = body;

    if (!merchantId) {
      return NextResponse.json(
        { error: 'merchantId is required' },
        { status: 400 },
      );
    }

    // Check if default Fingrow API already exists
    const existing = await prisma.adminApi.findFirst({
      where: {
        type: 'fingrow',
        isDefault: true,
      },
    });

    let api;

    if (existing) {
      // Update existing default
      api = await prisma.adminApi.update({
        where: { id: existing.id },
        data: {
          name,
          description,
          apiKey: merchantId,
          baseUrl,
          scopes: JSON.stringify({
            baseUrl,
            statusCheckUrl,
            payoutEndpoint: baseUrl,
          }),
          isActive: true,
        },
      });
      return NextResponse.json({
        success: true,
        message: 'Default Fingrow API updated',
        data: api,
      });
    }

    // Create new default
    api = await prisma.adminApi.create({
      data: {
        type: 'fingrow',
        name,
        description,
        apiKey: merchantId,
        baseUrl,
        authHeader: 'merchantId',
        scopes: JSON.stringify({
          baseUrl,
          statusCheckUrl,
          payoutEndpoint: baseUrl,
        }),
        isActive: true,
        isDefault: true,
      },
    });

    return NextResponse.json(
      {
        success: true,
        message: 'Default Fingrow API created successfully',
        data: api,
      },
      { status: 201 },
    );
  } catch (error) {
    console.error('POST /api/admin/fingrow-apis/setup-default error:', error);
    return NextResponse.json({ error: 'Failed to setup Fingrow API' }, { status: 500 });
  }
}

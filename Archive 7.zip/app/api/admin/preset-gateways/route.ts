import { NextRequest, NextResponse } from 'next/server';
import { authMiddleware } from '@/lib/middleware';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    return NextResponse.json({
      success: true,
      data: [],
    });
  } catch (error) {
    console.error('GET /api/admin/preset-gateways error:', error);
    return NextResponse.json({ error: 'Failed to fetch preset gateways' }, { status: 500 });
  }
}

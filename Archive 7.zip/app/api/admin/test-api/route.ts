import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';

// Helper to safely parse JSON
function safeJsonParse<T = any>(val?: string | null): T | undefined {
  if (!val) return undefined;
  try {
    return JSON.parse(val) as T;
  } catch {
    return undefined;
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { apiId, testPayload: rawTestPayload } = body;

    if (!apiId) {
      return NextResponse.json({ error: 'API ID required' }, { status: 400 });
    }

    const customApi = await prisma.customPaymentApi.findUnique({
      where: { id: apiId },
    });

    if (!customApi) {
      return NextResponse.json({ error: 'API not found' }, { status: 404 });
    }

    // Allow override of apiKey (userid) from headers
    const overrideUserId = req.headers.get('userid');
    const effectiveApiKey = overrideUserId || customApi.apiKey;
    // Create an effective object for usage
    const effectiveApi = { ...customApi, apiKey: effectiveApiKey };

    /* 
       ALLOW USER TO TEST BOTH ADMIN AND USER APIs
       (Commented out restriction to allow flexible testing)
       if (customApi.userId) {
         return NextResponse.json({ error: 'Can only test admin-provided APIs' }, { status: 403 });
       }
    */

    // Parse configuration
    // CustomPaymentApi stores config in apiSecret (JSON string)
    const secretConf = safeJsonParse<any>(customApi.apiSecret);

    // Merge templates into testPayload
    // 1. Start with user-provided test payload
    let testPayload = { ...rawTestPayload };

    // 2. Merge Request Templates from apiSecret
    // Admin UI often stores these in apiSecret
    const payoutTemplate = secretConf?.payoutRequestTemplate ?? secretConf?.requestTemplate;
    if (payoutTemplate) {
      const templateObj = (typeof payoutTemplate === 'string')
        ? (safeJsonParse<any>(payoutTemplate) || {})
        : (payoutTemplate || {});
      testPayload = { ...templateObj, ...testPayload };
    }

    // 3. Merge Body Template (explicit field in some admin UIs)
    if (secretConf?.bodyTemplate) {
      let tpl = secretConf.bodyTemplate;
      if (typeof tpl === 'string') tpl = safeJsonParse<any>(tpl) || {};
      if (typeof tpl === 'object') {
        testPayload = { ...tpl, ...testPayload };
      }
    }

    // 4. Handle Field Mapping (similar to real payout logic)
    const maps: Array<Record<string, string>> = [];
    if (secretConf?.payoutFieldMap && typeof secretConf.payoutFieldMap === 'object') maps.push(secretConf.payoutFieldMap);
    if (secretConf?.fieldMap && typeof secretConf.fieldMap === 'object') maps.push(secretConf.fieldMap);

    if (maps.length) {
      const mapped: Record<string, any> = {};
      for (const key of Object.keys(testPayload)) {
        let mappedKey = key;
        for (const m of maps) {
          if (m[key]) { mappedKey = m[key]; break; }
        }
        mapped[mappedKey] = (testPayload as any)[key];
      }
      // If mapping produced keys, use them. Otherwise stick to original.
      // Actually we should merge? Typically mapping completely transforms structure.
      // But for testing, we might want to keep unmapped fields too?
      // Real logic replaces payload with mapped version. We'll do same.
      if (Object.keys(mapped).length > 0) {
        // Copy over any keys that weren't mapped? No, strict mapping is safer.
        // But if map is partial? 
        // Let's blindly apply mapping where exists, keep others?
        // The logic in payout-integration.ts was:
        // const mapped = {}; loop keys; if map found use new key else use old key; mapped[newKey] = val;
        // So it preserves unmapped keys (as old key).
        testPayload = mapped;
      }
    }


    if (!rawTestPayload) {
      const fullUrl = `${customApi.apiBaseUrl}${customApi.apiEndpoint}`.replace(/\s+/g, '');

      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);

        const healthCheckResponse = await fetch(fullUrl, {
          method: 'HEAD',
          signal: controller.signal,
        }).catch(() =>
          fetch(fullUrl, {
            method: customApi.apiMethod as 'GET' | 'POST' | 'PUT',
            signal: controller.signal,
          })
        );

        clearTimeout(timeout);
        const isOnline = healthCheckResponse?.ok || healthCheckResponse?.status !== 0;
        return NextResponse.json({ isOnline, message: 'Health check completed' });
      } catch {
        return NextResponse.json({ isOnline: false, message: 'API unreachable' });
      }
    }

    const fullUrl = `${customApi.apiBaseUrl}${customApi.apiEndpoint}`.replace(/\s+/g, '');

    // CHECK FOR FINGROW - Special handling for Encryption
    if (fullUrl.includes('fingrow') || (customApi.apiName && customApi.apiName.toLowerCase().includes('fingrow'))) {
      console.log('Detected Fingrow URL in Test API. Using Fingrow Encryption Bridge.');

      const { executeFingrowTransaction } = await import('@/lib/fingrow-integration');

      // Map the generic test payload to Fingrow request structure
      // We check multiple keys to allow users to input either our internal names or Fingrow native names
      const fingrowRequest = {
        amount: testPayload?.amount || 100,
        beneficiaryName: testPayload?.beneficiaryName || testPayload?.name || 'Test User',
        beneficiaryAccount: testPayload?.beneficiaryAccount || testPayload?.account_number || testPayload?.accountNumber || '2029001700058769',
        beneficiaryIfsc: testPayload?.beneficiaryIfsc || testPayload?.ifsc_code || testPayload?.ifscCode || 'PUNB0202900',
        beneficiaryVpa: testPayload?.beneficiaryVpa || testPayload?.mobile_number || testPayload?.mobileNumber,
        transferMode: testPayload?.transferMode || testPayload?.transfer_type || 'NEFT',
        // Fallback to timestamp if no ID is provided in the payload
        merchantTransactionId: testPayload?.merchantTransactionId || testPayload?.merchantTxnOrderId || testPayload?.txnId || testPayload?.orderId || testPayload?.merchant_order_id || `TEST_${Date.now()}`,
        ipAddress: testPayload?.ipAddress || testPayload?.ip_address || '127.0.0.1',
        userAgent: testPayload?.userAgent || testPayload?.user_agent || 'Admin Test Tool'
      };

      // Determine Merchant ID:
      // 1. Try to get it from the payload (if user entered "merchantId" or "merchant_id" in the test box)
      // 2. Fallback to the saved API Key
      // 3. Fallback to merchantId in apiSecret configuration
      const payloadMerchantId = testPayload?.merchantId || testPayload?.merchant_id;
      const merchantId = payloadMerchantId || customApi.apiKey || secretConf?.merchantId;

      if (!merchantId) {
        return NextResponse.json({ success: false, message: 'Merchant ID (API Key) is missing for Fingrow API' });
      }

      const result = await executeFingrowTransaction(merchantId, fullUrl, fingrowRequest);

      return NextResponse.json({
        success: result.success,
        statusCode: result.success ? 200 : 400,
        response: result,
        message: result.message
      });
    }

    // CHECK FOR RUDRAXPAY - Special handling for userid in body
    if (fullUrl.includes('rudraxpay.com') || (customApi.apiName && customApi.apiName.toLowerCase().includes('rudrax'))) {
      const merchantId = effectiveApi.apiKey || secretConf?.userid;
      // 'apiToken' is not on CustomPaymentApi, usually stored in apiSecret for custom gateways
      const token = secretConf?.token || secretConf?.apiToken || effectiveApi.apiSecret || null;

      if (!testPayload) testPayload = {};

      // Inject credentials if missing from payload
      if (merchantId && !testPayload.userid) testPayload.userid = merchantId;
      if (token && !testPayload.token) testPayload.token = token;

      // Ensure standard fields are mapped for RudraxPay
      if (!testPayload.ifsc && (testPayload.beneficiaryIfsc || testPayload.ifscCode)) {
        testPayload.ifsc = testPayload.beneficiaryIfsc || testPayload.ifscCode;
      }
      if (!testPayload.number && (testPayload.beneficiaryAccount || testPayload.accountNumber)) {
        testPayload.number = testPayload.beneficiaryAccount || testPayload.accountNumber;
      }
      if (!testPayload.name && (testPayload.beneficiaryName || testPayload.accountName)) {
        testPayload.name = testPayload.beneficiaryName || testPayload.accountName;
      }
      if (!testPayload.mobile) {
        testPayload.mobile = testPayload.beneficiaryMobile || '9876543210';
      }

      // Ensure orderid exists
      if (!testPayload.orderid) {
        testPayload.orderid = testPayload.merchantTransactionId || `test_${Date.now()}`;
      }

      // Ensure URL handles the endpoint correctly if it's just the base URL
      if (!fullUrl.includes('/payout/initiate') && !fullUrl.includes('/pg/phonepe/initiate')) {
        // It's ambiguous if payin or payout. But if testPayload has 'number' or 'accountNumber', probably payout.
        if (testPayload.number || testPayload.accountNumber || testPayload.beneficiaryAccount) {
          // Assuming payout test
          // But wait, fullUrl comes from DB config. If user set full URL, great.
        }
      }
    }

    // STANDARD JSON API TEST
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (effectiveApi.authType === 'bearer' && effectiveApi.apiKey) {
      headers['Authorization'] = `Bearer ${effectiveApi.apiKey}`;
    } else if (effectiveApi.authType === 'basic' && effectiveApi.apiKey && effectiveApi.apiSecret) {
      const credentials = Buffer.from(`${effectiveApi.apiKey}:${effectiveApi.apiSecret}`).toString('base64');
      headers['Authorization'] = `Basic ${credentials}`;
    } else if (effectiveApi.authType === 'apikey' && effectiveApi.authHeader && effectiveApi.apiKey) {
      headers[effectiveApi.authHeader] = effectiveApi.apiKey;
    }

    // Add custom headers from config
    if (secretConf?.headers && typeof secretConf.headers === 'object') {
      Object.assign(headers, secretConf.headers);
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);

    const response = await fetch(fullUrl, {
      method: customApi.apiMethod as 'GET' | 'POST' | 'PUT',
      headers,
      body: testPayload ? JSON.stringify(testPayload) : undefined,
      signal: controller.signal,
    });

    clearTimeout(timeout);
    console.log('API Test Request:', { fullUrl, method: customApi.apiMethod, hasAuth: !!headers['Authorization'], statusCode: response.status });
    const responseText = await response.text();
    let responseData;
    try {
      responseData = JSON.parse(responseText);
    } catch {
      responseData = responseText;
    }

    return NextResponse.json({
      success: response.ok,
      statusCode: response.status,
      response: responseData,
      message: response.ok ? 'API test successful' : 'API returned error',
    });
  } catch (error) {
    console.error('POST /api/admin/test-api error:', error);
    return NextResponse.json(
      {
        success: false,
        error: String(error),
        message: 'Failed to test API',
      },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { extractIpAddress, getUserAgent } from '@/lib/middleware';
import { toRupees, toPaise } from '@/lib/money';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const subUserId = searchParams.get('subUserId');

    if (!subUserId) {
      return NextResponse.json({ error: 'SubUser ID required' }, { status: 400 });
    }

    let wallet = await prisma.walletsDb.findFirst({
      where: {
        ownerType: 'child' as any,
        ownerId: subUserId,
      },
    });

    if (!wallet) {
      wallet = await prisma.walletsDb.create({
        data: {
          ownerType: 'child' as any,
          ownerId: subUserId,
          currency: 'INR',
          balance: 0,
        },
      });
    }

    const [payouts, payins, pendingTransactions] = await Promise.all([
      prisma.payOutTransaction.aggregate({
        where: { subUserId, status: 'completed' },
        _sum: { amount: true },
      }),
      prisma.payOutTransaction.aggregate({
        where: { subUserId, status: 'success' },
        _sum: { amount: true },
      }),
      prisma.payOutTransaction.aggregate({
        where: { subUserId, status: { in: ['pending', 'processing'] } },
        _sum: { amount: true },
      }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        walletBalance: toRupees(wallet.balance),
        totalPayouts: toRupees(payouts._sum.amount || 0),
        totalPayins: toRupees(payins._sum.amount || 0),
        totalPending: toRupees(pendingTransactions._sum.amount || 0),
        currency: wallet.currency,
      },
    });
  } catch (error: any) {
    console.error('Failed to fetch payment status:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to fetch payment status' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { subUserId, amount, type = 'CREDIT', description = 'Admin credit' } = body;

    if (!subUserId || !amount) {
      return NextResponse.json({ error: 'SubUser ID and amount required' }, { status: 400 });
    }

    const amountInPaise = toPaise(amount);

    // Find or create wallet
    let wallet = await prisma.walletsDb.findFirst({
      where: {
        ownerType: 'child' as any,
        ownerId: subUserId,
      },
    });

    if (!wallet) {
      wallet = await prisma.walletsDb.create({
        data: {
          ownerType: 'child' as any,
          ownerId: subUserId,
          currency: 'INR',
          balance: 0,
        },
      });
    }

    // Update wallet balance
    if (type === 'CREDIT') {
      await prisma.walletsDb.update({
        where: { id: wallet.id },
        data: {
          balance: { increment: amountInPaise },
        },
      });
    } else {
      await prisma.walletsDb.update({
        where: { id: wallet.id },
        data: {
          balance: { decrement: amountInPaise },
        },
      });
    }

    await logActivity({
      user,
      action: type === 'CREDIT' ? 'credit_subuser_wallet' : 'debit_subuser_wallet',
      resource: 'wallet',
      resourceId: wallet.id,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      metadata: {
        subUserId,
        amount: Number(amount), // Log Rupees
        description,
      },
    });

    return NextResponse.json({
      success: true,
      message: `${type === 'CREDIT' ? 'Added' : 'Deducted'} ₹${amount} successfully`,
    });
  } catch (error: any) {
    console.error('POST /api/admin/subuser-wallet error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to update wallet' },
      { status: 500 }
    );
  }
}


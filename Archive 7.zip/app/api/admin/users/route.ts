import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { extractIpAddress, getUserAgent } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const role = searchParams.get('role');
    const search = searchParams.get('search');

    const where: any = {};
    if (role) where.role = role;
    const userId = searchParams.get('userId');
    if (userId) {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: {
          id: true,
          email: true,
          name: true,
          username: true,
          role: true,
          phone: true,
          defaultApiId: true,
          createdAt: true,
          active: true,
          transactionCharge: true,
          _count: {
            select: { subUsers: true },
          },
          services: {
            where: { isActive: true },
            select: { serviceId: true }
          }
        }
      });
      return NextResponse.json({ success: true, data: serializeBigInt(user) });
    }

    if (search) {
      where.OR = [
        { email: { contains: search, mode: 'insensitive' } },
        { name: { contains: search, mode: 'insensitive' } },
        { username: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        select: {
          id: true,
          email: true,
          name: true,
          username: true,
          role: true,
          phone: true,
          defaultApiId: true,
          createdAt: true,
          _count: {
            select: { subUsers: true },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.user.count({ where }),
    ]);

    await logActivity({
      user,
      action: 'view_analytics',
      resource: 'user',
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: serializeBigInt(users),
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/admin/users error:', error);
    return NextResponse.json({ error: 'Failed to fetch users' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { userId, role, isActive, transactionCharge, defaultApiId, assignedServices } = body;

    if (!userId) {
      return NextResponse.json({ error: 'User ID required' }, { status: 400 });
    }

    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: {
        ...(role && { role }),
        ...(isActive !== undefined && { active: isActive }),
        ...(transactionCharge !== undefined && { transactionCharge: transactionCharge ? parseFloat(transactionCharge) : 0 }),
        ...(defaultApiId !== undefined && { defaultApiId }),
      },
    });

    if (assignedServices) {
      const serviceIds = typeof assignedServices === 'string'
        ? assignedServices.split(',').map(s => s.trim()).filter(s => s)
        : Array.isArray(assignedServices) ? assignedServices : [];

      if (serviceIds.length > 0) {
        await prisma.userService.deleteMany({
          where: { userId },
        });

        for (const serviceId of serviceIds) {
          await prisma.userService.create({
            data: {
              userId,
              serviceId,
              isActive: true,
            },
          });
        }
      }
    }

    await logActivity({
      user,
      action: 'update_subuser',
      resource: 'user',
      resourceId: userId,
      metadata: { role, isActive, transactionCharge, defaultApiId },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ success: true, data: serializeBigInt(updatedUser) });
  } catch (error) {
    console.error('PATCH /api/admin/users error:', error);
    return NextResponse.json({ error: 'Failed to update user' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'User ID required' }, { status: 400 });
    }

    await prisma.user.delete({
      where: { id: userId },
    });

    await logActivity({
      user,
      action: 'delete_subuser',
      resource: 'user',
      resourceId: userId,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ success: true, message: 'User deleted' });
  } catch (error) {
    console.error('DELETE /api/admin/users error:', error);
    return NextResponse.json({ error: 'Failed to delete user' }, { status: 500 });
  }
}

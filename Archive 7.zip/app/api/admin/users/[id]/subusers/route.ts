import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest, { params }: { params: { id: string } | Promise<{ id: string }> }) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const realParams = typeof params === 'object' && 'then' in params ? await params : params;
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const search = searchParams.get('search');

    const parentUser = await prisma.user.findUnique({
      where: { id: realParams.id },
    });

    if (!parentUser) {
      return NextResponse.json({ error: 'Parent user not found' }, { status: 404 });
    }

    const where: any = { userId: realParams.id };
    if (search) {
      where.OR = [
        { email: { contains: search, mode: 'insensitive' } },
        { name: { contains: search, mode: 'insensitive' } },
        { username: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [subUsers, total] = await Promise.all([
      prisma.subUser.findMany({
        where,
        select: {
          id: true,
          email: true,
          name: true,
          username: true,
          phone: true,
          isActive: true,
          role: true,
          createdAt: true,
          updatedAt: true,
          permissions: true,
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.subUser.count({ where }),
    ]);

    await logActivity({
      user,
      action: 'view_subusers',
      resource: 'subuser',
      resourceId: realParams.id,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: serializeBigInt(subUsers),
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/admin/users/[id]/subusers error:', error);
    return NextResponse.json({ error: 'Failed to fetch subusers' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } | Promise<{ id: string }> }) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const realParams = typeof params === 'object' && 'then' in params ? await params : params;
    const body = await req.json();
    const { subUserId, isActive, permissions, name, email, phone } = body;

    if (!subUserId) {
      return NextResponse.json({ error: 'SubUser ID required' }, { status: 400 });
    }

    const subUser = await prisma.subUser.update({
      where: { id: subUserId, userId: realParams.id },
      data: {
        ...(isActive !== undefined && { isActive }),
        ...(permissions && { permissions }),
        ...(name && { name }),
        ...(email && { email }),
        ...(phone && { phone }),
      },
    });

    await logActivity({
      user,
      action: 'update_subuser',
      resource: 'subuser',
      resourceId: subUserId,
      metadata: { isActive, permissions, name, email },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ success: true, data: serializeBigInt(subUser) });
  } catch (error) {
    console.error('PATCH /api/admin/users/[id]/subusers error:', error);
    return NextResponse.json({ error: 'Failed to update subuser' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } | Promise<{ id: string }> }) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const realParams = typeof params === 'object' && 'then' in params ? await params : params;
    const { searchParams } = new URL(req.url);
    const subUserId = searchParams.get('subUserId');

    if (!subUserId) {
      return NextResponse.json({ error: 'SubUser ID required' }, { status: 400 });
    }

    await prisma.subUser.delete({
      where: { id: subUserId, userId: realParams.id },
    });

    await logActivity({
      user,
      action: 'delete_subuser',
      resource: 'subuser',
      resourceId: subUserId,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ success: true, message: 'SubUser deleted' });
  } catch (error) {
    console.error('DELETE /api/admin/users/[id]/subusers error:', error);
    return NextResponse.json({ error: 'Failed to delete subuser' }, { status: 500 });
  }
}

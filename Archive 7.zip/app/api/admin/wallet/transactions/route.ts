import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
    const admin = await authMiddleware(req, ['ADMIN']);
    if (admin instanceof NextResponse) return admin;

    try {
        const { searchParams } = new URL(req.url);
        const userId = searchParams.get('userId');
        const limit = Math.min(parseInt(searchParams.get('limit') || '50'), 100);
        const offset = parseInt(searchParams.get('offset') || '0');
        const type = searchParams.get('type');

        // Build where clause
        const whereClause: any = {};

        if (userId) {
            // Get specific user's wallet
            const wallet = await prisma.wallet.findUnique({
                where: { userId },
            });
            if (wallet) {
                whereClause.walletId = wallet.id;
            } else {
                return safeJson({
                    success: true,
                    data: [],
                    pagination: { limit, offset, total: 0, hasMore: false },
                });
            }
        }

        if (type) {
            whereClause.type = type;
        }

        // Get transactions with user info
        const [transactions, total] = await Promise.all([
            prisma.walletTransactionLocal.findMany({
                where: whereClause,
                orderBy: { createdAt: 'desc' },
                take: limit,
                skip: offset,
                include: {
                    wallet: {
                        include: {
                            user: {
                                select: {
                                    id: true,
                                    name: true,
                                    email: true,
                                    username: true,
                                },
                            },
                        },
                    },
                },
            }),
            prisma.walletTransactionLocal.count({ where: whereClause }),
        ]);

        // Format transactions
        const formattedTransactions = transactions.map(tx => ({
            id: tx.id,
            userId: tx.userId,
            userName: tx.wallet?.user?.name || 'Unknown',
            userEmail: tx.wallet?.user?.email || '',
            type: tx.type,
            amount: String(tx.amount),
            amountDisplay: `₹${(Number(tx.amount)).toLocaleString('en-IN', { minimumFractionDigits: 5, maximumFractionDigits: 5 })}`,
            chargeAmount: String(tx.chargeAmount),
            chargeDisplay: `₹${(Number(tx.chargeAmount)).toLocaleString('en-IN', { minimumFractionDigits: 5, maximumFractionDigits: 5 })}`,
            balanceAfter: String(tx.balanceAfter),
            balanceAfterDisplay: `₹${(Number(tx.balanceAfter)).toLocaleString('en-IN', { minimumFractionDigits: 5, maximumFractionDigits: 5 })}`,
            referenceType: tx.referenceType,
            referenceId: tx.referenceId,
            description: tx.description,
            metadata: tx.metadata,
            createdAt: tx.createdAt.toISOString(),
        }));

        return safeJson({
            success: true,
            data: formattedTransactions,
            pagination: {
                limit,
                offset,
                total,
                hasMore: offset + limit < total,
            },
        });
    } catch (error) {
        console.error('GET /api/admin/wallet/transactions error:', error);
        return safeJson({ error: 'Failed to fetch transactions' }, { status: 500 });
    }
}

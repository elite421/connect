import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';

export async function GET(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN']);
    if (user instanceof NextResponse) return user;

    try {
        const { searchParams } = new URL(req.url);
        const subUserId = searchParams.get('subUserId');
        const limit = parseInt(searchParams.get('limit') || '50');
        const offset = parseInt(searchParams.get('offset') || '0');

        if (!subUserId) {
            return NextResponse.json({ error: 'SubUser ID required' }, { status: 400 });
        }

        const [transactions, total] = await Promise.all([
            prisma.payOutTransaction.findMany({
                where: { subUserId },
                select: {
                    id: true,
                    amount: true,
                    status: true,
                    createdAt: true,
                    beneficiaryName: true,
                    beneficiaryAccount: true,
                    transferMode: true,
                    utrNumber: true,
                    responseData: true,
                },
                orderBy: { createdAt: 'desc' },
                take: limit,
                skip: offset,
            }),
            prisma.payOutTransaction.count({ where: { subUserId } }),
        ]);

        const formattedTransactions = transactions.map(tx => ({
            id: tx.id,
            type: 'PAYOUT',
            amount: tx.amount,
            status: tx.status,
            createdAt: tx.createdAt.toISOString(),
            description: `Payout to ${tx.beneficiaryName || tx.beneficiaryAccount || 'N/A'}`,
            beneficiaryName: tx.beneficiaryName,
            beneficiaryAccount: tx.beneficiaryAccount,
            transferMode: tx.transferMode,
            utrNumber: tx.utrNumber,
            responseData: tx.responseData,
        }));

        return NextResponse.json({
            success: true,
            data: formattedTransactions,
            pagination: { limit, offset, total, hasMore: offset + limit < total },
        });
    } catch (error: any) {
        console.error('GET /api/admin/subuser-transactions error:', error);
        return NextResponse.json(
            { error: error.message || 'Failed to fetch transactions' },
            { status: 500 }
        );
    }
}

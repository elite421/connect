import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

function safeJsonParse<T = any>(val?: string | null): T | undefined {
  if (!val) return undefined;
  try {
    return JSON.parse(val) as T;
  } catch {
    return undefined;
  }
}

function buildHeaders(api: any, override?: any) {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  const conf = safeJsonParse<any>(api.apiSecret) || {};
  const mergedStatic = { ...(conf.headers || {}), ...(override?.headers || {}) };
  for (const k of Object.keys(mergedStatic)) {
    const v = mergedStatic[k];
    if (typeof v === 'string') headers[k] = v;
  }

  const explicitHeader = override?.authHeader || api.authHeader || conf.authHeader;
  const token = override?.apiToken || override?.apiKey || api.apiToken || api.apiKey || conf.apiToken || conf.apiKey;
  if (explicitHeader && token) {
    headers[String(explicitHeader)] = String(token);
    return headers;
  }

  const authType = override?.authType || conf.authType;
  if (authType === 'bearer') {
    if (token) headers['Authorization'] = `Bearer ${token}`;
  } else if (authType === 'basic') {
    const key = override?.apiKey || api.apiKey || conf.apiKey;
    const secret = override?.apiSecret || conf.apiSecret; // api.apiSecret may be JSON string
    if (key && secret) {
      const b64 = Buffer.from(`${key}:${secret}`).toString('base64');
      headers['Authorization'] = `Basic ${b64}`;
    }
  } else if (token) {
    headers['X-API-Key'] = String(token);
  }

  return headers;
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const {
      apiId,
      userId,
      type = 'payin',
      endpoint: endpointOverride,
      method: methodOverride,
      headers: headersOverride,
      payload: payloadOverride,
      timeoutMs = 20000,
    } = await req.json();

    let api: any | null = null;
    if (apiId) {
      api = await prisma.userApi.findUnique({ where: { id: apiId } });
    } else if (userId) {
      api = await prisma.userApi.findFirst({
        where: { userId, isActive: true },
        orderBy: { isDefault: 'desc' },
      });
    }

    if (!api) {
      return NextResponse.json({ error: 'UserApi not found' }, { status: 404 });
    }

    const scopes = safeJsonParse<any>(api.scopes) || {};
    const secretConf = safeJsonParse<any>(api.apiSecret) || {};

    let endpoint = endpointOverride as string | undefined;
    if (!endpoint) {
      if (type === 'payin') endpoint = scopes.payinEndpoint || secretConf.endpoint || api.baseUrl;
      else if (type === 'payout') endpoint = scopes.payoutEndpoint || secretConf.endpoint || api.baseUrl;
      else endpoint = secretConf.endpoint || api.baseUrl;
    }

    if (!endpoint) {
      return NextResponse.json({ error: 'Endpoint not configured' }, { status: 400 });
    }

    const headers = buildHeaders(api, { ...(headersOverride || {}), authType: secretConf.authType, authHeader: secretConf.authHeader, apiKey: secretConf.apiKey, apiToken: secretConf.apiToken, apiSecret: secretConf.apiSecret });

    let payload: any = payloadOverride;
    if (!payload) {
      if (type === 'payin') {
        const cb = scopes.callbackUrl || `${process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/payin`;
        payload = {
          memberId: 'MT12729XXX',
          amount: '31',
          mobile: '91663696945',
          orderid: `test-${Date.now()}`,
          callback_url: cb,
        };
      } else if (type === 'payout') {
        payload = {
          MemberId: 'MT1433XXXX',
          account_number: '67490156XXXX',
          address: 'XXXXXX',
          amount: '500',
          email: 'test@example.com',
          ifsc_code: 'ICIC000XXXX',
          merchant_order_id: `test-${Date.now()}`,
          mobile_number: '9878767XXX',
          name: 'Test User',
          BankName: 'ICICI Bank',
        };
      } else {
        payload = { ping: 'ok', ts: Date.now() };
      }
    }

    // Optional payout field mapping from scopes
    if (type === 'payout' && scopes?.payoutFieldMap && typeof scopes.payoutFieldMap === 'object') {
      const mapped: Record<string, any> = {};
      for (const k of Object.keys(payload)) {
        const mappedKey = scopes.payoutFieldMap[k] || k;
        mapped[mappedKey] = payload[k];
      }
      payload = mapped;
    }

    const controller = new AbortController();
    const to = setTimeout(() => controller.abort(), Math.max(5000, Math.min(60000, Number(timeoutMs) || 20000)));

    const method = String(methodOverride || secretConf.method || 'POST').toUpperCase();
    const res = await fetch(endpoint, {
      method,
      headers,
      body: method === 'GET' || method === 'HEAD' ? undefined : JSON.stringify(payload),
      signal: controller.signal,
    });
    clearTimeout(to);

    const status = res.status;
    const ok = res.ok;
    const text = await res.text();
    let data: any;
    try { data = JSON.parse(text); } catch { data = { raw: text }; }

    await logActivity({
      user,
      action: 'test_gateway_connection',
      resource: 'custom_api',
      resourceId: api.id,
      metadata: { type, endpoint, status, ok },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: ok,
      status,
      response: data,
      request: { endpoint, method, headers, payload },
    }, { status: ok ? 200 : 400 });
  } catch (error: any) {
    const errMsg = error?.message || 'Test failed';
    return NextResponse.json({ success: false, error: errMsg }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { safeJson } from '@/lib/safe-json';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  let timeoutId: NodeJS.Timeout | null = null;

  try {
    const { gatewayId, config, requestBody, callbackUrl } = await req.json();

    if (!gatewayId) {
      return safeJson({ error: 'Gateway ID required' }, { status: 400 });
    }

    if (!requestBody || typeof requestBody !== 'object') {
      return safeJson({ error: 'Valid request body required' }, { status: 400 });
    }

    const gateway = await prisma.paymentGateway.findUnique({
      where: { id: gatewayId },
    });

    if (!gateway) {
      return safeJson({ error: 'Gateway not found' }, { status: 404 });
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    // Prefer explicit custom header if provided
    if (config?.authHeader && (config?.apiToken || config?.apiKey)) {
      headers[String(config.authHeader)] = String(config.apiToken || config.apiKey);
    } else if (gateway.authType === 'bearer') {
      const authToken = config.apiToken || config.apiKey || gateway.apiKey;
      if (authToken) headers['Authorization'] = `Bearer ${authToken}`;
    } else if (gateway.authType === 'api-key') {
      const apiKey = config.apiKey || gateway.apiKey;
      if (apiKey) headers['X-API-Key'] = apiKey;
    } else if (gateway.authType === 'basic') {
      const apiKey = config.apiKey || gateway.apiKey;
      const apiSecret = config.apiSecret || gateway.apiSecret;
      if (apiKey && apiSecret) {
        const credentials = Buffer.from(`${apiKey}:${apiSecret}`).toString('base64');
        headers['Authorization'] = `Basic ${credentials}`;
      }
    }

    const finalRequestBody = {
      ...requestBody,
      ...(callbackUrl && { callback_url: callbackUrl }),
    };

    const controller = new AbortController();
    timeoutId = setTimeout(() => controller.abort(), 30000);

    const response = await fetch(gateway.apiEndpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify(finalRequestBody),
      signal: controller.signal,
    });

    if (timeoutId) clearTimeout(timeoutId);

    const responseText = await response.text();
    let responseData: any = null;

    try {
      responseData = JSON.parse(responseText);
    } catch {
      responseData = { raw: responseText };
    }

    const result = {
      statusCode: response.status,
      statusText: response.statusText,
      data: responseData,
      headers: Object.fromEntries(response.headers.entries()),
    };

    await logActivity({
      user,
      action: 'test_gateway_connection',
      resource: 'gateway',
      resourceId: gatewayId,
      metadata: {
        provider: gateway.provider,
        statusCode: response.status,
        endpoint: gateway.apiEndpoint,
        callbackUrl,
        requestBodyKeys: Object.keys(finalRequestBody),
      },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return safeJson({
      success: response.ok,
      response: result,
      ...(response.ok ? {} : { error: `API returned status ${response.status}` }),
    });
  } catch (error: any) {
    if (timeoutId) clearTimeout(timeoutId);

    console.error('POST /api/admin/test-gateway-api error:', error);

    let errorMessage = 'Failed to test gateway API';
    if (error.code === 'ECONNREFUSED') {
      errorMessage = 'Connection refused - gateway endpoint is not accessible';
    } else if (error.code === 'ENOTFOUND') {
      errorMessage = 'Gateway endpoint not found - check the URL';
    } else if (error.name === 'AbortError') {
      errorMessage = 'Request timeout - gateway took too long to respond (>30s)';
    } else if (error.message) {
      errorMessage = error.message;
    }

    return safeJson(
      { error: errorMessage },
      { status: 500 }
    );
  }
}

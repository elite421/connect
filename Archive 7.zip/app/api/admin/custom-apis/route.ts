import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const showUserApis = searchParams.get('includeUserApis') === 'true';

    const apis = await prisma.customPaymentApi.findMany({
      where: showUserApis ? {} : {
        adminProvided: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(apis) });
  } catch (error) {
    console.error('GET /api/admin/custom-apis error:', error);
    return NextResponse.json({ error: 'Failed to fetch APIs' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      apiName,
      apiBaseUrl,
      apiEndpoint,
      apiMethod,
      authType,
      apiKey,
      apiSecret,
      authHeader,
      contentType,
      apiPreset,
      requestFormat,
      responseFormat,
      isActive,
      isDefault,
      assignedServices,
      statusCheckUrl,
      apiType,
      chargeRules,
    } = body;

    if (!apiName || !apiBaseUrl || !apiEndpoint) {
      return NextResponse.json({ error: 'API name, base URL, and endpoint are required' }, { status: 400 });
    }

    if (isDefault) {
      // Unset defaults for the specific apiType
      await prisma.customPaymentApi.updateMany({
        where: {
          adminProvided: true,
          isDefault: true,
          apiType: apiType || 'PAYOUT'
        },
        data: { isDefault: false },
      });
    }

    const api = await prisma.customPaymentApi.create({
      data: {
        apiName,
        apiBaseUrl,
        apiEndpoint,
        apiMethod: apiMethod || 'POST',
        authType: authType || 'bearer',
        apiKey: apiKey || null,
        apiSecret: apiSecret || null,
        authHeader: authHeader || null,
        requestFormat: requestFormat || null,
        responseFormat: responseFormat || null,
        isActive: isActive !== false,
        isDefault: isDefault || false,
        assignedServices: assignedServices || [],
        adminProvided: true,
        apiType: apiType || 'PAYOUT',
        statusCheckUrl: statusCheckUrl || null,
        chargeRules: chargeRules || [], // Save charge rules
        apiNumber: `API-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
        callbackToken: require('crypto').randomBytes(32).toString('hex'),
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(api) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/admin/custom-apis error:', error);
    return NextResponse.json({ error: 'Failed to create API' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      id,
      apiName,
      apiBaseUrl,
      apiEndpoint,
      apiMethod,
      authType,
      apiKey,
      apiSecret,
      authHeader,
      contentType,
      apiPreset,
      requestFormat,
      responseFormat,
      isActive,
      isDefault,
      assignedServices,
      statusCheckUrl,
      apiType,
      chargeRules,
    } = body;

    if (!id) {
      return NextResponse.json({ error: 'API ID is required' }, { status: 400 });
    }

    if (isDefault) {
      // Unset defaults for the specific apiType
      await prisma.customPaymentApi.updateMany({
        where: {
          adminProvided: true,
          isDefault: true,
          NOT: { id },
          apiType: apiType || undefined
        },
        data: { isDefault: false },
      });
    }

    const api = await prisma.customPaymentApi.update({
      where: { id },
      data: {
        apiName,
        apiBaseUrl,
        apiEndpoint,
        apiMethod,
        authType,
        apiKey: apiKey || null,
        apiSecret: apiSecret || null,
        authHeader: authHeader || null,
        requestFormat: requestFormat || null,
        responseFormat: responseFormat || null,
        isActive,
        isDefault,
        assignedServices: assignedServices || [],
        statusCheckUrl: statusCheckUrl || null,
        apiType: apiType || undefined,
        chargeRules: chargeRules || undefined, // Update rules
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(api) });
  } catch (error) {
    console.error('PATCH /api/admin/custom-apis error:', error);
    return NextResponse.json({ error: 'Failed to update API' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'API ID is required' }, { status: 400 });
    }

    await prisma.customPaymentApi.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: 'API deleted' });
  } catch (error) {
    console.error('DELETE /api/admin/custom-apis error:', error);
    return NextResponse.json({ error: 'Failed to delete API' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function POST(req: NextRequest) {
  const admin = await authMiddleware(req, ['ADMIN']);
  if (admin instanceof NextResponse) return admin;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const userId = searchParams.get('userId');
    const apiKeyId = searchParams.get('apiKeyId');
    const method = searchParams.get('method');
    const statusCode = searchParams.get('statusCode');

    const whereClause: any = {};

    if (userId) {
      whereClause.userId = userId;
    }

    if (apiKeyId) {
      whereClause.apiKeyId = apiKeyId;
    }

    if (method) {
      whereClause.method = method;
    }

    if (statusCode) {
      const code = parseInt(statusCode);
      if (statusCode === 'error') {
        whereClause.statusCode = { not: null };
        whereClause.error = { not: null };
      } else {
        whereClause.statusCode = code;
      }
    }

    const logs = await prisma.apiRequestLog.findMany({
      where: whereClause,
      skip: offset,
      take: limit,
      select: {
        id: true,
        method: true,
        endpoint: true,
        statusCode: true,
        responseTime: true,
        ipAddress: true,
        userAgent: true,
        error: true,
        createdAt: true,
        user: { select: { id: true, username: true, email: true } },
        apiKey: { select: { id: true, name: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    const total = await prisma.apiRequestLog.count({
      where: whereClause,
    });

    return NextResponse.json({
      success: true,
      data: logs,
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('POST /api/admin/api-logs error:', error);
    return NextResponse.json({ error: 'Failed to fetch API logs' }, { status: 500 });
  }
}

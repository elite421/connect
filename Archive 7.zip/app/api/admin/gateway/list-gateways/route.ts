import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || (session.user as any)?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const gateways = await prisma.gatewayIntegration.findMany({
      select: {
        id: true,
        gatewayName: true,
        gatewayCode: true,
        userId: true,
        isPrimary: true,
        isActive: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      success: true,
      gateways,
    });
  } catch (error: any) {
    console.error('Failed to fetch gateways:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to fetch gateways' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || (session.user as any)?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const documentations = await prisma.apiDocumentation.findMany({
      select: {
        id: true,
        name: true,
        description: true,
        documentType: true,
        status: true,
        fileName: true,
        createdAt: true,
        parsedSchema: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      success: true,
      documentations,
    });
  } catch (error: any) {
    console.error('Failed to fetch documentations:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to fetch documentations' },
      { status: 500 }
    );
  }
}

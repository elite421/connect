import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';
import AutoIntegrationService from '@/lib/ai-auto-integration';
import GatewayIntegrationService from '@/lib/gateway-integration';

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || (session.user as any)?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { documentationId, userId, gatewayName, baseUrl, credentials } = await req.json();

    if (!documentationId || !userId || !gatewayName || !baseUrl || !credentials) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const documentation = await prisma.apiDocumentation.findUnique({
      where: { id: documentationId },
    });

    if (!documentation || !documentation.parsedSchema) {
      return NextResponse.json(
        { error: 'Documentation not found or not parsed' },
        { status: 404 }
      );
    }

    const schema = documentation.parsedSchema as any;
    const autoIntegration = new AutoIntegrationService();
    const integrationService = new GatewayIntegrationService(prisma);

    // Automatically analyze and generate field mappings
    const analysisResult = await autoIntegration.analyzeAndIntegrate(
      schema,
      documentation.documentType,
      gatewayName
    );

    if (!analysisResult.success) {
      return NextResponse.json(
        { error: analysisResult.error || 'Failed to analyze API' },
        { status: 400 }
      );
    }

    const gatewayCode = gatewayName.toLowerCase().replace(/\s+/g, '_');

    // Register the gateway with extracted mappings
    const integration = await integrationService.registerGateway(
      userId,
      gatewayName,
      gatewayCode,
      baseUrl,
      credentials,
      {
        ...schema,
        fieldMappings: analysisResult.fieldMappings || {},
        autoDetected: true,
        detectedEndpoints: analysisResult.endpoints,
      } as any,
      true
    );

    // Generate automation script
    const automationScript = await autoIntegration.generateAutomationScript(
      schema,
      analysisResult.fieldMappings || {}
    );

    // Create endpoint configurations automatically
    if (analysisResult.endpoints && Array.isArray(analysisResult.endpoints)) {
      for (const endpoint of analysisResult.endpoints) {
        await prisma.gatewayEndpointConfig.create({
          data: {
            integrationId: integration.id,
            endpoint: endpoint.path,
            method: endpoint.method,
            description: endpoint.description || `${endpoint.type} endpoint`,
            requestSchema: endpoint.requestBody,
            responseSchema: endpoint.responses,
            mappings: analysisResult.fieldMappings,
          },
        });
      }
    }

    // Update documentation status
    await prisma.apiDocumentation.update({
      where: { id: documentationId },
      data: {
        status: 'approved',
        approvedBy: (session.user as any).id,
        approvedAt: new Date(),
      },
    });

    return NextResponse.json({
      success: true,
      integration: {
        id: integration.id,
        gatewayName: integration.gatewayName,
        gatewayCode: integration.gatewayCode,
        baseUrl: integration.baseUrl,
        isPrimary: integration.isPrimary,
        isActive: integration.isActive,
      },
      analysis: {
        fieldMappings: analysisResult.fieldMappings,
        endpoints: analysisResult.endpoints,
        authentication: analysisResult.authentication,
        webhooks: analysisResult.webhooks,
      },
      automationScript,
    });
  } catch (error: any) {
    console.error('Auto integration error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to auto-integrate gateway' },
      { status: 500 }
    );
  }
}

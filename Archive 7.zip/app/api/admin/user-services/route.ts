import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const offset = parseInt(searchParams.get('offset') || '0');
    const limit = parseInt(searchParams.get('limit') || '50');

    const [userServices, total] = await Promise.all([
      prisma.userService.findMany({
        include: {
          user: { select: { id: true, email: true, name: true } },
          service: { select: { id: true, code: true, name: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip: offset,
        take: limit,
      }),
      prisma.userService.count(),
    ]);

    return NextResponse.json({
      success: true,
      data: userServices,
      pagination: { offset, limit, total },
    });
  } catch (error) {
    console.error('GET /api/admin/user-services error:', error);
    return NextResponse.json({ error: 'Failed to fetch user services' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { userId, serviceId, isActive, transactionCharge, transactionChargeType } = await req.json();

    if (!userId || !serviceId) {
      return NextResponse.json(
        { error: 'User ID and Service ID are required' },
        { status: 400 }
      );
    }

    const existingAssignment = await prisma.userService.findFirst({
      where: {
        userId,
        serviceId,
      },
    });

    if (existingAssignment) {
      return NextResponse.json(
        { error: 'Service is already assigned to this user' },
        { status: 400 }
      );
    }

    const userService = await prisma.userService.create({
      data: {
        userId,
        serviceId,
        isActive: isActive !== false,
        transactionCharge: transactionCharge ? parseFloat(String(transactionCharge)) : 0,
        transactionChargeType: transactionChargeType || 'fixed',
      },
      include: {
        user: { select: { id: true, email: true, name: true } },
        service: { select: { id: true, code: true, name: true } },
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(userService) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/admin/user-services error:', error);
    return NextResponse.json({ error: 'Failed to assign service to user' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { userServiceId, isActive, transactionCharge, transactionChargeType } = await req.json();

    if (!userServiceId) {
      return NextResponse.json({ error: 'User Service ID is required' }, { status: 400 });
    }

    const userService = await prisma.userService.update({
      where: { id: userServiceId },
      data: {
        ...(isActive !== undefined && { isActive }),
        ...(transactionCharge !== undefined && { 
          transactionCharge: parseFloat(String(transactionCharge))
        }),
        ...(transactionChargeType && { transactionChargeType }),
      },
      include: {
        user: { select: { id: true, email: true, name: true } },
        service: { select: { id: true, code: true, name: true } },
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(userService) });
  } catch (error) {
    console.error('PATCH /api/admin/user-services error:', error);
    return NextResponse.json({ error: 'Failed to update user service' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const userServiceId = searchParams.get('userServiceId');

    if (!userServiceId) {
      return NextResponse.json({ error: 'User Service ID is required' }, { status: 400 });
    }

    await prisma.userService.delete({
      where: { id: userServiceId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/admin/user-services error:', error);
    return NextResponse.json({ error: 'Failed to delete user service' }, { status: 500 });
  }
}

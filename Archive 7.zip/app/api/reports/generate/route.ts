import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN', 'USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const type = searchParams.get('type') || 'transactions';
    const format = searchParams.get('format') || 'csv';
    const startDateStr = searchParams.get('startDate');
    const endDateStr = searchParams.get('endDate');

    if (!startDateStr || !endDateStr) {
      return NextResponse.json({ error: 'startDate and endDate required' }, { status: 400 });
    }

    const startDate = new Date(startDateStr);
    const endDate = new Date(endDateStr);

    const wherePayments: any = { createdAt: { gte: startDate, lte: endDate } };
    const whereTx: any = { createdAt: { gte: startDate, lte: endDate } };
    if (user.role === 'ADMIN') {
      // system-wide
    } else if (user.role === 'USER') {
      wherePayments.userId = user.id;
      whereTx.userId = user.id;
    } else if (user.role === 'SUBUSER') {
      wherePayments.subUserId = user.id;
      whereTx.subUserId = user.id;
    }

    const [payments, transactions] = await Promise.all([
      prisma.payment.findMany({ where: wherePayments, orderBy: { createdAt: 'desc' } }),
      prisma.subUserTransaction.findMany({ where: whereTx, orderBy: { createdAt: 'desc' } }),
    ]);

    const rows = [
      ...payments.map((p) => ({
        id: p.id,
        kind: 'payment',
        serviceType: p.serviceType,
        amount: Number(p.amount),
        currency: p.currency,
        status: p.status,
        createdAt: p.createdAt.toISOString(),
      })),
      ...transactions.map((t) => ({
        id: t.id,
        kind: 'transaction',
        type: t.type,
        amount: Number(t.amount),
        currency: t.currency,
        status: t.status,
        createdAt: t.createdAt.toISOString(),
      })),
    ];

    const headers = type === 'transactions'
      ? ['id','kind','type','amount','currency','status','createdAt']
      : ['id','kind','serviceType','amount','currency','status','createdAt'];

    const csv = [headers.join(','), ...rows.map((r) => headers.map((h) => (r as any)[h] ?? '').join(','))].join('\n');
    const bytes = new TextEncoder().encode(csv);

    await logActivity({
      user,
      action: 'view_report',
      resource: 'report.generate',
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      metadata: { type, format, startDate: startDateStr, endDate: endDateStr },
    });

    const filename = `report-${Date.now()}.${format === 'pdf' ? 'pdf' : format === 'xlsx' ? 'xlsx' : 'csv'}`;
    const contentType = format === 'csv'
      ? 'text/csv'
      : 'application/octet-stream';

    return new NextResponse(bytes, {
      status: 200,
      headers: {
        'Content-Type': contentType,
        'Content-Disposition': `attachment; filename=${filename}`,
      },
    });
  } catch (error) {
    console.error('GET /api/reports/generate error:', error);
    return NextResponse.json({ error: 'Failed to generate report' }, { status: 500 });
  }
}


import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN', 'USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const wherePayments: any = {};
    const whereTx: any = {};
    if (user.role === 'ADMIN') {
      // system-wide
    } else if (user.role === 'USER') {
      wherePayments.userId = user.id;
      whereTx.userId = user.id;
    } else if (user.role === 'SUBUSER') {
      wherePayments.subUserId = user.id;
      whereTx.subUserId = user.id;
    }

    const [payments, transactions] = await Promise.all([
      prisma.payment.findMany({
        where: wherePayments,
        orderBy: { createdAt: 'desc' },
        take: 200,
      }),
      prisma.subUserTransaction.findMany({
        where: whereTx,
        orderBy: { createdAt: 'desc' },
        take: 200,
      }),
    ]);

    const rows = [
      ...payments.map((p) => ({
        id: p.id,
        type: 'credit',
        amount: Number(p.amount),
        currency: p.currency as 'INR' | 'USD',
        status: p.status === 'completed' ? 'success' : 'failed',
        createdAt: p.createdAt.toISOString(),
      })),
      ...transactions.map((t) => ({
        id: t.id,
        type: t.type === 'credit' ? 'credit' : 'debit',
        amount: Number(t.amount),
        currency: t.currency as 'INR' | 'USD',
        status: t.status === 'completed' ? 'success' : 'failed',
        createdAt: t.createdAt.toISOString(),
      })),
    ];

    const total = rows.reduce((sum, r) => sum + (Number.isFinite(r.amount) ? Number(r.amount) : 0), 0);
    const successCount = rows.filter((r) => r.status === 'success').length;
    const successRate = rows.length > 0 ? Math.round((successCount / rows.length) * 100) : 0;

    await logActivity({
      user,
      action: 'view_report',
      resource: 'report',
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({ rows, total, successRate });
  } catch (error) {
    console.error('GET /api/reports error:', error);
    return NextResponse.json({ error: 'Failed to load reports' }, { status: 500 });
  }
}


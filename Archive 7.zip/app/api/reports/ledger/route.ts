import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { toRupees } from '@/lib/money';
import { safeJson } from '@/lib/safe-json';

function serializeBigInt(obj: unknown): unknown {
    if (obj === null || obj === undefined) return obj;
    if (typeof obj === 'bigint') return obj.toString();
    if (obj instanceof Date) return obj.toISOString();
    if (typeof obj === 'object') {
        if (Array.isArray(obj)) return obj.map(serializeBigInt);
        const result: Record<string, unknown> = {};
        for (const [key, value] of Object.entries(obj)) {
            result[key] = serializeBigInt(value);
        }
        return result;
    }
    return obj;
}

// Helper to safely convert BigInt or Decimal to Rupees
function safeToRupees(value: any): number {
    if (value === null || value === undefined) return 0;
    return Number(value);
}

export async function GET(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN', 'USER', 'SUBUSER']);
    if (user instanceof NextResponse) return user;

    try {
        const { searchParams } = new URL(req.url);
        const startDate = searchParams.get('startDate');
        const endDate = searchParams.get('endDate');
        const type = searchParams.get('type') || 'all'; // all, payin, payout, wallet
        const format = searchParams.get('format') || 'json'; // json, csv

        const userRole = user.role;
        let parentUserId = user.id;

        // For subusers, get their parent user ID for wallet lookups
        if (userRole === 'SUBUSER') {
            const subUser = await prisma.subUser.findFirst({
                where: { id: user.id },
            });
            if (subUser) {
                parentUserId = subUser.userId; // userId is the parent user's ID
            }
        }

        // Build date filter
        const dateFilter: any = {};
        if (startDate) {
            dateFilter.gte = new Date(startDate);
        }
        if (endDate) {
            const end = new Date(endDate);
            end.setHours(23, 59, 59, 999);
            dateFilter.lte = end;
        }

        const createdAtFilter = Object.keys(dateFilter).length > 0 ? { createdAt: dateFilter } : {};

        // For admin, allow filtering by specific userId
        const filterUserId = searchParams.get('userId');
        const isAdmin = userRole === 'ADMIN';

        // Fetch wallet transactions (ledger entries)
        let walletFilter: any = {};
        if (isAdmin && filterUserId && filterUserId !== 'all') {
            // Admin filtering by specific user
            walletFilter = { userId: filterUserId };
        } else if (!isAdmin) {
            // Non-admin users see only their own data
            walletFilter = { userId: parentUserId };
        }
        // If admin with no filter, walletFilter stays empty (all users)

        const walletTransactions = await prisma.walletTransactionLocal.findMany({
            where: {
                ...walletFilter,
                ...createdAtFilter,
            },
            orderBy: { createdAt: 'desc' },
            take: 500,
            include: {
                wallet: {
                    include: {
                        user: {
                            select: { name: true, email: true }
                        }
                    }
                }
            }
        });

        // Combine and format ledger entries
        const ledgerEntries: any[] = [];

        // Add wallet transactions
        walletTransactions.forEach(tx => {
            ledgerEntries.push({
                id: tx.id,
                date: tx.createdAt,
                type: tx.type,
                category: 'WALLET',
                description: tx.description || `${tx.type} transaction`,
                debit: tx.type.includes('DEBIT') || tx.type.includes('WITHDRAW') ? safeToRupees(tx.amount) : 0,
                credit: tx.type.includes('CREDIT') || tx.type.includes('DEPOSIT') || tx.type.includes('REFUND') ? safeToRupees(tx.amount) : 0,
                closingBalance: safeToRupees(tx.balanceAfter),
                openingBalance: safeToRupees(tx.balanceAfter) +
                    (tx.type.includes('DEBIT') || tx.type.includes('WITHDRAW') ? safeToRupees(tx.amount) : 0) -
                    (tx.type.includes('CREDIT') || tx.type.includes('DEPOSIT') || tx.type.includes('REFUND') ? safeToRupees(tx.amount) : 0),
                charge: tx.chargeAmount ? safeToRupees(tx.chargeAmount) : 0,
                referenceId: tx.referenceId,
                referenceType: tx.referenceType,
                userName: tx.wallet?.user?.name || 'N/A',
                userEmail: tx.wallet?.user?.email || 'N/A',
            });
        });

        // Sort by date descending
        ledgerEntries.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

        // Calculate totals
        const totals = {
            totalDebit: ledgerEntries.reduce((sum, e) => sum + (e.debit || 0), 0),
            totalCredit: ledgerEntries.reduce((sum, e) => sum + (e.credit || 0), 0),
            totalCharges: ledgerEntries.reduce((sum, e) => sum + (e.charge || 0), 0),
            netBalance: ledgerEntries.reduce((sum, e) => sum + (e.credit || 0) - (e.debit || 0), 0),
            totalEntries: ledgerEntries.length,
        };

        // If CSV format requested
        if (format === 'csv') {
            const headers = ['Date', 'Type', 'Category', 'Description', 'Debit (₹)', 'Credit (₹)', 'Balance (₹)', 'Charge (₹)', 'Reference ID', 'Status', 'UTR', 'User Name', 'User Email'];
            const csvRows = [headers.join(',')];

            ledgerEntries.forEach(entry => {
                const row = [
                    new Date(entry.date).toLocaleString('en-IN'),
                    entry.type,
                    entry.category,
                    `"${entry.description}"`,
                    entry.debit.toFixed(5),
                    entry.credit.toFixed(5),
                    entry.closingBalance !== null && entry.closingBalance !== undefined ? entry.closingBalance.toFixed(5) : '-',
                    entry.charge.toFixed(5),
                    entry.referenceId || '-',
                    entry.status || '-',
                    entry.utrNumber || '-',
                    entry.userName,
                    entry.userEmail,
                ];
                csvRows.push(row.join(','));
            });

            // Add totals row
            csvRows.push('');
            csvRows.push(`Totals,,,,${totals.totalDebit.toFixed(5)},${totals.totalCredit.toFixed(5)},,${totals.totalCharges.toFixed(5)},,,,`);
            csvRows.push(`Net Balance,,,,,${totals.netBalance.toFixed(5)},,,,,`);

            const csv = csvRows.join('\n');

            return new NextResponse(csv, {
                headers: {
                    'Content-Type': 'text/csv',
                    'Content-Disposition': `attachment; filename="ledger-${new Date().toISOString().split('T')[0]}.csv"`,
                },
            });
        }

        return safeJson({
            success: true,
            data: ledgerEntries,
            totals,
            filters: {
                startDate,
                endDate,
                type,
                userRole,
            }
        });
    } catch (error) {
        console.error('GET /api/reports/ledger error:', error);
        return safeJson({ error: 'Failed to fetch ledger data' }, { status: 500 });
    }
}

import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { requireRole } from "@/lib/roles";
import nodeCrypto from "crypto";
import { toRupees } from "@/lib/money";

const ALLOWED = new Set([
  "dth_recharge",
  "mobile_recharge",
  "payout_imps",
  "electricity_bill",
  "broadband",
  "fastag",
  "gas_recharge",
  "water_bill",
  "landline",
  "cable_tv",
  "insurance_premium",
  "loan_repayment",
  "bank_transfer_neft",
]);

export async function POST(req: NextRequest, { params }: { params: { code: string } | Promise<{ code: string }> }) {
  const realParams = typeof params === 'object' && 'then' in params ? await params : params;
  if (!ALLOWED.has(realParams.code)) {
    return NextResponse.json({ error: "Unknown service" }, { status: 404 });
  }

  const roleCheck = await requireRole(req, ["ADMIN", "USER"]);
  if (roleCheck instanceof NextResponse) return roleCheck;
  const userId = roleCheck.id;

  const idempoKey = req.headers.get("idempotency-key") || undefined;
  const body = await req.json().catch(() => ({} as Record<string, unknown>));
  const amountNum = typeof body.amount === "number" ? body.amount : Number(body.amount);
  if (!amountNum || !isFinite(amountNum) || amountNum <= 0) {
    return NextResponse.json({ error: "Invalid amount" }, { status: 400 });
  }
  const currency = (body.currency === "USD" ? "USD" : "INR") as "INR" | "USD";
  const amountInRupees = amountNum;

  let wallet = await prisma.walletsDb.findFirst({ where: { ownerType: "user", ownerId: userId, currency } });
  if (!wallet) {
    wallet = await prisma.walletsDb.create({ data: { ownerType: "user", ownerId: userId, currency, balance: 0 } });
  }

  if (idempoKey) {
    const existing = await prisma.walletTransaction.findFirst({ where: { walletId: wallet.id, idempotencyKey: idempoKey } });
    if (existing) {
      return NextResponse.json({
        success: true,
        service: realParams.code,
        amount: existing.amount.toString(),
        currency: existing.currency,
        txId: existing.id,
        balanceAfter: existing.balanceAfter.toString(),
        idempotencyKey: idempoKey,
      });
    }
  }

  if (wallet.balance < amountInRupees) {
    return NextResponse.json({ error: "Insufficient wallet balance" }, { status: 402 });
  }

  const nextBalance = wallet.balance - amountInRupees;
  const referenceId = cryptoRandomId();

  const tx = await prisma.$transaction(async (txPrisma) => {
    await txPrisma.walletsDb.update({ where: { id: wallet!.id }, data: { balance: nextBalance } });
    const ledger = await txPrisma.walletTransaction.create({
      data: {
        walletId: wallet!.id,
        txType: "debit",
        amount: amountInRupees,
        balanceAfter: nextBalance,
        currency,
        referenceType: "service",
        referenceId,
        idempotencyKey: idempoKey,
        metadata: { serviceCode: realParams.code, request: body },
      },
    });
    return ledger;
  });

  return NextResponse.json({
    success: true,
    service: realParams.code,
    amount: tx.amount.toString(),
    currency: tx.currency,
    txId: tx.id,
    balanceAfter: tx.balanceAfter.toString(),
    idempotencyKey: idempoKey,
    referenceId,
  });
}

function cryptoRandomId() {
  const bytes = cryptoGetRandomBytes(12);
  return Buffer.from(bytes).toString("hex");
}

function cryptoGetRandomBytes(n: number) {
  if (typeof nodeCrypto?.randomBytes === "function") return nodeCrypto.randomBytes(n);
  const arr = new Uint8Array(n);
  crypto.getRandomValues(arr);
  return Buffer.from(arr);
}

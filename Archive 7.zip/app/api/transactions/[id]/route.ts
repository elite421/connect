import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER', 'ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const type = searchParams.get('type') || 'PAYIN';
    const { id } = await params;
    const transactionId = id;

    if (type === 'PAYIN') {
      const transaction = await prisma.payInTransaction.findUnique({
        where: { id: transactionId },
      });

      if (!transaction) {
        return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
      }

      if (user.role === 'USER' && transaction.userId !== user.id) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
      }

      return NextResponse.json({
        success: true,
        data: {
          id: transaction.id,
          amount: transaction.amount,
          currency: 'INR',
          status: transaction.status,
          createdAt: transaction.createdAt,
          updatedAt: transaction.updatedAt,
          merchantTransactionId: transaction.merchantTransactionId,
          externalTransactionId: transaction.externalTransactionId,
          utrNumber: transaction.utrNumber,
          responseData: transaction.responseData,
          customerName: transaction.customerName,
          customerEmail: transaction.customerEmail,
          customerPhone: transaction.customerPhone,
          paymentMethod: transaction.paymentMethod,
        },
      });
    } else if (type === 'PAYOUT') {
      const transaction = await prisma.payOutTransaction.findUnique({
        where: { id: transactionId },
      });

      if (!transaction) {
        return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
      }

      if (user.role === 'USER' && transaction.userId !== user.id) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
      }

      if (user.role === 'SUBUSER' && transaction.subUserId !== user.id) {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
      }

      return NextResponse.json({
        success: true,
        data: {
          id: transaction.id,
          amount: transaction.amount,
          currency: 'INR',
          status: transaction.status,
          createdAt: transaction.createdAt,
          updatedAt: transaction.updatedAt,
          beneficiaryName: transaction.beneficiaryName,
          beneficiaryAccount: transaction.beneficiaryAccount,
          beneficiaryIfsc: transaction.beneficiaryIfsc,
          transferMode: transaction.transferMode,
        },
      });
    }

    return NextResponse.json(
      { error: 'Invalid transaction type' },
      { status: 400 }
    );
  } catch (error) {
    console.error('GET /api/transactions/[id] error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch transaction details' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { statusCode, message, orderId, Utr } = body;

    const transaction = await prisma.payOutTransaction.findFirst({
      where: { id: orderId },
    });

    if (!transaction) {
      console.warn(`Payout callback received for unknown transaction: ${orderId}`);
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
    }

    const isSuccess = statusCode === 200 && message === 'Success';
    const isFailed = statusCode === 400;
    const isPending = statusCode === 202;

    await prisma.payOutTransaction.update({
      where: { id: transaction.id },
      data: {
        status: isSuccess ? 'completed' : isFailed ? 'failed' : isPending ? 'pending' : 'processing',
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Callback processed',
    });
  } catch (error) {
    console.error('POST /api/gateway/payout/callback error:', error);
    return NextResponse.json(
      { error: 'Failed to process callback' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { orderId, gatewayName = 'marketingllp' } = body;

    if (!orderId) {
      return NextResponse.json(
        { error: 'Order ID required' },
        { status: 400 }
      );
    }

    const transaction = await prisma.payOutTransaction.findUnique({
      where: { id: orderId },
    });

    if (!transaction) {
      return NextResponse.json(
        { error: 'Transaction not found' },
        { status: 404 }
      );
    }

    const userApis = await prisma.userApi.findMany({
      where: { userId: user.id, isActive: true },
    });

    const selectedApi = userApis.find(api => api.name?.toLowerCase().includes(gatewayName.toLowerCase()));
    if (!selectedApi || !selectedApi.apiKey) {
      return NextResponse.json(
        { error: 'Payment gateway not configured' },
        { status: 400 }
      );
    }

    const gatewayUrl = selectedApi.baseUrl || 'https://marketingllp.in/api/v1/Payout/CheckStatus';
    const token = selectedApi.apiKey;

    const statusResponse = await fetch(gatewayUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Token': token,
      },
      body: JSON.stringify({ orderId }),
    });

    const gatewayData = await statusResponse.json();

    const statusMap: { [key: number]: string } = {
      200: 'completed',
      202: 'pending',
      400: 'failed',
    };

    const mappedStatus = statusMap[gatewayData.statusCode] || 'unknown';

    if (mappedStatus !== transaction.status) {
      await prisma.payOutTransaction.update({
        where: { id: orderId },
        data: { status: mappedStatus },
      });
    }

    await logActivity({
      user,
      action: 'view_transactions',
      resource: 'payout',
      resourceId: orderId,
      metadata: { gatewayStatus: gatewayData.statusCode },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: {
        transactionId: orderId,
        status: mappedStatus,
        gatewayStatus: gatewayData.statusCode,
        message: gatewayData.message,
        utr: gatewayData.Utr,
      },
    });
  } catch (error) {
    console.error('POST /api/gateway/payout/status error:', error);
    return NextResponse.json(
      { error: 'Failed to check payout status' },
      { status: 500 }
    );
  }
}

import { Decimal } from '@prisma/client/runtime/library';
import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import GatewayIntegrationService from '@/lib/gateway-integration';

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
  try {
    const gatewayId = req.nextUrl.searchParams.get('gatewayId');
    const signature = req.headers.get('x-webhook-signature') || req.headers.get('signature');

    if (!gatewayId) {
      return NextResponse.json({ error: 'Gateway ID required' }, { status: 400 });
    }

    const payload = await req.json();
    const integrationService = new GatewayIntegrationService(prisma);

    const webhookResult = await integrationService.handleWebhook(
      gatewayId,
      payload,
      signature || undefined
    );

    if (!webhookResult.valid) {
      return NextResponse.json({ error: 'Invalid webhook signature' }, { status: 401 });
    }

    const integration = await prisma.gatewayIntegration.findUnique({
      where: { id: gatewayId },
    });

    if (!integration) {
      return NextResponse.json({ error: 'Gateway not found' }, { status: 404 });
    }

    const schema = integration.apiSchema as any;
    const fieldMappings = schema?.fieldMappings || {};

    const externalTransactionId = extractField(payload, fieldMappings['transactionId'] || ['id', 'transaction_id']);
    const utrNumber = extractField(payload, fieldMappings['utrNumber'] || ['utr', 'reference_number']);
    const statusStr = extractField(payload, fieldMappings['status'] || ['status', 'state']);
    const status = mapStatus(statusStr);

    const transaction = await prisma.payInTransaction.findFirst({
      where: {
        externalTransactionId,
        gatewayId,
      },
    });

    if (transaction) {
      const updatedTx = await prisma.payInTransaction.update({
        where: { id: transaction.id },
        data: {
          status,
          utrNumber,
          responseData: payload,
        },
      });

      await integrationService.logTransaction(
        gatewayId,
        transaction.id,
        {},
        payload,
        utrNumber,
        status
      );

      if (status === 'success') {
        await updateWalletBalance(updatedTx.userId, updatedTx.amount);
      }

      const approval = await prisma.webhookApproval.findFirst({
        where: {
          integrationId: gatewayId,
          status: 'approved',
        },
      });

      if (approval) {
        await notifyWebhookCallback(approval.webhookUrl, {
          event: 'transaction.completed',
          transaction: updatedTx,
        });
      }
    }

    return NextResponse.json({ success: true, received: true });
  } catch (error: any) {
    console.error('Webhook processing error:', error);
    return NextResponse.json(
      { error: error.message || 'Webhook processing failed' },
      { status: 500 }
    );
  }
}

function extractField(obj: any, paths: string | string[]): any {
  const pathArray = Array.isArray(paths) ? paths : [paths];
  for (const path of pathArray) {
    const value = path.split('.').reduce((current, part) => current?.[part], obj);
    if (value !== undefined && value !== null) {
      return value;
    }
  }
  return undefined;
}

function mapStatus(status?: string): 'pending' | 'success' | 'failed' {
  if (!status) return 'pending';
  const lower = status.toLowerCase();
  if (['success', 'completed', 'approved'].includes(lower)) return 'success';
  if (['failed', 'declined', 'error', 'cancelled'].includes(lower)) return 'failed';
  return 'pending';
}

async function updateWalletBalance(userId: string, amount: any) {
  try {
    let wallet = await prisma.wallet.findUnique({
      where: { userId },
    });

    if (!wallet) {
      wallet = await prisma.wallet.create({
        data: { userId },
      });
    }

    const currentBalance = (wallet as any).balance || new Decimal(0);
    const newBalance = new Decimal(currentBalance).add(new Decimal(amount || 0));

    await prisma.wallet.update({
      where: { id: wallet.id },
      data: { balance: newBalance } as any,
    });
  } catch (error) {
    console.error('Failed to update wallet:', error);
  }
}

async function notifyWebhookCallback(webhookUrl: string, data: any) {
  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!response.ok) {
      console.warn(`Webhook notification failed: ${response.status}`);
    }
  } catch (error) {
    console.error('Failed to send webhook notification:', error);
  }
}

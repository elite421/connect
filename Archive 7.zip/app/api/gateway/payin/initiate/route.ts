import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { toPaise } from '@/lib/money';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      memberId,
      amount,
      mobile,
      orderId,
      callbackUrl,
      gatewayName = 'marketingllp'
    } = body;

    if (!memberId || !amount || !mobile || !orderId) {
      return NextResponse.json(
        { error: 'Missing required fields: memberId, amount, mobile, orderId' },
        { status: 400 }
      );
    }

    const userApis = await prisma.userApi.findMany({
      where: { userId: user.id, isActive: true },
    });

    const selectedApi = userApis.find(api => api.name?.toLowerCase().includes(gatewayName.toLowerCase()));
    if (!selectedApi || !selectedApi.apiKey) {
      return NextResponse.json(
        { error: 'Payment gateway not configured' },
        { status: 400 }
      );
    }

    const gatewayUrl = selectedApi.baseUrl || 'https://marketingllp.in/api/payin/initiate';
    const token = selectedApi.apiKey;

    const payinResponse = await fetch(gatewayUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Token': token,
      },
      body: JSON.stringify({
        memberId,
        amount,
        mobile,
        orderid: orderId,
        callback_url: callbackUrl || `${process.env.NEXTAUTH_URL}/api/gateway/payin/callback`,
      }),
    });

    const gatewayData = await payinResponse.json();

    if (!payinResponse.ok || !gatewayData.status) {
      await logActivity({
        user,
        action: 'create_payment',
        resource: 'payin',
        status: 'failure',
        metadata: { error: gatewayData.message, orderId },
        ipAddress: extractIpAddress(req),
        userAgent: getUserAgent(req),
      });

      return NextResponse.json(
        { error: gatewayData.message || 'Payment initiation failed' },
        { status: 400 }
      );
    }

    const payinTransaction = await prisma.payInTransaction.create({
      data: {
        userId: user.id,
        amount: toPaise(amount),
        customerName: '',
        customerEmail: '',
        customerPhone: mobile,
        paymentMethod: 'upi',
        merchantTransactionId: orderId,
        externalTransactionId: gatewayData.url?.split('tr=')[1]?.split('&')[0] || '',
        gatewayId: selectedApi.id,
        status: 'pending',
        responseData: {
          initiationResponse: gatewayData,
          paymentUrl: gatewayData.url,
        },
      },
    });

    await logActivity({
      user,
      action: 'create_payment',
      resource: 'payin',
      resourceId: payinTransaction.id,
      status: 'success',
      metadata: { orderId, amount, gatewayName },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: {
        transactionId: payinTransaction.id,
        paymentUrl: gatewayData.url,
        orderId,
        amount,
        transaction: {
          ...payinTransaction,
          amount: payinTransaction.amount.toString(),
        },
      },
    });
  } catch (error) {
    console.error('POST /api/gateway/payin/initiate error:', error);
    return NextResponse.json(
      { error: 'Failed to initiate payment' },
      { status: 500 }
    );
  }
}

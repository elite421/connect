'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { formatINR } from '@/lib/money';

interface AnalyticsData {
  totalSubUsers: number;
  activeSubUsers: number;
  transactions: {
    total: number;
    completed: number;
    failed: number;
    pending: number;
    successRate: string;
  };
  revenue: {
    total: number;
    monthlyCount: number;
    averageTransaction: number;
  };
}

export default function ReportsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [reportType, setReportType] = useState('transactions');
  const [format, setFormat] = useState('pdf');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
  }, [status, router]);

  useEffect(() => {
    const fetchAnalytics = async () => {
      setLoading(true);
      try {
        const userRole = (session?.user as any)?.role;
        let url = '';

        if (userRole === 'ADMIN') {
          url = '/api/admin/analytics';
        } else if (userRole === 'USER') {
          url = '/api/user/analytics';
        } else if (userRole === 'SUBUSER') {
          url = '/api/subuser/analytics';
        }

        if (url) {
          const response = await fetch(url);
          const data = await response.json();
          if (data.success) {
            setAnalytics(data.data);
          } else {
            console.error('Analytics API returned error:', data);
          }
        }
      } catch (error) {
        console.error('Failed to fetch analytics:', error);
      } finally {
        setLoading(false);
      }
    };

    if (session && status === 'authenticated') {
      fetchAnalytics();
    } else if (status !== 'loading') {
      setLoading(false);
    }
  }, [session, status]);

  const generateReport = async () => {
    if (!startDate || !endDate) {
      alert('Please select both start and end dates');
      return;
    }

    try {
      const params = new URLSearchParams({
        type: reportType,
        format,
        startDate,
        endDate,
      });

      const response = await fetch(`/api/reports/generate?${params}`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `report-${Date.now()}.${format === 'pdf' ? 'pdf' : format === 'csv' ? 'csv' : 'xlsx'}`;
        a.click();
      } else {
        alert('Failed to generate report');
      }
    } catch (error) {
      console.error('Failed to generate report:', error);
      alert('Error generating report');
    }
  };

  if (status === "loading" || loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-gray-600">Loading reports...</div>
      </div>
    );
  }

  if (status === "unauthenticated") {
    return null;
  }

  if (!session) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-gray-600">Loading session...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Reports & Analytics</h1>
        <p className="text-gray-600 mt-2">View detailed reports and generate custom analytics</p>
      </div>

      {analytics && analytics.revenue && analytics.transactions && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="text-3xl font-bold text-blue-600">{analytics.totalSubUsers || 0}</div>
              <div className="text-sm text-gray-600 mt-1">Total SubUsers</div>
            </div>
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="text-3xl font-bold text-green-600">{analytics.activeSubUsers || 0}</div>
              <div className="text-sm text-gray-600 mt-1">Active SubUsers</div>
            </div>
            <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
              <div className="text-3xl font-bold text-purple-600">
                {formatINR(Number(analytics.revenue?.total || 0))}
              </div>
              <div className="text-sm text-gray-600 mt-1">Total Revenue</div>
            </div>
            <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
              <div className="text-3xl font-bold text-orange-600">{analytics.transactions?.total || 0}</div>
              <div className="text-sm text-gray-600 mt-1">Total Transactions</div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
              <h3 className="font-semibold text-gray-900 mb-4">Transaction Summary</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="text-gray-600">Completed</span>
                  <span className="font-semibold text-green-600">{analytics.transactions?.completed || 0}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="text-gray-600">Failed</span>
                  <span className="font-semibold text-red-600">{analytics.transactions?.failed || 0}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="text-gray-600">Pending</span>
                  <span className="font-semibold text-yellow-600">{analytics.transactions?.pending || 0}</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600">Success Rate</span>
                  <span className="font-semibold text-blue-600">{analytics.transactions?.successRate || '0'}%</span>
                </div>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
              <h3 className="font-semibold text-gray-900 mb-4">Revenue Metrics</h3>
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="text-gray-600">Total Revenue</span>
                  <span className="font-semibold">{formatINR(Number(analytics.revenue?.total || 0))}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="text-gray-600">Avg Transaction</span>
                  <span className="font-semibold">{formatINR(Number(analytics.revenue?.averageTransaction || 0))}</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-600">Monthly Transactions</span>
                  <span className="font-semibold">{analytics.revenue?.monthlyCount || 0}</span>
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Generate Custom Report</h2>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Report Type</label>
              <select
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="transactions">Transactions</option>
                <option value="revenue">Revenue</option>
                <option value="users">Users</option>
                <option value="payments">Payments</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Format</label>
              <select
                value={format}
                onChange={(e) => setFormat(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="pdf">PDF</option>
                <option value="csv">CSV</option>
                <option value="xlsx">Excel</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <button
            onClick={generateReport}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Generate Report
          </button>
        </div>
      </div>
    </div>
  );
}

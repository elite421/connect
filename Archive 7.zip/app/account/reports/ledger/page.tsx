'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { useGlobalToast } from '@/context/ToastContext';
import { formatINR } from '@/lib/money';

interface LedgerEntry {
    id: string;
    date: string;
    type: string;
    category: string;
    description: string;
    debit: number;
    credit: number;
    openingBalance: number | null;
    closingBalance: number | null;
    charge: number;
    referenceId: string | null;
    referenceType: string | null;
    status?: string;
    utrNumber?: string | null;
    beneficiary?: string;
    userName: string;
    userEmail: string;
}

interface Totals {
    totalDebit: number;
    totalCredit: number;
    totalCharges: number;
    netBalance: number;
    totalEntries: number;
}

export default function LedgerPage() {
    const { data: session, status } = useSession();
    const router = useRouter();
    const toast = useGlobalToast();
    const [entries, setEntries] = useState<LedgerEntry[]>([]);
    const [totals, setTotals] = useState<Totals | null>(null);
    const [loading, setLoading] = useState(true);
    const [downloading, setDownloading] = useState(false);
    const [filters, setFilters] = useState({
        startDate: '',
        endDate: '',
        type: 'all',
    });

    useEffect(() => {
        if (status === 'unauthenticated') {
            router.push('/login');
        }
    }, [status, router]);

    useEffect(() => {
        if (session && status === 'authenticated') {
            fetchLedger();
        }
    }, [session, status]);

    const fetchLedger = async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (filters.startDate) params.set('startDate', filters.startDate);
            if (filters.endDate) params.set('endDate', filters.endDate);
            if (filters.type !== 'all') params.set('type', filters.type);

            const response = await fetch(`/api/reports/ledger?${params.toString()}`);
            const data = await response.json();
            if (data.success) {
                setEntries(data.data);
                setTotals(data.totals);
            } else {
                toast.showError(data.error || 'Failed to fetch ledger');
            }
        } catch (error) {
            console.error('Failed to fetch ledger:', error);
            toast.showError('Failed to fetch ledger data');
        } finally {
            setLoading(false);
        }
    };

    const downloadCSV = async () => {
        setDownloading(true);
        try {
            const params = new URLSearchParams();
            if (filters.startDate) params.set('startDate', filters.startDate);
            if (filters.endDate) params.set('endDate', filters.endDate);
            if (filters.type !== 'all') params.set('type', filters.type);
            params.set('format', 'csv');

            const response = await fetch(`/api/reports/ledger?${params.toString()}`);
            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `ledger-${new Date().toISOString().split('T')[0]}.csv`;
                a.click();
                window.URL.revokeObjectURL(url);
                toast.showSuccess('Ledger downloaded successfully');
            } else {
                toast.showError('Failed to download ledger');
            }
        } catch (error) {
            console.error('Failed to download ledger:', error);
            toast.showError('Error downloading ledger');
        } finally {
            setDownloading(false);
        }
    };

    const handleFilterChange = (key: string, value: string) => {
        setFilters(prev => ({ ...prev, [key]: value }));
    };

    const handleApplyFilters = () => {
        fetchLedger();
    };

    const clearFilters = () => {
        setFilters({
            startDate: '',
            endDate: '',
            type: 'all',
        });
        setTimeout(fetchLedger, 100);
    };

    const columns: Column<LedgerEntry>[] = [
        {
            key: 'date',
            label: 'Date & Time',
            render: (_, entry) => (
                <div className="text-sm">
                    <div className="font-medium">{new Date(entry.date).toLocaleDateString('en-IN')}</div>
                    <div className="text-gray-500">{new Date(entry.date).toLocaleTimeString('en-IN')}</div>
                </div>
            ),
        },
        {
            key: 'type',
            label: 'Type',
            render: (_, entry) => {
                const colors: Record<string, string> = {
                    PAYOUT: 'bg-orange-100 text-orange-800',
                    PAYIN: 'bg-green-100 text-green-800',
                    PAYOUT_DEBIT: 'bg-red-100 text-red-800',
                    PAYOUT_REFUND: 'bg-blue-100 text-blue-800',
                    DEPOSIT: 'bg-green-100 text-green-800',
                    WITHDRAW: 'bg-red-100 text-red-800',
                    CREDIT: 'bg-green-100 text-green-800',
                    DEBIT: 'bg-red-100 text-red-800',
                };
                return (
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${colors[entry.type] || 'bg-gray-100 text-gray-800'}`}>
                        {entry.type.replace(/_/g, ' ')}
                    </span>
                );
            },
        },
        {
            key: 'description',
            label: 'Description',
            render: (_, entry) => (
                <div className="max-w-xs truncate" title={entry.description}>
                    {entry.description}
                </div>
            ),
        },
        {
            key: 'debit',
            label: 'Debit (₹)',
            render: (_, entry) => (
                <span className={entry.debit > 0 ? 'text-red-600 font-semibold' : 'text-gray-400'}>
                    {entry.debit > 0 ? formatINR(entry.debit) : '-'}
                </span>
            ),
        },
        {
            key: 'credit',
            label: 'Credit (₹)',
            render: (_, entry) => (
                <span className={entry.credit > 0 ? 'text-green-600 font-semibold' : 'text-gray-400'}>
                    {entry.credit > 0 ? formatINR(entry.credit) : '-'}
                </span>
            ),
        },
        {
            key: 'openingBalance',
            label: 'Opening (₹)',
            render: (_, entry) => (
                <span className="text-gray-700">
                    {entry.openingBalance !== null ? formatINR(entry.openingBalance) : '-'}
                </span>
            ),
        },
        {
            key: 'closingBalance',
            label: 'Closing (₹)',
            render: (_, entry) => (
                <span className="font-medium">
                    {entry.closingBalance !== null ? formatINR(entry.closingBalance) : '-'}
                </span>
            ),
        },
        {
            key: 'charge',
            label: 'Charge (₹)',
            render: (_, entry) => (
                <span className={entry.charge > 0 ? 'text-orange-600' : 'text-gray-400'}>
                    {entry.charge > 0 ? formatINR(entry.charge) : '-'}
                </span>
            ),
        },
        {
            key: 'referenceId',
            label: 'Reference',
            render: (_, entry) => (
                <div className="text-sm">
                    {entry.referenceId ? (
                        <span className="font-mono text-xs bg-gray-100 px-2 py-1 rounded">
                            {entry.referenceId.slice(0, 12)}...
                        </span>
                    ) : (
                        '-'
                    )}
                </div>
            ),
        },
    ];

    if (status === 'loading' || loading) {
        return (
            <div className="flex items-center justify-center p-12">
                <div className="text-gray-600">Loading ledger...</div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-start">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">📒 Ledger</h1>
                    <p className="text-gray-600 mt-2">Complete transaction history and account ledger</p>
                </div>
                <button
                    onClick={downloadCSV}
                    disabled={downloading}
                    className="px-6 py-2 rounded-lg transition-colors font-medium bg-green-600 text-white hover:bg-green-700 disabled:bg-gray-400 flex items-center gap-2"
                >
                    {downloading ? (
                        <>Downloading...</>
                    ) : (
                        <>📥 Download CSV</>
                    )}
                </button>
            </div>

            {/* Filters */}
            <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
                <h3 className="font-semibold text-gray-900 mb-4">Filters</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
                        <input
                            type="date"
                            value={filters.startDate}
                            onChange={(e) => handleFilterChange('startDate', e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
                        <input
                            type="date"
                            value={filters.endDate}
                            onChange={(e) => handleFilterChange('endDate', e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Transaction Type</label>
                        <select
                            value={filters.type}
                            onChange={(e) => handleFilterChange('type', e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        >
                            <option value="all">All Transactions</option>
                            <option value="wallet">Wallet Only</option>
                            <option value="payout">Payouts Only</option>
                            <option value="payin">PayIns Only</option>
                        </select>
                    </div>
                    <div className="flex items-end gap-2">
                        <button
                            onClick={handleApplyFilters}
                            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
                        >
                            Apply
                        </button>
                        <button
                            onClick={clearFilters}
                            className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-medium"
                        >
                            Clear
                        </button>
                    </div>
                </div>
            </div>

            {/* Summary Cards */}
            {totals && (
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                        <div className="text-2xl font-bold text-red-600">{formatINR(totals.totalDebit)}</div>
                        <div className="text-sm text-gray-600 mt-1">Total Debit</div>
                    </div>
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">{formatINR(totals.totalCredit)}</div>
                        <div className="text-sm text-gray-600 mt-1">Total Credit</div>
                    </div>
                    <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                        <div className="text-2xl font-bold text-orange-600">{formatINR(totals.totalCharges)}</div>
                        <div className="text-sm text-gray-600 mt-1">Total Charges</div>
                    </div>
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <div className={`text-2xl font-bold ${totals.netBalance >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                            {formatINR(totals.netBalance)}
                        </div>
                        <div className="text-sm text-gray-600 mt-1">Net Balance</div>
                    </div>
                    <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">{totals.totalEntries}</div>
                        <div className="text-sm text-gray-600 mt-1">Total Entries</div>
                    </div>
                </div>
            )}

            {/* Ledger Table */}
            <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                <DataTable<LedgerEntry>
                    data={entries}
                    columns={columns}
                    loading={loading}
                />
            </div>

            {entries.length === 0 && !loading && (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                    <div className="text-gray-500 text-lg">No ledger entries found</div>
                    <p className="text-gray-400 mt-2">Adjust your filters or wait for transactions</p>
                </div>
            )}
        </div>
    );
}

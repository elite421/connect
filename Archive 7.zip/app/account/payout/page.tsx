"use client";
import { useEffect, useState } from "react";
import { formatINR } from '@/lib/money';

type Payout = { id: string; beneficiary: string; account: string; amount: number; currency: "INR" | "USD"; status: "queued" | "sent" | "failed"; createdAt: string };

export default function PayoutPage() {
  const [beneficiary, setBeneficiary] = useState("");
  const [account, setAccount] = useState("");
  const [amount, setAmount] = useState("");
  const [currency, setCurrency] = useState<"INR" | "USD">("INR");
  const [items, setItems] = useState<Payout[]>([]);

  async function load() {
    const res = await fetch("/api/payouts", { cache: "no-store" });
    if (!res.ok) return;
    const data = await res.json();
    const arr: unknown = data ?? [];
    const items: Payout[] = Array.isArray(arr)
      ? arr.map((d: unknown) => {
          const o = d as { id: string; beneficiary: string; account: string; amount: number | string; currency: "INR" | "USD"; status: "queued" | "sent" | "failed"; createdAt: string };
          return { id: o.id, beneficiary: o.beneficiary, account: o.account, amount: Number(o.amount), currency: o.currency, status: o.status, createdAt: o.createdAt };
        })
      : [];
    setItems(items);
  }

  async function queue() {
    if (!beneficiary || !account || !amount) return;
    const res = await fetch("/api/payouts", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ beneficiary, account, amount: Number(amount), currency }) });
    if (!res.ok) return;
    await load();
    setBeneficiary("");
    setAccount("");
    setAmount("");
  }

  useEffect(() => {
    const t = setTimeout(() => { void load(); }, 0);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Payouts</h1>

      <div className="bg-white border rounded-xl p-6 shadow-sm space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <input className="border rounded-md p-2" placeholder="Beneficiary Name" value={beneficiary} onChange={(e) => setBeneficiary(e.target.value)} />
          <input className="border rounded-md p-2" placeholder="Account Number" value={account} onChange={(e) => setAccount(e.target.value)} />
          <input className="border rounded-md p-2" placeholder="Amount" value={amount} onChange={(e) => setAmount(e.target.value)} />
          <select className="border rounded-md p-2" value={currency} onChange={(e) => setCurrency(e.target.value as "INR" | "USD")}>
            <option value="INR">INR</option>
            <option value="USD">USD</option>
          </select>
          <button onClick={queue} className="bg-green-600 hover:bg-green-700 text-white rounded-lg px-5 py-2 font-medium">Queue Payout</button>
        </div>
      </div>

      <div className="bg-white border rounded-xl p-6 shadow-sm">
        <h2 className="text-xl font-semibold mb-4">Recent Payouts</h2>
        {items.length === 0 ? (
          <p className="text-gray-600">No payouts yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="text-left text-gray-600">
                  <th className="py-2">Beneficiary</th>
                  <th className="py-2">Account</th>
                  <th className="py-2">Amount</th>
                  <th className="py-2">Status</th>
                  <th className="py-2">Created</th>
                </tr>
              </thead>
              <tbody>
                {items.map((p) => (
                  <tr key={p.id} className="border-t">
                    <td className="py-2">{p.beneficiary}</td>
                    <td className="py-2">{p.account}</td>
                    <td className="py-2">{p.currency === 'INR' ? formatINR(p.amount) : `${p.currency} ${p.amount.toFixed(2)}`}</td>
                    <td className="py-2 capitalize">{p.status}</td>
                    <td className="py-2">{new Date(p.createdAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

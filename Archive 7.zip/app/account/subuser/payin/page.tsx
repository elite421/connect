'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useGlobalToast } from '@/context/ToastContext';
import { formatINR } from '@/lib/money';

interface PayInTransaction {
    id: string;
    amount: number;
    status: string;
    utrNumber: string | null;
    createdAt: string;
}

export default function SubUserPayInPage() {
    const { data: session, status } = useSession();
    const router = useRouter();
    const toast = useGlobalToast();
    const [transactions, setTransactions] = useState<PayInTransaction[]>([]);
    const [loading, setLoading] = useState(true);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [formData, setFormData] = useState({
        amount: '',
        customerName: '',
        customerEmail: '',
        customerPhone: '',
    });
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        if (status === 'unauthenticated') router.push('/login');
        if ((session?.user as any)?.role !== 'SUBUSER') router.push('/account/dashboard');
    }, [session, status, router]);

    useEffect(() => {
        if (session && status === 'authenticated') fetchTransactions();
    }, [session, status]);

    const fetchTransactions = async () => {
        setLoading(true);
        try {
            const response = await fetch('/api/subuser/payin');
            const data = await response.json();
            if (data.success) setTransactions(data.data || []);
        } catch (error) {
            console.error('Failed to fetch payins:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleCreatePayIn = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            const response = await fetch('/api/subuser/payin', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...formData,
                    amount: parseFloat(formData.amount),
                }),
            });

            const data = await response.json();
            if (data.success) {
                toast.showSuccess('PayIn initiated successfully');
                setShowCreateModal(false);
                setFormData({ amount: '', customerName: '', customerEmail: '', customerPhone: '' });
                fetchTransactions();
            } else {
                toast.showError(data.error || 'Failed to create payin');
            }
        } catch (error) {
            toast.showError('Error creating payin');
        } finally {
            setSubmitting(false);
        }
    };

    const getStatusColor = (status: string) => {
        switch (status.toLowerCase()) {
            case 'success': case 'completed': return 'bg-green-100 text-green-800';
            case 'pending': return 'bg-yellow-100 text-yellow-800';
            case 'processing': return 'bg-blue-100 text-blue-800';
            case 'failed': return 'bg-red-100 text-red-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    if (status === 'loading' || loading) {
        return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">PayIn</h1>
                    <p className="text-gray-600 mt-2">Manage incoming payment collections</p>
                </div>
                <button onClick={() => setShowCreateModal(true)} className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium">
                    + Create PayIn
                </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{transactions.length}</div>
                    <div className="text-sm text-gray-600">Total PayIns</div>
                </div>
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{transactions.filter(t => t.status.toLowerCase() === 'success' || t.status.toLowerCase() === 'completed').length}</div>
                    <div className="text-sm text-gray-600">Successful</div>
                </div>
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="text-2xl font-bold text-yellow-600">{transactions.filter(t => t.status.toLowerCase() === 'pending' || t.status.toLowerCase() === 'processing').length}</div>
                    <div className="text-sm text-gray-600">Pending</div>
                </div>
                <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">{formatINR(transactions.reduce((sum, t) => sum + t.amount, 0))}</div>
                    <div className="text-sm text-gray-600">Total Amount</div>
                </div>
            </div>

            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Amount</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
                            <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">UTR</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {transactions.length === 0 ? (
                            <tr>
                                <td colSpan={4} className="px-4 py-12 text-center text-gray-500">No payin transactions yet</td>
                            </tr>
                        ) : (
                            transactions.map((tx) => (
                                <tr key={tx.id} className="hover:bg-gray-50">
                                    <td className="px-4 py-3 text-sm">{new Date(tx.createdAt).toLocaleDateString()}</td>
                                    <td className="px-4 py-3 font-semibold">{formatINR(tx.amount)}</td>
                                    <td className="px-4 py-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(tx.status)}`}>{tx.status}</span></td>
                                    <td className="px-4 py-3 text-sm font-mono">{tx.utrNumber || '-'}</td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            {showCreateModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-xl p-8 w-full max-w-md shadow-2xl max-h-[90vh] overflow-y-auto">
                        <h2 className="text-2xl font-bold mb-6">Create PayIn</h2>
                        <form onSubmit={handleCreatePayIn} className="space-y-4">
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">Amount (₹) *</label>
                                <input type="number" value={formData.amount} onChange={(e) => setFormData({ ...formData, amount: e.target.value })} className="w-full px-4 py-2 border rounded-lg" required min="1" />
                            </div>
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">Customer Name</label>
                                <input type="text" value={formData.customerName} onChange={(e) => setFormData({ ...formData, customerName: e.target.value })} className="w-full px-4 py-2 border rounded-lg" />
                            </div>
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">Customer Email</label>
                                <input type="email" value={formData.customerEmail} onChange={(e) => setFormData({ ...formData, customerEmail: e.target.value })} className="w-full px-4 py-2 border rounded-lg" />
                            </div>
                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">Customer Phone</label>
                                <input type="tel" value={formData.customerPhone} onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })} className="w-full px-4 py-2 border rounded-lg" />
                            </div>
                            <div className="flex gap-3 pt-4">
                                <button type="submit" disabled={submitting} className="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 font-medium disabled:opacity-50">
                                    {submitting ? 'Creating...' : 'Create PayIn'}
                                </button>
                                <button type="button" onClick={() => setShowCreateModal(false)} className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}

'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { FormBuilder, type FormField } from '@/components/form-builder';

interface Beneficiary {
  id: string;
  accountName: string;
  accountNumber: string;
  bankName: string;
  ifscCode?: string;
  upiId?: string;
  beneficiaryType: string;
  isVerified: boolean;
  createdAt: string;
}

export default function BeneficiariesPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<'bank' | 'upi'>('bank');
  const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'SUBUSER') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchBeneficiaries = async (offset: number = 0) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/subuser/beneficiaries?offset=${offset}&limit=50`);
      const data = await response.json();
      if (data.success) {
        setBeneficiaries(data.data);
        setPagination(data.pagination);
      }
    } catch (error) {
      console.error('Failed to fetch beneficiaries:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBeneficiaries();
  }, []);

  const columns: Column<Beneficiary>[] = [
    { key: 'accountName', label: 'Account Name' },
    { 
      key: 'accountNumber', 
      label: 'Account/UPI', 
      render: (val, item) => {
        if (item?.beneficiaryType === 'upi') {
          return item?.upiId ? item.upiId : 'N/A';
        }
        return val ? val.slice(-4) : 'N/A';
      }
    },
    { key: 'bankName', label: 'Bank/Provider' },
    { key: 'beneficiaryType', label: 'Type', render: (type) => type.toUpperCase() },
    { key: 'isVerified', label: 'Status', render: (verified) => verified ? '✓ Verified' : '⏳ Pending' },
  ];

  const bankFormFields: FormField[] = [
    { name: 'accountName', label: 'Account Name', type: 'text', required: true },
    { name: 'accountNumber', label: 'Account Number', type: 'text', required: true },
    { name: 'bankName', label: 'Bank Name', type: 'text', required: true },
    { name: 'ifscCode', label: 'IFSC Code', type: 'text', required: true },
  ];

  const upiFormFields: FormField[] = [
    { name: 'accountName', label: 'Account Name', type: 'text', required: true },
    { name: 'upiId', label: 'UPI ID', type: 'text', required: true, placeholder: 'user@bank' },
  ];

  const handleAddBeneficiary = async (data: Record<string, any>) => {
    try {
      const response = await fetch('/api/subuser/beneficiaries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...data, beneficiaryType: selectedType }),
      });

      if (response.ok) {
        setIsModalOpen(false);
        fetchBeneficiaries(pagination.offset);
      }
    } catch (error) {
      console.error('Failed to add beneficiary:', error);
    }
  };

  const handleDelete = async (beneficiary: Beneficiary) => {
    if (!confirm(`Delete beneficiary ${beneficiary.accountName}?`)) return;
    try {
      const response = await fetch(`/api/subuser/beneficiaries?beneficiaryId=${beneficiary.id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        fetchBeneficiaries(pagination.offset);
      }
    } catch (error) {
      console.error('Failed to delete:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Beneficiaries</h1>
          <p className="text-gray-600 mt-2">Manage your payment beneficiaries</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
        >
          + Add Beneficiary
        </button>
      </div>

      <DataTable<Beneficiary>
        data={beneficiaries}
        columns={columns}
        loading={loading}
        pagination={{
          ...pagination,
          onPageChange: (offset) => fetchBeneficiaries(offset),
        }}
        actions={[
          { label: 'Delete', onClick: handleDelete, variant: 'danger' },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Add Beneficiary"
        size="md"
      >
        <div className="space-y-4">
          <div className="flex gap-4 mb-4">
            <button
              onClick={() => setSelectedType('bank')}
              className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${
                selectedType === 'bank'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              🏦 Bank Account
            </button>
            <button
              onClick={() => setSelectedType('upi')}
              className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors ${
                selectedType === 'upi'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              📱 UPI
            </button>
          </div>

          <FormBuilder
            fields={selectedType === 'bank' ? bankFormFields : upiFormFields}
            onSubmit={handleAddBeneficiary}
            submitLabel="Add Beneficiary"
          />
        </div>
      </Modal>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

interface WhitelistedIP {
  id: string;
  ipAddress: string;
  label: string | null;
  isActive: boolean;
  createdAt: string;
}

export default function SubuserIpWhitelistPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [ips, setIps] = useState<WhitelistedIP[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({ ipAddress: '', label: '' });
  const [currentIP, setCurrentIP] = useState<string>('');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'SUBUSER') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') {
      fetchIPs();
      fetchCurrentIP();
    }
  }, [session, status]);

  const fetchCurrentIP = async () => {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      setCurrentIP(data.ip);
    } catch (error) {
      console.error('Failed to fetch current IP:', error);
    }
  };

  const fetchIPs = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/subuser/ip-whitelist');
      const data = await response.json();
      if (data.success) {
        setIps(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch IPs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddIP = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/subuser/ip-whitelist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      if (data.success) {
        setShowAddModal(false);
        setFormData({ ipAddress: '', label: '' });
        fetchIPs();
        alert('IP address added to whitelist!');
      } else {
        alert(data.error || 'Failed to add IP');
      }
    } catch (error) {
      console.error('Failed to add IP:', error);
      alert('Error adding IP');
    }
  };

  const handleToggleIP = async (ip: WhitelistedIP) => {
    try {
      const response = await fetch('/api/subuser/ip-whitelist', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: ip.id, isActive: !ip.isActive }),
      });

      if (response.ok) {
        fetchIPs();
      }
    } catch (error) {
      console.error('Failed to toggle IP:', error);
    }
  };

  const handleDeleteIP = async (ip: WhitelistedIP) => {
    if (!confirm(`Remove IP "${ip.ipAddress}" from whitelist?`)) return;

    try {
      const response = await fetch(`/api/subuser/ip-whitelist?id=${ip.id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        fetchIPs();
        alert('IP removed from whitelist');
      }
    } catch (error) {
      console.error('Failed to delete IP:', error);
    }
  };

  const addCurrentIP = () => {
    setFormData({ ...formData, ipAddress: currentIP, label: 'My Current IP' });
    setShowAddModal(true);
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">IP Whitelist</h1>
          <p className="text-gray-600 mt-2">Manage allowed IP addresses for API access</p>
        </div>
        <div className="flex gap-3">
          {currentIP && (
            <button
              onClick={addCurrentIP}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-medium"
            >
              + Add My IP ({currentIP})
            </button>
          )}
          <button
            onClick={() => setShowAddModal(true)}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            + Add IP Address
          </button>
        </div>
      </div>

      {/* Info Banner */}
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 p-6 rounded-xl">
        <div className="flex items-start gap-3">
          <div className="text-2xl">🔒</div>
          <div>
            <h3 className="font-semibold text-blue-900 mb-2">IP Whitelist Security</h3>
            <p className="text-sm text-blue-800 leading-relaxed">
              Only whitelisted IP addresses can make API requests to your account. This adds an extra layer of security 
              to prevent unauthorized access. Add your server IPs, office IPs, or any trusted IP addresses.
            </p>
            {currentIP && (
              <p className="text-sm text-blue-700 mt-2">
                <strong>Your current IP:</strong> {currentIP}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-2xl font-bold text-blue-600">{ips.length}</div>
          <div className="text-sm text-gray-600 mt-1">Total IPs</div>
        </div>
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="text-2xl font-bold text-green-600">
            {ips.filter(ip => ip.isActive).length}
          </div>
          <div className="text-sm text-gray-600 mt-1">Active IPs</div>
        </div>
        <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
          <div className="text-2xl font-bold text-gray-600">
            {ips.filter(ip => !ip.isActive).length}
          </div>
          <div className="text-sm text-gray-600 mt-1">Disabled IPs</div>
        </div>
      </div>

      {/* IP List */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                IP Address
              </th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Label
              </th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Added
              </th>
              <th className="px-6 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {ips.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                  No IP addresses whitelisted yet. Add your first IP to secure API access.
                </td>
              </tr>
            ) : (
              ips.map((ip) => (
                <tr key={ip.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <code className="px-2 py-1 bg-gray-100 rounded text-sm font-mono">
                        {ip.ipAddress}
                      </code>
                      {ip.ipAddress === currentIP && (
                        <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">
                          Current
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-600">
                    {ip.label || '-'}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                      ip.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {ip.isActive ? 'Active' : 'Disabled'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {new Date(ip.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => handleToggleIP(ip)}
                        className={`px-3 py-1 rounded text-sm font-medium ${
                          ip.isActive 
                            ? 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200' 
                            : 'bg-green-100 text-green-700 hover:bg-green-200'
                        }`}
                      >
                        {ip.isActive ? 'Disable' : 'Enable'}
                      </button>
                      <button
                        onClick={() => handleDeleteIP(ip)}
                        className="px-3 py-1 bg-red-100 text-red-700 rounded text-sm font-medium hover:bg-red-200"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Add IP Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-md shadow-2xl">
            <h2 className="text-2xl font-bold mb-6">Add IP to Whitelist</h2>
            <form onSubmit={handleAddIP} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  IP Address *
                </label>
                <input
                  type="text"
                  value={formData.ipAddress}
                  onChange={(e) => setFormData({ ...formData, ipAddress: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="192.168.1.1 or 10.0.0.0/24"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  Enter IPv4 address or CIDR notation (e.g., 192.168.1.0/24)
                </p>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Label (Optional)
                </label>
                <input
                  type="text"
                  value={formData.label}
                  onChange={(e) => setFormData({ ...formData, label: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="e.g., Production Server, Office Network"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-medium"
                >
                  Add to Whitelist
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setFormData({ ipAddress: '', label: '' });
                  }}
                  className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

interface KYCSubmission {
  id: string;
  firstName?: string;
  lastName?: string;
  dateOfBirth?: string;
  email?: string;
  phone?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  postalCode?: string;
  country?: string;
  idType?: string;
  idNumber?: string;
  panNumber?: string;
  aadharNumber?: string;
  kycStatus: string;
  submittedAt: string;
  rejectionReason?: string;
}

export default function SubUserKYC() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [uploading, setUploading] = useState<{ [key: string]: boolean }>({});
  const [uploadError, setUploadError] = useState<{ [key: string]: string }>({});
  const [kycData, setKycData] = useState<KYCSubmission | null>(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    email: '',
    phone: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postalCode: '',
    country: '',
    idType: 'aadhar',
    idNumber: '',
    panNumber: '',
    aadharNumber: '',
  });
  const [uploadedFiles, setUploadedFiles] = useState<{ [key: string]: string }>({
    idPhoto: '',
    panPhoto: '',
    aadharPhoto: '',
  });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'SUBUSER') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  useEffect(() => {
    if (session) {
      fetchKYC();
    }
  }, [session]);

  const fetchKYC = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/user/kyc');
      const data = await response.json();
      if (data.success && data.data) {
        setKycData(data.data);
        setFormData({
          firstName: data.data.firstName || '',
          lastName: data.data.lastName || '',
          dateOfBirth: data.data.dateOfBirth ? data.data.dateOfBirth.split('T')[0] : '',
          email: data.data.email || '',
          phone: data.data.phone || '',
          addressLine1: data.data.addressLine1 || '',
          addressLine2: data.data.addressLine2 || '',
          city: data.data.city || '',
          state: data.data.state || '',
          postalCode: data.data.postalCode || '',
          country: data.data.country || '',
          idType: data.data.idType || 'aadhar',
          idNumber: data.data.idNumber || '',
          panNumber: data.data.panNumber || '',
          aadharNumber: data.data.aadharNumber || '',
        });
      }
    } catch (error) {
      console.error('Failed to fetch KYC:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, fieldName: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(prev => ({ ...prev, [fieldName]: true }));
    setUploadError(prev => ({ ...prev, [fieldName]: '' }));

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/user/upload', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (response.ok) {
        setUploadedFiles(prev => ({ ...prev, [fieldName]: data.url }));
      } else {
        setUploadError(prev => ({ ...prev, [fieldName]: data.error || 'Upload failed' }));
      }
    } catch (error) {
      console.error('Upload error:', error);
      setUploadError(prev => ({ ...prev, [fieldName]: 'Upload failed. Please try again.' }));
    } finally {
      setUploading(prev => ({ ...prev, [fieldName]: false }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const response = await fetch('/api/user/kyc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        const data = await response.json();
        setKycData(data.data);
        alert('KYC submitted successfully for review');
      } else {
        alert('Failed to submit KYC');
      }
    } catch (error) {
      console.error('Error submitting KYC:', error);
      alert('Error submitting KYC');
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'expired':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-500">Loading KYC information...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">📋 KYC Verification</h1>
        <p className="text-gray-600 mt-2">Complete your Know Your Customer (KYC) verification to access payment services</p>
      </div>

      {kycData && (
        <div className={`p-4 rounded-lg ${getStatusColor(kycData.kycStatus)}`}>
          <div className="flex items-start justify-between">
            <div>
              <h3 className="font-semibold mb-1">Current Status: {kycData.kycStatus.toUpperCase()}</h3>
              {kycData.submittedAt && (
                <p className="text-sm opacity-75">Submitted on: {new Date(kycData.submittedAt).toLocaleDateString()}</p>
              )}
              {kycData.rejectionReason && (
                <p className="text-sm opacity-75 mt-2">Reason: {kycData.rejectionReason}</p>
              )}
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-md p-6">
        <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-4">
          {/* Personal Information */}
          <div className="col-span-2">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Personal Information</h2>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">First Name *</label>
            <input
              type="text"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="John"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Last Name *</label>
            <input
              type="text"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Doe"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Date of Birth *</label>
            <input
              type="date"
              name="dateOfBirth"
              value={formData.dateOfBirth}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email Address *</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="john@example.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number *</label>
            <input
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="+91 98765 43210"
            />
          </div>

          {/* Address Information */}
          <div className="col-span-2">
            <h2 className="text-lg font-semibold text-gray-900 mb-4 mt-6">Address Information</h2>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Address Line 1 *</label>
            <input
              type="text"
              name="addressLine1"
              value={formData.addressLine1}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="123 Main Street"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Address Line 2</label>
            <input
              type="text"
              name="addressLine2"
              value={formData.addressLine2}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Apartment, suite, etc."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">City *</label>
            <input
              type="text"
              name="city"
              value={formData.city}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="New York"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">State/Province *</label>
            <input
              type="text"
              name="state"
              value={formData.state}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="NY"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Postal Code *</label>
            <input
              type="text"
              name="postalCode"
              value={formData.postalCode}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="10001"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Country *</label>
            <input
              type="text"
              name="country"
              value={formData.country}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="United States"
            />
          </div>

          {/* Identity Information */}
          <div className="col-span-2">
            <h2 className="text-lg font-semibold text-gray-900 mb-4 mt-6">Identity Documents</h2>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">ID Type *</label>
            <select
              name="idType"
              value={formData.idType}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="aadhar">Aadhar</option>
              <option value="pan">PAN</option>
              <option value="passport">Passport</option>
              <option value="driving_license">Driving License</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">ID Number *</label>
            <input
              type="text"
              name="idNumber"
              value={formData.idNumber}
              onChange={handleChange}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="123456789012"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">PAN Number</label>
            <input
              type="text"
              name="panNumber"
              value={formData.panNumber}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="ABCDE1234F"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Aadhar Number</label>
            <input
              type="text"
              name="aadharNumber"
              value={formData.aadharNumber}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="123456789012"
            />
          </div>

          {/* Document Uploads */}
          <div className="col-span-2">
            <h2 className="text-lg font-semibold text-gray-900 mb-4 mt-6">Upload Document Photos (Max 250 KB)</h2>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">ID Photo *</label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleFileUpload(e, 'idPhoto')}
                disabled={uploading['idPhoto']}
                className="hidden"
                id="idPhoto"
              />
              <label htmlFor="idPhoto" className="cursor-pointer">
                <div className="text-4xl mb-2">📸</div>
                <p className="text-sm text-gray-600">
                  {uploading['idPhoto'] ? 'Uploading...' : 'Click to upload ID photo'}
                </p>
                <p className="text-xs text-gray-500 mt-1">PNG, JPG, WebP (max 250 KB)</p>
              </label>
              {uploadError['idPhoto'] && (
                <p className="text-red-500 text-xs mt-2">{uploadError['idPhoto']}</p>
              )}
              {uploadedFiles['idPhoto'] && (
                <p className="text-green-600 text-xs mt-2">✓ Uploaded successfully</p>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">PAN Photo</label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleFileUpload(e, 'panPhoto')}
                disabled={uploading['panPhoto']}
                className="hidden"
                id="panPhoto"
              />
              <label htmlFor="panPhoto" className="cursor-pointer">
                <div className="text-4xl mb-2">📸</div>
                <p className="text-sm text-gray-600">
                  {uploading['panPhoto'] ? 'Uploading...' : 'Click to upload PAN photo'}
                </p>
                <p className="text-xs text-gray-500 mt-1">PNG, JPG, WebP (max 250 KB)</p>
              </label>
              {uploadError['panPhoto'] && (
                <p className="text-red-500 text-xs mt-2">{uploadError['panPhoto']}</p>
              )}
              {uploadedFiles['panPhoto'] && (
                <p className="text-green-600 text-xs mt-2">✓ Uploaded successfully</p>
              )}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Aadhar Photo</label>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleFileUpload(e, 'aadharPhoto')}
                disabled={uploading['aadharPhoto']}
                className="hidden"
                id="aadharPhoto"
              />
              <label htmlFor="aadharPhoto" className="cursor-pointer">
                <div className="text-4xl mb-2">📸</div>
                <p className="text-sm text-gray-600">
                  {uploading['aadharPhoto'] ? 'Uploading...' : 'Click to upload Aadhar photo'}
                </p>
                <p className="text-xs text-gray-500 mt-1">PNG, JPG, WebP (max 250 KB)</p>
              </label>
              {uploadError['aadharPhoto'] && (
                <p className="text-red-500 text-xs mt-2">{uploadError['aadharPhoto']}</p>
              )}
              {uploadedFiles['aadharPhoto'] && (
                <p className="text-green-600 text-xs mt-2">✓ Uploaded successfully</p>
              )}
            </div>
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="col-span-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 font-medium mt-4"
          >
            {submitting ? 'Submitting...' : 'Submit KYC'}
          </button>
        </form>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h3 className="font-semibold text-blue-900 mb-2">Required Documents</h3>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Government-issued ID (Passport, Aadhar, or Driver's License)</li>
          <li>• Proof of Address (utility bill, bank statement)</li>
          <li>• PAN card (if applicable)</li>
          <li>• Clear photos of all documents</li>
        </ul>
      </div>
    </div>
  );
}

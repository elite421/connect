'use client';

import { useState, useEffect } from 'react';
import { formatINR } from '@/lib/money';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useGlobalToast } from '@/context/ToastContext';

interface SubuserStats {
  totalTransactions: number;
  totalAmount: number;
  successRate: number;
  totalBeneficiaries: number;
  pendingPayouts: number;
  servicesActive: number;
}

export default function SubuserDashboardPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const { showError } = useGlobalToast();
  const [timeRange, setTimeRange] = useState('30d');

  const [stats, setStats] = useState<SubuserStats>({
    totalTransactions: 0,
    totalAmount: 0,
    successRate: 0,
    totalBeneficiaries: 0,
    pendingPayouts: 0,
    servicesActive: 0,
  });

  const [recentTransactions, setRecentTransactions] = useState<Array<{
    id: string;
    type: string;
    amount: number;
    status: string;
    date: string;
  }>>([]);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
  }, [status, router]);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const analyticsRes = await fetch(`/api/subuser/analytics?range=${timeRange}`);
        const transactionsRes = await fetch('/api/subuser/transactions?limit=5');

        if (analyticsRes.ok) {
          const analyticsData = await analyticsRes.json();
          if (analyticsData.success && analyticsData.data) {
            setStats({
              totalTransactions: analyticsData.data.payments?.total || 0,
              totalAmount: analyticsData.data.revenue?.total || 0,
              successRate: parseFloat(analyticsData.data.payments?.successRate || '0'),
              totalBeneficiaries: analyticsData.data.beneficiaries?.total || 0,
              pendingPayouts: analyticsData.data.payments?.pending || 0,
              servicesActive: analyticsData.data.servicesActive || 0, // This might be missing in API too
            });
          }
        }

        if (transactionsRes.ok) {
          const transactionsData = await transactionsRes.json();
          if (transactionsData.success && Array.isArray(transactionsData.data)) {
            setRecentTransactions(transactionsData.data.slice(0, 5).map((txn: any) => ({
              id: txn.id,
              type: txn.type || txn.txType || 'PAYIN',
              amount: Number(txn.amount) || 0,
              status: txn.status || 'PENDING',
              date: txn.createdAt ? new Date(txn.createdAt).toLocaleDateString() : new Date().toLocaleDateString(),
            })));
          }
        }
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
        showError('Failed to load dashboard data');
      }
    };

    if (status === 'authenticated' && session) {
      fetchDashboardData();
    }
  }, [status, session, timeRange, showError]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Subuser Dashboard</h1>
        <p className="text-gray-600 mt-2">
          Welcome, {session?.user?.name}! Here's your performance overview.
        </p>
      </div>

      <div className="flex justify-end">
        <select
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value)}
          className="bg-white border border-gray-300 text-gray-700 py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
        >
          <option value="today">Today</option>
          <option value="7d">Last 7 Days</option>
          <option value="30d">Last 30 Days</option>
          <option value="all">All Time</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow-lg p-6 text-white">
          <h3 className="text-sm font-semibold opacity-80">Total Transactions</h3>
          <p className="text-3xl font-bold mt-2">{stats.totalTransactions}</p>
          <p className="text-xs mt-2 opacity-75">All time</p>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg shadow-lg p-6 text-white">
          <h3 className="text-sm font-semibold opacity-80">Total Amount Processed</h3>
          <p className="text-3xl font-bold mt-2">₹{(stats.totalAmount / 100000).toFixed(1)}L</p>
          <p className="text-xs mt-2 opacity-75">Cumulative</p>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg shadow-lg p-6 text-white">
          <h3 className="text-sm font-semibold opacity-80">Success Rate</h3>
          <p className="text-3xl font-bold mt-2">{stats.successRate}%</p>
          <p className="text-xs mt-2 opacity-75">Transaction success</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow p-4 border-l-4 border-yellow-500">
          <h4 className="text-sm font-semibold text-gray-700">Active Services</h4>
          <p className="text-2xl font-bold text-gray-900 mt-2">{stats.servicesActive}</p>
          <p className="text-xs text-gray-600 mt-1">Services assigned</p>
        </div>

        <div className="bg-white rounded-lg shadow p-4 border-l-4 border-orange-500">
          <h4 className="text-sm font-semibold text-gray-700">Beneficiaries</h4>
          <p className="text-2xl font-bold text-gray-900 mt-2">{stats.totalBeneficiaries}</p>
          <p className="text-xs text-gray-600 mt-1">Added accounts</p>
        </div>

        <div className="bg-white rounded-lg shadow p-4 border-l-4 border-red-500">
          <h4 className="text-sm font-semibold text-gray-700">Pending Payouts</h4>
          <p className="text-2xl font-bold text-gray-900 mt-2">{stats.pendingPayouts}</p>
          <p className="text-xs text-gray-600 mt-1">Waiting approval</p>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Transactions</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Type</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Amount</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                <th className="text-left py-3 px-4 font-semibold text-gray-700">Date</th>
                <th className="text-center py-3 px-4 font-semibold text-gray-700">Action</th>
              </tr>
            </thead>
            <tbody>
              {recentTransactions.map((txn) => (
                <tr key={txn.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4">
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${txn.type === 'PAYOUT'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-green-100 text-green-800'
                      }`}>
                      {txn.type}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-semibold text-gray-900">{formatINR(Number(txn.amount))}</td>
                  <td className="py-3 px-4">
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${txn.status === 'SUCCESS'
                        ? 'bg-green-100 text-green-800'
                        : txn.status === 'PENDING'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                      {txn.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-gray-700">{txn.date}</td>
                  <td className="py-3 px-4 text-center">
                    <button className="text-blue-600 hover:text-blue-800 text-sm font-semibold">
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-indigo-50 to-blue-50 border border-blue-200 rounded-lg p-6">
          <h3 className="text-lg font-bold text-indigo-900 mb-3">📊 Quick Actions</h3>
          <div className="space-y-2">
            <a href="/account/subuser/payout" className="block px-4 py-2 bg-white text-indigo-700 rounded-lg hover:bg-indigo-100 font-semibold text-sm transition-colors">
              → Initiate Payout
            </a>
            <a href="/account/subuser/payin" className="block px-4 py-2 bg-white text-indigo-700 rounded-lg hover:bg-indigo-100 font-semibold text-sm transition-colors">
              → Create PayIn
            </a>
            <a href="/account/subuser/beneficiaries" className="block px-4 py-2 bg-white text-indigo-700 rounded-lg hover:bg-indigo-100 font-semibold text-sm transition-colors">
              → Manage Beneficiaries
            </a>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-lg p-6">
          <h3 className="text-lg font-bold text-green-900 mb-3">✨ Insights</h3>
          <div className="space-y-3 text-sm text-green-800">
            <p>💡 Your success rate is excellent! Keep it up.</p>
            <p>📈 You've processed ₹{(stats.totalAmount / 100000).toFixed(1)}L this year.</p>
            <p>✅ All your beneficiaries are verified and ready to use.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

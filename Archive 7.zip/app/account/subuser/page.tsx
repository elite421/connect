import { redirect } from "next/navigation";

export default function SubUserPage() {
  // Redirect to the subuser dashboard instead of rendering content here
  // This allows child routes like /subuser/payout, /subuser/transactions to work properly
  redirect("/account/subuser/dashboard");
}

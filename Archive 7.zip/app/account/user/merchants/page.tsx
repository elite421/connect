'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useGlobalToast } from '@/context/ToastContext';

interface Merchant {
  id: string;
  merchantName: string;
  merchantKey: string;
  transactionMode: string;
  minAmount: number;
  maxAmount: number;
  dailyLimit: number | null;
  monthlyLimit: number | null;
  allowedIPs: string[];
  isActive: boolean;
  createdAt: string;
}

export default function MerchantsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showCredentialsModal, setShowCredentialsModal] = useState(false);
  const [credentials, setCredentials] = useState({ merchantKey: '', merchantSecret: '' });
  const [selectedMerchant, setSelectedMerchant] = useState<Merchant | null>(null);
  const [formData, setFormData] = useState({
    merchantName: '',
    transactionMode: 'both',
    minAmount: '100',
    maxAmount: '10000000',
    dailyLimit: '',
    monthlyLimit: '',
    allowedIPs: '',
  });

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if ((session?.user as any)?.role !== 'USER') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') fetchMerchants();
  }, [session, status]);

  const fetchMerchants = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/user/merchants');
      const data = await response.json();
      if (data.success) setMerchants(data.data);
    } catch (error) {
      console.error('Failed to fetch merchants:', error);
      toast.showError('Failed to load merchants');
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/user/merchants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          minAmount: parseFloat(formData.minAmount),
          maxAmount: parseFloat(formData.maxAmount),
          dailyLimit: formData.dailyLimit ? parseFloat(formData.dailyLimit) : null,
          monthlyLimit: formData.monthlyLimit ? parseFloat(formData.monthlyLimit) : null,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setCredentials({
          merchantKey: data.data.merchantKey,
          merchantSecret: data.data.merchantSecret
        });
        setShowCreateModal(false);
        setShowCredentialsModal(true);
        toast.showSuccess('Merchant created successfully!');
        resetForm();
        fetchMerchants();
      } else {
        toast.showError(data.error || 'Failed to create merchant');
      }
    } catch (error) {
      toast.showError('Failed to create merchant');
    }
  };

  const handleEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMerchant) return;

    try {
      const response = await fetch('/api/user/merchants', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedMerchant.id,
          ...formData,
          minAmount: parseFloat(formData.minAmount),
          maxAmount: parseFloat(formData.maxAmount),
          dailyLimit: formData.dailyLimit ? parseFloat(formData.dailyLimit) : null,
          monthlyLimit: formData.monthlyLimit ? parseFloat(formData.monthlyLimit) : null,
        }),
      });

      const data = await response.json();
      if (data.success) {
        toast.showSuccess('Merchant updated successfully!');
        setShowEditModal(false);
        resetForm();
        fetchMerchants();
      } else {
        toast.showError(data.error || 'Failed to update merchant');
      }
    } catch (error) {
      toast.showError('Failed to update merchant');
    }
  };

  const handleDelete = async (merchant: Merchant) => {
    if (!confirm(`Delete merchant "${merchant.merchantName}"?`)) return;

    try {
      const response = await fetch(`/api/user/merchants?id=${merchant.id}`, { method: 'DELETE' });
      const data = await response.json();
      if (data.success) {
        toast.showSuccess('Merchant deleted successfully');
        fetchMerchants();
      } else {
        toast.showError(data.error || 'Failed to delete merchant');
      }
    } catch (error) {
      toast.showError('Failed to delete merchant');
    }
  };

  const openEditModal = (merchant: Merchant) => {
    setSelectedMerchant(merchant);
    setFormData({
      merchantName: merchant.merchantName,
      transactionMode: merchant.transactionMode,
      minAmount: String(merchant.minAmount),
      maxAmount: String(merchant.maxAmount),
      dailyLimit: merchant.dailyLimit ? String(merchant.dailyLimit) : '',
      monthlyLimit: merchant.monthlyLimit ? String(merchant.monthlyLimit) : '',
      allowedIPs: merchant.allowedIPs?.join(', ') || '',
    });
    setShowEditModal(true);
  };

  const resetForm = () => {
    setFormData({
      merchantName: '',
      transactionMode: 'both',
      minAmount: '100',
      maxAmount: '10000000',
      dailyLimit: '',
      monthlyLimit: '',
      allowedIPs: '',
    });
    setSelectedMerchant(null);
  };

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <>

      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Merchant Configuration</h1>
            <p className="text-gray-600 mt-2">Manage your payment merchants and API credentials</p>
          </div>
          <button onClick={() => setShowCreateModal(true)} className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
            + Create Merchant
          </button>
        </div>

        <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 p-6 rounded-xl">
          <div className="flex items-start gap-3">
            <div className="text-2xl">🏪</div>
            <div>
              <h3 className="font-semibold text-purple-900 mb-2">Merchant Configuration</h3>
              <p className="text-sm text-purple-800">Configure merchants for PayIn and PayOut operations. Each merchant gets unique API credentials, IP restrictions, and transaction limits.</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{merchants.length}</div>
            <div className="text-sm text-gray-600">Total Merchants</div>
          </div>
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{merchants.filter(m => m.isActive).length}</div>
            <div className="text-sm text-gray-600">Active</div>
          </div>
          <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
            <div className="text-2xl font-bold text-gray-600">{merchants.filter(m => !m.isActive).length}</div>
            <div className="text-sm text-gray-600">Inactive</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {merchants.length === 0 ? (
            <div className="col-span-full bg-white p-12 rounded-lg border text-center text-gray-500">
              No merchants configured yet. Create your first merchant to start accepting payments.
            </div>
          ) : (
            merchants.map((merchant) => (
              <div key={merchant.id} className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{merchant.merchantName}</h3>
                    <code className="text-xs text-gray-500">{merchant.merchantKey}</code>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${merchant.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {merchant.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                  <div>
                    <span className="text-gray-500">Mode:</span>
                    <span className="ml-2 font-medium capitalize">{merchant.transactionMode}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Min:</span>
                    <span className="ml-2 font-medium">₹{(merchant.minAmount).toFixed(0)}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Max:</span>
                    <span className="ml-2 font-medium">₹{(merchant.maxAmount).toFixed(0)}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">IPs:</span>
                    <span className="ml-2 font-medium">{merchant.allowedIPs?.length || 0}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button onClick={() => openEditModal(merchant)} className="flex-1 px-3 py-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 text-sm font-medium">Edit</button>
                  <button onClick={() => handleDelete(merchant)} className="flex-1 px-3 py-2 bg-red-100 text-red-700 rounded hover:bg-red-200 text-sm font-medium">Delete</button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Credentials Modal */}
        {showCredentialsModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-8 w-full max-w-lg shadow-2xl">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-gray-900">Merchant Created!</h2>
                <p className="text-gray-600 mt-2">Save these credentials - you won't see the secret again!</p>
              </div>

              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <label className="block text-xs font-semibold text-gray-500 mb-2">MERCHANT KEY</label>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 text-sm bg-white px-3 py-2 rounded border font-mono">{credentials.merchantKey}</code>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(credentials.merchantKey);
                        toast.showInfo('Merchant key copied!');
                      }}
                      className="px-3 py-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
                    >
                      Copy
                    </button>
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <label className="block text-xs font-semibold text-gray-500 mb-2">MERCHANT SECRET</label>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 text-sm bg-white px-3 py-2 rounded border font-mono break-all">{credentials.merchantSecret}</code>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(credentials.merchantSecret);
                        toast.showInfo('Merchant secret copied!');
                      }}
                      className="px-3 py-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
                    >
                      Copy
                    </button>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-start gap-2">
                  <svg className="w-5 h-5 text-yellow-600 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  <p className="text-sm text-yellow-800">Store these credentials securely. The secret will not be shown again.</p>
                </div>
              </div>

              <button
                onClick={() => setShowCredentialsModal(false)}
                className="w-full mt-6 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 font-medium"
              >
                I've Saved My Credentials
              </button>
            </div>
          </div>
        )}

        {/* Create/Edit Modal */}
        {(showCreateModal || showEditModal) && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-8 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
              <h2 className="text-2xl font-bold mb-6">{showEditModal ? 'Edit Merchant' : 'Create Merchant'}</h2>
              <form onSubmit={showEditModal ? handleEdit : handleCreate} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Merchant Name *</label>
                  <input type="text" value={formData.merchantName} onChange={(e) => setFormData({ ...formData, merchantName: e.target.value })} className="w-full px-4 py-2 border rounded-lg" placeholder="My Payment Gateway" required />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Transaction Mode</label>
                  <select value={formData.transactionMode} onChange={(e) => setFormData({ ...formData, transactionMode: e.target.value })} className="w-full px-4 py-2 border rounded-lg">
                    <option value="both">Both (PayIn & PayOut)</option>
                    <option value="payin">PayIn Only</option>
                    <option value="payout">PayOut Only</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Min Amount (₹)</label>
                    <input type="number" value={formData.minAmount} onChange={(e) => setFormData({ ...formData, minAmount: e.target.value })} className="w-full px-4 py-2 border rounded-lg" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Max Amount (₹)</label>
                    <input type="number" value={formData.maxAmount} onChange={(e) => setFormData({ ...formData, maxAmount: e.target.value })} className="w-full px-4 py-2 border rounded-lg" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Daily Limit (₹)</label>
                    <input type="number" value={formData.dailyLimit} onChange={(e) => setFormData({ ...formData, dailyLimit: e.target.value })} className="w-full px-4 py-2 border rounded-lg" placeholder="Optional" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Monthly Limit (₹)</label>
                    <input type="number" value={formData.monthlyLimit} onChange={(e) => setFormData({ ...formData, monthlyLimit: e.target.value })} className="w-full px-4 py-2 border rounded-lg" placeholder="Optional" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Allowed IPs (comma-separated)</label>
                  <input type="text" value={formData.allowedIPs} onChange={(e) => setFormData({ ...formData, allowedIPs: e.target.value })} className="w-full px-4 py-2 border rounded-lg" placeholder="192.168.1.1, 10.0.0.1" />
                </div>
                <div className="flex gap-3 pt-4">
                  <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-medium">{showEditModal ? 'Update' : 'Create'}</button>
                  <button type="button" onClick={() => { setShowCreateModal(false); setShowEditModal(false); resetForm(); }} className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium">Cancel</button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { formatINR } from '@/lib/money';

interface PaymentTransaction {
  id: string;
  amount: number;
  utrNumber?: string;
  status: string;
  externalTransactionId?: string;
  gatewayName?: string;
  customerName?: string;
  customerEmail?: string;
  paymentMethod?: string;
  responseData?: any;
  createdAt: string;
}

export default function PaymentTransactionsPage() {
  const { data: session, status } = useSession();
  const [transactions, setTransactions] = useState<PaymentTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<"all" | "success" | "failed" | "pending">("all");

  useEffect(() => {
    if (status === "authenticated") {
      fetchTransactions();
    }
  }, [status, filter]);

  const fetchTransactions = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `/api/user/payin/transactions?status=${filter !== "all" ? filter : ""}`,
        { cache: "no-store" }
      );

      const data = await response.json();
      if (data.success) {
        setTransactions(data.transactions || []);
      } else {
        setError(data.error || "Failed to fetch transactions");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch transactions");
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case "success":
      case "completed":
        return "bg-green-100 text-green-800";
      case "failed":
        return "bg-red-100 text-red-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatAmount = (amount: number) => formatINR(Number(amount));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Payment Transactions</h1>
        <p className="text-gray-600 mt-2">View all your payment gateway transactions</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-4 border border-gray-200">
        <div className="flex gap-4 flex-wrap">
          {(["all", "success", "failed", "pending"] as const).map((status_filter) => (
            <button
              key={status_filter}
              onClick={() => setFilter(status_filter)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                filter === status_filter
                  ? "bg-blue-600 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              {status_filter.charAt(0).toUpperCase() + status_filter.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-white rounded-lg shadow border border-gray-200 overflow-hidden">
        {loading ? (
          <div className="p-8 text-center text-gray-600">Loading transactions...</div>
        ) : error ? (
          <div className="p-8 text-center text-red-600">{error}</div>
        ) : transactions.length === 0 ? (
          <div className="p-8 text-center text-gray-600">No transactions found</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">Transaction ID</th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">Amount</th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">UTR Number</th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">Status</th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">Gateway</th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">Date</th>
                  <th className="px-6 py-3 text-left font-semibold text-gray-700">Details</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx) => (
                  <tr key={tx.id} className="border-b border-gray-200 hover:bg-gray-50 transition">
                    <td className="px-6 py-3 font-mono text-xs">{tx.id.substring(0, 12)}...</td>
                    <td className="px-6 py-3 font-semibold">{formatAmount(tx.amount)}</td>
                    <td className="px-6 py-3 font-mono text-xs">{tx.utrNumber || "N/A"}</td>
                    <td className="px-6 py-3">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(tx.status)}`}>
                        {tx.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-6 py-3 text-sm">{tx.gatewayName || "N/A"}</td>
                    <td className="px-6 py-3 text-sm">
                      {new Date(tx.createdAt).toLocaleDateString()} {new Date(tx.createdAt).toLocaleTimeString()}
                    </td>
                    <td className="px-6 py-3">
                      <details className="cursor-pointer">
                        <summary className="text-blue-600 hover:text-blue-800 font-medium">View</summary>
                        <div className="mt-2 p-3 bg-gray-50 rounded border border-gray-200 text-xs">
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <span className="font-semibold">Customer:</span>
                              <div>{tx.customerName || "N/A"}</div>
                            </div>
                            <div>
                              <span className="font-semibold">Email:</span>
                              <div>{tx.customerEmail || "N/A"}</div>
                            </div>
                            <div>
                              <span className="font-semibold">Method:</span>
                              <div>{tx.paymentMethod || "N/A"}</div>
                            </div>
                            <div>
                              <span className="font-semibold">Gateway Ref:</span>
                              <div className="font-mono">{tx.externalTransactionId || "N/A"}</div>
                            </div>
                          </div>
                          {tx.responseData && (
                            <div className="mt-2 p-2 bg-white rounded border border-gray-200">
                              <span className="font-semibold block mb-1">Raw Response:</span>
                              <pre className="text-xs overflow-auto max-h-40">
                                {JSON.stringify(tx.responseData, null, 2)}
                              </pre>
                            </div>
                          )}
                        </div>
                      </details>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

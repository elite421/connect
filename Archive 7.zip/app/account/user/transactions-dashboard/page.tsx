"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { formatINR } from '@/lib/money';

interface WalletData {
  balance: number;
  currency: string;
  lastUpdated: string;
}

interface Transaction {
  id: string;
  amount: number;
  status: string;
  utrNumber?: string;
  gatewayName?: string;
  createdAt: string;
}

export default function TransactionsDashboardPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [wallet, setWallet] = useState<WalletData | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"overview" | "transactions">("overview");

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login");
    }
    if (status === "authenticated") {
      fetchData();
    }
  }, [status, router]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [walletRes, txRes] = await Promise.all([
        fetch("/api/user/wallet/transactions?limit=1", { cache: "no-store" }),
        fetch("/api/user/payin/transactions?limit=10", { cache: "no-store" }),
      ]);

      if (walletRes.ok) {
        const walletData = await walletRes.json();
        if (walletData.success && walletData.wallet) {
          setWallet({
            balance: Number(walletData.wallet.balance),
            currency: walletData.wallet.currency || "INR",
            lastUpdated: new Date().toISOString(),
          });
        }
      }

      if (txRes.ok) {
        const txData = await txRes.json();
        if (txData.success) {
          setTransactions(txData.transactions || []);
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load data");
    } finally {
      setLoading(false);
    }
  };

  const formatAmount = (amount: number) => formatINR(Number(amount));

  const getStatusBadge = (status: string) => {
    const baseClass = "px-3 py-1 rounded-full text-xs font-semibold";
    switch (status?.toLowerCase()) {
      case "success":
      case "completed":
        return <span className={`${baseClass} bg-green-100 text-green-800`}>✓ Success</span>;
      case "failed":
        return <span className={`${baseClass} bg-red-100 text-red-800`}>✕ Failed</span>;
      case "pending":
        return <span className={`${baseClass} bg-yellow-100 text-yellow-800`}>⏳ Pending</span>;
      default:
        return <span className={`${baseClass} bg-gray-100 text-gray-800`}>Unknown</span>;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col gap-2">
        <h1 className="text-4xl font-bold text-gray-900">Transactions & Wallet</h1>
        <p className="text-gray-600">Manage your payment transactions and wallet balance</p>
      </div>

      {/* Wallet Card */}
      {wallet && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-xl shadow-lg p-6">
            <div className="text-sm opacity-90 mb-2">Wallet Balance</div>
            <div className="text-4xl font-bold">
              {wallet.currency} {formatAmount(wallet.balance)}
            </div>
            <div className="text-xs opacity-75 mt-2">Updated just now</div>
          </div>

          <div className="bg-gradient-to-br from-green-500 to-green-600 text-white rounded-xl shadow-lg p-6">
            <div className="text-sm opacity-90 mb-2">Total Transactions</div>
            <div className="text-4xl font-bold">{transactions.length}</div>
            <div className="text-xs opacity-75 mt-2">This month</div>
          </div>

          <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white rounded-xl shadow-lg p-6">
            <div className="text-sm opacity-90 mb-2">Success Rate</div>
            <div className="text-4xl font-bold">
              {transactions.length > 0
                ? Math.round(
                    (transactions.filter((t) => t.status.toLowerCase() === "success").length /
                      transactions.length) *
                      100
                  )
                : 0}
              %
            </div>
            <div className="text-xs opacity-75 mt-2">Success transactions</div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <div className="flex space-x-8">
          <button
            onClick={() => setActiveTab("overview")}
            className={`py-3 px-2 border-b-2 font-semibold transition ${
              activeTab === "overview"
                ? "border-blue-600 text-blue-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab("transactions")}
            className={`py-3 px-2 border-b-2 font-semibold transition ${
              activeTab === "transactions"
                ? "border-blue-600 text-blue-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            All Transactions
          </button>
        </div>
      </div>

      {/* Content */}
      {loading ? (
        <div className="text-center py-12 text-gray-600">Loading...</div>
      ) : error ? (
        <div className="text-center py-12 text-red-600">{error}</div>
      ) : (
        <>
          {activeTab === "overview" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold mb-4">Recent Transactions</h2>
                {transactions.length === 0 ? (
                  <div className="text-center py-12 bg-gray-50 rounded-lg text-gray-600">
                    No transactions yet
                  </div>
                ) : (
                  <div className="space-y-3">
                    {transactions.slice(0, 5).map((tx) => (
                      <div
                        key={tx.id}
                        className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200 hover:shadow-md transition"
                      >
                        <div className="flex-1">
                          <div className="font-semibold text-gray-900">
                            {tx.gatewayName || "Payment Gateway"}
                          </div>
                          <div className="text-sm text-gray-600">
                            {tx.utrNumber ? `UTR: ${tx.utrNumber}` : `ID: ${tx.id.substring(0, 12)}...`}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-lg text-gray-900">
                            {formatAmount(tx.amount)}
                          </div>
                          {getStatusBadge(tx.status)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === "transactions" && (
            <div>
              <h2 className="text-2xl font-bold mb-4">All Transactions</h2>
              {transactions.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg text-gray-600">
                  No transactions found
                </div>
              ) : (
                <div className="overflow-x-auto rounded-lg border border-gray-200">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-6 py-3 text-left font-semibold text-gray-700">
                          Transaction ID
                        </th>
                        <th className="px-6 py-3 text-left font-semibold text-gray-700">Amount</th>
                        <th className="px-6 py-3 text-left font-semibold text-gray-700">
                          UTR/Reference
                        </th>
                        <th className="px-6 py-3 text-left font-semibold text-gray-700">Gateway</th>
                        <th className="px-6 py-3 text-left font-semibold text-gray-700">Status</th>
                        <th className="px-6 py-3 text-left font-semibold text-gray-700">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {transactions.map((tx) => (
                        <tr key={tx.id} className="hover:bg-gray-50 transition">
                          <td className="px-6 py-3 font-mono text-xs text-gray-600">
                            {tx.id.substring(0, 12)}...
                          </td>
                          <td className="px-6 py-3 font-semibold">{formatAmount(tx.amount)}</td>
                          <td className="px-6 py-3 font-mono text-xs">{tx.utrNumber || "N/A"}</td>
                          <td className="px-6 py-3 text-sm">{tx.gatewayName || "N/A"}</td>
                          <td className="px-6 py-3">{getStatusBadge(tx.status)}</td>
                          <td className="px-6 py-3 text-sm text-gray-600">
                            {new Date(tx.createdAt).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </>
      )}

      {/* Quick Actions */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="font-semibold text-blue-900 mb-3">Quick Links</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <a
            href="/account/wallet"
            className="p-3 bg-white rounded-lg border border-blue-200 text-center hover:bg-blue-50 transition font-medium text-sm"
          >
            View Wallet
          </a>
          <a
            href="/account/user/payin"
            className="p-3 bg-white rounded-lg border border-blue-200 text-center hover:bg-blue-50 transition font-medium text-sm"
          >
            Make Payment
          </a>
          <a
            href="/account/user/payment-transactions"
            className="p-3 bg-white rounded-lg border border-blue-200 text-center hover:bg-blue-50 transition font-medium text-sm"
          >
            Transaction History
          </a>
          <a
            href="/account/connectingAPI"
            className="p-3 bg-white rounded-lg border border-blue-200 text-center hover:bg-blue-50 transition font-medium text-sm"
          >
            Connect APIs
          </a>
        </div>
      </div>
    </div>
  );
}

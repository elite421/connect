import { redirect } from "next/navigation";

export default function UserPage() {
  // Redirect to the user dashboard instead of rendering content here
  // This allows child routes like /user/payout, /user/transactions to work properly
  redirect("/account/user/dashboard");
}

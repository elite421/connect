'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { FormBuilder, type FormField } from '@/components/form-builder';

interface SubUser {
  id: string;
  username: string;
  name: string;
  email: string;
  phone?: string;
  isActive: boolean;
  isApiEnabled: boolean;
  createdAt: string;
  _count: { payments: number };
}

export default function SubUsersPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [subUsers, setSubUsers] = useState<SubUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [selectedSubUser, setSelectedSubUser] = useState<SubUser | null>(null);
  const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'USER') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchSubUsers = async (offset: number = 0) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/user/subusers?offset=${offset}&limit=50`);
      const data = await response.json();
      if (data.success) {
        setSubUsers(data.data);
        setPagination(data.pagination);
      }
    } catch (error) {
      console.error('Failed to fetch subusers:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubUsers();
  }, []);

  const columns: Column<SubUser>[] = [
    { key: 'username', label: 'Username' },
    { key: 'name', label: 'Name' },
    { key: 'email', label: 'Email' },
    { key: 'phone', label: 'Phone' },
    { key: 'phone', label: 'Phone' },
    { key: 'isActive', label: 'Status', render: (active) => active ? '🟢 Active' : '🔴 Inactive' },
    { key: 'isApiEnabled', label: 'API Access', render: (enabled) => enabled ? '✅ Enabled' : '❌ Disabled' },
    { key: '_count', label: 'Payments', render: (count) => count.payments },
  ];

  const formFields: FormField[] = [
    { name: 'username', label: 'Username', type: 'text', required: true },
    { name: 'name', label: 'Full Name', type: 'text', required: true },
    { name: 'email', label: 'Email', type: 'email', required: true },
    { name: 'password', label: 'Password', type: 'password', required: modalMode === 'create' },
    { name: 'password', label: 'Password', type: 'password', required: modalMode === 'create' },
    { name: 'phone', label: 'Phone Number', type: 'text' },
    { name: 'isApiEnabled', label: 'Enable API Access', type: 'checkbox', placeholder: 'Allow subuser to use API keys' },
  ];

  const handleCreateSubUser = () => {
    setModalMode('create');
    setSelectedSubUser(null);
    setIsModalOpen(true);
  };

  const handleEditSubUser = (subUser: SubUser) => {
    setModalMode('edit');
    setSelectedSubUser(subUser);
    setIsModalOpen(true);
  };

  const handleSubmit = async (data: Record<string, any>) => {
    try {
      const method = modalMode === 'create' ? 'POST' : 'PATCH';
      const body = modalMode === 'create' ? data : { subUserId: selectedSubUser?.id, ...data };

      const response = await fetch('/api/user/subusers', {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (response.ok) {
        setIsModalOpen(false);
        fetchSubUsers(pagination.offset);
      }
    } catch (error) {
      console.error('Failed to submit:', error);
    }
  };

  const handleDelete = async (subUser: SubUser) => {
    if (!confirm(`Delete subuser ${subUser.username}?`)) return;
    try {
      const response = await fetch(`/api/user/subusers?subUserId=${subUser.id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        fetchSubUsers(pagination.offset);
      }
    } catch (error) {
      console.error('Failed to delete:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Manage SubUsers</h1>
          <p className="text-gray-600 mt-2">Create and manage your team members</p>
        </div>
        <button
          onClick={handleCreateSubUser}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
        >
          + Add SubUser
        </button>
      </div>

      <DataTable<SubUser>
        data={subUsers}
        columns={columns}
        loading={loading}
        pagination={{
          ...pagination,
          onPageChange: (offset) => fetchSubUsers(offset),
        }}
        actions={[
          { label: 'Edit', onClick: handleEditSubUser, variant: 'primary' },
          { label: 'Delete', onClick: handleDelete, variant: 'danger' },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={modalMode === 'create' ? 'Add SubUser' : `Edit ${selectedSubUser?.name}`}
        size="md"
      >
        <FormBuilder
          fields={formFields}
          onSubmit={handleSubmit}
          initialValues={selectedSubUser || {}}
          submitLabel={modalMode === 'create' ? 'Create SubUser' : 'Update SubUser'}
        />
      </Modal>
    </div>
  );
}

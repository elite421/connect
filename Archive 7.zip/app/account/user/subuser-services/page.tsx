'use client';

import { useEffect, useState } from 'react';
import { formatINR } from '@/lib/money';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { useGlobalToast } from '@/context/ToastContext';
import { useConfirm } from '@/hooks/useConfirm';

interface SubUserService {
  id: string;
  subUserId: string;
  serviceId: string;
  isActive: boolean;
  transactionCharge: number;
  transactionChargeType: string;
  service: {
    id: string;
    code: string;
    name: string;
  };
  subUser?: {
    id: string;
    username: string;
    name: string;
  };
}

interface SubUser {
  id: string;
  username: string;
  name: string;
  email: string;
}

interface Service {
  id: string;
  code: string;
  name: string;
}

export default function SubUserServicesPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const { confirm, ConfirmProvider } = useConfirm();

  const [subUserServices, setSubUserServices] = useState<SubUserService[]>([]);
  const [subUsers, setSubUsers] = useState<SubUser[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedSubUserService, setSelectedSubUserService] = useState<SubUserService | null>(null);
  const [filterSubUser, setFilterSubUser] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [chargeForm, setChargeForm] = useState({
    transactionCharge: 0,
    transactionChargeType: 'fixed',
  });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    const userRole = (session?.user as { role?: string })?.role;
    if (userRole !== 'USER') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchSubUserServices = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/user-services?limit=1000');
      const data = await response.json();
      if (data.success) {
        setSubUserServices(data.data);
      } else {
        toast.showError('Failed to fetch subuser services');
      }
    } catch (error) {
      console.error('Failed to fetch subuser services:', error);
      toast.showError('Error fetching subuser services');
    } finally {
      setLoading(false);
    }
  };

  const fetchSubUsers = async () => {
    try {
      const response = await fetch('/api/user/subusers?limit=1000');
      const data = await response.json();
      if (data.success) {
        setSubUsers(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch subusers:', error);
    }
  };

  const fetchServices = async () => {
    try {
      const response = await fetch('/api/admin/services?limit=1000');
      const data = await response.json();
      if (data.success) {
        setServices(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch services:', error);
    }
  };

  useEffect(() => {
    fetchSubUserServices();
    fetchSubUsers();
    fetchServices();
  }, []);

  const columns: Column<SubUserService>[] = [
    {
      key: 'subUser.username',
      label: 'SubUser',
      render: (_, item) => item.subUser?.username || 'Unknown',
    },
    { key: 'service.name', label: 'Service' },
    {
      key: 'transactionCharge',
      label: 'Charge',
      render: (charge, item) =>
        item.transactionChargeType === 'percentage'
          ? `${charge}%`
          : formatINR(Number(charge)),
    },
    {
      key: 'isActive',
      label: 'Status',
      render: (isActive) => (
        <span
          className={`px-3 py-1 rounded-full text-xs font-semibold ${isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}
        >
          {isActive ? 'Active' : 'Inactive'}
        </span>
      ),
    },
  ];

  const filteredServices = filterSubUser
    ? subUserServices.filter((us) => us.subUserId === filterSubUser)
    : subUserServices;

  const handleEditCharge = (subUserService: SubUserService) => {
    setSelectedSubUserService(subUserService);
    setChargeForm({
      transactionCharge: subUserService.transactionCharge || 0,
      transactionChargeType: subUserService.transactionChargeType || 'fixed',
    });
    setIsModalOpen(true);
  };

  const handleSaveCharges = async () => {
    if (!selectedSubUserService) {
      toast.showError('Service not found');
      return;
    }

    setSubmitting(true);
    try {
      const response = await fetch('/api/user/subuser-services', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subUserServiceId: selectedSubUserService.id,
          transactionCharge: parseFloat(String(chargeForm.transactionCharge)) || 0,
          transactionChargeType: chargeForm.transactionChargeType,
        }),
      });

      if (response.ok) {
        toast.showSuccess('Service charges updated successfully');
        setIsModalOpen(false);
        fetchSubUserServices();
      } else {
        const errorData = await response.json().catch(() => ({}));
        toast.showError(errorData.error || 'Failed to update charges');
      }
    } catch (error) {
      console.error('Failed to save charges:', error);
      toast.showError('Error saving charges');
    } finally {
      setSubmitting(false);
    }
  };

  const handleToggleStatus = async (subUserService: SubUserService) => {
    try {
      const response = await fetch('/api/user/subuser-services', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subUserServiceId: subUserService.id,
          isActive: !subUserService.isActive,
        }),
      });

      if (response.ok) {
        toast.showSuccess(
          subUserService.isActive ? 'Service deactivated' : 'Service activated'
        );
        fetchSubUserServices();
      } else {
        toast.showError('Failed to update service status');
      }
    } catch (error) {
      toast.showError('Error updating service status');
    }
  };

  const handleRemoveService = async (subUserService: SubUserService) => {
    const confirmed = await confirm({
      title: 'Remove Service',
      message: `Remove ${subUserService.service.name} from ${subUserService.subUser?.name}?`,
      confirmText: 'Remove',
      cancelText: 'Cancel',
      isDangerous: true,
    });

    if (!confirmed) return;

    try {
      const response = await fetch(
        `/api/user/subuser-services?subUserServiceId=${subUserService.id}`,
        { method: 'DELETE' }
      );

      if (response.ok) {
        toast.showSuccess('Service removed successfully');
        fetchSubUserServices();
      } else {
        toast.showError('Failed to remove service');
      }
    } catch (error) {
      toast.showError('Error removing service');
    }
  };

  return (
    <div className="space-y-6">

      <ConfirmProvider />

      <div>
        <h1 className="text-3xl font-bold text-gray-900">SubUser Services</h1>
        <p className="text-gray-600 mt-2">Manage services assigned to subusers and set transaction charges</p>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Filter by SubUser
        </label>
        <select
          value={filterSubUser}
          onChange={(e) => setFilterSubUser(e.target.value)}
          className="w-full md:w-64 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="">All SubUsers</option>
          {subUsers.map((subUser) => (
            <option key={subUser.id} value={subUser.id}>
              {subUser.name} ({subUser.username})
            </option>
          ))}
        </select>
      </div>

      <DataTable<SubUserService>
        data={filteredServices}
        columns={columns}
        loading={loading}
        actions={[
          {
            label: 'Edit Charges',
            onClick: handleEditCharge,
            variant: 'primary',
          },
          {
            label: 'Toggle Status',
            onClick: handleToggleStatus,
            variant: 'secondary',
          },
          {
            label: 'Remove',
            onClick: handleRemoveService,
            variant: 'danger',
          },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`Set Charges: ${selectedSubUserService?.subUser?.name} - ${selectedSubUserService?.service.name}`}
        size="md"
      >
        {selectedSubUserService && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Transaction Charge
              </label>
              <input
                type="number"
                step="0.01"
                value={chargeForm.transactionCharge}
                onChange={(e) =>
                  setChargeForm({
                    ...chargeForm,
                    transactionCharge: parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="0.00"
              />
              <p className="mt-1 text-xs text-gray-500">
                Amount deducted per transaction
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Charge Type
              </label>
              <select
                value={chargeForm.transactionChargeType}
                onChange={(e) =>
                  setChargeForm({
                    ...chargeForm,
                    transactionChargeType: e.target.value,
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="fixed">Fixed Amount (₹)</option>
                <option value="percentage">Percentage (%)</option>
              </select>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-800">
                <strong>Example:</strong> If you set {chargeForm.transactionChargeType === 'fixed' ? formatINR(chargeForm.transactionCharge) : `${chargeForm.transactionCharge}%`} as{' '}
                {chargeForm.transactionChargeType === 'fixed' ? 'fixed charge' : 'percentage'}
                {chargeForm.transactionChargeType === 'percentage' && ', on a ₹1000 transaction it would be ' + formatINR(1000 * chargeForm.transactionCharge / 100)}
              </p>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={() => setIsModalOpen(false)}
                disabled={submitting}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveCharges}
                disabled={submitting}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {submitting ? 'Saving...' : 'Save Charges'}
              </button>
            </div>
          </div>
        )}
      </Modal>

      <div className="bg-blue-50 border border-blue-200 p-6 rounded-lg">
        <h3 className="font-semibold text-blue-900 mb-2">💡 Transaction Charges</h3>
        <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
          <li>Set transaction charges for each subuser per service</li>
          <li>Fixed charges: Same amount for all transactions</li>
          <li>Percentage charges: Calculated based on transaction amount</li>
          <li>Charges are deducted from the subuser's wallet on successful transactions</li>
        </ul>
      </div>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { formatINR } from '@/lib/money';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { ServiceToggle } from '@/components/service-toggle';
import { Modal } from '@/components/modal';
import { useGlobalToast } from '@/context/ToastContext';

interface Service {
  id: string;
  code: string;
  name: string;
  description?: string;
  isActive: boolean;
}

interface UserService {
  id: string | null;
  serviceId: string;
  isActive: boolean;
  transactionCharge?: number;
  transactionChargeType?: string;
  service: Service;
}

interface UserApi {
  id: string;
  name: string;
  key: string;
  isActive: boolean;
  isDefault: boolean;
}

export default function ServicesPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const [services, setServices] = useState<UserService[]>([]);
  const [apis, setApis] = useState<UserApi[]>([]);
  const [loading, setLoading] = useState(true);
  const [kycStatus, setKycStatus] = useState<string | null>(null);
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [showServiceModal, setShowServiceModal] = useState(false);
  const [selectedService, setSelectedService] = useState<UserService | null>(null);
  const [walletForm, setWalletForm] = useState({ accountHolderName: '', bankName: '', linkedServices: [] as string[] });
  const [creatingWallet, setCreatingWallet] = useState(false);
  const [serviceForm, setServiceForm] = useState({ apiId: '', transactionCharge: 0, transactionChargeType: 'fixed' });
  const [savingService, setSavingService] = useState(false);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'USER') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') {
      checkKYCStatus();
    }
  }, [session, status]);

  const checkKYCStatus = async () => {
    try {
      const response = await fetch('/api/user/kyc-status');
      const data = await response.json();
      setKycStatus(data.status || 'pending');
    } catch (error) {
      console.error('Failed to check KYC status:', error);
      setKycStatus('pending');
    }
  };

  const fetchServices = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/user/services');
      const data = await response.json();
      if (data.success) {
        setServices(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch services:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchApis = async () => {
    try {
      const response = await fetch('/api/user/apis');
      const data = await response.json();
      if (data.success) {
        setApis(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch APIs:', error);
    }
  };

  useEffect(() => {
    if (session && status === 'authenticated') {
      fetchServices();
      fetchApis();
    }
  }, [session, status]);

  const handleOpenServiceConfig = (service: UserService) => {
    setSelectedService(service);
    setServiceForm({
      apiId: '',
      transactionCharge: service.transactionCharge || 0,
      transactionChargeType: service.transactionChargeType || 'fixed',
    });
    setShowServiceModal(true);
  };

  const handleSaveServiceConfig = async () => {
    if (!selectedService?.id) {
      toast.showError('Service not found');
      return;
    }

    setSavingService(true);
    try {
      const response = await fetch('/api/user/services', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userServiceId: selectedService.id,
          transactionCharge: parseFloat(String(serviceForm.transactionCharge)) || 0,
          transactionChargeType: serviceForm.transactionChargeType,
        }),
      });

      if (response.ok) {
        toast.showSuccess('Service configuration updated successfully');
        setShowServiceModal(false);
        fetchServices();
      } else {
        const errorData = await response.json().catch(() => ({}));
        toast.showError(errorData.error || 'Failed to update service');
      }
    } catch (error) {
      console.error('Failed to save service config:', error);
      toast.showError('Error saving service configuration');
    } finally {
      setSavingService(false);
    }
  };

  const handleToggleService = async (serviceId: string, newIsActive: boolean) => {
    try {
      const userService = services.find((s) => s.serviceId === serviceId);
      const isWalletService = userService?.service.code === 'WALLET';

      if (!userService?.id) {
        const response = await fetch('/api/user/services', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            serviceId,
            isActive: newIsActive,
          }),
        });

        if (response.ok) {
          await fetchServices();
          toast.showSuccess('Service activated successfully');
          if (isWalletService && newIsActive) {
            setShowWalletModal(true);
          }
        } else {
          const errorData = await response.json().catch(() => ({}));
          console.error('Failed to activate service:', errorData);
          toast.showError(errorData.error || 'Failed to activate service');
        }
      } else {
        const response = await fetch('/api/user/services', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userServiceId: userService.id,
            isActive: newIsActive,
          }),
        });

        if (response.ok) {
          await fetchServices();
          toast.showSuccess(newIsActive ? 'Service activated' : 'Service deactivated');
          if (isWalletService && newIsActive) {
            setShowWalletModal(true);
          }
        } else {
          const errorData = await response.json().catch(() => ({}));
          console.error('Failed to toggle service:', errorData);
          toast.showError(errorData.error || 'Failed to toggle service');
        }
      }
    } catch (error) {
      console.error('Failed to toggle service:', error);
      toast.showError('Error toggling service');
    }
  };

  const handleCreateWallet = async () => {
    if (!walletForm.accountHolderName.trim()) {
      alert('Please enter account holder name');
      return;
    }

    setCreatingWallet(true);
    try {
      const response = await fetch('/api/user/virtual-accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accountHolderName: walletForm.accountHolderName,
          bankName: walletForm.bankName || 'Virtual Bank',
          linkedServices: walletForm.linkedServices,
        }),
      });

      if (response.ok) {
        setShowWalletModal(false);
        setWalletForm({ accountHolderName: '', bankName: '', linkedServices: [] });
        fetchServices();
        alert('Virtual account created successfully!');
      } else {
        alert('Failed to create virtual account');
      }
    } catch (error) {
      console.error('Failed to create wallet:', error);
      alert('Error creating virtual account');
    } finally {
      setCreatingWallet(false);
    }
  };

  const serviceIcons: Record<string, string> = {
    WALLET: '💰',
    NEFT: '🏦',
    IMPS: '⚡',
    UPI: '📱',
    CREDIT_CARD: '💳',
    BILL_PAY: '📄',
    REPORTS: '📊',
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-gray-600">Loading services...</div>
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  return (
    <div className="space-y-6">


      {kycStatus !== 'approved' && (
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <h3 className="font-semibold text-yellow-800">KYC Verification Required</h3>
          <p className="text-yellow-700 text-sm mt-1">
            {kycStatus === 'pending'
              ? 'Your KYC submission is pending approval. You can activate services once approved.'
              : 'Please complete your KYC verification to access this service.'}
          </p>
        </div>
      )}

      <div>
        <h1 className="text-3xl font-bold text-gray-900">Payment Services</h1>
        <p className="text-gray-600 mt-2">Activate and manage payment services for your business</p>
      </div>

      {services.length === 0 ? (
        <div className="flex items-center justify-center p-12 bg-gray-50 rounded-lg border border-gray-200">
          <div className="text-center text-gray-600">
            <div className="text-6xl mb-4">📦</div>
            <p className="text-lg font-semibold mb-2">No services available</p>
            <p className="text-sm">Contact support to add services to your account</p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <ServiceToggle
              key={service.serviceId}
              id={service.serviceId}
              name={service.service.name}
              description={service.service.description}
              isActive={service.isActive}
              icon={serviceIcons[service.service.code] || '⚙️'}
              onToggle={handleToggleService}
              onConfigure={() => handleOpenServiceConfig(service)}
              showConfig={true}
            />
          ))}
        </div>
      )}

      {showWalletModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96 shadow-lg">
            <h2 className="text-2xl font-bold mb-4">Create Virtual Account</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Account Holder Name</label>
                <input
                  type="text"
                  value={walletForm.accountHolderName}
                  onChange={(e) => setWalletForm({ ...walletForm, accountHolderName: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-3 py-2 border"
                  placeholder="Enter name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Bank Name</label>
                <input
                  type="text"
                  value={walletForm.bankName}
                  onChange={(e) => setWalletForm({ ...walletForm, bankName: e.target.value })}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 px-3 py-2 border"
                  placeholder="Virtual Bank"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Link Services</label>
                <div className="mt-2 space-y-2">
                  {services
                    .filter((s) => s.service.code !== 'WALLET')
                    .map((service) => (
                      <label key={service.serviceId} className="flex items-center">
                        <input
                          type="checkbox"
                          checked={walletForm.linkedServices.includes(service.service.code)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setWalletForm({
                                ...walletForm,
                                linkedServices: [...walletForm.linkedServices, service.service.code],
                              });
                            } else {
                              setWalletForm({
                                ...walletForm,
                                linkedServices: walletForm.linkedServices.filter((code) => code !== service.service.code),
                              });
                            }
                          }}
                          className="rounded"
                        />
                        <span className="ml-2 text-sm">{service.service.name}</span>
                      </label>
                    ))}
                </div>
              </div>
              <div className="flex gap-2 pt-4">
                <button
                  onClick={handleCreateWallet}
                  disabled={creatingWallet}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {creatingWallet ? 'Creating...' : 'Create'}
                </button>
                <button
                  onClick={() => setShowWalletModal(false)}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-md hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <Modal
        isOpen={showServiceModal}
        onClose={() => setShowServiceModal(false)}
        title={`Configure Service: ${selectedService?.service.name}`}
        size="md"
      >
        {selectedService && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Transaction Charge
              </label>
              <input
                type="number"
                step="0.01"
                value={serviceForm.transactionCharge}
                onChange={(e) =>
                  setServiceForm({
                    ...serviceForm,
                    transactionCharge: parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="0.00"
              />
              <p className="mt-1 text-xs text-gray-500">
                Charge applied to each transaction for this service
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Charge Type
              </label>
              <select
                value={serviceForm.transactionChargeType}
                onChange={(e) =>
                  setServiceForm({
                    ...serviceForm,
                    transactionChargeType: e.target.value,
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="fixed">Fixed Amount (₹)</option>
                <option value="percentage">Percentage (%)</option>
              </select>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-800">
                <strong>Example:</strong> If you set {serviceForm.transactionChargeType === 'fixed' ? formatINR(serviceForm.transactionCharge) : `${serviceForm.transactionCharge}%`} as{' '}
                {serviceForm.transactionChargeType === 'fixed' ? 'fixed charge' : 'percentage'}
                {serviceForm.transactionChargeType === 'percentage' && ', on a ₹1000 transaction it would be ' + formatINR(1000 * serviceForm.transactionCharge / 100)}
              </p>
            </div>

            <div className="flex gap-3 pt-4">
              <button
                onClick={() => setShowServiceModal(false)}
                disabled={savingService}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveServiceConfig}
                disabled={savingService}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                {savingService ? 'Saving...' : 'Save Configuration'}
              </button>
            </div>
          </div>
        )}
      </Modal>

      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 p-6 rounded-xl shadow-sm">
        <div className="flex items-start gap-3">
          <div className="text-2xl">💡</div>
          <div>
            <h3 className="font-semibold text-blue-900 mb-2">Service Information</h3>
            <p className="text-sm text-blue-800 leading-relaxed">
              Enable services that you want to offer to your subusers. Once activated, you can assign them permissions to use these services. The Wallet service allows you to create virtual accounts for fund management.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

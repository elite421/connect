'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { formatINR } from '@/lib/money';

interface Transaction {
  id: string;
  type: 'payin' | 'payout';
  amount: number;
  status: string;
  paymentMethod?: string;
  transferMode?: string;
  customerName?: string;
  beneficiaryName?: string;
  utrNumber?: string;
  createdAt: string;
  responseData?: any;
}

export default function TransactionsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ type: 'all', status: 'all', dateFrom: '', dateTo: '' });
  const [stats, setStats] = useState({ totalPayin: 0, totalPayout: 0, successRate: 0 });
  const [walletBalance, setWalletBalance] = useState<string | null>(null);

  useEffect(() => {
    if (status === 'loading') return;
    if (status === 'unauthenticated') router.push('/login');
    if (status === 'authenticated' && (session?.user as any)?.role !== 'USER') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') fetchTransactions();
  }, [session, status]);

  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const [payinRes, payoutRes, walletRes] = await Promise.all([
        fetch('/api/user/payin'),
        fetch('/api/user/payout'),
        fetch('/api/user/wallet/transactions?limit=1')
      ]);

      const payinData = await payinRes.json();
      const payoutData = await payoutRes.json();
      const walletData = await walletRes.json();

      if (walletData.success && walletData.wallet) {
        setWalletBalance(walletData.wallet.balanceDisplay);
      }

      const allTransactions: Transaction[] = [
        ...(payinData.data || []).map((t: any) => ({ ...t, type: 'payin' as const })),
        ...(payoutData.data || []).map((t: any) => ({ ...t, type: 'payout' as const })),
      ].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

      setTransactions(allTransactions);

      const totalPayin = allTransactions.filter(t => t.type === 'payin').reduce((sum, t) => sum + Number(t.amount), 0);
      const totalPayout = allTransactions.filter(t => t.type === 'payout').reduce((sum, t) => sum + Number(t.amount), 0);
      const successful = allTransactions.filter(t => t.status === 'success').length;
      const successRate = allTransactions.length > 0 ? (successful / allTransactions.length) * 100 : 0;

      setStats({ totalPayin, totalPayout, successRate });
    } catch (error) {
      console.error('Failed to fetch transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredTransactions = transactions.filter(t => {
    if (filter.type !== 'all' && t.type !== filter.type) return false;
    if (filter.status !== 'all' && t.status !== filter.status) return false;
    if (filter.dateFrom && new Date(t.createdAt) < new Date(filter.dateFrom)) return false;
    if (filter.dateTo && new Date(t.createdAt) > new Date(filter.dateTo + 'T23:59:59')) return false;
    return true;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'processing': return 'bg-blue-100 text-blue-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Transaction History</h1>
          <p className="text-gray-600 mt-2">View and manage all PayIn and PayOut transactions</p>
        </div>
        {walletBalance && (
          <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
            <div className="text-sm text-gray-500 mb-1">Wallet Balance</div>
            <div className="text-2xl font-bold text-gray-900">{walletBalance}</div>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="text-2xl font-bold text-green-600">{formatINR(stats.totalPayin)}</div>
          <div className="text-sm text-gray-600">Total PayIn</div>
        </div>
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-2xl font-bold text-blue-600">{formatINR(stats.totalPayout)}</div>
          <div className="text-sm text-gray-600">Total PayOut</div>
        </div>
        <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
          <div className="text-2xl font-bold text-purple-600">{transactions.length}</div>
          <div className="text-sm text-gray-600">Total Transactions</div>
        </div>
        <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
          <div className="text-2xl font-bold text-orange-600">{stats.successRate.toFixed(1)}%</div>
          <div className="text-sm text-gray-600">Success Rate</div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg border border-gray-200 flex flex-wrap gap-4 items-end">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
          <select value={filter.type} onChange={(e) => setFilter({ ...filter, type: e.target.value })} className="px-3 py-2 border rounded-lg">
            <option value="all">All Types</option>
            <option value="payin">PayIn</option>
            <option value="payout">PayOut</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
          <select value={filter.status} onChange={(e) => setFilter({ ...filter, status: e.target.value })} className="px-3 py-2 border rounded-lg">
            <option value="all">All Status</option>
            <option value="success">Success</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="failed">Failed</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">From Date</label>
          <input type="date" value={filter.dateFrom} onChange={(e) => setFilter({ ...filter, dateFrom: e.target.value })} className="px-3 py-2 border rounded-lg" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">To Date</label>
          <input type="date" value={filter.dateTo} onChange={(e) => setFilter({ ...filter, dateTo: e.target.value })} className="px-3 py-2 border rounded-lg" />
        </div>
        <button onClick={() => setFilter({ type: 'all', status: 'all', dateFrom: '', dateTo: '' })} className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">
          Clear Filters
        </button>
      </div>

      {/* Transaction Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Type</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Details</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Amount</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Charges</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Method</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">UTR</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredTransactions.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-4 py-12 text-center text-gray-500">
                  No transactions found matching your filters.
                </td>
              </tr>
            ) : (
              filteredTransactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm">
                    <div>{new Date(tx.createdAt).toLocaleDateString()}</div>
                    <div className="text-xs text-gray-500">{new Date(tx.createdAt).toLocaleTimeString()}</div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${tx.type === 'payin' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
                      {tx.type === 'payin' ? 'PayIn' : 'PayOut'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm">
                    <div className="font-medium">{tx.customerName || tx.beneficiaryName || 'N/A'}</div>
                    <div className="text-xs text-gray-500">{tx.id.slice(0, 12)}...</div>
                  </td>
                  <td className="px-4 py-3 font-semibold">
                    <span className={tx.type === 'payin' ? 'text-green-600' : 'text-blue-600'}>
                      {tx.type === 'payin' ? '+' : '-'}{formatINR(Number(tx.amount))}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-red-600">
                    {(() => {
                      // Prefer unified rupees chargeInfo; fall back to chargeAmount if present
                      const charge = (tx.responseData?.chargeInfo?.totalCharge != null)
                        ? Number(tx.responseData.chargeInfo.totalCharge)
                        : (tx.responseData?.chargeAmount != null ? Number(tx.responseData.chargeAmount) : null);
                      return charge != null && Number(charge) > 0
                        ? <span className="text-red-600">-{formatINR(Number(charge))}</span>
                        : <span className="text-gray-400">-</span>;
                    })()}
                  </td>
                  <td className="px-4 py-3 text-sm uppercase">
                    {tx.paymentMethod || tx.transferMode || 'N/A'}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(tx.status)}`}>
                      {tx.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm font-mono">
                    {tx.utrNumber || '-'}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="text-sm text-gray-500 text-center">
        Showing {filteredTransactions.length} of {transactions.length} transactions
      </div>
    </div>
  );
}

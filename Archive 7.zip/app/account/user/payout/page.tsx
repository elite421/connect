'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { useGlobalToast } from '@/context/ToastContext';
import { formatINR } from '@/lib/money';

interface PayOutTransaction {
  id: string;
  amount: number;
  currency: string;
  beneficiaryName: string;
  beneficiaryAccount: string;
  transferMode: string;
  utrNumber: string | null;
  status: string;
  createdAt: string;
  priorityUsed: number | null;
  responseData?: {
    chargeInfo?: {
      userCharge?: number;
      schemeCharge?: number;
      totalCharge?: number;
      gstAmount?: number;
      totalDebit?: string;
      amountToApi?: number;
    };
  };
}

interface Beneficiary {
  id: string;
  accountName: string;
  accountNumber: string;
  bankName: string;
  ifscCode: string | null;
  upiId: string | null;
  beneficiaryType: string;
}

interface WalletData {
  id: string;
  balance: string;
  userId: string;
}

export default function PayOutPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const [transactions, setTransactions] = useState<PayOutTransaction[]>([]);
  const [beneficiaries, setBeneficiaries] = useState<Beneficiary[]>([]);
  const [wallet, setWallet] = useState<WalletData | null>(null);
  const [loading, setLoading] = useState(true);
  const [kycStatus, setKycStatus] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [transactionCharge, setTransactionCharge] = useState<number>(0);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [useExisting, setUseExisting] = useState(true);
  const [formData, setFormData] = useState({
    amount: '',
    beneficiaryId: '',
    beneficiaryName: '',
    beneficiaryAccount: '',
    beneficiaryIfsc: '',
    beneficiaryVpa: '',
    transferMode: 'imps',
  });
  // IP Whitelist states
  const [showIpModal, setShowIpModal] = useState(false);
  const [ipList, setIpList] = useState<any[]>([]);
  const [newIpAddress, setNewIpAddress] = useState('');
  const [ipDescription, setIpDescription] = useState('');
  const [loadingIps, setLoadingIps] = useState(false);
  const [submittingIp, setSubmittingIp] = useState(false);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'USER') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') {
      checkKYCStatus();
    }
  }, [session, status]);

  const checkKYCStatus = async () => {
    try {
      const response = await fetch('/api/user/kyc-status');
      const data = await response.json();
      setKycStatus(data.status || 'pending');
    } catch (error) {
      console.error('Failed to check KYC status:', error);
      setKycStatus('pending');
    }
  };

  useEffect(() => {
    if (session && status === 'authenticated') {
      fetchTransactions();
    }
  }, [session, status]);

  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/user/payout');
      const data = await response.json();
      if (data.success) {
        setTransactions(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch payout transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchBeneficiaries = async () => {
    try {
      const response = await fetch('/api/user/beneficiaries');
      const data = await response.json();
      if (data.success) {
        setBeneficiaries(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch beneficiaries:', error);
    }
  };

  const fetchWallet = async () => {
    try {
      const response = await fetch('/api/user/wallet');
      const data = await response.json();
      if (data.success) {
        setWallet(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch wallet:', error);
    }
  };

  const fetchTransactionCharge = async () => {
    try {
      const response = await fetch('/api/user/kyc-status');
      const data = await response.json();
      if (data.data?.user) {
        setTransactionCharge(data.data.user.transactionCharge ? Number(data.data.user.transactionCharge) : 0);
      }
    } catch (error) {
      console.error('Failed to fetch transaction charge:', error);
    }
  };

  const handleOpenModal = () => {
    fetchBeneficiaries();
    fetchWallet();
    fetchTransactionCharge();
    setShowCreateModal(true);
  };

  const handleCreatePayout = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payoutData: any = {
        amount: parseInt(formData.amount),
        transferMode: formData.transferMode,
      };

      if (useExisting && formData.beneficiaryId) {
        const beneficiary = beneficiaries.find(b => b.id === formData.beneficiaryId);
        if (!beneficiary) {
          toast.showWarning('Please select a valid beneficiary');
          return;
        }

        if (formData.transferMode === 'upi') {
          if (!beneficiary.upiId || beneficiary.upiId.trim() === '') {
            toast.showWarning('Selected beneficiary does not have a valid UPI ID for UPI transfers');
            return;
          }
        } else {
          if (!beneficiary.accountNumber || beneficiary.accountNumber.trim() === '' ||
            !beneficiary.ifscCode || beneficiary.ifscCode.trim() === '') {
            toast.showWarning('Selected beneficiary does not have account number or IFSC code.');
            return;
          }
        }

        payoutData.beneficiaryName = beneficiary.accountName;
        payoutData.beneficiaryAccount = beneficiary.accountNumber;
        payoutData.beneficiaryIfsc = beneficiary.ifscCode;
        payoutData.beneficiaryVpa = beneficiary.upiId;
      } else {
        payoutData.beneficiaryName = formData.beneficiaryName;
        payoutData.beneficiaryAccount = formData.beneficiaryAccount;
        payoutData.beneficiaryIfsc = formData.beneficiaryIfsc;
        payoutData.beneficiaryVpa = formData.beneficiaryVpa;
      }

      setSubmitting(true);
      toast.showInfo('Processing payout... Please wait');
      const response = await fetch('/api/user/payout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payoutData),
      });

      const data = await response.json();
      if (data.success) {
        setShowCreateModal(false);
        setFormData({
          amount: '',
          beneficiaryId: '',
          beneficiaryName: '',
          beneficiaryAccount: '',
          beneficiaryIfsc: '',
          beneficiaryVpa: '',
          transferMode: 'imps',
        });
        setUseExisting(true);
        fetchTransactions();
        const gr = data.gatewayResponse || {};
        const status = gr.status || 'processing';
        const utr = gr.utrNumber || '-';
        if (status === 'success') {
          toast.showSuccess(`Payout successful! UTR: ${utr}`);
        } else if (data.refunded) {
          toast.showError(`Payout failed. Amount refunded to wallet.`);
        } else {
          toast.showInfo(`Payout ${status}. UTR: ${utr}`);
        }
      } else {
        toast.showError(data.error || 'Failed to create payout');
      }
    } catch (error) {
      console.error('Failed to create payout:', error);
      toast.showError('Error creating payout');
    } finally {
      setSubmitting(false);
    }
  };

  // IP Whitelist functions
  const fetchIpWhitelist = async () => {
    setLoadingIps(true);
    try {
      const response = await fetch('/api/user/ip-whitelist');
      const data = await response.json();
      if (data.success) {
        setIpList(data.data || []);
      }
    } catch (error) {
      console.error('Failed to fetch IP whitelist:', error);
    } finally {
      setLoadingIps(false);
    }
  };

  const submitIpRequest = async () => {
    if (!newIpAddress.trim()) {
      toast.showError('Please enter an IP address');
      return;
    }

    // Simple IP validation
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (!ipRegex.test(newIpAddress.trim())) {
      toast.showError('Please enter a valid IP address (e.g., 192.168.1.1)');
      return;
    }

    setSubmittingIp(true);
    try {
      const response = await fetch('/api/user/ip-whitelist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ipAddress: newIpAddress.trim(),
          description: ipDescription.trim() || 'Payout API access',
        }),
      });

      const data = await response.json();
      if (data.success) {
        toast.showSuccess('IP whitelist request submitted successfully');
        setNewIpAddress('');
        setIpDescription('');
        fetchIpWhitelist();
      } else {
        toast.showError(data.error || 'Failed to submit IP request');
      }
    } catch (error) {
      console.error('Failed to submit IP request:', error);
      toast.showError('Error submitting IP request');
    } finally {
      setSubmittingIp(false);
    }
  };

  const columns: Column<PayOutTransaction>[] = [
    {
      key: 'createdAt',
      label: 'Date',
      render: (_, tx) => {
        try {
          const date = new Date(tx.createdAt);
          return isNaN(date.getTime()) ? 'Invalid Date' : date.toLocaleDateString();
        } catch {
          return 'Invalid Date';
        }
      },
    },
    {
      key: 'beneficiaryName',
      label: 'Beneficiary',
      render: (_, tx) => (
        <div>
          <div className="font-medium">{tx.beneficiaryName}</div>
          <div className="text-sm text-gray-600">{tx.beneficiaryAccount}</div>
        </div>
      ),
    },
    {
      key: 'amount',
      label: 'Amount',
      render: (_, tx) => (
        <div>
          <div className="font-semibold">{formatINR(Number(tx.amount))}</div>
        </div>
      ),
    },
    {
      key: 'id',
      label: 'Charge',
      render: (_, tx) => {
        const chargeInfo = tx.responseData?.chargeInfo;
        const totalCharge = chargeInfo?.totalCharge || 0;
        return (
          <div className="text-sm">
            <span className="text-orange-600 font-medium">{formatINR(Number(totalCharge))}</span>
          </div>
        );
      },
    },
    {
      key: 'currency',
      label: 'Total Debit',
      render: (_, tx) => {
        const chargeInfo = tx.responseData?.chargeInfo;
        const totalDebit = chargeInfo?.totalDebit != null ? Number(chargeInfo.totalDebit) : Number(tx.amount);
        return (
          <div className="text-sm">
            <span className="text-purple-600 font-semibold">{formatINR(totalDebit)}</span>
          </div>
        );
      },
    },
    {
      key: 'transferMode',
      label: 'Mode',
      render: (_, tx) => (
        <span className="px-2 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 uppercase">
          {tx.transferMode}
        </span>
      ),
    },
    {
      key: 'status',
      label: 'Status',
      render: (_, tx) => {
        const statusColors: Record<string, string> = {
          pending: 'bg-yellow-100 text-yellow-800',
          processing: 'bg-blue-100 text-blue-800',
          success: 'bg-green-100 text-green-800',
          failed: 'bg-red-100 text-red-800',
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${statusColors[tx.status] || 'bg-gray-100 text-gray-800'}`}>
            {tx.status}
          </span>
        );
      },
    },
    {
      key: 'utrNumber',
      label: 'UTR',
      render: (_, tx) => tx.utrNumber || '-',
    },
  ];

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-gray-600">Loading payouts...</div>
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">PayOut Management</h1>
          <p className="text-gray-600 mt-2">Manage and track all payout transactions</p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => {
              setShowIpModal(true);
              fetchIpWhitelist();
            }}
            className="px-6 py-2 rounded-lg transition-colors font-medium bg-gray-600 text-white hover:bg-gray-700 flex items-center gap-2"
          >
            🔒 IP Whitelisting
          </button>
          <button
            onClick={handleOpenModal}
            className="px-6 py-2 rounded-lg transition-colors font-medium bg-blue-600 text-white hover:bg-blue-700"
          >
            + Create PayOut
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-2xl font-bold text-blue-600">{transactions.length}</div>
          <div className="text-sm text-gray-600 mt-1">Total Payouts</div>
        </div>
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="text-2xl font-bold text-green-600">
            {transactions.filter(t => t.status === 'success').length}
          </div>
          <div className="text-sm text-gray-600 mt-1">Successful</div>
        </div>
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="text-2xl font-bold text-yellow-600">
            {transactions.filter(t => t.status === 'pending' || t.status === 'processing').length}
          </div>
          <div className="text-sm text-gray-600 mt-1">Pending</div>
        </div>
        <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
          <div className="text-2xl font-bold text-purple-600">
            {formatINR(transactions.reduce((sum, t) => sum + Number(t.amount), 0))}
          </div>
          <div className="text-sm text-gray-600 mt-1">Total Amount</div>
        </div>
      </div>

      <DataTable<PayOutTransaction>
        data={transactions}
        columns={columns}
        loading={loading}
      />

      {/* Create PayOut Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-md shadow-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-4">Create PayOut</h2>

            {wallet && (
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg mb-4">
                <div className="text-sm text-blue-700">
                  <div className="font-semibold">Wallet Balance: {formatINR(Number(wallet.balance))}</div>
                  {transactionCharge > 0 && (
                    <div className="text-xs mt-1">Transaction Charge: {formatINR(transactionCharge)}</div>
                  )}
                </div>
              </div>
            )}

            <form onSubmit={handleCreatePayout} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Amount (₹)
                </label>
                <input
                  type="number"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="1000"
                  required
                  min="1"
                />
                {formData.amount && (
                  <div className="mt-2 p-2 bg-gray-50 rounded text-sm">
                    <div className="flex justify-between text-gray-700">
                      <span>Amount:</span>
                      <span>{formatINR(Number(formData.amount))}</span>
                    </div>
                    {transactionCharge > 0 && (
                      <div className="flex justify-between text-gray-700">
                        <span>Charge:</span>
                        <span>{formatINR(transactionCharge)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-gray-900 font-semibold border-t border-gray-200 pt-2 mt-2">
                      <span>Total Debit:</span>
                      <span>{formatINR(Number(formData.amount) + transactionCharge)}</span>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Beneficiary</label>
                <div className="flex gap-2 mb-3">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      checked={useExisting}
                      onChange={() => setUseExisting(true)}
                      className="w-4 h-4"
                    />
                    <span className="text-sm text-gray-700">Use Existing</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      checked={!useExisting}
                      onChange={() => setUseExisting(false)}
                      className="w-4 h-4"
                    />
                    <span className="text-sm text-gray-700">Add New</span>
                  </label>
                </div>

                {useExisting ? (
                  beneficiaries.length > 0 ? (
                    <select
                      value={formData.beneficiaryId}
                      onChange={(e) => setFormData({ ...formData, beneficiaryId: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value="">Select a beneficiary</option>
                      {beneficiaries.map(b => (
                        <option key={b.id} value={b.id}>
                          {b.accountName} ({b.beneficiaryType === 'upi' ? b.upiId : b.accountNumber})
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded text-sm text-yellow-700">
                      No saved beneficiaries. Please add a new one.
                    </div>
                  )
                ) : (
                  <div className="space-y-3">
                    <input
                      type="text"
                      placeholder="Beneficiary Name"
                      value={formData.beneficiaryName}
                      onChange={(e) => setFormData({ ...formData, beneficiaryName: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  Transfer Mode
                </label>
                <select
                  value={formData.transferMode}
                  onChange={(e) => setFormData({ ...formData, transferMode: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="imps">IMPS</option>
                  <option value="neft">NEFT</option>
                  <option value="upi">UPI</option>
                </select>
              </div>

              {!useExisting && (formData.transferMode === 'upi' ? (
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    VPA Address
                  </label>
                  <input
                    type="text"
                    value={formData.beneficiaryVpa}
                    onChange={(e) => setFormData({ ...formData, beneficiaryVpa: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    placeholder="user@upi"
                    required
                  />
                </div>
              ) : (
                <>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Account Number
                    </label>
                    <input
                      type="text"
                      value={formData.beneficiaryAccount}
                      onChange={(e) => setFormData({ ...formData, beneficiaryAccount: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      placeholder="1234567890"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      IFSC Code
                    </label>
                    <input
                      type="text"
                      value={formData.beneficiaryIfsc}
                      onChange={(e) => setFormData({ ...formData, beneficiaryIfsc: e.target.value })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      placeholder="SBIN0001234"
                      required
                    />
                  </div>
                </>
              ))}

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-medium"
                >
                  Create PayOut
                </button>
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* IP Whitelist Modal */}
      {showIpModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">🔒 IP Whitelisting</h2>
              <button
                onClick={() => setShowIpModal(false)}
                className="text-gray-500 hover:text-gray-700 text-2xl"
              >
                ×
              </button>
            </div>

            <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg mb-6">
              <p className="text-sm text-blue-800">
                <strong>Note:</strong> Only API requests from whitelisted IP addresses will be processed.
                Add your server IP addresses to ensure your payout API calls work correctly.
              </p>
            </div>

            {/* Add New IP Form */}
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <h3 className="font-semibold text-gray-900 mb-3">Request New IP</h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">IP Address</label>
                  <input
                    type="text"
                    value={newIpAddress}
                    onChange={(e) => setNewIpAddress(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., 192.168.1.100"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description (optional)</label>
                  <input
                    type="text"
                    value={ipDescription}
                    onChange={(e) => setIpDescription(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    placeholder="e.g., Production Server"
                  />
                </div>
                <button
                  onClick={submitIpRequest}
                  disabled={submittingIp}
                  className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 font-medium disabled:bg-gray-400"
                >
                  {submittingIp ? 'Submitting...' : '+ Request IP Whitelist'}
                </button>
              </div>
            </div>

            {/* Existing IPs List */}
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">Whitelisted IPs</h3>
              {loadingIps ? (
                <div className="text-center py-4 text-gray-500">Loading...</div>
              ) : ipList.length === 0 ? (
                <div className="text-center py-4 text-gray-500 bg-gray-50 rounded-lg">
                  No IPs whitelisted yet
                </div>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {ipList.map((ip: any) => (
                    <div key={ip.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <div>
                        <div className="font-mono font-medium">{ip.ipAddress || ip.cidr}</div>
                        <div className="text-sm text-gray-500">{ip.description || 'No description'}</div>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${ip.status === 'active' || ip.status === 'approved'
                        ? 'bg-green-100 text-green-800'
                        : ip.status === 'pending'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-gray-100 text-gray-800'
                        }`}>
                        {ip.status || 'Active'}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="mt-6">
              <button
                onClick={() => setShowIpModal(false)}
                className="w-full bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

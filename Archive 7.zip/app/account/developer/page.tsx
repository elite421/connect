"use client";
import { useMemo } from "react";

export default function DeveloperToolsPage() {
  const examples = useMemo(() => {
    const creds = `POST /api/user-integrations
Content-Type: application/json

{
  "code": "provider-x",
  "baseUrl": "https://api.provider-x.com",
  "apiKey": "secret"
}`;
    const call = `POST /api/integration/{code}/call
Authorization: Bearer <jwt>
Idempotency-Key: <uuid>
Content-Type: application/json

{
  "payload": { "phone": "+919999999999" }
}`;
    return { creds, call };
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Developer Tools</h1>
      <div className="bg-white border rounded-xl p-6 shadow-sm space-y-6">
        <div>
          <h2 className="text-xl font-semibold mb-2">Save Credentials</h2>
          <pre className="bg-gray-900 text-gray-100 p-4 rounded-md text-sm overflow-x-auto whitespace-pre-wrap">{examples.creds}</pre>
        </div>
        <div>
          <h2 className="text-xl font-semibold mb-2">Call Integration</h2>
          <pre className="bg-gray-900 text-gray-100 p-4 rounded-md text-sm overflow-x-auto whitespace-pre-wrap">{examples.call}</pre>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="rounded-xl bg-green-100 text-green-700 px-4 py-2 font-semibold">JWT required</div>
          <div className="rounded-xl bg-green-100 text-green-700 px-4 py-2 font-semibold">Idempotent keys supported</div>
          <div className="rounded-xl bg-green-100 text-green-700 px-4 py-2 font-semibold">Wallet debits on success</div>
        </div>
      </div>
    </div>
  );
}

'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function DashboardPage() {
  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    if (status === 'loading') return;

    if (status === 'unauthenticated') {
      router.push('/login');
      return;
    }

    const role = (session?.user as any)?.role;

    if (role === 'ADMIN') {
      router.push('/account/admin/dashboard');
    } else if (role === 'USER') {
      router.push('/account/user/dashboard');
    } else if (role === 'SUBUSER') {
      router.push('/account/subuser/dashboard');
    } else {
      router.push('/login');
    }
  }, [session, status, router]);

  return (
    <div className="flex items-center justify-center h-screen">
      <div className="text-lg text-gray-600">Redirecting...</div>
    </div>
  );
}

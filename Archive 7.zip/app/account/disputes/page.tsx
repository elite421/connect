'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useGlobalToast } from '@/context/ToastContext';

interface Dispute {
    id: string;
    userId: string;
    user?: {
        name: string;
        email: string;
    };
    transactionId: string | null;
    type: string;
    status: string;
    description: string;
    adminComment: string | null;
    createdAt: string;
    updatedAt: string;
}

export default function DisputesPage() {
    const { data: session, status } = useSession();
    const toast = useGlobalToast();
    const [disputes, setDisputes] = useState<Dispute[]>([]);
    const [loading, setLoading] = useState(true);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [showManageModal, setShowManageModal] = useState(false);
    const [selectedDispute, setSelectedDispute] = useState<Dispute | null>(null);

    // Filter state
    const [filterStatus, setFilterStatus] = useState('ALL');

    // Create Form State
    const [createForm, setCreateForm] = useState({
        type: 'PAYOUT_ISSUE',
        transactionId: '',
        description: ''
    });

    // Manage Form State (Admin)
    const [manageForm, setManageForm] = useState({
        status: '',
        adminComment: ''
    });

    const isAdmin = (session?.user as any)?.role === 'ADMIN';

    useEffect(() => {
        if (status === 'authenticated') {
            fetchDisputes();
        }
    }, [status]);

    const fetchDisputes = async () => {
        setLoading(true);
        try {
            const res = await fetch('/api/disputes');
            const data = await res.json();
            if (data.success) {
                setDisputes(data.data);
            } else {
                toast.showError('Failed to fetch disputes');
            }
        } catch (err) {
            console.error(err);
            toast.showError('Error loading disputes');
        } finally {
            setLoading(false);
        }
    };

    const handleCreateSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            const res = await fetch('/api/disputes', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(createForm)
            });
            const data = await res.json();
            if (data.success) {
                toast.showSuccess('Dispute raised successfully');
                setShowCreateModal(false);
                setCreateForm({ type: 'PAYOUT_ISSUE', transactionId: '', description: '' });
                fetchDisputes();
            } else {
                toast.showError(data.error);
            }
        } catch (err) {
            toast.showError('Failed to create dispute');
        }
    };

    const handleManageSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!selectedDispute) return;

        try {
            const res = await fetch('/api/admin/disputes', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: selectedDispute.id,
                    status: manageForm.status,
                    adminComment: manageForm.adminComment
                })
            });
            const data = await res.json();
            if (data.success) {
                toast.showSuccess('Dispute updated');
                setShowManageModal(false);
                setSelectedDispute(null);
                fetchDisputes();
            } else {
                toast.showError(data.error);
            }
        } catch (err) {
            toast.showError('Failed to update dispute');
        }
    };

    const openManageModal = (dispute: Dispute) => {
        setSelectedDispute(dispute);
        setManageForm({
            status: dispute.status,
            adminComment: dispute.adminComment || ''
        });
        setShowManageModal(true);
    };

    const filteredDisputes = disputes.filter(d =>
        filterStatus === 'ALL' ? true : d.status === filterStatus
    );

    const getStatusColor = (s: string) => {
        switch (s) {
            case 'OPEN': return 'bg-yellow-100 text-yellow-800 border border-yellow-200';
            case 'RESOLVED': return 'bg-green-100 text-green-800 border border-green-200';
            case 'REJECTED': return 'bg-red-100 text-red-800 border border-red-200';
            default: return 'bg-gray-100 text-gray-800 border border-gray-200';
        }
    };

    const getStatusIcon = (s: string) => {
        switch (s) {
            case 'OPEN': return '⏳';
            case 'RESOLVED': return '✅';
            case 'REJECTED': return '❌';
            default: return '❓';
        }
    };

    if (status === 'loading') return <div className="p-8 text-center">Loading...</div>;

    return (
        <div className="p-6 space-y-6 max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">🚨 Dispute Center</h1>
                    <p className="text-gray-600">
                        {isAdmin
                            ? 'Manage and resolve user disputes'
                            : 'View status of your disputes or raise a new one'}
                    </p>
                </div>
                <button
                    onClick={() => setShowCreateModal(true)}
                    className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 font-medium flex items-center gap-2"
                >
                    <span>+ Raise New Dispute</span>
                </button>
            </div>

            {/* Stats/Filters */}
            <div className="flex gap-2 overflow-x-auto pb-2">
                {['ALL', 'OPEN', 'RESOLVED', 'REJECTED'].map((st) => (
                    <button
                        key={st}
                        onClick={() => setFilterStatus(st)}
                        className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${filterStatus === st
                            ? 'bg-gray-800 text-white'
                            : 'bg-white border text-gray-600 hover:bg-gray-50'
                            }`}
                    >
                        {st}
                    </button>
                ))}
            </div>

            {/* List */}
            <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
                {loading ? (
                    <div className="p-8 text-center text-gray-500">Loading disputes...</div>
                ) : filteredDisputes.length === 0 ? (
                    <div className="p-12 text-center">
                        <div className="text-4xl mb-3">🧐</div>
                        <h3 className="text-lg font-medium text-gray-900">No disputes found</h3>
                        <p className="text-gray-500">
                            {filterStatus === 'ALL'
                                ? "You don't have any raised disputes."
                                : `No disputes found with status ${filterStatus}`}
                        </p>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-gray-50 border-b">
                                <tr>
                                    <th className="px-6 py-3 font-semibold text-gray-700">Type / ID</th>
                                    {isAdmin && <th className="px-6 py-3 font-semibold text-gray-700">User</th>}
                                    <th className="px-6 py-3 font-semibold text-gray-700">Description</th>
                                    <th className="px-6 py-3 font-semibold text-gray-700">Status</th>
                                    <th className="px-6 py-3 font-semibold text-gray-700">Admin Comment</th>
                                    <th className="px-6 py-3 font-semibold text-gray-700">Date</th>
                                    {isAdmin && <th className="px-6 py-3 font-semibold text-gray-700">Actions</th>}
                                </tr>
                            </thead>
                            <tbody className="divide-y">
                                {filteredDisputes.map((d) => (
                                    <tr key={d.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4">
                                            <div className="font-medium text-gray-900">{d.type}</div>
                                            <div className="text-xs text-gray-500 font-mono">{d.transactionId ? `Tx: ${d.transactionId}` : d.id.slice(0, 8)}</div>
                                        </td>
                                        {isAdmin && (
                                            <td className="px-6 py-4">
                                                <div className="font-medium">{d.user?.name || 'Unknown'}</div>
                                                <div className="text-xs text-gray-500">{d.user?.email}</div>
                                            </td>
                                        )}
                                        <td className="px-6 py-4 max-w-xs truncate" title={d.description}>
                                            {d.description}
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={`px-2 py-1 rounded-full text-xs font-semibold flex items-center gap-1 w-fit ${getStatusColor(d.status)}`}>
                                                <span>{getStatusIcon(d.status)}</span>
                                                {d.status}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 text-gray-500 italic max-w-xs truncate">
                                            {d.adminComment || '-'}
                                        </td>
                                        <td className="px-6 py-4 text-gray-500 whitespace-nowrap">
                                            {new Date(d.createdAt).toLocaleDateString()}
                                        </td>
                                        {isAdmin && (
                                            <td className="px-6 py-4">
                                                <button
                                                    onClick={() => openManageModal(d)}
                                                    className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded hover:bg-indigo-100 font-medium"
                                                >
                                                    Manage
                                                </button>
                                            </td>
                                        )}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {/* Create Modal */}
            {showCreateModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
                        <div className="p-4 border-b flex justify-between items-center bg-gray-50">
                            <h3 className="font-bold text-lg">Raise Dispute</h3>
                            <button onClick={() => setShowCreateModal(false)} className="text-gray-400 hover:text-gray-600">×</button>
                        </div>
                        <form onSubmit={handleCreateSubmit} className="p-4 space-y-4">
                            <div>
                                <label className="block text-sm font-medium mb-1">Issue Type</label>
                                <select
                                    value={createForm.type}
                                    onChange={(e) => setCreateForm({ ...createForm, type: e.target.value })}
                                    className="w-full px-3 py-2 border rounded-lg"
                                >
                                    <option value="PAYOUT_ISSUE">Payout Not Received / Failed</option>
                                    <option value="PAYIN_ISSUE">PayIn Not Credited</option>
                                    <option value="WALLET_ISSUE">Wallet Balance Discrepancy</option>
                                    <option value="OTHER">Other Issue</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-1">Transaction ID (Optional)</label>
                                <input
                                    type="text"
                                    value={createForm.transactionId}
                                    onChange={(e) => setCreateForm({ ...createForm, transactionId: e.target.value })}
                                    className="w-full px-3 py-2 border rounded-lg"
                                    placeholder="e.g. txn_123456"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-1">Description</label>
                                <textarea
                                    value={createForm.description}
                                    onChange={(e) => setCreateForm({ ...createForm, description: e.target.value })}
                                    className="w-full px-3 py-2 border rounded-lg"
                                    rows={4}
                                    placeholder="Describe your issue in detail..."
                                    required
                                />
                            </div>
                            <button
                                type="submit"
                                className="w-full bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 font-medium"
                            >
                                Submit Dispute
                            </button>
                        </form>
                    </div>
                </div>
            )}

            {/* Manage Modal (Admin) */}
            {showManageModal && selectedDispute && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden">
                        <div className="p-4 border-b flex justify-between items-center bg-gray-50">
                            <h3 className="font-bold text-lg">Manage Dispute</h3>
                            <button onClick={() => setShowManageModal(false)} className="text-gray-400 hover:text-gray-600">×</button>
                        </div>
                        <form onSubmit={handleManageSubmit} className="p-4 space-y-4">
                            <div className="bg-gray-50 p-3 rounded-lg text-sm">
                                <p className="font-semibold text-gray-700 mb-1">User Issue:</p>
                                <p className="text-gray-600">{selectedDispute.description}</p>
                            </div>

                            <div>
                                <label className="block text-sm font-medium mb-1">Status</label>
                                <select
                                    value={manageForm.status}
                                    onChange={(e) => setManageForm({ ...manageForm, status: e.target.value })}
                                    className="w-full px-3 py-2 border rounded-lg"
                                >
                                    <option value="OPEN">OPEN - Reviewing</option>
                                    <option value="RESOLVED">✅ RESOLVED - Issue Fixed</option>
                                    <option value="REJECTED">❌ REJECTED - Invalid</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium mb-1">Admin Comment</label>
                                <textarea
                                    value={manageForm.adminComment}
                                    onChange={(e) => setManageForm({ ...manageForm, adminComment: e.target.value })}
                                    className="w-full px-3 py-2 border rounded-lg"
                                    rows={4}
                                    placeholder="Explain the resolution or reason for rejection..."
                                />
                            </div>
                            <button
                                type="submit"
                                className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 font-medium"
                            >
                                Update Status
                            </button>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}

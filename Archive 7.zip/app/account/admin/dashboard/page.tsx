'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { KPICard } from '@/components/kpi-card';
import { ChartCard } from '@/components/chart-card';
import { DataTable } from '@/components/data-table';
import { formatINR } from '@/lib/money';

interface Analytics {
  kpis: {
    totalUsers: number;
    totalSubUsers: number;
    activeUsers: number;
    userEngagementRate: string;
  };
  apis: {
    total: number;
    online: number;
    offline: number;
    healthPercentage: string;
  };
  transactions: {
    total: number;
    completed: number;
    pending: number;
    successRate: string;
  };
  revenue: {
    total: number;
    monthlyCount: number;
    averageTransaction: number;
  };
  profit: {
    totalChargesCollected: number;
    gstAmount: number;
    gstPercentage: number;
    netProfit: number;
    applyGst: boolean;
  };
  recentActivity: any[];
  dateRange?: {
    start: string;
    end: string;
    filter: string;
  };
}

export default function AdminDashboard() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('30d');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }

    if ((session?.user as any)?.role !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  useEffect(() => {
    const fetchAnalytics = async () => {
      setLoading(true);
      try {
        const response = await fetch(`/api/admin/analytics?range=${timeRange}`);
        const data = await response.json();
        if (data.success) {
          setAnalytics(data.data);
        }
      } catch (error) {
        console.error('Failed to fetch analytics:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAnalytics();
  }, [timeRange]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-lg text-gray-600">Loading...</div>
      </div>
    );
  }

  if (!analytics) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-lg text-gray-600">Failed to load analytics</div>
      </div>
    );
  }

  const activityColumns = [
    { key: 'action', label: 'Action', width: '150px' },
    { key: 'resource', label: 'Resource', width: '150px' },
    {
      key: 'user',
      label: 'User',
      render: (user: any) => user?.email || 'Unknown',
    },
    { key: 'status', label: 'Status' },
    {
      key: 'createdAt',
      label: 'Time',
      render: (date: string) => new Date(date).toLocaleString(),
    },
  ];

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-2">System Overview & Analytics</p>
        </div>

        <select
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value)}
          className="bg-white border border-gray-300 text-gray-700 py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
        >
          <option value="today">Today</option>
          <option value="yesterday">Yesterday</option>
          <option value="this_week">This Week</option>
          <option value="7d">Last 7 Days</option>
          <option value="this_month">This Month</option>
          <option value="previous_month">Previous Month</option>
          <option value="30d">Last 30 Days</option>
          <option value="all">All Time</option>
        </select>
      </div>

      {/* Main KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard
          title="Total Users"
          value={analytics.kpis.totalUsers}
          color="blue"
          icon="👥"
        />
        <KPICard
          title="Total SubUsers"
          value={analytics.kpis.totalSubUsers}
          color="green"
          icon="👤"
        />
        <KPICard
          title="Active Users"
          value={analytics.kpis.activeUsers}
          subtitle={`${analytics.kpis.userEngagementRate}% engagement`}
          color="purple"
          icon="📊"
        />
        <KPICard
          title="System Health"
          value={`${analytics.apis.healthPercentage}%`}
          subtitle={`${analytics.apis.online}/${analytics.apis.total} APIs online`}
          color="yellow"
          icon="🔌"
        />
      </div>

      {/* Profit & GST Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-6 rounded-xl shadow-lg text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm font-medium">Total Profit (Charges)</p>
              <p className="text-3xl font-bold mt-2">{formatINR(analytics.profit?.totalChargesCollected || 0)}</p>
              <p className="text-green-200 text-sm mt-1">From all successful payouts</p>
            </div>
            <div className="text-5xl opacity-80">💰</div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-amber-600 p-6 rounded-xl shadow-lg text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100 text-sm font-medium">GST Collected ({analytics.profit?.gstPercentage || 18}%)</p>
              <p className="text-3xl font-bold mt-2">{formatINR(analytics.profit?.gstAmount || 0)}</p>
              <p className="text-orange-200 text-sm mt-1">{analytics.profit?.applyGst ? 'GST Applied' : 'GST Not Applied'}</p>
            </div>
            <div className="text-5xl opacity-80">🧾</div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-6 rounded-xl shadow-lg text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm font-medium">Net Profit (GST + Charges)</p>
              <p className="text-3xl font-bold mt-2">{formatINR(analytics.profit?.netProfit || 0)}</p>
              <p className="text-blue-200 text-sm mt-1">Total collected amount</p>
            </div>
            <div className="text-5xl opacity-80">📈</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Transaction Statistics</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">Total Transactions</span>
              <span className="text-2xl font-bold text-gray-900">{analytics.transactions.total}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">Completed</span>
              <span className="text-green-600 font-semibold">{analytics.transactions.completed}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">Pending</span>
              <span className="text-yellow-600 font-semibold">{analytics.transactions.pending}</span>
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="text-gray-600">Success Rate</span>
              <span className="text-blue-600 font-semibold">{analytics.transactions.successRate}%</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Overview</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">Total Volume</span>
              <span className="text-2xl font-bold text-gray-900">{formatINR(Number(analytics.revenue.total))}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">Transactions Count</span>
              <span className="font-semibold">{analytics.revenue.monthlyCount}</span>
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="text-gray-600">Average Transaction</span>
              <span className="font-semibold">{formatINR(Number(analytics.revenue.averageTransaction))}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity Log</h3>
        <DataTable
          data={analytics.recentActivity.map((log) => ({
            id: log.id,
            ...log,
          }))}
          columns={activityColumns}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard
          title="API Health Distribution"
          data={[
            { label: 'Online', value: analytics.apis.online },
            { label: 'Offline', value: analytics.apis.offline },
          ]}
          type="pie"
        />
        <ChartCard
          title="Transaction Status"
          data={[
            { label: 'Completed', value: analytics.transactions.completed },
            { label: 'Pending', value: analytics.transactions.pending },
          ]}
          type="pie"
        />
      </div>
    </div>
  );
}

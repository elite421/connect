'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useGlobalToast } from '@/context/ToastContext';

interface ApiKeyWithUser {
  id: string;
  name: string;
  userId: string;
  isActive: boolean;
  permissions: string[];
  lastUsedAt: string | null;
  lastUsedIp: string | null;
  requestCount: number;
  expiresAt: string | null;
  createdAt: string;
  user: { username: string; email: string };
  keyAccess: Array<{ action: string; reason: string | null; createdAt: string }>;
}

export default function AdminApiKeysPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const [apiKeys, setApiKeys] = useState<ApiKeyWithUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterActive, setFilterActive] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedKey, setSelectedKey] = useState<ApiKeyWithUser | null>(null);
  const [showActionModal, setShowActionModal] = useState(false);
  const [actionData, setActionData] = useState({
    action: 'revoke' as 'revoke' | 'deny' | 'suspend' | 'activate',
    reason: '',
  });

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    const userRole = (session?.user as { role?: string })?.role;
    if (userRole !== 'ADMIN') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') {
      fetchApiKeys();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, status, filterActive]);

  const fetchApiKeys = async () => {
    setLoading(true);
    try {
      const isActiveParam = filterActive === 'all' ? null : filterActive === 'active';
      const queryString = isActiveParam !== null ? `?isActive=${isActiveParam}` : '';

      const response = await fetch(`/api/admin/api-keys${queryString}`, {
        method: 'GET',
      });

      const data = await response.json();
      if (data.success) {
        let filtered = data.data;

        if (searchQuery) {
          filtered = filtered.filter(
            (key: ApiKeyWithUser) =>
              key.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
              key.user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
              key.user.email.toLowerCase().includes(searchQuery.toLowerCase())
          );
        }

        setApiKeys(filtered);
      }
    } catch {
      toast.showError('Failed to load API keys');
    } finally {
      setLoading(false);
    }
  };

  const handleActionKey = async () => {
    if (!selectedKey) return;

    try {
      const response = await fetch('/api/admin/api-keys', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKeyId: selectedKey.id,
          action: actionData.action,
          reason: actionData.reason || null,
        }),
      });

      const data = await response.json();
      if (data.success) {
        toast.showSuccess(data.message);
        setShowActionModal(false);
        setSelectedKey(null);
        fetchApiKeys();
        setActionData({ action: 'revoke', reason: '' });
      } else {
        toast.showError(data.error || 'Failed to perform action');
      }
    } catch {
      toast.showError('Failed to perform action');
    }
  };

  const handleDeleteKey = async (id: string) => {
    if (!confirm('Permanently delete this API key?')) return;

    try {
      const response = await fetch(`/api/admin/api-keys?id=${id}`, {
        method: 'DELETE',
      });

      const data = await response.json();
      if (data.success) {
        toast.showSuccess('API key deleted');
        fetchApiKeys();
      } else {
        toast.showError(data.error || 'Failed to delete API key');
      }
    } catch {
      toast.showError('Failed to delete API key');
    }
  };

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <>

      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">API Keys Management</h1>
          <p className="text-gray-600 mt-2">Monitor and manage all user API keys, revoke access, and review activity</p>
        </div>

        <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 p-6 rounded-xl">
          <div className="flex items-start gap-3">
            <div className="text-2xl">🔑</div>
            <div>
              <h3 className="font-semibold text-purple-900 mb-2">API Key Management</h3>
              <p className="text-sm text-purple-800">
                Monitor user API key usage, revoke access if keys are misused, and maintain security across integrations.
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{apiKeys.length}</div>
            <div className="text-sm text-gray-600">Total API Keys</div>
          </div>
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="text-2xl font-bold text-green-600">
              {apiKeys.filter((k) => k.isActive).length}
            </div>
            <div className="text-sm text-gray-600">Active</div>
          </div>
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="text-2xl font-bold text-red-600">
              {apiKeys.filter((k) => !k.isActive).length}
            </div>
            <div className="text-sm text-gray-600">Inactive</div>
          </div>
          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">
              {apiKeys.reduce((sum, k) => sum + k.requestCount, 0)}
            </div>
            <div className="text-sm text-gray-600">Total Requests</div>
          </div>
        </div>

        <div className="flex gap-4 items-center">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by key name, username, or email..."
            className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <select
            value={filterActive}
            onChange={(e) => setFilterActive(e.target.value)}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Keys</option>
            <option value="active">Active Only</option>
            <option value="inactive">Inactive Only</option>
          </select>
        </div>

        <div className="overflow-x-auto">
          {apiKeys.length === 0 ? (
            <div className="bg-white p-12 rounded-lg border text-center text-gray-500">
              No API keys found
            </div>
          ) : (
            <table className="w-full text-sm bg-white rounded-lg border">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-6 py-4 text-left font-semibold text-gray-900">Key Name</th>
                  <th className="px-6 py-4 text-left font-semibold text-gray-900">User</th>
                  <th className="px-6 py-4 text-left font-semibold text-gray-900">Status</th>
                  <th className="px-6 py-4 text-left font-semibold text-gray-900">Requests</th>
                  <th className="px-6 py-4 text-left font-semibold text-gray-900">Last Used</th>
                  <th className="px-6 py-4 text-left font-semibold text-gray-900">Expires</th>
                  <th className="px-6 py-4 text-left font-semibold text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {apiKeys.map((key) => (
                  <tr key={key.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 font-medium text-gray-900">{key.name}</td>
                    <td className="px-6 py-4 text-sm">
                      <div className="font-medium">{key.user.username}</div>
                      <div className="text-xs text-gray-600">{key.user.email}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${key.isActive
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                          }`}
                      >
                        {key.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm">{key.requestCount}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      {key.lastUsedAt ? new Date(key.lastUsedAt).toLocaleDateString() : 'Never'}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      {key.expiresAt ? new Date(key.expiresAt).toLocaleDateString() : 'Never'}
                    </td>
                    <td className="px-6 py-4 text-sm space-y-2">
                      <button
                        onClick={() => {
                          setSelectedKey(key);
                          setShowActionModal(true);
                        }}
                        className="block w-full px-3 py-1 bg-yellow-100 text-yellow-700 rounded hover:bg-yellow-200 font-medium"
                      >
                        ⚡ Actions
                      </button>
                      <button
                        onClick={() => handleDeleteKey(key.id)}
                        className="block w-full px-3 py-1 bg-red-100 text-red-700 rounded hover:bg-red-200 font-medium"
                      >
                        🗑 Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {showActionModal && selectedKey && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-8 w-full max-w-md shadow-2xl">
              <h2 className="text-2xl font-bold mb-6">Manage API Key Access</h2>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <p className="text-sm text-blue-900">
                  <strong>Key:</strong> {selectedKey.name}
                </p>
                <p className="text-sm text-blue-900">
                  <strong>User:</strong> {selectedKey.user.username}
                </p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Action</label>
                  <select
                    value={actionData.action}
                    onChange={(e) =>
                      setActionData({
                        ...actionData,
                        action: e.target.value as 'revoke' | 'deny' | 'suspend' | 'activate',
                      })
                    }
                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="revoke">Revoke Access</option>
                    <option value="deny">Deny Request</option>
                    <option value="suspend">Suspend Key</option>
                    <option value="activate">Activate Key</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Reason (Optional)</label>
                  <textarea
                    value={actionData.reason}
                    onChange={(e) => setActionData({ ...actionData, reason: e.target.value })}
                    placeholder="Why are you taking this action?"
                    className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={3}
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    onClick={handleActionKey}
                    className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-medium"
                  >
                    Confirm
                  </button>
                  <button
                    onClick={() => {
                      setShowActionModal(false);
                      setSelectedKey(null);
                      setActionData({ action: 'revoke', reason: '' });
                    }}
                    className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

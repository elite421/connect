'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

interface KYCSubmission {
  id: string;
  userId: string;
  subUserId?: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  dateOfBirth?: string;
  addressLine1?: string;
  addressLine2?: string;
  city?: string;
  state?: string;
  postalCode?: string;
  country?: string;
  idType?: string;
  idNumber?: string;
  idPhotoUrl?: string;
  idPhotoVerified?: boolean;
  panNumber?: string;
  panPhotoUrl?: string;
  panPhotoVerified?: boolean;
  aadharNumber?: string;
  aadharPhotoUrl?: string;
  aadharVerified?: boolean;
  kycStatus: string;
  submittedAt: string;
  verifiedAt?: string;
  expiryDate?: string;
  rejectionReason?: string;
}

export default function KYCManagement() {
  const { data: session } = useSession();
  const router = useRouter();
  const [kycSubmissions, setKycSubmissions] = useState<KYCSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedKyc, setSelectedKyc] = useState<KYCSubmission | null>(null);
  const [status, setStatus] = useState('');
  const [rejectionReason, setRejectionReason] = useState('');

  useEffect(() => {
    if (session?.user && (session.user as any).role === 'ADMIN') {
      fetchKYCSubmissions();
    } else {
      router.push('/login');
    }
  }, [session, router]);

  const fetchKYCSubmissions = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/kyc');
      const data = await response.json();
      if (data.success) {
        setKycSubmissions(data.data);
      }
    } catch (error) {
      console.error('Error fetching KYC submissions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (kycId: string, newStatus: string, reason?: string) => {
    try {
      const response = await fetch('/api/admin/kyc', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: kycId,
          status: newStatus,
          rejectionReason: reason,
        }),
      });

      if (response.ok) {
        setSelectedKyc(null);
        setRejectionReason('');
        setStatus('');
        fetchKYCSubmissions();
      }
    } catch (error) {
      console.error('Error updating KYC status:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'expired':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-blue-100 text-blue-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-500">Loading KYC submissions...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">📋 KYC Management</h1>
        <p className="text-gray-600 mt-2">Review and manage user and subuser KYC submissions</p>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User Info</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Submitted</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {kycSubmissions.map((kyc) => (
              <tr key={kyc.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div>
                    <p className="font-medium text-gray-900">{kyc.firstName} {kyc.lastName}</p>
                    <p className="text-sm text-gray-500">{kyc.email}</p>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                  {kyc.subUserId ? 'SubUser' : 'User'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(kyc.kycStatus)}`}>
                    {kyc.kycStatus.charAt(0).toUpperCase() + kyc.kycStatus.slice(1)}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                  {new Date(kyc.submittedAt).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <button
                    onClick={() => {
                      setSelectedKyc(kyc);
                      setStatus('');
                      setRejectionReason('');
                    }}
                    className="text-blue-600 hover:text-blue-900 font-medium"
                  >
                    Review
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedKyc && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 p-6 border-b border-gray-200 bg-white">
              <h2 className="text-xl font-bold text-gray-900">Review KYC Submission</h2>
              <p className="text-gray-600 text-sm mt-1">{selectedKyc.firstName} {selectedKyc.lastName}</p>
            </div>

            <div className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">First Name</label>
                  <p className="text-gray-900">{selectedKyc.firstName || 'N/A'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Last Name</label>
                  <p className="text-gray-900">{selectedKyc.lastName || 'N/A'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Email</label>
                  <p className="text-gray-900">{selectedKyc.email || 'N/A'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Phone</label>
                  <p className="text-gray-900">{selectedKyc.phone || 'N/A'}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Date of Birth</label>
                  <p className="text-gray-900">{selectedKyc.dateOfBirth ? new Date(selectedKyc.dateOfBirth).toLocaleDateString() : 'N/A'}</p>
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Address Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="text-sm font-medium text-gray-700">Address Line 1</label>
                    <p className="text-gray-900">{selectedKyc.addressLine1 || 'N/A'}</p>
                  </div>
                  <div className="col-span-2">
                    <label className="text-sm font-medium text-gray-700">Address Line 2</label>
                    <p className="text-gray-900">{selectedKyc.addressLine2 || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">City</label>
                    <p className="text-gray-900">{selectedKyc.city || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">State</label>
                    <p className="text-gray-900">{selectedKyc.state || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Postal Code</label>
                    <p className="text-gray-900">{selectedKyc.postalCode || 'N/A'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Country</label>
                    <p className="text-gray-900">{selectedKyc.country || 'N/A'}</p>
                  </div>
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">ID Documents</h3>
                <div className="space-y-6">
                  {selectedKyc.idType && (
                    <div className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <label className="text-sm font-medium text-gray-700">ID Type</label>
                          <p className="text-gray-900">{selectedKyc.idType}</p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          selectedKyc.idPhotoVerified
                            ? 'bg-green-100 text-green-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {selectedKyc.idPhotoVerified ? '✓ Verified' : 'Pending'}
                        </span>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700">ID Number</label>
                        <p className="text-gray-900 mb-4">{selectedKyc.idNumber || 'N/A'}</p>
                      </div>
                      {selectedKyc.idPhotoUrl && (
                        <div>
                          <label className="text-sm font-medium text-gray-700 block mb-2">ID Photo</label>
                          <div className="w-full bg-gray-100 rounded-lg overflow-hidden">
                            <img
                              src={selectedKyc.idPhotoUrl}
                              alt="ID Photo"
                              className="w-full h-auto max-h-96 object-contain"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {selectedKyc.panNumber && (
                    <div className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <label className="text-sm font-medium text-gray-700">PAN Number</label>
                          <p className="text-gray-900">{selectedKyc.panNumber}</p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          selectedKyc.panPhotoVerified
                            ? 'bg-green-100 text-green-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {selectedKyc.panPhotoVerified ? '✓ Verified' : 'Pending'}
                        </span>
                      </div>
                      {selectedKyc.panPhotoUrl && (
                        <div>
                          <label className="text-sm font-medium text-gray-700 block mb-2">PAN Photo</label>
                          <div className="w-full bg-gray-100 rounded-lg overflow-hidden">
                            <img
                              src={selectedKyc.panPhotoUrl}
                              alt="PAN Photo"
                              className="w-full h-auto max-h-96 object-contain"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {selectedKyc.aadharNumber && (
                    <div className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <label className="text-sm font-medium text-gray-700">Aadhar Number</label>
                          <p className="text-gray-900">{selectedKyc.aadharNumber}</p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          selectedKyc.aadharVerified
                            ? 'bg-green-100 text-green-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {selectedKyc.aadharVerified ? '✓ Verified' : 'Pending'}
                        </span>
                      </div>
                      {selectedKyc.aadharPhotoUrl && (
                        <div>
                          <label className="text-sm font-medium text-gray-700 block mb-2">Aadhar Photo</label>
                          <div className="w-full bg-gray-100 rounded-lg overflow-hidden">
                            <img
                              src={selectedKyc.aadharPhotoUrl}
                              alt="Aadhar Photo"
                              className="w-full h-auto max-h-96 object-contain"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Submission Status</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Status</label>
                    <p className="text-gray-900">{selectedKyc.kycStatus}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Submitted Date</label>
                    <p className="text-gray-900">{new Date(selectedKyc.submittedAt).toLocaleDateString()}</p>
                  </div>
                  {selectedKyc.verifiedAt && (
                    <div>
                      <label className="text-sm font-medium text-gray-700">Verified Date</label>
                      <p className="text-gray-900">{new Date(selectedKyc.verifiedAt).toLocaleDateString()}</p>
                    </div>
                  )}
                  {selectedKyc.expiryDate && (
                    <div>
                      <label className="text-sm font-medium text-gray-700">Expiry Date</label>
                      <p className="text-gray-900">{new Date(selectedKyc.expiryDate).toLocaleDateString()}</p>
                    </div>
                  )}
                  {selectedKyc.rejectionReason && (
                    <div className="col-span-2">
                      <label className="text-sm font-medium text-gray-700">Rejection Reason</label>
                      <p className="text-gray-900">{selectedKyc.rejectionReason}</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t pt-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Decision</label>
                <div className="space-y-2">
                  <button
                    onClick={() => setStatus('approved')}
                    className={`w-full px-4 py-2 rounded-lg font-medium transition-colors ${
                      status === 'approved'
                        ? 'bg-green-600 text-white'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                    }`}
                  >
                    ✓ Approve
                  </button>
                  <button
                    onClick={() => setStatus('rejected')}
                    className={`w-full px-4 py-2 rounded-lg font-medium transition-colors ${
                      status === 'rejected'
                        ? 'bg-red-600 text-white'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                    }`}
                  >
                    ✗ Reject
                  </button>
                </div>
              </div>

              {status === 'rejected' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Rejection Reason</label>
                  <textarea
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    placeholder="Enter reason for rejection..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    rows={3}
                  />
                </div>
              )}
            </div>

            <div className="sticky bottom-0 p-6 border-t border-gray-200 bg-white flex justify-end gap-3">
              <button
                onClick={() => setSelectedKyc(null)}
                className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 font-medium"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (status) {
                    handleStatusUpdate(selectedKyc.id, status, rejectionReason);
                  }
                }}
                disabled={!status}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 font-medium"
              >
                Update Status
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { formatINR } from '@/lib/money';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { KPICard } from '@/components/kpi-card';

interface Analytics {
  kpis: {
    totalUsers: number;
    totalSubUsers: number;
    activeUsers: number;
    userEngagementRate: string;
  };
  apis: {
    total: number;
    online: number;
    offline: number;
    healthPercentage: string;
  };
  transactions: {
    total: number;
    completed: number;
    pending: number;
    failed: number;
    successRate: string;
  };
  revenue: {
    total: number;
    monthlyCount: number;
    averageTransaction: number;
  };
}

export default function AdminAnalyticsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState({ start: '', end: '' });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  useEffect(() => {
    if (session) {
      fetchAnalytics();
    }
  }, [session]);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/analytics');
      const data = await response.json();
      if (data.success) {
        setAnalytics(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-gray-600">Loading analytics...</div>
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  if (!session || !analytics) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-gray-600">No analytics data available</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">System Analytics</h1>
        <p className="text-gray-600 mt-2">Comprehensive system performance metrics and insights</p>
      </div>

      {/* Date Range Filter */}
      <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Filter by Date Range</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            type="date"
            value={dateRange.start}
            onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Start Date"
          />
          <input
            type="date"
            value={dateRange.end}
            onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="End Date"
          />
          <button
            onClick={fetchAnalytics}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            Apply Filter
          </button>
        </div>
      </div>

      {/* User Metrics */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">User Metrics</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <KPICard
            title="Total Users"
            value={analytics.kpis.totalUsers}
            color="blue"
            icon="👥"
          />
          <KPICard
            title="Total SubUsers"
            value={analytics.kpis.totalSubUsers}
            color="green"
            icon="👤"
          />
          <KPICard
            title="Active Users"
            value={analytics.kpis.activeUsers}
            subtitle={`${analytics.kpis.userEngagementRate}% engagement`}
            color="purple"
            icon="📊"
          />
          <KPICard
            title="System Health"
            value={`${analytics.apis.healthPercentage}%`}
            subtitle={`${analytics.apis.online}/${analytics.apis.total} APIs online`}
            color="yellow"
            icon="🔌"
          />
        </div>
      </div>

      {/* Transaction Metrics */}
      <div>
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Transaction Metrics</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-4">Transaction Summary</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Total Transactions</span>
                <span className="font-semibold text-blue-600">{analytics.transactions.total}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Completed</span>
                <span className="font-semibold text-green-600">{analytics.transactions.completed}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Pending</span>
                <span className="font-semibold text-yellow-600">{analytics.transactions.pending}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Failed</span>
                <span className="font-semibold text-red-600">{analytics.transactions.failed || 0}</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-gray-600">Success Rate</span>
                <span className="font-semibold text-blue-600">{analytics.transactions.successRate}%</span>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-4">Revenue Metrics</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Total Revenue</span>
                <span className="font-semibold text-purple-600">
                  {formatINR(Number(analytics.revenue.total))}
                </span>
              </div>
              <div className="flex justify-between items-center py-2 border-b">
                <span className="text-gray-600">Monthly Transactions</span>
                <span className="font-semibold">{analytics.revenue.monthlyCount}</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-gray-600">Avg Transaction</span>
                <span className="font-semibold">
                  {formatINR(Number(analytics.revenue.averageTransaction))}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* API Health */}
      <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">API Health Status</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="text-4xl font-bold text-blue-600">{analytics.apis.total}</div>
            <div className="text-sm text-gray-600 mt-2">Total APIs</div>
          </div>
          <div className="text-center p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="text-4xl font-bold text-green-600">{analytics.apis.online}</div>
            <div className="text-sm text-gray-600 mt-2">Online</div>
          </div>
          <div className="text-center p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="text-4xl font-bold text-red-600">{analytics.apis.offline}</div>
            <div className="text-sm text-gray-600 mt-2">Offline</div>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Overall Health</span>
            <span className="text-sm font-semibold text-gray-900">{analytics.apis.healthPercentage}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div
              className="bg-green-600 h-3 rounded-full transition-all"
              style={{ width: `${analytics.apis.healthPercentage}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

import { redirect } from "next/navigation";

export default function AdminPage() {
  // Redirect to the admin dashboard instead of rendering content here
  // This allows child routes like /admin/users, /admin/payouts to work properly
  redirect("/account/admin/dashboard");
}

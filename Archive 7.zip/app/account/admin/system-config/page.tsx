'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useGlobalToast } from '@/context/ToastContext';

interface SystemConfig {
  id: string;
  globalTransactionCharge: number;
  globalTransactionChargeType: string;
  globalGstPercentage: number;
  enableGst: boolean;
}

export default function SystemConfigPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();


  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [formData, setFormData] = useState({
    globalTransactionCharge: 0,
    globalTransactionChargeType: 'fixed',
    globalGstPercentage: 18,
    enableGst: true,
  });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    const userRole = (session?.user as { role?: string })?.role;
    if (userRole !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  useEffect(() => {
    fetchConfig();
  }, []);

  const fetchConfig = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/system-config');
      const data = await response.json();
      if (data.success) {
        setFormData({
          globalTransactionCharge: Number(data.data.globalTransactionCharge) || 0,
          globalTransactionChargeType: data.data.globalTransactionChargeType || 'fixed',
          globalGstPercentage: Number(data.data.globalGstPercentage) || 18,
          enableGst: data.data.enableGst !== false,
        });
      }
    } catch {
      toast.showError('Failed to fetch system configuration');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const response = await fetch('/api/admin/system-config', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        toast.showSuccess('System configuration updated successfully');
        fetchConfig();
      } else {
        toast.showError('Failed to update system configuration');
      }
    } catch {
      toast.showError('Error updating system configuration');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-lg text-gray-600">Loading...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-2xl">


      <div>
        <h1 className="text-3xl font-bold text-gray-900">System Configuration</h1>
        <p className="text-gray-600 mt-2">Manage global transaction charges and GST settings</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Global Transaction Charge
            </label>
            <input
              type="number"
              step="0.01"
              value={formData.globalTransactionCharge}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  globalTransactionCharge: parseFloat(e.target.value) || 0,
                })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="Enter charge amount"
            />
            <p className="mt-1 text-xs text-gray-500">
              Amount deducted from every transaction (in addition to per-service charges)
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Charge Type
            </label>
            <select
              value={formData.globalTransactionChargeType}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  globalTransactionChargeType: e.target.value,
                })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="fixed">Fixed Amount (₹)</option>
              <option value="percentage">Percentage (%)</option>
            </select>
            <p className="mt-1 text-xs text-gray-500">
              Fixed: Same amount for all transactions. Percentage: Calculated based on transaction amount
            </p>
          </div>
        </div>

        <div className="border-t border-gray-200 pt-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">GST Configuration</h3>
              <p className="text-sm text-gray-600 mt-1">Configure Goods and Services Tax settings</p>
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.enableGst}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    enableGst: e.target.checked,
                  })
                }
                className="w-4 h-4 rounded border-gray-300"
              />
              <span className="text-sm font-medium text-gray-700">Enable GST</span>
            </label>
          </div>

          {formData.enableGst && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                GST Percentage (%)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                max="100"
                value={formData.globalGstPercentage}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    globalGstPercentage: parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="Enter GST percentage"
              />
              <p className="mt-1 text-xs text-gray-500">
                GST will be calculated on the transaction charges. Standard GST rate is 18%
              </p>
            </div>
          )}
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h4 className="font-semibold text-blue-900 mb-2">Example Calculation</h4>
          <div className="text-sm text-blue-800 space-y-1">
            <p>
              Transaction Amount: ₹1,000
              <br />
              Global Charge ({formData.globalTransactionChargeType === 'fixed' ? '₹' : '%'}
              {formData.globalTransactionCharge}): ₹
              {formData.globalTransactionChargeType === 'fixed'
                ? formData.globalTransactionCharge
                : Math.round((1000 * formData.globalTransactionCharge) / 100)}
              <br />
              {formData.enableGst && (
                <>
                  GST ({formData.globalGstPercentage}%): ₹
                  {formData.globalTransactionChargeType === 'fixed'
                    ? Math.round(
                      (formData.globalTransactionCharge *
                        formData.globalGstPercentage) /
                      100
                    )
                    : Math.round(
                      ((1000 * formData.globalTransactionCharge) /
                        100 *
                        formData.globalGstPercentage) /
                      100
                    )}
                  <br />
                </>
              )}
              Total Charge: ₹
              {formData.globalTransactionChargeType === 'fixed'
                ? formData.globalTransactionCharge +
                (formData.enableGst
                  ? Math.round(
                    (formData.globalTransactionCharge *
                      formData.globalGstPercentage) /
                    100
                  )
                  : 0)
                : Math.round((1000 * formData.globalTransactionCharge) / 100) +
                (formData.enableGst
                  ? Math.round(
                    ((1000 * formData.globalTransactionCharge) /
                      100 *
                      formData.globalGstPercentage) /
                    100
                  )
                  : 0)}
            </p>
          </div>
        </div>

        <div className="flex gap-4 justify-end border-t border-gray-200 pt-6">
          <button
            type="button"
            onClick={fetchConfig}
            className="px-4 py-2 text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50"
            disabled={saving}
          >
            Reset
          </button>
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            disabled={saving}
          >
            {saving ? 'Saving...' : 'Save Configuration'}
          </button>
        </div>
      </form>
    </div>
  );
}

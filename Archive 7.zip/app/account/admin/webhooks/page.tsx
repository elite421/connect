'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { FormBuilder, type FormField } from '@/components/form-builder';

interface Webhook {
  id: string;
  webhookUrl: string;
  webhookSecret: string;
  userId: string;
  userName: string;
  userEmail: string;
  merchantId: string | null;
  merchantName: string | null;
  events: string[];
  retryCount: number;
  retryDelay: number;
  isActive: boolean;
  createdAt: string;
}

const AVAILABLE_EVENTS = [
  'payment.success',
  'payment.failed',
  'payment.pending',
  'payout.success',
  'payout.failed',
  'payout.pending',
  'refund.success',
  'refund.failed',
  'settlement.completed',
  'dispute.created',
];

export default function AdminWebhooksPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [webhooks, setWebhooks] = useState<Webhook[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedWebhook, setSelectedWebhook] = useState<Webhook | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    const userRole = (session?.user as { role?: string })?.role;
    if (userRole !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchWebhooks = async (offset: number = 0, search: string = '') => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        offset: offset.toString(),
        limit: '50',
        ...(search && { search }),
      });
      const response = await fetch(`/api/admin/webhooks?${params}`);
      const data = await response.json();
      if (data.success) {
        setWebhooks(data.data);
        setPagination(data.pagination);
      }
    } catch (error) {
      console.error('Failed to fetch webhooks:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWebhooks();
  }, []);

  const columns: Column<Webhook>[] = [
    { key: 'userEmail', label: 'User Email' },
    { key: 'webhookUrl', label: 'Webhook URL', render: (url) => <code className="text-xs bg-gray-100 px-2 py-1 rounded break-all">{url}</code> },
    { key: 'retryCount', label: 'Retries' },
    {
      key: 'isActive',
      label: 'Status',
      render: (isActive) => (
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
          isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
          {isActive ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'createdAt',
      label: 'Created',
      render: (date) => new Date(date).toLocaleDateString(),
    },
  ];

  const formFields: FormField[] = [
    {
      name: 'isActive',
      label: 'Status',
      type: 'select',
      required: true,
      options: [
        { label: 'Active', value: 'true' },
        { label: 'Inactive', value: 'false' },
      ],
    },
    {
      name: 'events',
      label: 'Events',
      type: 'textarea',
      required: true,
      placeholder: 'payment.success, payment.failed, payout.success',
    },
    {
      name: 'retryCount',
      label: 'Retry Count',
      type: 'number',
      required: true,
      placeholder: '3',
    },
    {
      name: 'retryDelay',
      label: 'Retry Delay (seconds)',
      type: 'number',
      required: true,
      placeholder: '300',
    },
  ];

  const handleEditWebhook = (webhook: Webhook) => {
    setSelectedWebhook(webhook);
    setIsModalOpen(true);
  };

  const handleSubmit = async (data: Record<string, unknown>) => {
    if (!selectedWebhook) return;
    try {
      const response = await fetch('/api/admin/webhooks', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          webhookId: selectedWebhook.id,
          ...data,
        }),
      });
      if (response.ok) {
        setIsModalOpen(false);
        fetchWebhooks(pagination.offset, searchQuery);
      }
    } catch (error) {
      console.error('Failed to update webhook:', error);
    }
  };

  const handleDeleteWebhook = async (webhook: Webhook) => {
    if (!confirm(`Delete webhook for ${webhook.userEmail}?`)) return;
    try {
      const response = await fetch(`/api/admin/webhooks?webhookId=${webhook.id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        fetchWebhooks(pagination.offset, searchQuery);
      }
    } catch (error) {
      console.error('Failed to delete webhook:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Webhooks Management</h1>
        <p className="text-gray-600 mt-2">Manage user webhooks and event configurations</p>
      </div>

      <div className="flex gap-4">
        <input
          type="text"
          placeholder="Search by email or URL..."
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            fetchWebhooks(0, e.target.value);
          }}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <DataTable<Webhook>
        data={webhooks}
        columns={columns}
        loading={loading}
        pagination={{
          ...pagination,
          onPageChange: (offset) => fetchWebhooks(offset, searchQuery),
        }}
        actions={[
          {
            label: 'Edit',
            onClick: handleEditWebhook,
            variant: 'primary',
          },
          {
            label: 'Delete',
            onClick: handleDeleteWebhook,
            variant: 'danger',
          },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`Edit Webhook: ${selectedWebhook?.userEmail}`}
        size="md"
      >
        {selectedWebhook && (
          <FormBuilder
            fields={formFields}
            onSubmit={handleSubmit}
            initialValues={{
              isActive: selectedWebhook.isActive ? 'true' : 'false',
              events: selectedWebhook.events?.join(', ') || '',
              retryCount: selectedWebhook.retryCount,
              retryDelay: selectedWebhook.retryDelay,
            }}
            submitLabel="Update Webhook"
          />
        )}
      </Modal>
    </div>
  );
}

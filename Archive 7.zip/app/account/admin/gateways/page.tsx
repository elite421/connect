'use client';

import { useEffect, useState, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { FormBuilder, type FormField } from '@/components/form-builder';
import { useGlobalToast } from '@/context/ToastContext';
import { useConfirm } from '@/hooks/useConfirm';

interface PaymentGateway {
    id: string;
    code: string;
    name: string;
    provider: string;
    apiEndpoint: string;
    isActive: boolean;
    authType: string;
    createdAt: string;
}

export default function AdminGatewaysPage() {
    const { data: session, status } = useSession();
    const router = useRouter();
    const toast = useGlobalToast();
    const { confirm, ConfirmProvider } = useConfirm();

    const [gateways, setGateways] = useState<PaymentGateway[]>([]);
    const [loading, setLoading] = useState(true);
    const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const [selectedGateway, setSelectedGateway] = useState<PaymentGateway | null>(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [showInactive, setShowInactive] = useState(false);
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        if (status === 'unauthenticated') {
            router.push('/login');
        }
        const userRole = (session?.user as { role?: string })?.role;
        if (userRole !== 'ADMIN') {
            router.push('/account/dashboard');
        }
    }, [session, status, router]);

    const fetchGateways = useCallback(
        async (offset: number = 0, search: string = '') => {
            setLoading(true);
            try {
                const params = new URLSearchParams({
                    offset: offset.toString(),
                    limit: '50',
                    ...(search && { search }),
                    ...(showInactive && { showInactive: 'true' }),
                });
                const response = await fetch(`/api/admin/gateways?${params}`);
                const data = await response.json();
                if (data.success) {
                    setGateways(data.data);
                    setPagination(data.pagination);
                } else {
                    toast.showError('Failed to fetch gateways');
                }
            } catch (error) {
                console.error('Failed to fetch gateways:', error);
                toast.showError('Error fetching gateways');
            } finally {
                setLoading(false);
            }
        },
        [showInactive, toast]
    );

    useEffect(() => {
        fetchGateways();
    }, [fetchGateways]);

    const columns: Column<PaymentGateway>[] = [
        { key: 'code', label: 'Code' },
        { key: 'name', label: 'Name' },
        { key: 'provider', label: 'Provider' },
        { key: 'authType', label: 'Auth Type' },
        {
            key: 'isActive',
            label: 'Status',
            render: (isActive) => (
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                    {isActive ? 'Active' : 'Inactive'}
                </span>
            ),
        },
        {
            key: 'createdAt',
            label: 'Created',
            render: (date) => new Date(date).toLocaleDateString(),
        },
    ];

    const formFields: FormField[] = [
        { name: 'code', label: 'Gateway Code', type: 'text', required: true, placeholder: 'e.g., RAZORPAY' },
        { name: 'name', label: 'Gateway Name', type: 'text', required: true, placeholder: 'e.g., Razorpay Payment' },
        { name: 'provider', label: 'Provider', type: 'text', required: true, placeholder: 'e.g., Razorpay' },
        { name: 'apiEndpoint', label: 'API Endpoint', type: 'text', required: true, placeholder: 'https://api.example.com' },
        {
            name: 'authType',
            label: 'Auth Type',
            type: 'select',
            required: true,
            options: [
                { label: 'Bearer Token', value: 'bearer' },
                { label: 'Basic Auth', value: 'basic' },
                { label: 'API Key', value: 'apikey' },
            ],
        },
        { name: 'apiKey', label: 'API Key', type: 'password', required: false, placeholder: 'API Key / Client ID' },
        { name: 'apiSecret', label: 'API Secret', type: 'password', required: false, placeholder: 'API Secret / Client Secret' },
        { name: 'description', label: 'Description', type: 'textarea', required: false, placeholder: 'Gateway description' },
        {
            name: 'isActive',
            label: 'Status',
            type: 'select',
            required: true,
            options: [
                { label: 'Active', value: 'true' },
                { label: 'Inactive', value: 'false' },
            ],
        },
    ];

    const handleEditGateway = (gateway: PaymentGateway) => {
        setSelectedGateway(gateway);
        setIsModalOpen(true);
    };

    const handleSubmit = async (data: Record<string, unknown>) => {
        if (!selectedGateway) return;
        setSubmitting(true);
        try {
            const response = await fetch('/api/admin/gateways', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: selectedGateway.id,
                    ...data,
                    isActive: data.isActive === 'true' || data.isActive === true,
                }),
            });
            const result = await response.json();
            if (result.success) {
                toast.showSuccess('Gateway updated successfully');
                setIsModalOpen(false);
                fetchGateways(pagination.offset, searchQuery);
            } else {
                toast.showError(result.error || 'Failed to update gateway');
            }
        } catch (error) {
            console.error('Failed to update gateway:', error);
            toast.showError('Error updating gateway');
        } finally {
            setSubmitting(false);
        }
    };

    const handleCreateGateway = async (data: Record<string, unknown>) => {
        setSubmitting(true);
        try {
            const response = await fetch('/api/admin/gateways', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...data,
                    isActive: data.isActive === 'true' || data.isActive === true,
                }),
            });
            const result = await response.json();
            if (result.success) {
                toast.showSuccess('Gateway created successfully');
                setIsCreateModalOpen(false);
                fetchGateways(0, searchQuery);
            } else {
                toast.showError(result.error || 'Failed to create gateway');
            }
        } catch (error) {
            console.error('Failed to create gateway:', error);
            toast.showError('Error creating gateway');
        } finally {
            setSubmitting(false);
        }
    };

    const handleDeleteGateway = async (gateway: PaymentGateway) => {
        const confirmed = await confirm({
            title: 'Delete Gateway',
            message: `Are you sure you want to delete ${gateway.name}? This action cannot be undone.`,
            confirmText: 'Delete',
            cancelText: 'Cancel',
            isDangerous: true,
        });

        if (!confirmed) return;

        try {
            const response = await fetch(`/api/admin/gateways?id=${gateway.id}`, {
                method: 'DELETE',
            });
            const result = await response.json();
            if (result.success) {
                toast.showSuccess('Gateway deleted successfully');
                fetchGateways(pagination.offset, searchQuery);
            } else {
                toast.showError(result.error || 'Failed to delete gateway');
            }
        } catch (error) {
            console.error('Failed to delete gateway:', error);
            toast.showError('Error deleting gateway');
        }
    };

    return (
        <div className="space-y-6">

            <ConfirmProvider />

            <div className="flex justify-between items-start">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Gateway Management</h1>
                    <p className="text-gray-600 mt-2">Manage legacy payment gateways</p>
                </div>
                <button
                    onClick={() => {
                        setSelectedGateway(null);
                        setIsCreateModalOpen(true);
                    }}
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
                >
                    + Add Gateway
                </button>
            </div>

            <div className="flex gap-4 items-center">
                <input
                    type="text"
                    placeholder="Search gateways..."
                    value={searchQuery}
                    onChange={(e) => {
                        setSearchQuery(e.target.value);
                        fetchGateways(0, e.target.value);
                    }}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
                <label className="flex items-center gap-2 text-sm text-gray-700 bg-white px-4 py-2 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                        type="checkbox"
                        checked={showInactive}
                        onChange={(e) => setShowInactive(e.target.checked)}
                        className="rounded"
                    />
                    Show Inactive
                </label>
            </div>

            <DataTable<PaymentGateway>
                data={gateways}
                columns={columns}
                loading={loading}
                pagination={{
                    ...pagination,
                    onPageChange: (offset) => fetchGateways(offset, searchQuery),
                }}
                actions={[
                    {
                        label: 'Edit',
                        onClick: handleEditGateway,
                        variant: 'primary',
                    },
                    {
                        label: 'Delete',
                        onClick: handleDeleteGateway,
                        variant: 'danger',
                    },
                ]}
            />

            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                title={`Edit Gateway: ${selectedGateway?.name}`}
                size="md"
            >
                {selectedGateway && (
                    <FormBuilder
                        fields={formFields}
                        onSubmit={handleSubmit}
                        initialValues={{
                            code: selectedGateway.code,
                            name: selectedGateway.name,
                            provider: selectedGateway.provider,
                            apiEndpoint: selectedGateway.apiEndpoint,
                            authType: selectedGateway.authType,
                            apiKey: '', // Don't show sensitive data
                            apiSecret: '',
                            isActive: selectedGateway ? 'true' : 'false',
                        }}
                        submitLabel="Update Gateway"
                    />
                )}
            </Modal>

            <Modal
                isOpen={isCreateModalOpen}
                onClose={() => setIsCreateModalOpen(false)}
                title="Create New Gateway"
                size="md"
            >
                <FormBuilder
                    fields={formFields}
                    onSubmit={handleCreateGateway}
                    initialValues={{
                        code: '',
                        name: '',
                        provider: '',
                        apiEndpoint: '',
                        authType: 'bearer',
                        isActive: 'true',
                    }}
                    submitLabel="Create Gateway"
                />
            </Modal>
        </div>
    );
}
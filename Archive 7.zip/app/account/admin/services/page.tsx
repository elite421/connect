'use client';

import { useEffect, useState, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { FormBuilder, type FormField } from '@/components/form-builder';
import { useGlobalToast } from '@/context/ToastContext';
import { useConfirm } from '@/hooks/useConfirm';

interface Service {
  id: string;
  code: string;
  name: string;
  description?: string;
  isActive: boolean;
  createdAt: string;
}

const SERVICE_TEMPLATES = [
  { code: 'NEFT', name: 'NEFT Transfer', description: 'National Electronic Funds Transfer' },
  { code: 'IMPS', name: 'IMPS Transfer', description: 'Immediate Payment Service' },
  { code: 'RTGS', name: 'RTGS Transfer', description: 'Real Time Gross Settlement' },
  { code: 'UPI', name: 'UPI Payment', description: 'Unified Payments Interface' },
  { code: 'WALLET', name: 'Digital Wallet', description: 'Virtual account for fund management' },
  { code: 'DTH_RECHARGE', name: 'DTH Recharge', description: 'Direct-to-Home TV recharge' },
  { code: 'MOBILE_RECHARGE', name: 'Mobile Recharge', description: 'Prepaid mobile recharge' },
  { code: 'ELECTRICITY', name: 'Electricity Bill', description: 'Electric utility payments' },
  { code: 'WATER', name: 'Water Bill', description: 'Water utility payments' },
  { code: 'GAS', name: 'Gas Bill', description: 'Gas utility payments' },
  { code: 'INSURANCE', name: 'Insurance Payment', description: 'Insurance premium payments' },
  { code: 'CREDIT_CARD', name: 'Credit Card Payment', description: 'Credit card bill payments' },
  { code: 'LOAN_REPAYMENT', name: 'Loan Repayment', description: 'Loan installment payments' },
  { code: 'SUBSCRIPTION', name: 'Subscription', description: 'Online subscription services' },
  { code: 'TRANSFER', name: 'Money Transfer', description: 'General money transfer service' },
];

export default function AdminServicesPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const { confirm, ConfirmProvider } = useConfirm();

  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showInactive, setShowInactive] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    const userRole = (session?.user as { role?: string })?.role;
    if (userRole !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchServices = useCallback(
    async (offset: number = 0, search: string = '') => {
      setLoading(true);
      try {
        const params = new URLSearchParams({
          offset: offset.toString(),
          limit: '50',
          ...(search && { search }),
          ...(showInactive && { showInactive: 'true' }),
        });
        const response = await fetch(`/api/admin/services?${params}`);
        const data = await response.json();
        if (data.success) {
          setServices(data.data);
          setPagination(data.pagination);
        } else {
          toast.showError('Failed to fetch services');
        }
      } catch (error) {
        console.error('Failed to fetch services:', error);
        toast.showError('Error fetching services');
      } finally {
        setLoading(false);
      }
    },
    [showInactive, toast]
  );

  useEffect(() => {
    fetchServices();
  }, [fetchServices]);

  const columns: Column<Service>[] = [
    { key: 'code', label: 'Code' },
    { key: 'name', label: 'Name' },
    { key: 'description', label: 'Description' },
    {
      key: 'isActive',
      label: 'Status',
      render: (isActive) => (
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
          }`}>
          {isActive ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'createdAt',
      label: 'Created',
      render: (date) => new Date(date).toLocaleDateString(),
    },
  ];

  const formFields: FormField[] = [
    { name: 'code', label: 'Service Code', type: 'text', required: true, placeholder: 'e.g., NEFT' },
    { name: 'name', label: 'Service Name', type: 'text', required: true, placeholder: 'e.g., NEFT Transfer' },
    { name: 'description', label: 'Description', type: 'textarea', required: false, placeholder: 'Service description' },
    {
      name: 'isActive',
      label: 'Status',
      type: 'select',
      required: true,
      options: [
        { label: 'Active', value: 'true' },
        { label: 'Inactive', value: 'false' },
      ],
    },
  ];

  const handleEditService = (service: Service) => {
    setSelectedService(service);
    setIsModalOpen(true);
  };

  const handleManageAPIs = (service: Service) => {
    router.push(`/account/admin/services/${service.id}/apis`);
  };

  const handleSubmit = async (data: Record<string, unknown>) => {
    if (!selectedService) return;
    setSubmitting(true);
    try {
      const response = await fetch('/api/admin/services', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedService.id,
          ...data,
          isActive: data.isActive === 'true' || data.isActive === true,
        }),
      });
      const result = await response.json();
      if (result.success) {
        toast.showSuccess('Service updated successfully');
        setIsModalOpen(false);
        fetchServices(pagination.offset, searchQuery);
      } else {
        toast.showError(result.error || 'Failed to update service');
      }
    } catch (error) {
      console.error('Failed to update service:', error);
      toast.showError('Error updating service');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateService = async (data: Record<string, unknown>) => {
    setSubmitting(true);
    try {
      const response = await fetch('/api/admin/services', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          isActive: data.isActive === 'true' || data.isActive === true,
        }),
      });
      const result = await response.json();
      if (result.success) {
        toast.showSuccess('Service created successfully');
        setIsCreateModalOpen(false);
        fetchServices(0, searchQuery);
      } else {
        toast.showError(result.error || 'Failed to create service');
      }
    } catch (error) {
      console.error('Failed to create service:', error);
      toast.showError('Error creating service');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteService = async (service: Service) => {
    const confirmed = await confirm({
      title: 'Delete Service',
      message: `Are you sure you want to delete ${service.name}? This action cannot be undone.`,
      confirmText: 'Delete',
      cancelText: 'Cancel',
      isDangerous: true,
    });

    if (!confirmed) return;

    try {
      const response = await fetch(`/api/admin/services?id=${service.id}`, {
        method: 'DELETE',
      });
      const result = await response.json();
      if (result.success) {
        toast.showSuccess('Service deleted successfully');
        fetchServices(pagination.offset, searchQuery);
      } else {
        toast.showError(result.error || 'Failed to delete service');
      }
    } catch (error) {
      console.error('Failed to delete service:', error);
      toast.showError('Error deleting service');
    }
  };

  const addTemplateService = async (template: typeof SERVICE_TEMPLATES[0]) => {
    try {
      const response = await fetch('/api/admin/services', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: template.code,
          name: template.name,
          description: template.description,
          isActive: true,
        }),
      });
      const result = await response.json();
      if (result.success) {
        toast.showSuccess(`${template.name} added successfully`);
        fetchServices(0, searchQuery);
      } else if (result.error?.includes('already exists')) {
        toast.showWarning('This service already exists');
      } else {
        toast.showError(result.error || 'Failed to add service');
      }
    } catch (error) {
      console.error('Failed to add template service:', error);
      toast.showError('Error adding service');
    }
  };

  return (
    <div className="space-y-6">

      <ConfirmProvider />

      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Services Management</h1>
          <p className="text-gray-600 mt-2">Manage payment services available for users</p>
        </div>
        <button
          onClick={() => {
            setSelectedService(null);
            setIsCreateModalOpen(true);
          }}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
        >
          + Add Service
        </button>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 p-6 rounded-xl">
        <h3 className="font-semibold text-blue-900 mb-4">Quick Add Templates</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
          {SERVICE_TEMPLATES.map((template) => (
            <button
              key={template.code}
              onClick={() => addTemplateService(template)}
              className="px-3 py-2 bg-white border border-blue-200 rounded-lg hover:bg-blue-50 text-sm font-medium text-blue-700 transition-colors text-left"
              title={template.description}
            >
              <div className="truncate">{template.name}</div>
              <div className="text-xs text-gray-500">{template.code}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="flex gap-4 items-center">
        <input
          type="text"
          placeholder="Search services..."
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            fetchServices(0, e.target.value);
          }}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        />
        <label className="flex items-center gap-2 text-sm text-gray-700 bg-white px-4 py-2 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
          <input
            type="checkbox"
            checked={showInactive}
            onChange={(e) => setShowInactive(e.target.checked)}
            className="rounded"
          />
          Show Inactive
        </label>
      </div>

      <DataTable<Service>
        data={services}
        columns={columns}
        loading={loading}
        pagination={{
          ...pagination,
          onPageChange: (offset) => fetchServices(offset, searchQuery),
        }}
        actions={[
          {
            label: 'Edit',
            onClick: handleEditService,
            variant: 'primary',
          },
          {
            label: 'Manage APIs',
            onClick: handleManageAPIs,
            variant: 'secondary',
          },
          {
            label: 'Delete',
            onClick: handleDeleteService,
            variant: 'danger',
          },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`Edit Service: ${selectedService?.name}`}
        size="md"
      >
        {selectedService && (
          <FormBuilder
            fields={formFields}
            onSubmit={handleSubmit}
            initialValues={{
              code: selectedService.code,
              name: selectedService.name,
              description: selectedService.description || '',
              isActive: selectedService.isActive ? 'true' : 'false',
            }}
            submitLabel="Update Service"
          />
        )}
      </Modal>

      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Create New Service"
        size="md"
      >
        <FormBuilder
          fields={formFields}
          onSubmit={handleCreateService}
          initialValues={{
            code: '',
            name: '',
            description: '',
            isActive: 'true',
          }}
          submitLabel="Create Service"
        />
      </Modal>
    </div>
  );
}

'use client';

import { useEffect, useState, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { FormBuilder } from '@/components/form-builder';
import { useGlobalToast } from '@/context/ToastContext';
import { useConfirm } from '@/hooks/useConfirm';

interface UserService {
  id: string;
  userId: string;
  serviceId: string;
  user: {
    id: string;
    email: string;
    name: string;
  };
  service: {
    id: string;
    code: string;
    name: string;
  };
  isActive: boolean;
  transactionCharge: number;
  transactionChargeType: string;
  createdAt: string;
}

interface User {
  id: string;
  email: string;
  name: string;
}

interface Service {
  id: string;
  code: string;
  name: string;
  isActive: boolean;
}

export default function ServiceAssignmentsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const { confirm, ConfirmProvider } = useConfirm();

  const [userServices, setUserServices] = useState<UserService[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [customApis, setCustomApis] = useState<any[]>([]); // Accommodate custom APIs fetch
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedUserService, setSelectedUserService] = useState<UserService | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterUser, setFilterUser] = useState('');
  const [filterService, setFilterService] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    const userRole = (session?.user as { role?: string })?.role;
    if (userRole !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchUserServices = useCallback(
    async (offset: number = 0) => {
      setLoading(true);
      try {
        const response = await fetch('/api/admin/user-services?offset=' + offset + '&limit=50');
        const data = await response.json();
        if (data.success) {
          setUserServices(data.data);
          setPagination(data.pagination);
        } else {
          toast.showError('Failed to fetch user services');
        }
      } catch (error) {
        console.error('Failed to fetch user services:', error);
        toast.showError('Error fetching user services');
      } finally {
        setLoading(false);
      }
    },
    [toast]
  );

  const fetchUsers = useCallback(async () => {
    try {
      const response = await fetch('/api/admin/users?offset=0&limit=1000');
      const data = await response.json();
      if (data.success) {
        setUsers(data.data.filter((u: any) => u.role === 'USER'));
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
    }
  }, []);

  const fetchServices = useCallback(async () => {
    try {
      const response = await fetch('/api/admin/services?offset=0&limit=1000');
      const data = await response.json();
      if (data.success) {
        setServices(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch services:', error);
    }
  }, []);

  const fetchCustomApis = useCallback(async (userId: string) => {
    if (!userId) {
      setCustomApis([]);
      return;
    }
    try {
      // Need a way to fetch APIs for a specific user as admin. 
      // Assuming existing GET /api/admin/custom-apis?userId=... or similar or we filter client side if we fetch all?
      // Actually /api/admin/custom-apis returns all. Let's use that and filter.
      const response = await fetch('/api/admin/custom-apis');
      const data = await response.json();
      if (data.success) {
        // Filter for the specific user
        setCustomApis(data.data.filter((api: any) => api.userId === userId));
      }
    } catch (error) {
      console.error('Failed to fetch custom APIs:', error);
    }
  }, []);

  useEffect(() => {
    fetchUserServices();
    fetchUsers();
    fetchServices();
  }, [fetchUserServices, fetchUsers, fetchServices]);

  const columns: Column<UserService>[] = [
    { key: 'user.email', label: 'User Email' },
    { key: 'user.name', label: 'User Name' },
    { key: 'service.code', label: 'Service Code' },
    { key: 'service.name', label: 'Service Name' },
    // Transaction Charge column removed
    {
      key: 'isActive',
      label: 'Status',
      render: (isActive) => (
        <span
          className={`px-3 py-1 rounded-full text-xs font-semibold ${isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}
        >
          {isActive ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'isActive',
      label: 'Status',
      render: (isActive) => (
        <span
          className={`px-3 py-1 rounded-full text-xs font-semibold ${isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}
        >
          {isActive ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'config',
      label: 'API',
      render: (config: any) => (
        <span className="text-sm text-gray-600">
          {config?.customApiId ? 'Custom API Linked' : 'Default'}
        </span>
      ),
    },
  ];

  const filteredUserServices = userServices.filter((us) => {
    const matchesUser = !filterUser || us.userId === filterUser;
    const matchesService = !filterService || us.serviceId === filterService;
    return matchesUser && matchesService;
  });

  const handleAssignService = () => {
    setSelectedUserService(null);
    setIsModalOpen(true);
  };

  const handleEditAssignment = (userService: UserService) => {
    setSelectedUserService(userService);
    setIsModalOpen(true);
  };

  const getAssignedServiceIds = (userId: string) => {
    return userServices
      .filter((us) => us.userId === userId)
      .map((us) => us.serviceId);
  };

  const handleSubmit = async (data: Record<string, unknown>) => {
    setSubmitting(true);
    try {
      if (selectedUserService) {
        const response = await fetch('/api/admin/user-services', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userServiceId: selectedUserService.id,
            isActive: data.isActive === true || data.isActive === 'true',
            transactionCharge: parseFloat(String(data.transactionCharge)) || 0,
            transactionChargeType: String(data.transactionChargeType || 'fixed'),
          }),
        });

        const result = await response.json();
        if (result.success) {
          toast.showSuccess('Service assignment updated successfully');
          setIsModalOpen(false);
          fetchUserServices(pagination.offset);
        } else {
          toast.showError(result.error || 'Failed to update service assignment');
        }
      } else {
        const response = await fetch('/api/admin/user-services', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: String(data.userId),
            serviceId: String(data.serviceId),
            isActive: data.isActive === true || data.isActive === 'true',
            transactionCharge: parseFloat(String(data.transactionCharge)) || 0,
            transactionChargeType: String(data.transactionChargeType || 'fixed'),
          }),
        });

        const result = await response.json();
        if (result.success) {
          toast.showSuccess('Service assigned to user successfully');
          setIsModalOpen(false);
          fetchUserServices(0);
        } else {
          toast.showError(result.error || 'Failed to assign service');
        }
      }
    } catch (error) {
      console.error('Failed to save user service:', error);
      toast.showError('Error saving user service');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteAssignment = async (userService: UserService) => {
    const confirmed = await confirm({
      title: 'Unassign Service',
      message: `Are you sure you want to unassign ${userService.service.name} from ${userService.user.email}?`,
      confirmText: 'Unassign',
      cancelText: 'Cancel',
      isDangerous: true,
    });

    if (!confirmed) return;

    try {
      const response = await fetch(`/api/admin/user-services?userServiceId=${userService.id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.showSuccess('Service unassigned successfully');
        fetchUserServices(pagination.offset);
      } else {
        toast.showError('Failed to unassign service');
      }
    } catch (error) {
      console.error('Failed to delete user service:', error);
      toast.showError('Error unassigning service');
    }
  };

  return (
    <div className="space-y-6">

      <ConfirmProvider />

      <div>
        <h1 className="text-3xl font-bold text-gray-900">Service Assignments</h1>
        <p className="text-gray-600 mt-2">Manage which services are assigned to which users</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <input
          type="text"
          placeholder="Search by email..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        />
        <select
          value={filterUser}
          onChange={(e) => setFilterUser(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="">All Users</option>
          {users.map((user) => (
            <option key={user.id} value={user.id}>
              {user.email}
            </option>
          ))}
        </select>
        <select
          value={filterService}
          onChange={(e) => setFilterService(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="">All Services</option>
          {services.map((service) => (
            <option key={service.id} value={service.id}>
              {service.name}
            </option>
          ))}
        </select>
      </div>

      <button
        onClick={handleAssignService}
        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
      >
        + Assign Service to User
      </button>

      <DataTable<UserService>
        data={filteredUserServices}
        columns={columns}
        loading={loading}
        pagination={{
          ...pagination,
          onPageChange: (offset) => fetchUserServices(offset),
        }}
        actions={[
          {
            label: 'Edit',
            onClick: handleEditAssignment,
            variant: 'primary',
          },
          {
            label: 'Unassign',
            onClick: handleDeleteAssignment,
            variant: 'danger',
          },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={
          selectedUserService
            ? `Edit Assignment: ${selectedUserService.user.email}`
            : 'Assign Service to User'
        }
        size="md"
      >
        {selectedUserService ? (
          <FormBuilder
            fields={[
              {
                name: 'isActive',
                label: 'Status',
                type: 'select',
                options: [
                  { label: 'Active', value: 'true' },
                  { label: 'Inactive', value: 'false' },
                ],
                required: true,
              },
            ]}
            onSubmit={handleSubmit}
            initialValues={{
              isActive: selectedUserService.isActive ? 'true' : 'false',
              customApiId: (selectedUserService as any).config?.customApiId || '',
            }}
            loading={submitting}
          />
        ) : (
          <FormBuilder
            fields={[
              {
                name: 'userId',
                label: 'User',
                type: 'select',
                required: true,
                options: users.map((user) => ({
                  label: user.email,
                  value: user.id,
                })),
                onChange: (val) => fetchCustomApis(String(val)), // Fetch APIs when user selected
              },
              {
                name: 'serviceId',
                label: 'Service',
                type: 'select',
                required: true,
                options: services
                  .filter(
                    (service) =>
                      // Simple check to avoid creating duplicate assignment if we were strict, but here we just list services
                      true
                  )
                  .map((service) => ({
                    label: `${service.name} (${service.code})`,
                    value: service.id,
                  })),
              },
              {
                name: 'customApiId',
                label: 'Use Custom API (Optional)',
                type: 'select',
                options: [
                  { label: 'Default / None', value: '' },
                  ...customApis.map((api) => ({ label: `${api.apiName} (ID: ${api.apiNumber})`, value: api.id }))
                ],
              },
              {
                name: 'isActive',
                label: 'Status',
                type: 'select',
                options: [
                  { label: 'Active', value: 'true' },
                  { label: 'Inactive', value: 'false' },
                ],
                required: true,
              },
            ]}
            onSubmit={handleSubmit}
            initialValues={{
              userId: '',
              serviceId: '',
              isActive: 'true',
            }}
            loading={submitting}
          />
        )}
      </Modal>
    </div>
  );
}

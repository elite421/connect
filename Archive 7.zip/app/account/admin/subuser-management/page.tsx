'use client';

import { useEffect, useState, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { FormBuilder } from '@/components/form-builder';
import { useGlobalToast } from '@/context/ToastContext';
import { useConfirm } from '@/hooks/useConfirm';
import { formatINR } from '@/lib/money';

interface SubUser {
  id: string;
  email: string;
  name: string;
  username: string;
  isActive: boolean;
  createdAt: string;
  parentUser: {
    id: string;
    email: string;
    name: string;
  };
  wallet?: {
    balance: number;
  };
  _count?: {
    transactions: number;
  };
}

interface Transaction {
  id: string;
  type: string;
  amount: number;
  status: string;
  createdAt: string;
  description?: string;
}

export default function SubuserManagementPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const { confirm, ConfirmProvider } = useConfirm();

  const [subUsers, setSubUsers] = useState<SubUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'edit' | 'wallet' | 'transactions' | 'refund'>('edit');
  const [selectedSubUser, setSelectedSubUser] = useState<SubUser | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    const userRole = (session?.user as { role?: string })?.role;
    if (userRole !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchSubUsers = useCallback(async (offset: number = 0, search: string = '') => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        offset: offset.toString(),
        limit: '50',
        ...(search && { search }),
      });
      const response = await fetch(`/api/admin/subusers?${params}`);
      const data = await response.json();
      if (data.success) {
        setSubUsers(data.data || []);
        setPagination(data.pagination || { offset: 0, limit: 50, total: data.data?.length || 0 });
      } else {
        toast.showError('Failed to fetch subusers');
      }
    } catch (error) {
      console.error('Failed to fetch subusers:', error);
      toast.showError('Error fetching subusers');
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const fetchSubUserTransactions = useCallback(async (subUserId: string) => {
    try {
      const response = await fetch(`/api/admin/subuser-transactions?subUserId=${subUserId}`);
      const data = await response.json();
      if (data.success) {
        setTransactions(data.data || []);
      }
    } catch (error) {
      console.error('Failed to fetch transactions:', error);
    }
  }, []);

  useEffect(() => {
    fetchSubUsers();
  }, [fetchSubUsers]);

  const columns: Column<SubUser>[] = [
    { key: 'email', label: 'Email' },
    { key: 'name', label: 'Name' },
    { key: 'username', label: 'Username' },
    {
      key: 'parentUser.email',
      label: 'Parent User',
    },
    {
      key: 'wallet.balance',
      label: 'Wallet Balance',
      render: (balance) => formatINR(Number(balance || 0)),
    },
    {
      key: '_count.transactions',
      label: 'Transactions',
      render: (count) => count || 0,
    },
    {
      key: 'isApiEnabled',
      label: 'API Access',
      render: (enabled) => (
        <span
          className={`px-2 py-0.5 rounded text-xs font-semibold border ${enabled ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-gray-50 text-gray-600 border-gray-200'
            }`}
        >
          {enabled ? 'Enabled' : 'Disabled'}
        </span>
      ),
    },
    {
      key: 'isActive',
      label: 'Status',
      render: (isActive) => (
        <span
          className={`px-3 py-1 rounded-full text-xs font-semibold ${isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}
        >
          {isActive ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'createdAt',
      label: 'Created',
      render: (date) => new Date(date).toLocaleDateString(),
    },
  ];

  const transactionColumns: Column<Transaction>[] = [
    { key: 'type', label: 'Type' },
    {
      key: 'amount',
      label: 'Amount',
      render: (amount) => formatINR(Number(amount)),
    },
    {
      key: 'status',
      label: 'Status',
      render: (status) => (
        <span
          className={`px-2 py-1 rounded text-xs font-medium ${status === 'SUCCESS' || status === 'COMPLETED'
            ? 'bg-green-100 text-green-800'
            : status === 'PENDING'
              ? 'bg-yellow-100 text-yellow-800'
              : status === 'FAILED'
                ? 'bg-red-100 text-red-800'
                : 'bg-gray-100 text-gray-800'
            }`}
        >
          {status}
        </span>
      ),
    },
    {
      key: 'createdAt',
      label: 'Date',
      render: (date) => new Date(date).toLocaleString(),
    },
  ];

  const handleEditSubUser = (subUser: SubUser) => {
    setSelectedSubUser(subUser);
    setModalMode('edit');
    setIsModalOpen(true);
  };

  const handleViewWallet = (subUser: SubUser) => {
    setSelectedSubUser(subUser);
    setModalMode('wallet');
    setIsModalOpen(true);
  };

  const handleViewTransactions = async (subUser: SubUser) => {
    setSelectedSubUser(subUser);
    setModalMode('transactions');
    await fetchSubUserTransactions(subUser.id);
    setIsModalOpen(true);
  };

  const handleToggleStatus = async (subUser: SubUser) => {
    const confirmed = await confirm({
      title: subUser.isActive ? 'Deactivate SubUser' : 'Activate SubUser',
      message: `Are you sure you want to ${subUser.isActive ? 'deactivate' : 'activate'} ${subUser.email}?`,
      confirmText: subUser.isActive ? 'Deactivate' : 'Activate',
      cancelText: 'Cancel',
      isDangerous: subUser.isActive,
    });

    if (!confirmed) return;

    try {
      const response = await fetch('/api/admin/subusers', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subUserId: subUser.id,
          isActive: !subUser.isActive,
        }),
      });

      const result = await response.json();
      if (result.success) {
        toast.showSuccess(`SubUser ${subUser.isActive ? 'deactivated' : 'activated'} successfully`);
        fetchSubUsers(pagination.offset, searchQuery);
      } else {
        toast.showError(result.error || 'Failed to update subuser');
      }
    } catch (error) {
      console.error('Failed to toggle subuser status:', error);
      toast.showError('Error updating subuser');
    }
  };

  const handleRefundTransaction = async (transaction: Transaction) => {
    if (transaction.status !== 'FAILED') {
      toast.showError('Only failed transactions can be refunded');
      return;
    }

    const confirmed = await confirm({
      title: 'Refund Transaction',
      message: `Refund ${formatINR(Number(transaction.amount))} to the subuser wallet?`,
      confirmText: 'Refund',
      cancelText: 'Cancel',
      isDangerous: false,
    });

    if (!confirmed) return;

    try {
      const response = await fetch('/api/admin/refund', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transactionId: transaction.id,
          subUserId: selectedSubUser?.id,
        }),
      });

      const result = await response.json();
      if (result.success) {
        toast.showSuccess('Refund processed successfully');
        if (selectedSubUser) {
          await fetchSubUserTransactions(selectedSubUser.id);
        }
        fetchSubUsers(pagination.offset, searchQuery);
      } else {
        toast.showError(result.error || 'Failed to process refund');
      }
    } catch (error) {
      console.error('Failed to refund:', error);
      toast.showError('Error processing refund');
    }
  };

  const handleUpdateSubUser = async (data: Record<string, unknown>) => {
    if (!selectedSubUser) return;
    setSubmitting(true);

    try {
      const response = await fetch('/api/admin/subusers', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subUserId: selectedSubUser.id,
          name: String(data.name),
          isActive: data.isActive === true || data.isActive === 'true',
          isApiEnabled: data.isApiEnabled === true || data.isApiEnabled === 'true',
        }),
      });

      const result = await response.json();
      if (result.success) {
        toast.showSuccess('SubUser updated successfully');
        setIsModalOpen(false);
        fetchSubUsers(pagination.offset, searchQuery);
      } else {
        toast.showError(result.error || 'Failed to update subuser');
      }
    } catch (error) {
      console.error('Failed to update subuser:', error);
      toast.showError('Error updating subuser');
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddFunds = async (data: Record<string, unknown>) => {
    if (!selectedSubUser) return;
    setSubmitting(true);

    try {
      const response = await fetch('/api/admin/subuser-wallet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subUserId: selectedSubUser.id,
          amount: parseFloat(String(data.amount)),
          type: 'CREDIT',
          description: String(data.description || 'Admin credit'),
        }),
      });

      const result = await response.json();
      if (result.success) {
        toast.showSuccess('Funds added successfully');
        setIsModalOpen(false);
        fetchSubUsers(pagination.offset, searchQuery);
      } else {
        toast.showError(result.error || 'Failed to add funds');
      }
    } catch (error) {
      console.error('Failed to add funds:', error);
      toast.showError('Error adding funds');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">

      <ConfirmProvider />

      <div>
        <h1 className="text-3xl font-bold text-gray-900">SubUser Management</h1>
        <p className="text-gray-600 mt-2">Manage all subusers, view wallets, and process refunds</p>
      </div>

      <div className="flex gap-4">
        <input
          type="text"
          placeholder="Search by email or name..."
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            fetchSubUsers(0, e.target.value);
          }}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <DataTable<SubUser>
        data={subUsers}
        columns={columns}
        loading={loading}
        pagination={{
          ...pagination,
          onPageChange: (offset) => fetchSubUsers(offset, searchQuery),
        }}
        actions={[
          {
            label: 'Edit',
            onClick: handleEditSubUser,
            variant: 'primary',
          },
          {
            label: 'Wallet',
            onClick: handleViewWallet,
            variant: 'secondary',
          },
          {
            label: 'Transactions',
            onClick: handleViewTransactions,
            variant: 'secondary',
          },
          {
            label: 'Toggle Status',
            onClick: handleToggleStatus,
            variant: 'danger',
          },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={
          modalMode === 'edit'
            ? `Edit SubUser: ${selectedSubUser?.email}`
            : modalMode === 'wallet'
              ? `Wallet: ${selectedSubUser?.email}`
              : `Transactions: ${selectedSubUser?.email}`
        }
        size={modalMode === 'transactions' ? 'lg' : 'md'}
      >
        {modalMode === 'edit' && selectedSubUser && (
          <FormBuilder
            fields={[
              {
                name: 'name',
                label: 'Name',
                type: 'text',
                required: true,
              },
              {
                name: 'isActive',
                label: 'Status',
                type: 'select',
                options: [
                  { label: 'Active', value: 'true' },
                  { label: 'Inactive', value: 'false' },
                ],
                required: true,
              },
            ]}
            onSubmit={handleUpdateSubUser}
            initialValues={{
              name: selectedSubUser.name || '',
              isActive: selectedSubUser.isActive ? 'true' : 'false',
            }}
            loading={submitting}
          />
        )}

        {modalMode === 'wallet' && selectedSubUser && (
          <div className="space-y-6">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="text-sm text-gray-600">Current Balance</div>
              <div className="text-3xl font-bold text-gray-900">
                {formatINR(Number(selectedSubUser.wallet?.balance || 0))}
              </div>
            </div>

            <div className="border-t pt-4">
              <h4 className="font-medium mb-4">Add Funds</h4>
              <FormBuilder
                fields={[
                  {
                    name: 'amount',
                    label: 'Amount (₹)',
                    type: 'number',
                    required: true,
                    placeholder: '100.00',
                  },
                  {
                    name: 'description',
                    label: 'Description',
                    type: 'text',
                    required: false,
                    placeholder: 'Admin credit',
                  },
                ]}
                onSubmit={handleAddFunds}
                initialValues={{
                  amount: '',
                  description: '',
                }}
                loading={submitting}
                submitLabel="Add Funds"
              />
            </div>
          </div>
        )}

        {modalMode === 'transactions' && (
          <div className="space-y-4">
            {transactions.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No transactions found
              </div>
            ) : (
              <DataTable<Transaction>
                data={transactions}
                columns={transactionColumns}
                actions={[
                  {
                    label: 'Refund',
                    onClick: handleRefundTransaction,
                    variant: 'danger',
                    visible: (tx) => tx.status === 'FAILED',
                  },
                ]}
              />
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { formatINR } from '@/lib/money';

interface Settlement {
  id: string;
  userId: string;
  userName: string | null;
  userEmail: string | null;
  amount: number;
  fee: number;
  netAmount: number;
  bankName: string | null;
  accountNumber: string | null;
  settlementType: string;
  utrNumber: string | null;
  status: string;
  createdAt: string;
}

export default function AdminSettlementsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [settlements, setSettlements] = useState<Settlement[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ status: 'all' });
  const [stats, setStats] = useState({ total: 0, completed: 0, pending: 0, totalAmount: 0 });

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if ((session?.user as any)?.role !== 'ADMIN') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') fetchSettlements();
  }, [session, status]);

  const fetchSettlements = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/settlements');
      const data = await response.json();
      if (data.success) {
        setSettlements(data.data);
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Failed to fetch settlements:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (id: string, newStatus: string, utrNumber?: string) => {
    const utr = newStatus === 'completed' ? prompt('Enter UTR Number:') : null;
    if (newStatus === 'completed' && !utr) return;

    try {
      const response = await fetch('/api/admin/settlements', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus, utrNumber: utr }),
      });
      if (response.ok) fetchSettlements();
    } catch (error) {
      alert('Failed to update status');
    }
  };

  const filteredSettlements = settlements.filter(s => {
    if (filter.status !== 'all' && s.status !== filter.status) return false;
    return true;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'processing': return 'bg-blue-100 text-blue-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">All Settlements</h1>
        <p className="text-gray-600 mt-2">View and process settlement requests from all users</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
          <div className="text-sm text-gray-600">Total Settlements</div>
        </div>
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="text-2xl font-bold text-green-600">{stats.completed}</div>
          <div className="text-sm text-gray-600">Completed</div>
        </div>
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
          <div className="text-sm text-gray-600">Pending</div>
        </div>
        <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
          <div className="text-2xl font-bold text-purple-600">{formatINR(stats.totalAmount)}</div>
          <div className="text-sm text-gray-600">Total Settled</div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg border flex gap-4 items-end">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
          <select value={filter.status} onChange={(e) => setFilter({...filter, status: e.target.value})} className="px-3 py-2 border rounded-lg">
            <option value="all">All Status</option>
            <option value="completed">Completed</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="failed">Failed</option>
          </select>
        </div>
      </div>

      <div className="bg-white rounded-lg border overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">User</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Amount</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Fee</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Net Amount</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Bank</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Type</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">UTR</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {filteredSettlements.length === 0 ? (
              <tr><td colSpan={10} className="px-4 py-12 text-center text-gray-500">No settlements found</td></tr>
            ) : (
              filteredSettlements.map((s) => (
                <tr key={s.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm">{new Date(s.createdAt).toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-sm">
                    <div className="font-medium">{s.userName || 'N/A'}</div>
                    <div className="text-xs text-gray-500">{s.userEmail}</div>
                  </td>
                  <td className="px-4 py-3 font-semibold">{formatINR(s.amount)}</td>
                  <td className="px-4 py-3 text-sm text-red-600">-{formatINR(s.fee)}</td>
                  <td className="px-4 py-3 font-semibold text-green-600">{formatINR(s.netAmount)}</td>
                  <td className="px-4 py-3 text-sm">
                    {s.bankName ? `${s.bankName} (****${s.accountNumber?.slice(-4)})` : 'N/A'}
                  </td>
                  <td className="px-4 py-3"><span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded capitalize">{s.settlementType}</span></td>
                  <td className="px-4 py-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(s.status)}`}>{s.status}</span></td>
                  <td className="px-4 py-3 text-sm font-mono">{s.utrNumber || '-'}</td>
                  <td className="px-4 py-3">
                    {s.status === 'pending' && (
                      <div className="flex gap-1">
                        <button onClick={() => handleStatusUpdate(s.id, 'processing')} className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">Process</button>
                        <button onClick={() => handleStatusUpdate(s.id, 'completed')} className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs">Complete</button>
                        <button onClick={() => handleStatusUpdate(s.id, 'failed')} className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs">Reject</button>
                      </div>
                    )}
                    {s.status === 'processing' && (
                      <div className="flex gap-1">
                        <button onClick={() => handleStatusUpdate(s.id, 'completed')} className="px-2 py-1 bg-green-100 text-green-700 rounded text-xs">Complete</button>
                        <button onClick={() => handleStatusUpdate(s.id, 'failed')} className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs">Failed</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

'use client';

import { useState, useEffect } from 'react';
import { formatINR } from '@/lib/money';

interface TransactionDetailsSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  transactionId: string;
  transactionType: 'PAYIN' | 'PAYOUT' | 'TRANSFER';
}

interface TransactionData {
  id: string;
  amount: number;
  currency: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  merchantTransactionId?: string;
  externalTransactionId?: string;
  utrNumber?: string;
  responseData?: Record<string, any>;
  callbackData?: Record<string, any>;
  customerName?: string;
  customerEmail?: string;
  customerPhone?: string;
  beneficiaryName?: string;
  beneficiaryAccount?: string;
  beneficiaryIfsc?: string;
  paymentMethod?: string;
}

export default function TransactionDetailsSidebar({
  isOpen,
  onClose,
  transactionId,
  transactionType,
}: TransactionDetailsSidebarProps) {
  const [transaction, setTransaction] = useState<TransactionData | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'callback' | 'response'>('details');

  useEffect(() => {
    if (isOpen && transactionId) {
      fetchTransactionDetails();
    }
  }, [isOpen, transactionId]);

  const fetchTransactionDetails = async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api/transactions/${transactionId}?type=${transactionType}`);
      const data = await response.json();
      if (data.success) {
        setTransaction(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch transaction details:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="absolute inset-0 bg-black bg-opacity-50" onClick={onClose} />
      
      <div className="relative ml-auto w-full max-w-2xl bg-white shadow-lg overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between bg-gray-50 border-b px-6 py-4">
          <div>
            <h2 className="text-xl font-bold text-gray-900">Transaction Details</h2>
            <p className="text-sm text-gray-600 mt-1">ID: {transactionId}</p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-2xl font-light"
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="text-gray-600">Loading transaction details...</div>
            </div>
          ) : transaction ? (
            <>
              {/* Tabs */}
              <div className="flex border-b bg-white sticky top-0">
                {['details', 'callback', 'response'].map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab as any)}
                    className={`px-6 py-3 font-medium text-sm transition-colors ${
                      activeTab === tab
                        ? 'text-blue-600 border-b-2 border-blue-600'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    {tab.charAt(0).toUpperCase() + tab.slice(1)}
                  </button>
                ))}
              </div>

              {/* Tab Content */}
              <div className="p-6">
                {activeTab === 'details' && (
                  <div className="space-y-6">
                    {/* Status Section */}
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-3">Status</h3>
                      <div className="flex items-center gap-3">
                        <span
                          className={`px-3 py-1 rounded-full text-sm font-semibold ${
                            transaction.status === 'completed'
                              ? 'bg-green-100 text-green-800'
                              : transaction.status === 'failed'
                              ? 'bg-red-100 text-red-800'
                              : 'bg-yellow-100 text-yellow-800'
                          }`}
                        >
                          {transaction.status?.toUpperCase()}
                        </span>
                      </div>
                    </div>

                    {/* Amount Section */}
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-3">Amount</h3>
                      <div className="text-2xl font-bold text-gray-900">
                        {formatINR(transaction.amount)} {transaction.currency}
                      </div>
                    </div>

                    {/* Timestamps */}
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs text-gray-600 uppercase font-semibold">Created</label>
                        <p className="text-gray-900 mt-1">
                          {new Date(transaction.createdAt).toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <label className="text-xs text-gray-600 uppercase font-semibold">Updated</label>
                        <p className="text-gray-900 mt-1">
                          {new Date(transaction.updatedAt).toLocaleString()}
                        </p>
                      </div>
                    </div>

                    {/* Transaction IDs */}
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-3">Transaction IDs</h3>
                      <div className="space-y-2">
                        {transaction.merchantTransactionId && (
                          <div>
                            <label className="text-xs text-gray-600 uppercase font-semibold">Merchant ID</label>
                            <code className="block bg-gray-100 px-3 py-2 rounded mt-1 text-sm break-all">
                              {transaction.merchantTransactionId}
                            </code>
                          </div>
                        )}
                        {transaction.externalTransactionId && (
                          <div>
                            <label className="text-xs text-gray-600 uppercase font-semibold">External ID</label>
                            <code className="block bg-gray-100 px-3 py-2 rounded mt-1 text-sm break-all">
                              {transaction.externalTransactionId}
                            </code>
                          </div>
                        )}
                        {transaction.utrNumber && (
                          <div>
                            <label className="text-xs text-gray-600 uppercase font-semibold">UTR Number</label>
                            <code className="block bg-gray-100 px-3 py-2 rounded mt-1 text-sm break-all">
                              {transaction.utrNumber}
                            </code>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Customer/Beneficiary Details */}
                    {transactionType === 'PAYIN' && (
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-3">Customer Details</h3>
                        <div className="space-y-2 text-sm">
                          {transaction.customerName && (
                            <div>
                              <label className="text-gray-600">Name:</label>
                              <p className="text-gray-900">{transaction.customerName}</p>
                            </div>
                          )}
                          {transaction.customerEmail && (
                            <div>
                              <label className="text-gray-600">Email:</label>
                              <p className="text-gray-900">{transaction.customerEmail}</p>
                            </div>
                          )}
                          {transaction.customerPhone && (
                            <div>
                              <label className="text-gray-600">Phone:</label>
                              <p className="text-gray-900">{transaction.customerPhone}</p>
                            </div>
                          )}
                          {transaction.paymentMethod && (
                            <div>
                              <label className="text-gray-600">Payment Method:</label>
                              <p className="text-gray-900">{transaction.paymentMethod}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {transactionType === 'PAYOUT' && (
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-3">Beneficiary Details</h3>
                        <div className="space-y-2 text-sm">
                          {transaction.beneficiaryName && (
                            <div>
                              <label className="text-gray-600">Name:</label>
                              <p className="text-gray-900">{transaction.beneficiaryName}</p>
                            </div>
                          )}
                          {transaction.beneficiaryAccount && (
                            <div>
                              <label className="text-gray-600">Account:</label>
                              <p className="text-gray-900">••••{transaction.beneficiaryAccount.slice(-4)}</p>
                            </div>
                          )}
                          {transaction.beneficiaryIfsc && (
                            <div>
                              <label className="text-gray-600">IFSC:</label>
                              <p className="text-gray-900">{transaction.beneficiaryIfsc}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'callback' && (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3">Callback Data</h3>
                    {transaction.responseData?.callbackResponse ? (
                      <pre className="bg-gray-100 p-4 rounded overflow-auto text-sm">
                        {JSON.stringify(transaction.responseData.callbackResponse, null, 2)}
                      </pre>
                    ) : (
                      <p className="text-gray-500">No callback data received yet</p>
                    )}
                  </div>
                )}

                {activeTab === 'response' && (
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3">Gateway Response</h3>
                    {transaction.responseData ? (
                      <pre className="bg-gray-100 p-4 rounded overflow-auto text-sm">
                        {JSON.stringify(transaction.responseData, null, 2)}
                      </pre>
                    ) : (
                      <p className="text-gray-500">No response data available</p>
                    )}
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-64">
              <div className="text-red-600">Failed to load transaction details</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { useGlobalToast } from '@/context/ToastContext';

interface PayInApi {
    id: string;
    apiName: string;
    apiBaseUrl: string;
    isActive: boolean;
    isDefault: boolean;
    adminProvided: boolean;
    isLinked?: boolean;
}

export function UserPayInSettings({ userId }: { userId: string }) {
    const toast = useGlobalToast();
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [availableApis, setAvailableApis] = useState<PayInApi[]>([]);
    const [linkedApiId, setLinkedApiId] = useState<string | null>(null);
    const [selectedApiId, setSelectedApiId] = useState<string>('');

    useEffect(() => {
        if (userId) {
            fetchData();
        }
    }, [userId]);

    const fetchData = async () => {
        setLoading(true);
        try {
            // Fetch available Admin APIs
            const templatesRes = await fetch('/api/admin/custom-apis');
            const templatesData = await templatesRes.json();
            if (templatesData.success) {
                const payinApis = templatesData.data.filter((api: PayInApi) =>
                    api.adminProvided && api.isActive
                );
                setAvailableApis(payinApis);
            }

            // Fetch currently linked API for this user
            const userApisRes = await fetch(`/api/admin/connecting-api?userId=${userId}&apiType=PAYIN`);
            const userApisData = await userApisRes.json();
            if (userApisData.success && userApisData.data.length > 0) {
                // Find the linked one (isLinked flag from backend)
                const linked = userApisData.data.find((a: any) => a.isLinked);
                if (linked) {
                    setLinkedApiId(linked.id);
                    setSelectedApiId(linked.id);
                }
            }
        } catch (error) {
            console.error('Failed to fetch data:', error);
            toast.showError('Failed to load PayIn API settings');
        } finally {
            setLoading(false);
        }
    };

    const handleLinkApi = async () => {
        if (!selectedApiId) {
            toast.showError('Please select an API');
            return;
        }
        setSubmitting(true);
        try {
            const res = await fetch('/api/admin/connecting-api', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId, linkToApiId: selectedApiId })
            });
            const data = await res.json();
            if (data.success) {
                toast.showSuccess('PayIn API linked successfully');
                setLinkedApiId(selectedApiId);
            } else {
                toast.showError(data.error || 'Failed to link API');
            }
        } catch {
            toast.showError('Error linking API');
        } finally {
            setSubmitting(false);
        }
    };

    const handleUnlinkApi = async () => {
        if (!confirm('Remove PayIn API assignment from this user? They will fall back to global defaults.')) return;
        setSubmitting(true);
        try {
            // Send empty linkToApiId to clear
            const res = await fetch('/api/admin/connecting-api', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId, linkToApiId: null }) // Unlinking
            });
            const data = await res.json();
            if (data.success) {
                toast.showSuccess('PayIn API unlinked');
                setLinkedApiId(null);
                setSelectedApiId('');
            } else {
                toast.showError(data.error || 'Failed to unlink API');
            }
        } catch {
            toast.showError('Error unlinking API');
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) {
        return <div className="p-6 text-center text-gray-500">Loading PayIn settings...</div>;
    }

    const currentApi = availableApis.find(a => a.id === linkedApiId);

    return (
        <div className="bg-white p-6 rounded-lg border shadow-sm space-y-4">
            <h3 className="font-semibold text-lg">PayIn API Settings</h3>

            {currentApi ? (
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="font-medium text-green-800">Currently Assigned:</p>
                            <p className="text-sm text-green-700">{currentApi.apiName}</p>
                            <p className="text-xs text-gray-500">{currentApi.apiBaseUrl}</p>
                        </div>
                        <button
                            onClick={handleUnlinkApi}
                            disabled={submitting}
                            className="px-3 py-1 bg-red-100 text-red-700 rounded text-sm hover:bg-red-200"
                        >
                            Unlink
                        </button>
                    </div>
                </div>
            ) : (
                <p className="text-gray-500 text-sm p-3 bg-gray-50 rounded">No PayIn API assigned. User will use global defaults.</p>
            )}

            <div className="border-t pt-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    {currentApi ? 'Change PayIn API' : 'Assign PayIn API'}
                </label>
                <div className="flex gap-2">
                    <select
                        value={selectedApiId}
                        onChange={(e) => setSelectedApiId(e.target.value)}
                        className="flex-1 px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
                        disabled={availableApis.length === 0}
                    >
                        <option value="">-- Select an API --</option>
                        {availableApis.map(api => (
                            <option key={api.id} value={api.id}>
                                {api.apiName} ({api.apiBaseUrl})
                            </option>
                        ))}
                    </select>
                    <button
                        onClick={handleLinkApi}
                        disabled={submitting || !selectedApiId || selectedApiId === linkedApiId}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                    >
                        {submitting ? 'Saving...' : (currentApi ? 'Update' : 'Assign')}
                    </button>
                </div>
                {availableApis.length === 0 && (
                    <p className="text-xs text-amber-600 mt-2">
                        No Admin PayIn APIs configured. Go to Provider Master &gt; Custom APIs to create one.
                    </p>
                )}
            </div>
        </div>
    );
}


'use client';

import { usePathname, useRouter } from 'next/navigation';
import { SessionProvider, useSession } from 'next-auth/react';
import { useEffect, useState } from 'react';
import Sidebar from './sidebar';
import Footer from './footer';
import { ToastProvider } from '@/context/ToastContext';
import type { ReactNode } from 'react';

const CURRENT_PAGE_KEY = 'lastVisitedPage';

function PageRestorer({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { status } = useSession();
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    if (status === 'unauthenticated' || pathname === '/login' || pathname === '/signup') {
      setInitialized(true);
      return;
    }

    if (!initialized && typeof window !== 'undefined' && status === 'authenticated') {
      const lastPage = localStorage.getItem(CURRENT_PAGE_KEY);
      if (lastPage && lastPage !== pathname && !lastPage.includes('/login') && !lastPage.includes('/signup')) {
        router.push(lastPage);
      }
      setInitialized(true);
    }
  }, [status, initialized, pathname, router]);

  return children;
}

export default function ClientLayout({
  children,
}: {
  children: ReactNode;
}) {
  const pathname = usePathname();
  const isAuth = pathname === '/login' || pathname === '/signup';

  return (
    <SessionProvider>
      <ToastProvider>
        <PageRestorer>
          <div className="min-h-screen flex">
            {!isAuth && <Sidebar />}
            <main className={`flex-1 ${!isAuth ? 'p-6 md:p-8 lg:p-10 max-w-7xl mx-auto w-full' : ''}`}>
              {children}
            </main>
          </div>
          {!isAuth && <Footer />}
        </PageRestorer>
      </ToastProvider>
    </SessionProvider>
  );
}

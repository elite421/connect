'use client';

import React from 'react';

// Helper function to get nested property value using dot notation
function getNestedValue(obj: any, path: string): any {
  if (!path.includes('.')) {
    return obj[path];
  }
  return path.split('.').reduce((current, key) => current?.[key], obj);
}

export interface Column<T> {
  key: keyof T | string;
  label: string;
  width?: string;
  render?: (value: any, item: T) => React.ReactNode;
  sortable?: boolean;
  align?: 'left' | 'center' | 'right';
}

export interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  loading?: boolean;
  onRowClick?: (item: T) => void;
  actions?: {
    label: string;
    onClick: (item: T) => void;
    variant?: 'primary' | 'danger' | 'secondary';
    visible?: (item: T) => boolean;
  }[];
  pagination?: {
    total: number;
    limit: number;
    offset: number;
    onPageChange: (offset: number) => void;
  };
}

export function DataTable<T extends { id: string }>({
  data,
  columns,
  loading = false,
  onRowClick,
  actions,
  pagination,
}: DataTableProps<T>) {
  const totalPages = pagination ? Math.ceil(pagination.total / pagination.limit) : 0;
  const currentPage = pagination ? Math.floor(pagination.offset / pagination.limit) + 1 : 0;

  return (
    <div className="w-full overflow-x-auto bg-white rounded-lg border border-gray-200 shadow-sm">
      {loading ? (
        <div className="flex items-center justify-center p-8">
          <div className="text-gray-500">Loading...</div>
        </div>
      ) : data.length === 0 ? (
        <div className="flex items-center justify-center p-8">
          <div className="text-gray-500">No data available</div>
        </div>
      ) : (
        <>
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                {columns.map((col) => (
                  <th
                    key={String(col.key)}
                    className="px-6 py-3 text-left text-sm font-semibold text-gray-700"
                    style={{ textAlign: col.align }}
                  >
                    {col.label}
                  </th>
                ))}
                {actions && <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Actions</th>}
              </tr>
            </thead>
            <tbody>
              {data.map((item, idx) => (
                <tr
                  key={item.id}
                  className="border-b border-gray-200 hover:bg-gray-50 cursor-pointer"
                  onClick={() => onRowClick?.(item)}
                >
                  {columns.map((col) => {
                    const value = getNestedValue(item, String(col.key));
                    return (
                      <td key={String(col.key)} className="px-6 py-4 text-sm text-gray-700">
                        {col.render ? col.render(value, item) : (value !== undefined && value !== null ? String(value) : '—')}
                      </td>
                    );
                  })}
                  {actions && (
                    <td className="px-6 py-4 text-sm">
                      <div className="flex gap-2">
                        {actions
                          .filter((action) => !action.visible || action.visible(item))
                          .map((action) => (
                            <button
                              key={action.label}
                              onClick={(e) => {
                                e.stopPropagation();
                                action.onClick(item);
                              }}
                              className={`px-3 py-1 rounded text-xs font-medium ${action.variant === 'danger'
                                  ? 'bg-red-100 text-red-700 hover:bg-red-200'
                                  : action.variant === 'secondary'
                                    ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                    : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                                }`}
                            >
                              {action.label}
                            </button>
                          ))}
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>

          {pagination && (
            <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
              <div className="text-sm text-gray-600">
                Page {currentPage} of {totalPages} • Total: {pagination.total} items
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => pagination.onPageChange(Math.max(0, pagination.offset - pagination.limit))}
                  disabled={pagination.offset === 0}
                  className="px-4 py-2 text-sm font-medium bg-gray-100 text-gray-700 rounded hover:bg-gray-200 disabled:opacity-50"
                >
                  Previous
                </button>
                <button
                  onClick={() => pagination.onPageChange(pagination.offset + pagination.limit)}
                  disabled={pagination.offset + pagination.limit >= pagination.total}
                  className="px-4 py-2 text-sm font-medium bg-gray-100 text-gray-700 rounded hover:bg-gray-200 disabled:opacity-50"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const SERVICES: Array<{ code: string; name: string; description?: string }> = [
  { code: 'payout', name: 'Payout', description: 'Bank/UPI payouts (NEFT, IMPS, UPI) to beneficiaries' },
  { code: 'payin', name: 'Pay-in', description: 'Customer payments collection via UPI/Cards/Netbanking' },
  { code: 'settlement', name: 'Settlement', description: 'Bank account settlements and transfers' },
];

async function main() {
  console.log('🌱 Seeding core Services...');
  for (const s of SERVICES) {
    const existing = await prisma.service.findUnique({ where: { code: s.code } });
    if (existing) {
      console.log(`⏭️  Service ${s.code} already exists`);
      continue;
    }
    await prisma.service.create({ data: { code: s.code, name: s.name, description: s.description } });
    console.log(`✅ Created service: ${s.name} (${s.code})`);
  }
  console.log('✨ Done seeding Services');
}

main()
  .catch((e) => {
    console.error('❌ Error seeding services:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

const bcrypt = require('bcryptjs');
const { PrismaClient } = require('@prisma/client');

async function createAdmin() {
    const prisma = new PrismaClient();

    try {
        const hashedPassword = await bcrypt.hash('Admin@123', 12);

        const admin = await prisma.user.upsert({
            where: { email: 'admin@connect.com' },
            update: {},
            create: {
                username: 'admin',
                name: 'Administrator',
                email: 'admin@connect.com',
                password: hashedPassword,
                role: 'ADMIN',
                emailVerified: true,
            },
        });

        console.log('✅ Admin user created successfully!');
        console.log('📧 Email: admin@connect.com');
        console.log('🔑 Password: Admin@123');
        console.log('🆔 User ID:', admin.id);
    } catch (e) {
        console.error('Error:', e.message || e);
    } finally {
        await prisma.$disconnect();
    }
}

createAdmin();

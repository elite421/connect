import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen">
      <section className="bg-white border-b">
        <div className="max-w-6xl mx-auto px-6 py-16 flex flex-col items-start gap-6">
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900">Connect. Pay. Automate.</h1>
          <p className="text-lg text-gray-700 max-w-2xl">Unified payouts, collections and developer-first APIs to run your business finance operations.</p>
          <div className="flex gap-3">
            <Link href="/signup" className="px-5 py-3 rounded-lg bg-green-600 text-white font-semibold">Create Account</Link>
            <Link href="/login" className="px-5 py-3 rounded-lg bg-gray-200 text-gray-900 font-semibold">Login</Link>
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 py-12">
        <h2 className="text-2xl font-bold mb-6">What you can do</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {["Bulk Payments", "Single Payments", "Payroll", "Vendor Management", "Account Statement", "Mini Statement"].map((t) => (
            <div key={t} className="bg-white border rounded-xl p-5 shadow-sm flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-green-100 text-green-700 flex items-center justify-center font-bold">✓</div>
              <div className="text-lg font-medium text-gray-800">{t}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 py-12">
        <div className="bg-green-50 border rounded-xl p-6 flex items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold">Connect your bank account</h3>
            <p className="text-gray-700">Use your existing current account or open a new instant digital one.</p>
          </div>
          <Link href="/account/banking" className="px-5 py-3 rounded-lg bg-green-600 text-white font-semibold">Get Started</Link>
        </div>
      </section>
    </div>
  );
}

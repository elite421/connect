'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useGlobalToast } from '@/context/ToastContext';
import { useConfirm } from '@/hooks/useConfirm';

interface CustomApi {
    id: string;
    userId: string | null;
    adminProvided: boolean;
    apiName: string;
    apiBaseUrl: string;
    apiEndpoint: string;
    apiMethod: string;
    authType: string;
    apiKey: string | null;
    apiSecret: string | null;
    authHeader: string | null;
    requestFormat: any | null;
    responseFormat: any | null;
    isActive: boolean;
    isDefault: boolean;
    apiType: string;
    allowedModes: string[];
    statusCheckUrl: string | null;
    apiNumber: string | null;
    callbackToken: string | null;
    createdAt: string;
}

export default function UserCustomApisPage() {
    const { data: session, status } = useSession();
    const router = useRouter();
    const { confirm, ConfirmProvider } = useConfirm();
    const toast = useGlobalToast();

    const [apis, setApis] = useState<CustomApi[]>([]);
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [editingApi, setEditingApi] = useState<CustomApi | null>(null);
    const [submitting, setSubmitting] = useState(false);

    const [formData, setFormData] = useState({
        apiName: '',
        apiBaseUrl: '',
        apiEndpoint: '/api/transfer',
        apiMethod: 'POST',
        authType: 'bearer',
        apiKey: '',
        apiSecret: '',
        authHeader: '',
        apiType: 'PAYOUT',
        allowedModes: ['IMPS', 'NEFT', 'UPI', 'RTGS'],
        statusCheckUrl: '',
    });

    useEffect(() => {
        if (status === 'loading') return;
        if (status === 'unauthenticated') router.push('/login');
        const userRole = (session?.user as { role?: string })?.role;
        if (status === 'authenticated' && userRole !== 'USER') router.push('/account/dashboard');
    }, [session, status, router]);

    useEffect(() => {
        if (session && status === 'authenticated') {
            fetchApis();
        }
    }, [session, status]);

    const fetchApis = async () => {
        setLoading(true);
        try {
            const response = await fetch('/api/user/custom-apis');
            const data = await response.json();
            if (data.success) setApis(data.data);
        } catch (error) {
            console.error('Failed to fetch APIs:', error);
            toast.showError('Failed to load APIs');
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);

        try {
            const url = '/api/user/custom-apis';
            const method = editingApi ? 'PATCH' : 'POST';

            const response = await fetch(url, {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: editingApi?.id,
                    ...formData,
                }),
            });

            const data = await response.json();
            if (data.success) {
                toast.showSuccess(editingApi ? 'API updated!' : 'API submitted for admin configuration!');
                setShowModal(false);
                resetForm();
                fetchApis();
            } else {
                toast.showError(data.error || 'Failed to save API');
            }
        } catch (error) {
            toast.showError('Failed to save API');
        } finally {
            setSubmitting(false);
        }
    };

    const handleEdit = (api: CustomApi) => {
        setEditingApi(api);
        setFormData({
            apiName: api.apiName,
            apiBaseUrl: api.apiBaseUrl,
            apiEndpoint: api.apiEndpoint,
            apiMethod: api.apiMethod,
            authType: api.authType,
            apiKey: api.apiKey || '',
            apiSecret: api.apiSecret || '',
            authHeader: api.authHeader || '',
            apiType: api.apiType || 'PAYOUT',
            allowedModes: api.allowedModes || ['IMPS', 'NEFT', 'UPI', 'RTGS'],
            statusCheckUrl: api.statusCheckUrl || '',
        });
        setShowModal(true);
    };

    const handleDelete = async (id: string, name: string) => {
        const isConfirmed = await confirm({
            title: 'Delete API Configuration',
            message: `Are you sure you want to delete "${name}"? This action cannot be undone.`,
            confirmText: 'Delete API',
            cancelText: 'Cancel',
            isDangerous: true,
        });

        if (!isConfirmed) return;

        try {
            const response = await fetch(`/api/user/custom-apis?id=${id}`, { method: 'DELETE' });
            const data = await response.json();
            if (data.success) {
                toast.showSuccess('API deleted');
                fetchApis();
            } else {
                toast.showError(data.error || 'Failed to delete');
            }
        } catch (error) {
            toast.showError('Failed to delete API');
        }
    };

    const resetForm = () => {
        setFormData({
            apiName: '',
            apiBaseUrl: '',
            apiEndpoint: '/api/transfer',
            apiMethod: 'POST',
            authType: 'bearer',
            apiKey: '',
            apiSecret: '',
            authHeader: '',
            apiType: 'PAYOUT',
            allowedModes: ['IMPS', 'NEFT', 'UPI', 'RTGS'],
            statusCheckUrl: '',
        });
        setEditingApi(null);
    };

    const getCallbackUrl = (api: CustomApi) => {
        if (typeof window === 'undefined') return '';
        return `${window.location.origin}/api/callback/${api.apiNumber}`;
    };

    if (status === 'loading' || loading) {
        return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
    }

    return (
        <>
            <ConfirmProvider />
            <div className="space-y-6">
                <div className="flex justify-between items-center">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">🔌 Connect Your API</h1>
                        <p className="text-gray-600 mt-2">Submit your payment API details for admin configuration</p>
                    </div>
                    <button
                        onClick={() => { resetForm(); setShowModal(true); }}
                        className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
                    >
                        + Add New API
                    </button>
                </div>

                {/* Info Banner */}
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 p-6 rounded-xl">
                    <div className="flex items-start gap-3">
                        <div className="text-2xl">💡</div>
                        <div>
                            <h3 className="font-semibold text-blue-900 mb-2">How it works</h3>
                            <ol className="text-sm text-blue-800 space-y-1 list-decimal list-inside">
                                <li>Submit your payment gateway API details below</li>
                                <li>Admin will review and configure the API</li>
                                <li>Once activated, you can use it for transactions</li>
                                <li>Transaction charges will be applied per your plan</li>
                            </ol>
                        </div>
                    </div>
                </div>

                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">{apis.length}</div>
                        <div className="text-sm text-gray-600">Total APIs</div>
                    </div>
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">{apis.filter(a => a.isActive).length}</div>
                        <div className="text-sm text-gray-600">Active</div>
                    </div>
                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <div className="text-2xl font-bold text-yellow-600">{apis.filter(a => !a.isActive).length}</div>
                        <div className="text-sm text-gray-600">Pending Activation</div>
                    </div>
                </div>

                {/* API List */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {apis.length === 0 ? (
                        <div className="col-span-full bg-white p-12 rounded-lg border text-center text-gray-500">
                            No APIs configured yet. Click &quot;Add New API&quot; to submit your first API.
                        </div>
                    ) : (
                        apis.map((api) => (
                            <div key={api.id} className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
                                <div className="flex justify-between items-start mb-4">
                                    <div>
                                        <h3 className="text-lg font-semibold text-gray-900">{api.apiName}</h3>
                                        <code className="text-xs text-gray-500">{api.apiBaseUrl}</code>
                                    </div>

                                </div>

                                <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                                    <div>
                                        <span className="text-gray-500">API Number:</span>
                                        <span className="ml-2 font-mono text-blue-600">{api.apiNumber || 'N/A'}</span>
                                    </div>
                                    <div>
                                        <span className="text-gray-500">Type:</span>
                                        <span className="ml-2 font-medium">{api.apiType}</span>
                                    </div>
                                    <div>
                                        <span className="text-gray-500">Endpoint:</span>
                                        <span className="ml-2 font-medium">{api.apiEndpoint}</span>
                                    </div>
                                    <div>
                                        <span className="text-gray-500">Method:</span>
                                        <span className="ml-2 font-medium">{api.apiMethod}</span>
                                    </div>
                                </div>

                                {/* Callback URL */}
                                <div className="mt-3 pt-3 border-t">
                                    <div className="text-xs text-gray-500 mb-1">Callback URL (for payment gateway):</div>
                                    <div className="flex items-center gap-2">
                                        <code className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded font-mono flex-1 truncate">
                                            {getCallbackUrl(api)}
                                        </code>
                                        <button
                                            onClick={() => {
                                                navigator.clipboard.writeText(getCallbackUrl(api));
                                                toast.showSuccess('Callback URL copied!');
                                            }}
                                            className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
                                        >
                                            Copy
                                        </button>
                                    </div>
                                </div>

                                <button
                                    onClick={() => handleEdit(api)}
                                    className="flex-1 px-3 py-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 text-sm font-medium"
                                >
                                    Edit
                                </button>
                                <button
                                    onClick={() => handleDelete(api.id, api.apiName)}
                                    className="flex-1 px-3 py-2 bg-red-100 text-red-700 rounded hover:bg-red-200 text-sm font-medium"
                                >
                                    Delete
                                </button>
                            </div>
                        ))
                    )}
                </div>

                {/* Modal */}
                {showModal && (
                    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                        <div className="bg-white rounded-xl p-8 w-full max-w-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
                            <h2 className="text-2xl font-bold mb-6">{editingApi ? 'Edit' : 'Submit'} API Configuration</h2>
                            <form onSubmit={handleSubmit} className="space-y-4">
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">API Name *</label>
                                    <input
                                        type="text"
                                        value={formData.apiName}
                                        onChange={(e) => setFormData({ ...formData, apiName: e.target.value })}
                                        className="w-full px-4 py-2 border rounded-lg"
                                        placeholder="My Payment Gateway"
                                        required
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">Base URL *</label>
                                    <input
                                        type="url"
                                        value={formData.apiBaseUrl}
                                        onChange={(e) => setFormData({ ...formData, apiBaseUrl: e.target.value })}
                                        className="w-full px-4 py-2 border rounded-lg"
                                        placeholder="https://api.gateway.com"
                                        required
                                    />
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-sm font-semibold text-gray-700 mb-2">Endpoint *</label>
                                        <input
                                            type="text"
                                            value={formData.apiEndpoint}
                                            onChange={(e) => setFormData({ ...formData, apiEndpoint: e.target.value })}
                                            className="w-full px-4 py-2 border rounded-lg"
                                            placeholder="/api/transfer"
                                            required
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-semibold text-gray-700 mb-2">Method</label>
                                        <select
                                            value={formData.apiMethod}
                                            onChange={(e) => setFormData({ ...formData, apiMethod: e.target.value })}
                                            className="w-full px-4 py-2 border rounded-lg"
                                        >
                                            <option value="POST">POST</option>
                                            <option value="GET">GET</option>
                                            <option value="PUT">PUT</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-sm font-semibold text-gray-700 mb-2">API Type</label>
                                        <select
                                            value={formData.apiType}
                                            onChange={(e) => setFormData({ ...formData, apiType: e.target.value })}
                                            className="w-full px-4 py-2 border rounded-lg"
                                        >
                                            <option value="PAYOUT">Payout</option>
                                            <option value="PAYIN">PayIn</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-semibold text-gray-700 mb-2">Auth Type</label>
                                        <select
                                            value={formData.authType}
                                            onChange={(e) => setFormData({ ...formData, authType: e.target.value })}
                                            className="w-full px-4 py-2 border rounded-lg"
                                        >
                                            <option value="bearer">Bearer Token</option>
                                            <option value="basic">Basic Auth</option>
                                            <option value="apikey">API Key</option>
                                        </select>
                                    </div>
                                </div>

                                {formData.authType === 'bearer' && (
                                    <div>
                                        <label className="block text-sm font-semibold text-gray-700 mb-2">Bearer Token</label>
                                        <input
                                            type="text"
                                            value={formData.apiKey}
                                            onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                                            className="w-full px-4 py-2 border rounded-lg font-mono text-sm"
                                            placeholder="your_bearer_token"
                                        />
                                    </div>
                                )}

                                {formData.authType === 'basic' && (
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-semibold text-gray-700 mb-2">Username</label>
                                            <input
                                                type="text"
                                                value={formData.apiKey}
                                                onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                                                className="w-full px-4 py-2 border rounded-lg"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-semibold text-gray-700 mb-2">Password</label>
                                            <input
                                                type="password"
                                                value={formData.apiSecret}
                                                onChange={(e) => setFormData({ ...formData, apiSecret: e.target.value })}
                                                className="w-full px-4 py-2 border rounded-lg"
                                            />
                                        </div>
                                    </div>
                                )}

                                {formData.authType === 'apikey' && (
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-semibold text-gray-700 mb-2">Header Name</label>
                                            <input
                                                type="text"
                                                value={formData.authHeader}
                                                onChange={(e) => setFormData({ ...formData, authHeader: e.target.value })}
                                                className="w-full px-4 py-2 border rounded-lg"
                                                placeholder="X-API-Key"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-semibold text-gray-700 mb-2">API Key</label>
                                            <input
                                                type="text"
                                                value={formData.apiKey}
                                                onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                                                className="w-full px-4 py-2 border rounded-lg"
                                            />
                                        </div>
                                    </div>
                                )}

                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">Status Check URL (Optional)</label>
                                    <input
                                        type="url"
                                        value={formData.statusCheckUrl}
                                        onChange={(e) => setFormData({ ...formData, statusCheckUrl: e.target.value })}
                                        className="w-full px-4 py-2 border rounded-lg"
                                        placeholder="https://api.gateway.com/status"
                                    />
                                    <p className="text-xs text-gray-500 mt-1">URL to check transaction status from your provider</p>
                                </div>

                                <div className="flex gap-3 pt-4">
                                    <button
                                        type="button"
                                        onClick={() => { setShowModal(false); resetForm(); }}
                                        className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        type="submit"
                                        disabled={submitting}
                                        className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
                                    >
                                        {submitting ? 'Submitting...' : editingApi ? 'Update' : 'Submit for Review'}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                )}
            </div>
        </>
    );
}

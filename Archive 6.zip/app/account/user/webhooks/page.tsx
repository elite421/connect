'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

interface Webhook {
  id: string;
  webhookUrl: string;
  webhookSecret: string;
  merchantId: string | null;
  merchantName: string | null;
  events: string[];
  retryCount: number;
  retryDelay: number;
  isActive: boolean;
  createdAt: string;
}

interface Merchant {
  id: string;
  merchantName: string;
}

const AVAILABLE_EVENTS = [
  'payment.success',
  'payment.failed',
  'payment.pending',
  'payout.success',
  'payout.failed',
  'payout.pending',
  'refund.success',
  'refund.failed',
  'settlement.completed',
  'dispute.created',
];

export default function WebhooksPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [webhooks, setWebhooks] = useState<Webhook[]>([]);
  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedWebhook, setSelectedWebhook] = useState<Webhook | null>(null);
  const [formData, setFormData] = useState({
    webhookUrl: '',
    merchantId: '',
    events: ['payment.success', 'payment.failed', 'payout.success', 'payout.failed'],
    retryCount: '3',
    retryDelay: '300',
  });

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if ((session?.user as any)?.role !== 'USER') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') {
      fetchWebhooks();
      fetchMerchants();
    }
  }, [session, status]);

  const fetchWebhooks = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/user/webhooks');
      const data = await response.json();
      if (data.success) setWebhooks(data.data);
    } catch (error) {
      console.error('Failed to fetch webhooks:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMerchants = async () => {
    try {
      const response = await fetch('/api/user/merchants');
      const data = await response.json();
      if (data.success) setMerchants(data.data);
    } catch (error) {
      console.error('Failed to fetch merchants:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const method = selectedWebhook ? 'PATCH' : 'POST';
      const body = selectedWebhook 
        ? { id: selectedWebhook.id, ...formData, retryCount: parseInt(formData.retryCount), retryDelay: parseInt(formData.retryDelay) }
        : { ...formData, retryCount: parseInt(formData.retryCount), retryDelay: parseInt(formData.retryDelay) };

      const response = await fetch('/api/user/webhooks', {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await response.json();
      if (data.success) {
        if (!selectedWebhook && data.data?.webhookSecret) {
          alert(`Webhook Created!

Webhook Secret: ${data.data.webhookSecret}

Save this secret - you won't see it again!`);
        } else {
          alert('Webhook updated!');
        }
        setShowModal(false);
        resetForm();
        fetchWebhooks();
      } else {
        alert(data.error);
      }
    } catch (error) {
      alert('Failed to save webhook');
    }
  };

  const handleDelete = async (webhook: Webhook) => {
    if (!confirm('Delete this webhook?')) return;
    try {
      const response = await fetch(`/api/user/webhooks?id=${webhook.id}`, { method: 'DELETE' });
      if (response.ok) fetchWebhooks();
    } catch (error) {
      alert('Failed to delete webhook');
    }
  };

  const handleToggle = async (webhook: Webhook) => {
    try {
      await fetch('/api/user/webhooks', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: webhook.id, isActive: !webhook.isActive }),
      });
      fetchWebhooks();
    } catch (error) {
      alert('Failed to toggle webhook');
    }
  };

  const openEditModal = (webhook: Webhook) => {
    setSelectedWebhook(webhook);
    setFormData({
      webhookUrl: webhook.webhookUrl,
      merchantId: webhook.merchantId || '',
      events: webhook.events || [],
      retryCount: String(webhook.retryCount),
      retryDelay: String(webhook.retryDelay),
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      webhookUrl: '',
      merchantId: '',
      events: ['payment.success', 'payment.failed', 'payout.success', 'payout.failed'],
      retryCount: '3',
      retryDelay: '300',
    });
    setSelectedWebhook(null);
  };

  const toggleEvent = (event: string) => {
    setFormData(prev => ({
      ...prev,
      events: prev.events.includes(event)
        ? prev.events.filter(e => e !== event)
        : [...prev.events, event]
    }));
  };

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Webhook Configuration</h1>
          <p className="text-gray-600 mt-2">Configure webhooks for real-time event notifications</p>
        </div>
        <button onClick={() => { resetForm(); setShowModal(true); }} className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
          + Add Webhook
        </button>
      </div>

      <div className="bg-gradient-to-r from-green-50 to-teal-50 border border-green-200 p-6 rounded-xl">
        <div className="flex items-start gap-3">
          <div className="text-2xl">🔔</div>
          <div>
            <h3 className="font-semibold text-green-900 mb-2">Webhook Notifications</h3>
            <p className="text-sm text-green-800">Receive real-time HTTP POST notifications for payment events. Configure retry policies and filter events by type.</p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {webhooks.length === 0 ? (
          <div className="bg-white p-12 rounded-lg border text-center text-gray-500">
            No webhooks configured yet. Add your first webhook to receive event notifications.
          </div>
        ) : (
          webhooks.map((webhook) => (
            <div key={webhook.id} className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <code className="text-sm bg-gray-100 px-2 py-1 rounded break-all">{webhook.webhookUrl}</code>
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${webhook.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {webhook.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  {webhook.merchantName && (
                    <p className="text-sm text-gray-500">Merchant: {webhook.merchantName}</p>
                  )}
                </div>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-4">
                {webhook.events?.map((event) => (
                  <span key={event} className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full">{event}</span>
                ))}
              </div>

              <div className="flex items-center justify-between text-sm text-gray-500">
                <div>Retry: {webhook.retryCount}x | Delay: {webhook.retryDelay}s</div>
                <div className="flex gap-2">
                  <button onClick={() => handleToggle(webhook)} className={`px-3 py-1 rounded text-sm font-medium ${webhook.isActive ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}>
                    {webhook.isActive ? 'Disable' : 'Enable'}
                  </button>
                  <button onClick={() => openEditModal(webhook)} className="px-3 py-1 bg-blue-100 text-blue-700 rounded text-sm font-medium">Edit</button>
                  <button onClick={() => handleDelete(webhook)} className="px-3 py-1 bg-red-100 text-red-700 rounded text-sm font-medium">Delete</button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6">{selectedWebhook ? 'Edit Webhook' : 'Add Webhook'}</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Webhook URL *</label>
                <input type="url" value={formData.webhookUrl} onChange={(e) => setFormData({...formData, webhookUrl: e.target.value})} className="w-full px-4 py-2 border rounded-lg" placeholder="https://your-server.com/webhook" required />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Merchant (Optional)</label>
                <select value={formData.merchantId} onChange={(e) => setFormData({...formData, merchantId: e.target.value})} className="w-full px-4 py-2 border rounded-lg">
                  <option value="">All Merchants</option>
                  {merchants.map(m => <option key={m.id} value={m.id}>{m.merchantName}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Events</label>
                <div className="grid grid-cols-2 gap-2">
                  {AVAILABLE_EVENTS.map(event => (
                    <label key={event} className="flex items-center gap-2 text-sm">
                      <input type="checkbox" checked={formData.events.includes(event)} onChange={() => toggleEvent(event)} className="rounded" />
                      {event}
                    </label>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Retry Count</label>
                  <input type="number" value={formData.retryCount} onChange={(e) => setFormData({...formData, retryCount: e.target.value})} className="w-full px-4 py-2 border rounded-lg" min="0" max="10" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Retry Delay (seconds)</label>
                  <input type="number" value={formData.retryDelay} onChange={(e) => setFormData({...formData, retryDelay: e.target.value})} className="w-full px-4 py-2 border rounded-lg" min="60" max="3600" />
                </div>
              </div>
              <div className="flex gap-3 pt-4">
                <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-medium">{selectedWebhook ? 'Update' : 'Create'}</button>
                <button type="button" onClick={() => { setShowModal(false); resetForm(); }} className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

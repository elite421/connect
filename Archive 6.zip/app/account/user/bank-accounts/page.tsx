'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';

interface BankAccount {
  id: string;
  accountHolderName: string;
  accountNumber: string;
  ifscCode: string;
  bankName: string;
  branchName: string | null;
  accountType: string;
  isPrimary: boolean;
  isVerified: boolean;
  isActive: boolean;
  createdAt: string;
}

export default function BankAccountsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    accountHolderName: '',
    accountNumber: '',
    ifscCode: '',
    bankName: '',
    branchName: '',
    accountType: 'current',
    isPrimary: false,
  });

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if ((session?.user as any)?.role !== 'USER') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') fetchAccounts();
  }, [session, status]);

  const fetchAccounts = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/user/bank-accounts');
      const data = await response.json();
      if (data.success) setAccounts(data.data);
    } catch (error) {
      console.error('Failed to fetch bank accounts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/user/bank-accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      if (data.success) {
        alert('Bank account added successfully!');
        setShowModal(false);
        setFormData({ accountHolderName: '', accountNumber: '', ifscCode: '', bankName: '', branchName: '', accountType: 'current', isPrimary: false });
        fetchAccounts();
      } else {
        alert(data.error);
      }
    } catch (error) {
      alert('Failed to add bank account');
    }
  };

  const handleSetPrimary = async (account: BankAccount) => {
    try {
      await fetch('/api/user/bank-accounts', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: account.id, isPrimary: true }),
      });
      fetchAccounts();
    } catch (error) {
      alert('Failed to set primary');
    }
  };

  const handleDelete = async (account: BankAccount) => {
    if (!confirm(`Delete bank account ending in ${account.accountNumber.slice(-4)}?`)) return;
    try {
      await fetch(`/api/user/bank-accounts?id=${account.id}`, { method: 'DELETE' });
      fetchAccounts();
    } catch (error) {
      alert('Failed to delete account');
    }
  };

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Bank Accounts</h1>
          <p className="text-gray-600 mt-2">Manage bank accounts for settlements and payouts</p>
        </div>
        <button onClick={() => setShowModal(true)} className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
          + Add Bank Account
        </button>
      </div>

      <div className="bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200 p-6 rounded-xl">
        <div className="flex items-start gap-3">
          <div className="text-2xl">🏦</div>
          <div>
            <h3 className="font-semibold text-blue-900 mb-2">Bank Account Management</h3>
            <p className="text-sm text-blue-800">Add your bank accounts for receiving settlements. Set a primary account for automatic settlements. Accounts will be verified before activation.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {accounts.length === 0 ? (
          <div className="col-span-full bg-white p-12 rounded-lg border text-center text-gray-500">
            No bank accounts added yet. Add your first bank account to receive settlements.
          </div>
        ) : (
          accounts.map((account) => (
            <div key={account.id} className={`bg-white p-6 rounded-lg border-2 ${account.isPrimary ? 'border-blue-500' : 'border-gray-200'} shadow-sm`}>
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-semibold text-gray-900">{account.bankName}</h3>
                  <p className="text-sm text-gray-500">{account.branchName || 'Branch not specified'}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  {account.isPrimary && (
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full font-semibold">Primary</span>
                  )}
                  <span className={`px-2 py-1 text-xs rounded-full font-semibold ${account.isVerified ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                    {account.isVerified ? 'Verified' : 'Pending'}
                  </span>
                </div>
              </div>
              
              <div className="space-y-2 text-sm mb-4">
                <div><span className="text-gray-500">Holder:</span> <span className="font-medium">{account.accountHolderName}</span></div>
                <div><span className="text-gray-500">A/C:</span> <span className="font-mono">****{account.accountNumber.slice(-4)}</span></div>
                <div><span className="text-gray-500">IFSC:</span> <span className="font-mono">{account.ifscCode}</span></div>
                <div><span className="text-gray-500">Type:</span> <span className="capitalize">{account.accountType}</span></div>
              </div>

              <div className="flex gap-2">
                {!account.isPrimary && (
                  <button onClick={() => handleSetPrimary(account)} className="flex-1 px-3 py-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 text-sm font-medium">Set Primary</button>
                )}
                <button onClick={() => handleDelete(account)} className="flex-1 px-3 py-2 bg-red-100 text-red-700 rounded hover:bg-red-200 text-sm font-medium">Delete</button>
              </div>
            </div>
          ))
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-md shadow-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6">Add Bank Account</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Account Holder Name *</label>
                <input type="text" value={formData.accountHolderName} onChange={(e) => setFormData({...formData, accountHolderName: e.target.value})} className="w-full px-4 py-2 border rounded-lg" required />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Account Number *</label>
                <input type="text" value={formData.accountNumber} onChange={(e) => setFormData({...formData, accountNumber: e.target.value})} className="w-full px-4 py-2 border rounded-lg" required />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">IFSC Code *</label>
                <input type="text" value={formData.ifscCode} onChange={(e) => setFormData({...formData, ifscCode: e.target.value.toUpperCase()})} className="w-full px-4 py-2 border rounded-lg" placeholder="SBIN0001234" required />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Bank Name *</label>
                <input type="text" value={formData.bankName} onChange={(e) => setFormData({...formData, bankName: e.target.value})} className="w-full px-4 py-2 border rounded-lg" required />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Branch Name</label>
                <input type="text" value={formData.branchName} onChange={(e) => setFormData({...formData, branchName: e.target.value})} className="w-full px-4 py-2 border rounded-lg" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Account Type</label>
                <select value={formData.accountType} onChange={(e) => setFormData({...formData, accountType: e.target.value})} className="w-full px-4 py-2 border rounded-lg">
                  <option value="current">Current Account</option>
                  <option value="savings">Savings Account</option>
                </select>
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" checked={formData.isPrimary} onChange={(e) => setFormData({...formData, isPrimary: e.target.checked})} className="rounded" />
                <label className="text-sm text-gray-700">Set as primary account for settlements</label>
              </div>
              <div className="flex gap-3 pt-4">
                <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-medium">Add Account</button>
                <button type="button" onClick={() => setShowModal(false)} className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

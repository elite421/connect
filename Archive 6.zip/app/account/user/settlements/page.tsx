'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { formatINR } from '@/lib/money';

interface Settlement {
  id: string;
  amount: number;
  fee: number;
  netAmount: number;
  settlementType: string;
  bankName: string | null;
  accountNumber: string | null;
  utrNumber: string | null;
  status: string;
  settledAt: string | null;
  createdAt: string;
}

interface BankAccount {
  id: string;
  bankName: string;
  accountNumber: string;
  isPrimary: boolean;
}

export default function SettlementsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [settlements, setSettlements] = useState<Settlement[]>([]);
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [stats, setStats] = useState({ total_count: 0, total_settled: 0, pending_amount: 0 });
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({ amount: '', bankAccountId: '' });

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if ((session?.user as any)?.role !== 'USER') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') {
      fetchSettlements();
      fetchBankAccounts();
    }
  }, [session, status]);

  const fetchSettlements = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/user/settlements');
      const data = await response.json();
      if (data.success) {
        setSettlements(data.data);
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Failed to fetch settlements:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchBankAccounts = async () => {
    try {
      const response = await fetch('/api/user/bank-accounts');
      const data = await response.json();
      if (data.success) setBankAccounts(data.data.filter((a: BankAccount) => a.isPrimary || true));
    } catch (error) {
      console.error('Failed to fetch bank accounts:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/user/settlements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: parseFloat(formData.amount),
          bankAccountId: formData.bankAccountId,
        }),
      });

      const data = await response.json();
      if (data.success) {
        alert('Settlement request created successfully!');
        setShowModal(false);
        setFormData({ amount: '', bankAccountId: '' });
        fetchSettlements();
      } else {
        alert(data.error);
      }
    } catch (error) {
      alert('Failed to create settlement');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'processing': return 'bg-blue-100 text-blue-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Settlements</h1>
          <p className="text-gray-600 mt-2">View settlement history and request new settlements</p>
        </div>
        <button onClick={() => setShowModal(true)} className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-medium">
          + Request Settlement
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="text-2xl font-bold text-green-600">{formatINR(Number(stats.total_settled))}</div>
          <div className="text-sm text-gray-600">Total Settled</div>
        </div>
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="text-2xl font-bold text-yellow-600">{formatINR(Number(stats.pending_amount))}</div>
          <div className="text-sm text-gray-600">Pending Amount</div>
        </div>
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-2xl font-bold text-blue-600">{Number(stats.total_count)}</div>
          <div className="text-sm text-gray-600">Total Settlements</div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 p-6 rounded-xl">
        <div className="flex items-start gap-3">
          <div className="text-2xl">💰</div>
          <div>
            <h3 className="font-semibold text-emerald-900 mb-2">Settlement Information</h3>
            <p className="text-sm text-emerald-800">Settlements are processed within 24-48 hours. A 0.5% fee (minimum ₹5) is charged per settlement. Auto-settlements can be configured for daily or weekly transfers.</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Amount</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Fee</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Net Amount</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Bank</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Type</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">UTR</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {settlements.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-4 py-12 text-center text-gray-500">
                  No settlements yet. Request your first settlement when you have funds.
                </td>
              </tr>
            ) : (
              settlements.map((s) => (
                <tr key={s.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm">{new Date(s.createdAt).toLocaleDateString()}</td>
                  <td className="px-4 py-3 font-semibold">{formatINR(s.amount)}</td>
                  <td className="px-4 py-3 text-sm text-red-600">-{formatINR(s.fee)}</td>
                  <td className="px-4 py-3 font-semibold text-green-600">{formatINR(s.netAmount)}</td>
                  <td className="px-4 py-3 text-sm">
                    {s.bankName ? `${s.bankName} (****${s.accountNumber?.slice(-4)})` : 'N/A'}
                  </td>
                  <td className="px-4 py-3 text-sm capitalize">{s.settlementType}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(s.status)}`}>
                      {s.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm font-mono">{s.utrNumber || '-'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-md shadow-2xl">
            <h2 className="text-2xl font-bold mb-6">Request Settlement</h2>
            {bankAccounts.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">You need to add a bank account first</p>
                <button onClick={() => router.push('/account/user/bank-accounts')} className="px-4 py-2 bg-blue-600 text-white rounded-lg">
                  Add Bank Account
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Amount (₹) *</label>
                  <input type="number" value={formData.amount} onChange={(e) => setFormData({ ...formData, amount: e.target.value })} className="w-full px-4 py-2 border rounded-lg" placeholder="10000" min="100" required />
                  {formData.amount && (
                    <p className="text-xs text-gray-500 mt-1">
                      Fee: {formatINR(Math.max((parseInt(formData.amount) * 0.005), 5))} | Net: {formatINR(parseInt(formData.amount) - Math.max((parseInt(formData.amount) * 0.005), 5))}
                    </p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Bank Account *</label>
                  <select value={formData.bankAccountId} onChange={(e) => setFormData({ ...formData, bankAccountId: e.target.value })} className="w-full px-4 py-2 border rounded-lg" required>
                    <option value="">Select bank account</option>
                    {bankAccounts.map(a => (
                      <option key={a.id} value={a.id}>
                        {a.bankName} (****{a.accountNumber.slice(-4)}) {a.isPrimary ? '(Primary)' : ''}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex gap-3 pt-4">
                  <button type="submit" className="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 font-medium">Request Settlement</button>
                  <button type="button" onClick={() => setShowModal(false)} className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium">Cancel</button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

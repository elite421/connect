'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useGlobalToast } from '@/context/ToastContext';

interface ApiKey {
  id: string;
  name: string;
  keyValue: string;
  isActive: boolean;
  permissions: string[];
  expiresAt: string | null;
  lastUsedAt: string | null;
  requestCount: number;
  createdAt: string;
}

interface ApiLog {
  id: string;
  method: string;
  endpoint: string;
  statusCode: number | null;
  responseTime: number | null;
  ipAddress: string | null;
  error: string | null;
  createdAt: string;
  apiKey: { name: string };
}

interface Webhook {
  id: string;
  url: string;
  events: string[];
  isActive: boolean;
  secret: string;
  createdAt: string;
}

interface IpWhitelistEntry {
  id: string;
  ipAddress: string;
  label: string | null;
  isActive: boolean;
  createdAt: string;
}

export default function DeveloperPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [apiLogs, setApiLogs] = useState<ApiLog[]>([]);
  const [webhooks, setWebhooks] = useState<Webhook[]>([]);
  const [ipWhitelist, setIpWhitelist] = useState<IpWhitelistEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showWebhookModal, setShowWebhookModal] = useState(false);
  const [showCopyAlert, setShowCopyAlert] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'keys' | 'docs' | 'callbacks' | 'test' | 'logs' | 'ip'>('keys');
  const [newIpAddress, setNewIpAddress] = useState('');
  const [newIpLabel, setNewIpLabel] = useState('');
  const [detectedIp, setDetectedIp] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    permissions: ['read', 'write'],
    expiresAt: '',
  });
  const [webhookForm, setWebhookForm] = useState({
    url: '',
    events: ['payout.success', 'payout.failed'],
  });
  const [testForm, setTestForm] = useState({
    apiKey: '',
    endpoint: '/api/v1/payout',
    method: 'POST',
    body: JSON.stringify({
      amount: 100,
      beneficiaryName: 'Test User',
      beneficiaryAccount: '1234567890',
      beneficiaryIfsc: 'SBIN0001234',
      transferMode: 'imps'
    }, null, 2)
  });
  const [testResponse, setTestResponse] = useState<string | null>(null);
  const [testLoading, setTestLoading] = useState(false);
  const [newKey, setNewKey] = useState<ApiKey | null>(null);

  const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';

  useEffect(() => {
    if (status === 'loading') return; // Wait for session to load
    if (status === 'unauthenticated') router.push('/login');
    if (status === 'authenticated' && (session?.user as { role?: string })?.role !== 'USER') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') {
      fetchApiKeys();
      fetchApiLogs();
      fetchWebhooks();
      fetchIpWhitelist();
      detectClientIp();
    }
  }, [session, status]);

  const fetchApiKeys = async () => {
    try {
      const response = await fetch('/api/user/api-keys');
      const data = await response.json();
      if (data.success) setApiKeys(data.data);
    } catch {
      toast.showError('Failed to load API keys');
    }
  };

  const fetchApiLogs = async () => {
    try {
      const response = await fetch('/api/user/api-logs');
      const data = await response.json();
      if (data.success) setApiLogs(data.data);
    } finally {
      setLoading(false);
    }
  };

  const fetchWebhooks = async () => {
    try {
      const response = await fetch('/api/user/webhooks');
      const data = await response.json();
      if (data.success) setWebhooks(data.data || []);
    } catch {
      // Webhooks API might not exist yet
    }
  };

  const fetchIpWhitelist = async () => {
    try {
      const response = await fetch('/api/user/ip-whitelist');
      const data = await response.json();
      if (data.success) setIpWhitelist(data.data || []);
    } catch {
      // IP whitelist API might fail
    }
  };

  const detectClientIp = async () => {
    try {
      // Use external service to detect public IP
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      setDetectedIp(data.ip);
    } catch {
      setDetectedIp(null);
    }
  };

  const handleAddIp = async (ipAddress: string, label: string) => {
    if (!ipAddress.trim()) {
      toast.showError('IP address is required');
      return;
    }
    try {
      const response = await fetch('/api/user/ip-whitelist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ipAddress: ipAddress.trim(), label: label.trim() || null }),
      });
      const data = await response.json();
      if (data.success) {
        toast.showSuccess('IP added to whitelist');
        setNewIpAddress('');
        setNewIpLabel('');
        fetchIpWhitelist();
      } else {
        toast.showError(data.error || 'Failed to add IP');
      }
    } catch {
      toast.showError('Failed to add IP');
    }
  };

  const handleToggleIp = async (id: string, isActive: boolean) => {
    try {
      const response = await fetch('/api/user/ip-whitelist', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, isActive: !isActive }),
      });
      const data = await response.json();
      if (data.success) {
        toast.showSuccess(isActive ? 'IP disabled' : 'IP enabled');
        fetchIpWhitelist();
      } else {
        toast.showError(data.error || 'Failed to toggle IP');
      }
    } catch {
      toast.showError('Failed to toggle IP');
    }
  };

  const handleDeleteIp = async (id: string) => {
    if (!confirm('Remove this IP from whitelist?')) return;
    try {
      const response = await fetch(`/api/user/ip-whitelist?id=${id}`, { method: 'DELETE' });
      const data = await response.json();
      if (data.success) {
        toast.showSuccess('IP removed from whitelist');
        fetchIpWhitelist();
      } else {
        toast.showError(data.error || 'Failed to delete IP');
      }
    } catch {
      toast.showError('Failed to delete IP');
    }
  };

  const handleCreateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/user/api-keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          permissions: formData.permissions,
          expiresAt: formData.expiresAt || null,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setNewKey(data.data);
        setFormData({ name: '', permissions: ['read', 'write'], expiresAt: '' });
        toast.showSuccess('API key created successfully');
        setTimeout(() => {
          setShowCreateModal(false);
          fetchApiKeys();
          setNewKey(null);
        }, 3000);
      } else {
        toast.showError(data.error || 'Failed to create API key');
      }
    } catch {
      toast.showError('Failed to create API key');
    }
  };

  const handleDeleteKey = async (id: string) => {
    if (!confirm('Delete this API key? This action cannot be undone.')) return;
    try {
      const response = await fetch(`/api/user/api-keys?id=${id}`, { method: 'DELETE' });
      const data = await response.json();
      if (data.success) {
        toast.showSuccess('API key deleted');
        fetchApiKeys();
      } else {
        toast.showError(data.error || 'Failed to delete API key');
      }
    } catch {
      toast.showError('Failed to delete API key');
    }
  };

  const handleToggleKey = async (id: string, isActive: boolean) => {
    try {
      const response = await fetch('/api/user/api-keys', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, isActive: !isActive }),
      });
      const data = await response.json();
      if (data.success) {
        toast.showSuccess(isActive ? 'API key deactivated' : 'API key activated');
        fetchApiKeys();
      } else {
        toast.showError(data.error || 'Failed to toggle API key');
      }
    } catch {
      toast.showError('Failed to toggle API key');
    }
  };

  const handleCreateWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/user/webhooks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(webhookForm),
      });
      const data = await response.json();
      if (data.success) {
        toast.showSuccess('Webhook created successfully');
        setShowWebhookModal(false);
        setWebhookForm({ url: '', events: ['payout.success', 'payout.failed'] });
        fetchWebhooks();
      } else {
        toast.showError(data.error || 'Failed to create webhook');
      }
    } catch {
      toast.showError('Failed to create webhook');
    }
  };

  const handleTestApi = async () => {
    if (!testForm.apiKey) {
      toast.showError('Please select an API key');
      return;
    }

    setTestLoading(true);
    setTestResponse(null);

    try {
      // Determine method based on endpoint to strictly prevent 405s
      const effectiveMethod = testForm.endpoint.includes('balance') ? 'GET' : 'POST';

      const response = await fetch(testForm.endpoint, {
        method: effectiveMethod,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${testForm.apiKey}`,
        },
        body: effectiveMethod !== 'GET' ? testForm.body : undefined,
      });

      const data = await response.json();
      setTestResponse(JSON.stringify(data, null, 2));
    } catch (error: any) {
      setTestResponse(JSON.stringify({ error: error.message }, null, 2));
    } finally {
      setTestLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setShowCopyAlert(text.substring(0, 10));
    toast.showSuccess('Copied to clipboard!');
    setTimeout(() => setShowCopyAlert(null), 2000);
  };

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">🔧 Developer Portal</h1>
          <p className="text-gray-600 mt-2">Manage API keys, view documentation, and configure webhooks</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
        >
          + Generate API Key
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b overflow-x-auto">
        {[
          { id: 'keys', label: '🔑 API Keys', count: apiKeys.length },
          { id: 'ip', label: '🔒 IP Whitelist', count: ipWhitelist.length },
          { id: 'docs', label: '📖 Documentation' },
          { id: 'callbacks', label: '🔗 Callbacks', count: webhooks.length },
          { id: 'test', label: '🧪 Test API' },
          { id: 'logs', label: '📊 Logs', count: apiLogs.length },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 font-medium border-b-2 transition-colors whitespace-nowrap ${activeTab === tab.id
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
          >
            {tab.label} {tab.count !== undefined && `(${tab.count})`}
          </button>
        ))}
      </div>

      {/* API Keys Tab */}
      {activeTab === 'keys' && (
        <div className="space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              🔐 Use API keys to authenticate requests. Keep them secure and never share publicly.
            </p>
          </div>
          {apiKeys.length === 0 ? (
            <div className="bg-white p-12 rounded-lg border text-center text-gray-500">
              No API keys yet. Create one to get started.
            </div>
          ) : (
            apiKeys.map((key) => (
              <div key={key.id} className="bg-white p-6 rounded-lg border shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">{key.name}</h3>
                    <code className="text-xs text-gray-500">{key.keyValue}</code>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${key.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {key.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => copyToClipboard(key.keyValue)} className="flex-1 px-3 py-2 bg-blue-100 text-blue-700 rounded text-sm">📋 Copy</button>
                  <button onClick={() => handleToggleKey(key.id, key.isActive)} className="flex-1 px-3 py-2 bg-yellow-100 text-yellow-700 rounded text-sm">{key.isActive ? '⏸ Disable' : '▶ Enable'}</button>
                  <button onClick={() => handleDeleteKey(key.id)} className="flex-1 px-3 py-2 bg-red-100 text-red-700 rounded text-sm">🗑 Delete</button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Documentation Tab */}
      {activeTab === 'docs' && (
        <div className="space-y-6">
          <div className="bg-white rounded-lg border p-6">
            <h2 className="text-xl font-bold mb-4">🚀 API Documentation</h2>

            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-semibold mb-2">Base URL</h3>
              <code className="bg-gray-800 text-green-400 px-4 py-2 rounded block">{baseUrl}/api/v1</code>
            </div>

            <div className="mb-6">
              <h3 className="font-semibold mb-2">Authentication</h3>
              <p className="text-gray-600 mb-2">All API requests require a Bearer token in the Authorization header:</p>
              <code className="bg-gray-800 text-green-400 px-4 py-2 rounded block">
                Authorization: Bearer YOUR_API_KEY
              </code>
            </div>

            <div className="space-y-6">
              <div className="border rounded-lg p-4">
                <h3 className="font-semibold text-lg mb-2">💸 Create Payout</h3>
                <p className="text-gray-600 mb-4">Initiate a payout to a beneficiary account</p>
                <div className="bg-gray-800 rounded-lg p-4 text-sm overflow-x-auto">
                  <div className="text-purple-400 mb-2">POST /api/v1/payout</div>
                  <pre className="text-green-400">{`{
  "amount": 1000,
  "beneficiaryName": "John Doe",
  "beneficiaryAccount": "1234567890",
  "beneficiaryIfsc": "SBIN0001234",
  "transferMode": "imps"  // imps, neft, rtgs, upi
}`}</pre>
                </div>
                <div className="mt-4">
                  <h4 className="font-medium mb-2">Response:</h4>
                  <pre className="bg-gray-100 p-3 rounded text-sm">{`{
  "success": true,
  "transactionId": "TXN123456",
  "status": "processing",
  "utr": "UTR123456789"
}`}</pre>
                </div>
              </div>

              <div className="border rounded-lg p-4">
                <h3 className="font-semibold text-lg mb-2">📥 Check Transaction Status</h3>
                <div className="bg-gray-800 rounded-lg p-4 text-sm">
                  <div className="text-purple-400 mb-2">GET /api/v1/transaction/:id</div>
                  <pre className="text-green-400">{`// Response
{
  "success": true,
  "transaction": {
    "id": "TXN123456",
    "status": "success",
    "amount": 1000,
    "utr": "UTR123456789",
    "createdAt": "2024-12-24T10:00:00Z"
  }
}`}</pre>
                </div>
              </div>

              <div className="border rounded-lg p-4">
                <h3 className="font-semibold text-lg mb-2">💰 Check Wallet Balance</h3>
                <div className="bg-gray-800 rounded-lg p-4 text-sm">
                  <div className="text-purple-400 mb-2">GET /api/v1/wallet/balance</div>
                  <pre className="text-green-400">{`// Response
{
  "success": true,
  "balance": 50000,
  "currency": "INR"
}`}</pre>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <h4 className="font-semibold text-yellow-800 mb-2">📋 Code Examples</h4>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium mb-1">cURL:</p>
                  <pre className="bg-gray-800 text-green-400 p-3 rounded text-xs overflow-x-auto">{`curl -X POST ${baseUrl}/api/v1/payout \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"amount":1000,"beneficiaryName":"John","beneficiaryAccount":"123456","beneficiaryIfsc":"SBIN0001234","transferMode":"imps"}'`}</pre>
                </div>
                <div>
                  <p className="text-sm font-medium mb-1">Node.js:</p>
                  <pre className="bg-gray-800 text-green-400 p-3 rounded text-xs overflow-x-auto">{`const response = await fetch('${baseUrl}/api/v1/payout', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    amount: 1000,
    beneficiaryName: 'John Doe',
    beneficiaryAccount: '1234567890',
    beneficiaryIfsc: 'SBIN0001234',
    transferMode: 'imps'
  })
});
const data = await response.json();`}</pre>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Callbacks Tab */}
      {activeTab === 'callbacks' && (
        <div className="space-y-8">
          {/* Inbound Callback Section */}
          <div className="bg-white rounded-lg border p-6">
            <h3 className="text-lg font-semibold mb-4">🔗 Transaction Callback URL (Inbound)</h3>
            <p className="text-gray-600 mb-4">
              Use this URL to receive transaction updates from external payment gateways or websites. Configure this URL in your provider's settings to automatically update transaction statuses.
            </p>

            <div className="flex items-center gap-2 mb-6">
              <code className="flex-1 bg-gray-100 p-3 rounded font-mono text-sm border">
                {baseUrl}/api/v1/callbacks
              </code>
              <button
                onClick={() => copyToClipboard(`${baseUrl}/api/v1/callbacks`)}
                className="px-4 py-3 bg-blue-600 text-white rounded hover:bg-blue-700 font-medium whitespace-nowrap"
              >
                Copy URL
              </button>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium mb-2 text-sm text-gray-700">Expected JSON Payload</h4>
              <p className="text-xs text-gray-500 mb-3">
                Send a POST request with the following body. Support fields: <code>transactionId</code> (or <code>referenceId</code>), <code>status</code>, and <code>utr</code>.
              </p>
              <pre className="bg-gray-800 text-green-400 p-4 rounded text-sm overflow-x-auto font-mono">{`{
  "transactionId": "TXN_123456789",  // Required: The transaction ID from your system
  "status": "success",               // Required: success, completed, failed, rejected
  "utr": "123456789012",             // Optional: UTR or Bank Reference Number
  "externalId": "PAY_987654321",     // Optional: Gateway Transaction ID
  "failureReason": "Bank server down" // Optional: Reason for failure
}`}</pre>
            </div>
          </div>

          <div className="border-t pt-2"></div>

          {/* Outgoing Webhooks Section */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex-1 mr-4">
                <p className="text-sm text-blue-800">
                  🔔 <strong>Outgoing Webhooks</strong> notify <em>your</em> application when events occur here (e.g. payout success).
                </p>
              </div>
              <button
                onClick={() => setShowWebhookModal(true)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                + Add Webhook
              </button>
            </div>

            {webhooks.length === 0 ? (
              <div className="bg-white p-12 rounded-lg border text-center text-gray-500">
                No outgoing webhooks configured.
              </div>
            ) : (
              webhooks.map((webhook) => (
                <div key={webhook.id} className="bg-white p-6 rounded-lg border shadow-sm">
                  <div className="flex justify-between items-start">
                    <div>
                      <code className="text-sm font-medium bg-gray-100 px-2 py-1 rounded">{webhook.url}</code>
                      <div className="mt-2 flex gap-2">
                        {webhook.events.map((event) => (
                          <span key={event} className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">{event}</span>
                        ))}
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${webhook.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {webhook.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </div>
              ))
            )}

            <div className="bg-gray-50 rounded-lg p-4 mt-6">
              <h4 className="font-semibold mb-2">Outgoing Webhook Payload Example</h4>
              <pre className="bg-gray-800 text-green-400 p-4 rounded text-sm">{`{
  "event": "payout.success",
  "data": {
    "transactionId": "TXN123456",
    "amount": 1000,
    "status": "success",
    "utr": "UTR123456789",
    "beneficiaryName": "John Doe"
  },
  "timestamp": "2024-12-24T10:00:00Z"
}`}</pre>
            </div>
          </div>
        </div>
      )}

      {/* Test API Tab */}
      {activeTab === 'test' && (
        <div className="space-y-4">
          <div className="bg-white rounded-lg border p-6">
            <h2 className="text-xl font-bold mb-4">🧪 API Tester</h2>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-1">API Key</label>
                <input
                  type="text"
                  value={testForm.apiKey}
                  onChange={(e) => setTestForm({ ...testForm, apiKey: e.target.value })}
                  className="w-full px-3 py-2 border rounded-lg"
                  placeholder="sk_..."
                />
                <p className="text-xs text-red-500 mt-1 font-medium">
                  Important: Use a newly generated, full API Key. Keys copied from the list above are masked (e.g. sk_12...) and will NOT work (401 Unauthorized).
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Endpoint</label>
                <select
                  value={testForm.endpoint}
                  onChange={(e) => {
                    const ep = e.target.value;
                    const method = ep.includes('balance') ? 'GET' : 'POST';
                    setTestForm({ ...testForm, endpoint: ep, method });
                  }}
                  className="w-full px-3 py-2 border rounded-lg"
                >
                  <option value="/api/v1/payout">POST /api/v1/payout</option>
                  <option value="/api/v1/wallet/balance">GET /api/v1/wallet/balance</option>
                </select>
              </div>
            </div>
            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Request Body (JSON)</label>
              <textarea
                value={testForm.body}
                onChange={(e) => setTestForm({ ...testForm, body: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg font-mono text-sm"
                rows={8}
              />
            </div>
            <button
              onClick={handleTestApi}
              disabled={testLoading}
              className="w-full py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
            >
              {testLoading ? 'Testing...' : '▶ Execute Request'}
            </button>
            {testResponse && (
              <div className="mt-4">
                <label className="block text-sm font-medium mb-1">Response</label>
                <pre className="bg-gray-800 text-green-400 p-4 rounded text-sm overflow-x-auto">{testResponse}</pre>
              </div>
            )}
          </div>
        </div>
      )}

      {/* IP Whitelist Tab */}
      {activeTab === 'ip' && (
        <div className="space-y-4">
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-sm text-red-800 font-medium">
              ⚠️ API requests will be <strong>rejected</strong> from non-whitelisted IPs. Add at least one IP to use the API.
            </p>
          </div>

          {/* Add IP Form */}
          <div className="bg-white rounded-lg border p-6">
            <h3 className="font-semibold mb-4">Add IP Address</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">IP Address</label>
                <input
                  type="text"
                  value={newIpAddress}
                  onChange={(e) => setNewIpAddress(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg"
                  placeholder="192.168.1.1 or 10.0.0.0/24"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Label (Optional)</label>
                <input
                  type="text"
                  value={newIpLabel}
                  onChange={(e) => setNewIpLabel(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg"
                  placeholder="Office Server"
                />
              </div>
              <div className="flex items-end">
                <button
                  onClick={() => handleAddIp(newIpAddress, newIpLabel)}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  + Add IP
                </button>
              </div>
            </div>

            {detectedIp && (
              <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-center justify-between">
                <div>
                  <span className="text-sm text-blue-800">Your current IP: </span>
                  <code className="font-mono text-blue-900 font-semibold">{detectedIp}</code>
                </div>
                <button
                  onClick={() => handleAddIp(detectedIp, 'My Current IP')}
                  className="px-4 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
                >
                  Quick Add My IP
                </button>
              </div>
            )}
          </div>

          {/* IP List */}
          {ipWhitelist.length === 0 ? (
            <div className="bg-white p-12 rounded-lg border text-center text-gray-500">
              No IP addresses whitelisted yet. Add one above to enable API access.
            </div>
          ) : (
            <div className="bg-white rounded-lg border overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left">IP Address</th>
                    <th className="px-4 py-3 text-left">Label</th>
                    <th className="px-4 py-3 text-left">Status</th>
                    <th className="px-4 py-3 text-left">Added</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {ipWhitelist.map((ip) => (
                    <tr key={ip.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-mono">{ip.ipAddress}</td>
                      <td className="px-4 py-3 text-gray-600">{ip.label || '-'}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded text-xs font-semibold ${ip.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                          {ip.isActive ? 'Active' : 'Disabled'}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-gray-600">{new Date(ip.createdAt).toLocaleDateString()}</td>
                      <td className="px-4 py-3 text-right space-x-2">
                        <button
                          onClick={() => handleToggleIp(ip.id, ip.isActive)}
                          className={`px-2 py-1 rounded text-xs ${ip.isActive ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}
                        >
                          {ip.isActive ? 'Disable' : 'Enable'}
                        </button>
                        <button
                          onClick={() => handleDeleteIp(ip.id)}
                          className="px-2 py-1 bg-red-100 text-red-700 rounded text-xs"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Logs Tab */}
      {activeTab === 'logs' && (
        <div className="overflow-x-auto">
          {apiLogs.length === 0 ? (
            <div className="bg-white p-12 rounded-lg border text-center text-gray-500">
              No activity logs yet.
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left">API Key</th>
                  <th className="px-4 py-3 text-left">Method</th>
                  <th className="px-4 py-3 text-left">Endpoint</th>
                  <th className="px-4 py-3 text-left">Status</th>
                  <th className="px-4 py-3 text-left">Time</th>
                  <th className="px-4 py-3 text-left">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {apiLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">{log.apiKey.name}</td>
                    <td className="px-4 py-3 font-mono">{log.method}</td>
                    <td className="px-4 py-3 text-gray-600">{log.endpoint}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded text-xs font-semibold ${log.statusCode && log.statusCode < 300 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                        {log.statusCode || 'Error'}
                      </span>
                    </td>
                    <td className="px-4 py-3">{log.responseTime}ms</td>
                    <td className="px-4 py-3">{new Date(log.createdAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* Create Key Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-md shadow-2xl">
            <h2 className="text-2xl font-bold mb-6">{newKey ? 'API Key Created' : 'Generate API Key'}</h2>
            {newKey ? (
              <div className="space-y-4">
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <p className="text-sm text-yellow-800">⚠️ Save this key now. You won't see it again.</p>
                </div>
                <div className="flex gap-2">
                  <code className="flex-1 p-3 bg-gray-100 border rounded text-sm break-all">{newKey.keyValue}</code>
                  <button onClick={() => copyToClipboard(newKey.keyValue)} className="px-4 py-2 bg-blue-600 text-white rounded">Copy</button>
                </div>
                <button onClick={() => { setShowCreateModal(false); setNewKey(null); }} className="w-full bg-gray-200 py-2 rounded">Done</button>
              </div>
            ) : (
              <form onSubmit={handleCreateKey} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Name *</label>
                  <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="w-full px-3 py-2 border rounded-lg" required />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Permissions</label>
                  <div className="flex gap-4">
                    {['read', 'write'].map((perm) => (
                      <label key={perm} className="flex items-center gap-2">
                        <input type="checkbox" checked={formData.permissions.includes(perm)} onChange={(e) => {
                          if (e.target.checked) setFormData({ ...formData, permissions: [...formData.permissions, perm] });
                          else setFormData({ ...formData, permissions: formData.permissions.filter(p => p !== perm) });
                        }} />
                        <span className="capitalize">{perm}</span>
                      </label>
                    ))}
                  </div>
                </div>
                <div className="flex gap-3">
                  <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded-lg">Create</button>
                  <button type="button" onClick={() => setShowCreateModal(false)} className="flex-1 bg-gray-200 py-2 rounded-lg">Cancel</button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Webhook Modal */}
      {showWebhookModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-md shadow-2xl">
            <h2 className="text-2xl font-bold mb-6">Add Webhook</h2>
            <form onSubmit={handleCreateWebhook} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Callback URL *</label>
                <input type="url" value={webhookForm.url} onChange={(e) => setWebhookForm({ ...webhookForm, url: e.target.value })} className="w-full px-3 py-2 border rounded-lg" placeholder="https://yoursite.com/webhook" required />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Events</label>
                <div className="space-y-2">
                  {['payout.success', 'payout.failed', 'payout.pending', 'payin.success', 'payin.failed'].map((event) => (
                    <label key={event} className="flex items-center gap-2">
                      <input type="checkbox" checked={webhookForm.events.includes(event)} onChange={(e) => {
                        if (e.target.checked) setWebhookForm({ ...webhookForm, events: [...webhookForm.events, event] });
                        else setWebhookForm({ ...webhookForm, events: webhookForm.events.filter(ev => ev !== event) });
                      }} />
                      <span className="text-sm">{event}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="flex gap-3">
                <button type="submit" className="flex-1 bg-green-600 text-white py-2 rounded-lg">Create</button>
                <button type="button" onClick={() => setShowWebhookModal(false)} className="flex-1 bg-gray-200 py-2 rounded-lg">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { useGlobalToast } from '@/context/ToastContext';
import { formatINR } from '@/lib/money';

interface PayInTransaction {
  id: string;
  amount: number;
  currency: string;
  customerName: string | null;
  customerEmail: string | null;
  customerPhone: string | null;
  paymentMethod: string;
  utrNumber: string | null;
  merchantTransactionId: string | null;
  status: string;
  createdAt: string;
  merchantId: string | null;
  externalTransactionId?: string | null;
}

interface Gateway {
  id: string;
  gatewayName: string;
  gatewayCode: string;
  isPrimary: boolean;
  isActive: boolean;
}

export default function PayInPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const [transactions, setTransactions] = useState<PayInTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [kycStatus, setKycStatus] = useState<string | null>(null);
  const [walletBalance, setWalletBalance] = useState<number>(0);
  const [gateways, setGateways] = useState<Gateway[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [paymentLink, setPaymentLink] = useState<string | null>(null);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [depositMode, setDepositMode] = useState<'auto' | 'manual'>('manual');
  const [manualFormData, setManualFormData] = useState({
    amount: '',
    paymentMethod: 'upi',
    utrNumber: '',
    customerName: '',
  });
  const [formData, setFormData] = useState({
    amount: '',
    customerName: '',
    customerEmail: '',
    customerPhone: '',
    paymentMethod: 'upi',
    merchantTransactionId: '',
    gatewayId: '',
  });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'USER') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') {
      checkKYCStatus();
    }
  }, [session, status]);

  const checkKYCStatus = async () => {
    try {
      const response = await fetch('/api/user/kyc-status');
      const data = await response.json();
      setKycStatus(data.status || 'pending');
    } catch (error) {
      console.error('Failed to check KYC status:', error);
      setKycStatus('pending');
    }
  };

  useEffect(() => {
    if (session && status === 'authenticated') {
      fetchTransactions();
      fetchGateways();
      fetchWalletBalance();
    }
  }, [session, status]);

  // Auto-refresh wallet balance when there are pending PayIns
  useEffect(() => {
    const hasPending = transactions.some(t => t.status === 'pending');
    if (!hasPending) return;

    const interval = setInterval(() => {
      fetchWalletBalance();
      fetchTransactions();
    }, 10000); // Refresh every 10 seconds

    return () => clearInterval(interval);
  }, [transactions]);

  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/user/payin');
      const data = await response.json();
      if (data.success) {
        setTransactions(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch payin transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchGateways = async () => {
    try {
      const response = await fetch('/api/user/gateways');
      const data = await response.json();
      if (data.success) {
        setGateways(data.gateways);
        if (data.gateways.length > 0 && !formData.gatewayId) {
          const primaryGateway = data.gateways.find((g: Gateway) => g.isPrimary) || data.gateways[0];
          setFormData((prev) => ({ ...prev, gatewayId: primaryGateway.id }));
        }
      }
    } catch (error) {
      console.error('Failed to fetch gateways:', error);
    }
  };

  const fetchWalletBalance = async () => {
    try {
      const response = await fetch('/api/user/wallet');
      const data = await response.json();
      if (data.success && data.data) {
        setWalletBalance(data.data.balance || 0);
      }
    } catch (error) {
      console.error('Failed to fetch wallet balance:', error);
    }
  };

  const handleManualDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setPaymentError(null);
    toast.showInfo('Submitting deposit request... Please wait');

    try {
      const response = await fetch('/api/user/payin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: parseFloat(manualFormData.amount),
          paymentMethod: manualFormData.paymentMethod,
          utrNumber: manualFormData.utrNumber,
          customerName: manualFormData.customerName,
        }),
      });

      const data = await response.json();
      if (data.success) {
        toast.showSuccess(data.message || 'Deposit request submitted successfully. Awaiting admin approval.');
        setShowCreateModal(false);
        setManualFormData({
          amount: '',
          paymentMethod: 'upi',
          utrNumber: '',
          customerName: '',
        });
        fetchTransactions();
        fetchWalletBalance();
      } else {
        toast.showError(data.error || 'Failed to submit deposit request');
        setPaymentError(data.error || 'Failed to submit deposit request');
      }
    } catch (error: any) {
      console.error('Failed to submit deposit:', error);
      setPaymentError(error.message || 'Error submitting deposit request');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreatePayIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setPaymentError(null);
    setPaymentLink(null);

    try {
      if (!formData.gatewayId) {
        setPaymentError('Please select a payment gateway');
        setSubmitting(false);
        return;
      }

      const response = await fetch('/api/user/payin/initiate-with-gateway', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          amount: parseInt(formData.amount),
          gatewayId: formData.gatewayId,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setPaymentLink(data.paymentLink);
        fetchTransactions();
        fetchWalletBalance();
        if (!data.paymentLink) {
          alert(`Payment initiated! Transaction ID: ${data.transactionId}`);
          setShowCreateModal(false);
          setFormData({
            amount: '',
            customerName: '',
            customerEmail: '',
            customerPhone: '',
            paymentMethod: 'upi',
            merchantTransactionId: '',
            gatewayId: formData.gatewayId,
          });
        }
      } else {
        setPaymentError(data.error || data.gatewayError || 'Failed to initiate payment');
      }
    } catch (error: any) {
      console.error('Failed to initiate payin:', error);
      setPaymentError(error.message || 'Error initiating payment');
    } finally {
      setSubmitting(false);
    }
  };

  const columns: Column<PayInTransaction>[] = [
    {
      key: 'createdAt',
      label: 'Date',
      render: (_, tx) => {
        try {
          const date = new Date(tx.createdAt);
          return isNaN(date.getTime()) ? 'Invalid Date' : date.toLocaleDateString();
        } catch {
          return 'Invalid Date';
        }
      },
    },
    {
      key: 'customerName',
      label: 'Customer',
      render: (_, tx) => (
        <div>
          <div className="font-medium">{tx.customerName || 'N/A'}</div>
          <div className="text-sm text-gray-600">{tx.customerEmail || tx.customerPhone || '-'}</div>
        </div>
      ),
    },
    {
      key: 'amount',
      label: 'Amount',
      render: (_, tx) => formatINR(Number(tx.amount)),
    },
    {
      key: 'paymentMethod',
      label: 'Method',
      render: (_, tx) => (
        <span className="px-2 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-800 uppercase">
          {tx.paymentMethod}
        </span>
      ),
    },
    {
      key: 'status',
      label: 'Status',
      render: (_, tx) => {
        const statusColors: Record<string, string> = {
          pending: 'bg-yellow-100 text-yellow-800',
          processing: 'bg-blue-100 text-blue-800',
          success: 'bg-green-100 text-green-800',
          failed: 'bg-red-100 text-red-800',
        };
        return (
          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${statusColors[tx.status] || 'bg-gray-100 text-gray-800'}`}>
            {tx.status}
          </span>
        );
      },
    },
    {
      key: 'utrNumber',
      label: 'UTR Number',
      render: (_, tx) => (
        <div className="font-mono text-sm">
          {tx.utrNumber ? (
            <span className="text-green-600 font-semibold">{tx.utrNumber}</span>
          ) : (
            <span className="text-gray-400">-</span>
          )}
        </div>
      ),
    },
    {
      key: 'externalTransactionId',
      label: 'External TX ID',
      render: (_, tx) => (
        <div className="font-mono text-xs truncate max-w-xs">
          {tx.externalTransactionId || '-'}
        </div>
      ),
    },
    {
      key: 'merchantTransactionId',
      label: 'Merchant TX ID',
      render: (_, tx) => (
        <div className="font-mono text-xs truncate max-w-xs">
          {tx.merchantTransactionId || '-'}
        </div>
      ),
    },
  ];

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-gray-600">Loading payins...</div>
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  return (
    <div className="space-y-6">
      {kycStatus !== 'approved' && (
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <h3 className="font-semibold text-yellow-800">KYC Verification Required</h3>
          <p className="text-yellow-700 text-sm mt-1">
            {kycStatus === 'pending'
              ? 'Your KYC submission is pending approval. You can view and use payins once approved.'
              : 'Please complete your KYC verification to access this service.'}
          </p>
        </div>
      )}

      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">PayIn Management</h1>
          <p className="text-gray-600 mt-2">Manage and track all incoming payment transactions</p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          disabled={kycStatus !== 'approved'}
          className={`px-6 py-2 rounded-lg transition-colors font-medium ${kycStatus === 'approved'
              ? 'bg-green-600 text-white hover:bg-green-700'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
        >
          + Create PayIn
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-2xl font-bold text-blue-600">{formatINR(walletBalance)}</div>
          <div className="text-sm text-gray-600 mt-1">Wallet Balance</div>
        </div>
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="text-2xl font-bold text-green-600">{transactions.length}</div>
          <div className="text-sm text-gray-600 mt-1">Total PayIns</div>
        </div>
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
          <div className="text-2xl font-bold text-emerald-600">
            {transactions.filter(t => t.status === 'success').length}
          </div>
          <div className="text-sm text-gray-600 mt-1">Successful</div>
        </div>
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="text-2xl font-bold text-yellow-600">
            {transactions.filter(t => t.status === 'pending' || t.status === 'processing').length}
          </div>
          <div className="text-sm text-gray-600 mt-1">Pending</div>
        </div>
        <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
          <div className="text-2xl font-bold text-purple-600">
            {formatINR(transactions.reduce((sum, t) => sum + t.amount, 0))}
          </div>
          <div className="text-sm text-gray-600 mt-1">Total Amount</div>
        </div>
      </div>

      {/* Info Banner */}
      <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 p-6 rounded-xl shadow-sm">
        <div className="flex items-start gap-3">
          <div className="text-2xl">💡</div>
          <div>
            <h3 className="font-semibold text-green-900 mb-2">PayIn Information</h3>
            <p className="text-sm text-green-800 leading-relaxed">
              PayIn transactions represent incoming payments to your account. You can accept payments via UPI, Cards, Net Banking, and Wallets.
              Configure your merchant settings and webhooks to automate payment notifications.
            </p>
          </div>
        </div>
      </div>

      <DataTable<PayInTransaction>
        data={transactions}
        columns={columns}
        loading={loading}
      />

      {/* Create PayIn Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-md shadow-2xl max-h-[90vh] overflow-y-auto">
            {paymentLink ? (
              <div className="text-center space-y-4">
                <h2 className="text-2xl font-bold text-green-600">Payment Link Generated</h2>
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm text-gray-600 mb-3">Click the link below to complete payment:</p>
                  <a
                    href={paymentLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 font-medium text-center break-all text-sm"
                  >
                    Open Payment Link
                  </a>
                </div>
                <p className="text-xs text-gray-500">You can also copy and paste the link in your browser</p>
                <button
                  onClick={() => {
                    setShowCreateModal(false);
                    setPaymentLink(null);
                    setFormData({
                      amount: '',
                      customerName: '',
                      customerEmail: '',
                      customerPhone: '',
                      paymentMethod: 'upi',
                      merchantTransactionId: '',
                      gatewayId: '',
                    });
                  }}
                  className="w-full bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium"
                >
                  Close
                </button>
              </div>
            ) : (
              <>
                <h2 className="text-2xl font-bold mb-4">Add Funds to Wallet</h2>

                {/* Mode Selector */}
                <div className="flex gap-2 mb-6 p-1 bg-gray-100 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setDepositMode('manual')}
                    className={`flex-1 py-2 px-4 rounded-md font-medium transition-colors ${depositMode === 'manual'
                        ? 'bg-white text-green-600 shadow'
                        : 'text-gray-600 hover:text-gray-900'
                      }`}
                  >
                    📝 Manual Deposit
                  </button>
                  <button
                    type="button"
                    onClick={() => setDepositMode('auto')}
                    className={`flex-1 py-2 px-4 rounded-md font-medium transition-colors ${depositMode === 'auto'
                        ? 'bg-white text-green-600 shadow'
                        : 'text-gray-600 hover:text-gray-900'
                      }`}
                  >
                    ⚡ Gateway Payment
                  </button>
                </div>

                {paymentError && (
                  <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-sm text-red-700">{paymentError}</p>
                  </div>
                )}

                {depositMode === 'manual' ? (
                  <>
                    <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-sm text-blue-800">
                        <strong>Manual Deposit:</strong> Submit your deposit details. An admin will verify and approve your request to credit your wallet.
                      </p>
                    </div>

                    <form onSubmit={handleManualDeposit} className="space-y-4">
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Amount (₹) <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="number"
                          value={manualFormData.amount}
                          onChange={(e) => setManualFormData({ ...manualFormData, amount: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          placeholder="1000"
                          required
                          min="1"
                          step="0.01"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Payment Method <span className="text-red-500">*</span>
                        </label>
                        <select
                          value={manualFormData.paymentMethod}
                          onChange={(e) => setManualFormData({ ...manualFormData, paymentMethod: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          required
                        >
                          <option value="upi">UPI</option>
                          <option value="bank_transfer">Bank Transfer</option>
                          <option value="card">Card</option>
                          <option value="cash">Cash</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          UTR / Transaction Reference Number
                        </label>
                        <input
                          type="text"
                          value={manualFormData.utrNumber}
                          onChange={(e) => setManualFormData({ ...manualFormData, utrNumber: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          placeholder="Enter UTR or transaction ID"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Your Name
                        </label>
                        <input
                          type="text"
                          value={manualFormData.customerName}
                          onChange={(e) => setManualFormData({ ...manualFormData, customerName: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          placeholder="John Doe"
                        />
                      </div>

                      <div className="flex gap-3 pt-4">
                        <button
                          type="submit"
                          disabled={submitting}
                          className="flex-1 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 font-medium disabled:bg-gray-400 disabled:cursor-not-allowed"
                        >
                          {submitting ? 'Submitting...' : 'Submit Deposit Request'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setShowCreateModal(false);
                            setPaymentError(null);
                          }}
                          className="px-6 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  </>
                ) : (
                  <>
                    {gateways.length === 0 && (
                      <div className="mb-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <p className="text-sm text-yellow-700">No payment gateways configured. Please contact admin.</p>
                      </div>
                    )}
                    <form onSubmit={handleCreatePayIn} className="space-y-4">
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Payment Gateway
                        </label>
                        <select
                          value={formData.gatewayId}
                          onChange={(e) => setFormData({ ...formData, gatewayId: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          required
                        >
                          <option value="">Select Gateway</option>
                          {gateways.map((gateway) => (
                            <option key={gateway.id} value={gateway.id}>
                              {gateway.gatewayName} {gateway.isPrimary ? '(Primary)' : ''}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Amount (₹)
                        </label>
                        <input
                          type="number"
                          value={formData.amount}
                          onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          placeholder="1000"
                          required
                          min="1"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Payment Method
                        </label>
                        <select
                          value={formData.paymentMethod}
                          onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                        >
                          <option value="upi">UPI</option>
                          <option value="card">Card</option>
                          <option value="netbanking">Net Banking</option>
                          <option value="wallet">Wallet</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Customer Name
                        </label>
                        <input
                          type="text"
                          value={formData.customerName}
                          onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          placeholder="John Doe"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Customer Email
                        </label>
                        <input
                          type="email"
                          value={formData.customerEmail}
                          onChange={(e) => setFormData({ ...formData, customerEmail: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          placeholder="john@example.com"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Customer Phone
                        </label>
                        <input
                          type="tel"
                          value={formData.customerPhone}
                          onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          placeholder="+91 98765 43210"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Merchant Transaction ID (Optional)
                        </label>
                        <input
                          type="text"
                          value={formData.merchantTransactionId}
                          onChange={(e) => setFormData({ ...formData, merchantTransactionId: e.target.value })}
                          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                          placeholder="TXN123456"
                        />
                      </div>

                      <div className="flex gap-3 pt-4">
                        <button
                          type="submit"
                          disabled={submitting}
                          className="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 font-medium disabled:bg-gray-400 disabled:cursor-not-allowed"
                        >
                          {submitting ? 'Processing...' : 'Initiate Payment'}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setShowCreateModal(false);
                            setPaymentError(null);
                          }}
                          className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  </>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

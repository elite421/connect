'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { formatINR } from '@/lib/money';
import { KPICard } from '@/components/kpi-card';
import { ChartCard } from '@/components/chart-card';
import { useGlobalToast } from '@/context/ToastContext';

const CURRENT_PAGE_KEY = 'lastVisitedPage';

interface Analytics {
  subUsers: { total: number; active: number; inactive: number };
  payments: {
    total: number;
    completed: number;
    failed: number;
    pending: number;
    successRate: string;
  };
  revenue: { total: number; averageTransaction: number };
  services: { total: number; active: number; inactive: number };
  subUserActivity: any[];
}

interface Wallet {
  id: string;
  balance: string;
  userId: string;
}

export default function UserDashboard() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const { showSuccess, showError } = useGlobalToast();
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [loading, setLoading] = useState(true);
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [addMoneyAmount, setAddMoneyAmount] = useState('');
  const [timeRange, setTimeRange] = useState('30d');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const lastPage = localStorage.getItem(CURRENT_PAGE_KEY);
      if (lastPage && lastPage !== '/account/user/dashboard') {
        router.push(lastPage);
      } else {
        localStorage.setItem(CURRENT_PAGE_KEY, '/account/user/dashboard');
      }
    }
  }, [router]);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }

    if ((session?.user as any)?.role !== 'USER') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(CURRENT_PAGE_KEY, '/account/user/dashboard');
    }
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [analyticsRes, walletRes] = await Promise.all([
          fetch(`/api/user/analytics?range=${timeRange}`),
          fetch('/api/user/wallet')
        ]);
        const analyticsData = await analyticsRes.json();
        const walletData = await walletRes.json();
        
        if (analyticsData.success) {
          setAnalytics(analyticsData.data);
        }
        if (walletData.success) {
          setWallet(walletData.data);
        }
      } catch (error) {
        console.error('Failed to fetch data:', error);
        showError('Failed to fetch dashboard data');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [timeRange, showError]);

  const handleAddMoney = async () => {
    if (!addMoneyAmount || parseFloat(addMoneyAmount) <= 0) {
      showError('Please enter a valid amount');
      return;
    }

    try {
      const response = await fetch('/api/user/payin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount: parseFloat(addMoneyAmount),
          paymentMethod: 'card',
        }),
      });

      const data = await response.json();
      if (data.success) {
        setAddMoneyAmount('');
        setShowWalletModal(false);
        
        if (data.data?.paymentUrl) {
          window.location.href = data.data.paymentUrl;
        } else {
          showSuccess('PayIn initiated. Redirecting to payment gateway...');
        }
      } else {
        showError(data.error || 'Failed to initiate payment');
      }
    } catch (error) {
      console.error('Error adding money:', error);
      showError('Error processing payment');
    }
  };

  const handleSendMoney = () => {
    setShowWalletModal(false);
    router.push('/account/user/payout');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-lg text-gray-600">Loading...</div>
      </div>
    );
  }

  if (!analytics) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-lg text-gray-600">Failed to load analytics</div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-2">Your business overview</p>
        </div>

        <div className="flex gap-4 items-start">
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            className="bg-white border border-gray-300 text-gray-700 py-2 px-4 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm"
          >
            <option value="today">Today</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="all">All Time</option>
          </select>

          {wallet && (
            <div 
              onClick={() => setShowWalletModal(true)}
              className="cursor-pointer transform transition-transform hover:scale-105 w-64"
            >
              <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white p-4 rounded-xl shadow-lg">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xs font-semibold opacity-90">Wallet Balance</h3>
                    <p className="text-2xl font-bold mt-1">{formatINR(Number(wallet.balance))}</p>
                  </div>
                  <div className="text-2xl">💳</div>
                </div>
                <div className="flex gap-2 text-xs">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowWalletModal(true);
                    }}
                    className="flex-1 bg-white text-blue-600 font-semibold py-1 px-2 rounded hover:bg-gray-100 transition-colors"
                  >
                    Add Money
                  </button>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSendMoney();
                    }}
                    className="flex-1 bg-blue-700 text-white font-semibold py-1 px-2 rounded hover:bg-blue-900 transition-colors border border-white border-opacity-30"
                  >
                    Send
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <KPICard
          title="Total SubUsers"
          value={analytics.subUsers.total}
          subtitle={`${analytics.subUsers.active} active`}
          color="blue"
          icon="👤"
        />
        <KPICard
          title="Total Payments"
          value={analytics.payments.total}
          subtitle={`${analytics.payments.successRate}% success`}
          color="green"
          icon="💰"
        />
        <KPICard
          title="Active Services"
          value={analytics.services.active}
          subtitle={`of ${analytics.services.total} total`}
          color="purple"
          icon="⚙️"
        />
        <KPICard
          title="Total Revenue"
          value={formatINR(Number(analytics.revenue.total))}
          subtitle={`Avg: ${formatINR(Number(analytics.revenue.averageTransaction))}`}
          color="yellow"
          icon="📊"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">SubUser Status</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">Total SubUsers</span>
              <span className="text-2xl font-bold">{analytics.subUsers.total}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">Active</span>
              <span className="text-green-600 font-semibold">{analytics.subUsers.active}</span>
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="text-gray-600">Inactive</span>
              <span className="text-red-600 font-semibold">{analytics.subUsers.inactive}</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Payment Statistics</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">Completed</span>
              <span className="text-green-600 font-semibold">{analytics.payments.completed}</span>
            </div>
            <div className="flex justify-between items-center pb-2 border-b">
              <span className="text-gray-600">Failed</span>
              <span className="text-red-600 font-semibold">{analytics.payments.failed}</span>
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="text-gray-600">Pending</span>
              <span className="text-yellow-600 font-semibold">{analytics.payments.pending}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ChartCard
          title="SubUser Distribution"
          data={[
            { label: 'Active', value: analytics.subUsers.active },
            { label: 'Inactive', value: analytics.subUsers.inactive },
          ]}
          type="pie"
        />
        <ChartCard
          title="Service Usage"
          data={[
            { label: 'Active', value: analytics.services.active },
            { label: 'Inactive', value: analytics.services.inactive },
          ]}
          type="pie"
        />
      </div>

      <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <a
            href="/account/user/subusers"
            className="p-4 bg-blue-50 border border-blue-200 rounded-lg hover:shadow-md transition-shadow text-center"
          >
            <div className="text-2xl mb-2">👤</div>
            <div className="font-semibold text-gray-900">Manage SubUsers</div>
            <div className="text-sm text-gray-600 mt-1">Add and manage your team</div>
          </a>
          <a
            href="/account/user/services"
            className="p-4 bg-green-50 border border-green-200 rounded-lg hover:shadow-md transition-shadow text-center"
          >
            <div className="text-2xl mb-2">⚙️</div>
            <div className="font-semibold text-gray-900">Services</div>
            <div className="text-sm text-gray-600 mt-1">Activate payment services</div>
          </a>
          <a
            href="/account/reports"
            className="p-4 bg-purple-50 border border-purple-200 rounded-lg hover:shadow-md transition-shadow text-center"
          >
            <div className="text-2xl mb-2">📊</div>
            <div className="font-semibold text-gray-900">Reports</div>
            <div className="text-sm text-gray-600 mt-1">View detailed reports</div>
          </a>
        </div>
      </div>

      {showWalletModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-md shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Wallet</h2>
              <button 
                onClick={() => setShowWalletModal(false)}
                className="text-gray-500 hover:text-gray-700 text-2xl"
              >
                ✕
              </button>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <p className="text-sm text-gray-600">Current Balance</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{wallet ? formatINR(Number(wallet.balance)) : '₹0.00'}</p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">Add Money to Wallet</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={addMoneyAmount}
                    onChange={(e) => setAddMoneyAmount(e.target.value)}
                    placeholder="Enter amount (₹)"
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    min="1"
                    step="100"
                  />
                  <button
                    onClick={handleAddMoney}
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium transition-colors"
                  >
                    Add
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-2">Minimum amount: ₹100</p>
              </div>

              <div className="border-t pt-4">
                <button
                  onClick={handleSendMoney}
                  className="w-full px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold transition-colors flex items-center justify-center gap-2"
                >
                  <span>📤</span>
                  Send Money to Bank/UPI
                </button>
              </div>

              <div className="border-t pt-4">
                <button
                  onClick={() => setShowWalletModal(false)}
                  className="w-full px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-medium transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { formatINR } from '@/lib/money';

interface PayOutTransaction {
  id: string;
  amount: number;
  beneficiaryName: string;
  beneficiaryAccount: string;
  transferMode: string;
  utrNumber: string | null;
  status: string;
  createdAt: string;
}

export default function SubUserPayOutPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [transactions, setTransactions] = useState<PayOutTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [formData, setFormData] = useState({
    amount: '',
    beneficiaryName: '',
    beneficiaryAccount: '',
    beneficiaryIfsc: '',
    beneficiaryVpa: '',
    transferMode: 'imps',
  });

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if ((session?.user as any)?.role !== 'SUBUSER') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') fetchTransactions();
  }, [session, status]);

  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/subuser/payout');
      const data = await response.json();
      if (data.success) setTransactions(data.data);
    } catch (error) {
      console.error('Failed to fetch payouts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePayout = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/subuser/payout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          amount: parseFloat(formData.amount),
        }),
      });

      const data = await response.json();
      if (data.success) {
        const gr = data.gatewayResponse || {};
        const status = gr.status || 'processing';
        const utr = gr.utrNumber || '-';
        alert(`Payout initiated.\nStatus: ${status}\nUTR: ${utr}`);
        setShowCreateModal(false);
        setFormData({ amount: '', beneficiaryName: '', beneficiaryAccount: '', beneficiaryIfsc: '', beneficiaryVpa: '', transferMode: 'imps' });
        fetchTransactions();
      } else {
        alert(data.error || 'Failed to create payout');
      }
    } catch (error) {
      alert('Error creating payout');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'processing': return 'bg-blue-100 text-blue-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">PayOut</h1>
          <p className="text-gray-600 mt-2">Initiate and track payout transactions</p>
        </div>
        <button onClick={() => setShowCreateModal(true)} className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
          + Create PayOut
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-2xl font-bold text-blue-600">{transactions.length}</div>
          <div className="text-sm text-gray-600">Total Payouts</div>
        </div>
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="text-2xl font-bold text-green-600">{transactions.filter(t => t.status === 'success').length}</div>
          <div className="text-sm text-gray-600">Successful</div>
        </div>
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="text-2xl font-bold text-yellow-600">{transactions.filter(t => t.status === 'pending' || t.status === 'processing').length}</div>
          <div className="text-sm text-gray-600">Pending</div>
        </div>
        <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
          <div className="text-2xl font-bold text-purple-600">{formatINR(transactions.reduce((sum, t) => sum + t.amount, 0))}</div>
          <div className="text-sm text-gray-600">Total Amount</div>
        </div>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Beneficiary</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Amount</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Mode</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">UTR</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {transactions.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-4 py-12 text-center text-gray-500">No payout transactions yet</td>
              </tr>
            ) : (
              transactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm">{new Date(tx.createdAt).toLocaleDateString()}</td>
                  <td className="px-4 py-3">
                    <div className="font-medium text-sm">{tx.beneficiaryName}</div>
                    <div className="text-xs text-gray-500">{tx.beneficiaryAccount}</div>
                  </td>
                  <td className="px-4 py-3 font-semibold">{formatINR(tx.amount)}</td>
                  <td className="px-4 py-3"><span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded-full uppercase">{tx.transferMode}</span></td>
                  <td className="px-4 py-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(tx.status)}`}>{tx.status}</span></td>
                  <td className="px-4 py-3 text-sm font-mono">{tx.utrNumber || '-'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-md shadow-2xl max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6">Create PayOut</h2>
            <form onSubmit={handleCreatePayout} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Amount (₹) *</label>
                <input type="number" value={formData.amount} onChange={(e) => setFormData({ ...formData, amount: e.target.value })} className="w-full px-4 py-2 border rounded-lg" required min="1" />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Transfer Mode</label>
                <select value={formData.transferMode} onChange={(e) => setFormData({ ...formData, transferMode: e.target.value })} className="w-full px-4 py-2 border rounded-lg">
                  <option value="imps">IMPS</option>
                  <option value="neft">NEFT</option>
                  <option value="upi">UPI</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Beneficiary Name *</label>
                <input type="text" value={formData.beneficiaryName} onChange={(e) => setFormData({ ...formData, beneficiaryName: e.target.value })} className="w-full px-4 py-2 border rounded-lg" required />
              </div>
              {formData.transferMode === 'upi' ? (
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">VPA Address *</label>
                  <input type="text" value={formData.beneficiaryVpa} onChange={(e) => setFormData({ ...formData, beneficiaryVpa: e.target.value })} className="w-full px-4 py-2 border rounded-lg" placeholder="user@upi" required />
                </div>
              ) : (
                <>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Account Number *</label>
                    <input type="text" value={formData.beneficiaryAccount} onChange={(e) => setFormData({ ...formData, beneficiaryAccount: e.target.value })} className="w-full px-4 py-2 border rounded-lg" required />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">IFSC Code *</label>
                    <input type="text" value={formData.beneficiaryIfsc} onChange={(e) => setFormData({ ...formData, beneficiaryIfsc: e.target.value })} className="w-full px-4 py-2 border rounded-lg" required />
                  </div>
                </>
              )}
              <div className="flex gap-3 pt-4">
                <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-medium">Create PayOut</button>
                <button type="button" onClick={() => setShowCreateModal(false)} className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

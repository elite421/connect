'use client';

import { useEffect, useState } from 'react';
import { formatINR } from '@/lib/money';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';

interface Transaction {
  id: string;
  type: string;
  amount: number;
  description: string;
  status: string;
  createdAt: string;
}

export default function TransactionsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [summary, setSummary] = useState({ totalTransactions: 0, totalAmount: 0 });
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState('');
  const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'SUBUSER') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchTransactions = async (offset: number = 0, type: string = '') => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        offset: offset.toString(),
        limit: '50',
        ...(type && { type }),
      });
      const response = await fetch(`/api/subuser/transactions?${params}`);
      const data = await response.json();
      if (data.success) {
        setTransactions(data.data);
        setSummary(data.summary);
        setPagination(data.pagination);
      }
    } catch (error) {
      console.error('Failed to fetch transactions:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions(0, filterType);
  }, [filterType]);

  const columns: Column<Transaction>[] = [
    { key: 'type', label: 'Type' },
    { key: 'description', label: 'Description' },
    {
      key: 'amount',
      label: 'Amount',
      render: (amount) => formatINR(Number(amount)),
    },
    { key: 'status', label: 'Status' },
    {
      key: 'createdAt',
      label: 'Date',
      render: (date) => new Date(date).toLocaleDateString(),
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Transactions</h1>
        <p className="text-gray-600 mt-2">View your complete transaction history</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <p className="text-sm text-gray-600 mb-1">Total Transactions</p>
          <p className="text-3xl font-bold text-gray-900">{summary.totalTransactions}</p>
        </div>
        <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
          <p className="text-sm text-gray-600 mb-1">Total Amount</p>
          <p className="text-3xl font-bold text-gray-900">{formatINR(Number(summary.totalAmount))}</p>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Filter by Type</label>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        >
          <option value="">All Types</option>
          <option value="payment">Payment</option>
          <option value="credit">Credit</option>
          <option value="refund">Refund</option>
          <option value="adjustment">Adjustment</option>
        </select>
      </div>

      <DataTable<Transaction>
        data={transactions}
        columns={columns}
        loading={loading}
        pagination={{
          ...pagination,
          onPageChange: (offset) => fetchTransactions(offset, filterType),
        }}
      />

      <div className="bg-blue-50 border border-blue-200 p-6 rounded-lg">
        <h3 className="font-semibold text-blue-900 mb-2">📊 About Your Transactions</h3>
        <p className="text-sm text-blue-800">
          This page shows all your transactions including payments, credits, refunds, and adjustments. Download transaction
          reports from the Reports section.
        </p>
      </div>
    </div>
  );
}

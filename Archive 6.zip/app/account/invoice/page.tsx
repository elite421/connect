"use client";
import { useEffect, useState } from "react";

type Invoice = { id: string; number: string; amount: number; currency: "INR" | "USD"; status: "due" | "paid"; issuedAt: string };

export default function InvoicePage() {
  const [items, setItems] = useState<Invoice[]>([]);

  async function load() {
    const res = await fetch("/api/invoices", { cache: "no-store" });
    if (!res.ok) return;
    const data = await res.json();
    const arr: unknown = data ?? [];
    const items: Invoice[] = Array.isArray(arr)
      ? arr.map((d: unknown) => {
          const o = d as { id: string; number: string; amount: number | string; currency: "INR" | "USD"; status: "due" | "paid"; issuedAt: string };
          return { id: o.id, number: o.number, amount: Number(o.amount), currency: o.currency, status: o.status, issuedAt: o.issuedAt };
        })
      : [];
    setItems(items);
  }

  useEffect(() => {
    const t = setTimeout(() => { void load(); }, 0);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Invoices</h1>
      <div className="bg-white border rounded-xl p-6 shadow-sm">
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left text-gray-600">
                <th className="py-2">Invoice</th>
                <th className="py-2">Amount</th>
                <th className="py-2">Status</th>
                <th className="py-2">Issued</th>
                <th className="py-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((i) => (
                <tr key={i.id} className="border-t">
                  <td className="py-2">{i.number}</td>
                  <td className="py-2">{i.currency} {i.amount / 100}</td>
                  <td className="py-2 capitalize">{i.status}</td>
                  <td className="py-2">{new Date(i.issuedAt).toLocaleDateString()}</td>
                  <td className="py-2 space-x-2">
                    <button className="px-3 py-1 rounded-md bg-gray-100 hover:bg-gray-200">Download</button>
                    <button className="px-3 py-1 rounded-md bg-green-600 text-white">Pay</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

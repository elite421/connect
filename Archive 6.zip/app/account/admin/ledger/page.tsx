'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { useGlobalToast } from '@/context/ToastContext';
import { formatINR } from '@/lib/money';

interface LedgerEntry {
    id: string;
    date: string;
    type: string;
    category: string;
    description: string;
    debit: number;
    credit: number;
    openingBalance: number | null;
    closingBalance: number | null;
    charge: number;
    referenceId: string | null;
    referenceType: string | null;
    status?: string;
    utrNumber?: string | null;
    beneficiary?: string;
    userName: string;
    userEmail: string;
    userId: string;
}

interface User {
    id: string;
    name: string | null;
    email: string;
    username: string | null;
}

interface Totals {
    totalDebit: number;
    totalCredit: number;
    totalCharges: number;
    netBalance: number;
    totalEntries: number;
}

export default function AdminLedgerPage() {
    const { data: session, status } = useSession();
    const router = useRouter();
    const toast = useGlobalToast();
    const [entries, setEntries] = useState<LedgerEntry[]>([]);
    const [users, setUsers] = useState<User[]>([]);
    const [totals, setTotals] = useState<Totals | null>(null);
    const [loading, setLoading] = useState(true);
    const [downloading, setDownloading] = useState(false);
    const [filters, setFilters] = useState({
        userId: 'all',
        startDate: '',
        endDate: '',
        type: 'all',
    });

    useEffect(() => {
        if (status === 'unauthenticated') {
            router.push('/login');
        }
        if ((session?.user as any)?.role !== 'ADMIN') {
            router.push('/account/dashboard');
        }
    }, [status, session, router]);

    useEffect(() => {
        if (session && status === 'authenticated') {
            fetchUsers();
            fetchLedger();
        }
    }, [session, status]);

    const fetchUsers = async () => {
        try {
            const response = await fetch('/api/admin/users');
            const data = await response.json();
            if (data.success) {
                setUsers(data.data || []);
            }
        } catch (error) {
            console.error('Failed to fetch users:', error);
        }
    };

    const fetchLedger = async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (filters.userId !== 'all') params.set('userId', filters.userId);
            if (filters.startDate) params.set('startDate', filters.startDate);
            if (filters.endDate) params.set('endDate', filters.endDate);
            if (filters.type !== 'all') params.set('type', filters.type);
            params.set('admin', 'true');

            const response = await fetch(`/api/reports/ledger?${params.toString()}`);
            const data = await response.json();
            if (data.success) {
                setEntries(data.data);
                setTotals(data.totals);
            } else {
                toast.showError(data.error || 'Failed to fetch ledger');
            }
        } catch (error) {
            console.error('Failed to fetch ledger:', error);
            toast.showError('Failed to fetch ledger data');
        } finally {
            setLoading(false);
        }
    };

    const handleApplyFilters = () => {
        fetchLedger();
    };

    const clearFilters = () => {
        setFilters({
            userId: 'all',
            startDate: '',
            endDate: '',
            type: 'all',
        });
        setTimeout(() => fetchLedger(), 100);
    };

    const downloadCSV = () => {
        if (entries.length === 0) {
            toast.showWarning('No data to download');
            return;
        }

        setDownloading(true);

        const headers = ['Date', 'User', 'Email', 'Type', 'Category', 'Description', 'Debit (₹)', 'Credit (₹)', 'Charge (₹)', 'Balance (₹)', 'Status', 'UTR', 'Reference'];
        const rows = entries.map((entry) => [
            new Date(entry.date).toLocaleString(),
            entry.userName || 'N/A',
            entry.userEmail || 'N/A',
            entry.type,
            entry.category,
            entry.description,
            entry.debit.toFixed(5),
            entry.credit.toFixed(5),
            entry.charge.toFixed(5),
            entry.openingBalance?.toFixed(5) || 'N/A',
            entry.closingBalance?.toFixed(5) || 'N/A',
            entry.status || 'N/A',
            entry.utrNumber || 'N/A',
            entry.referenceId || 'N/A',
        ]);

        const csvContent = [
            headers.join(','),
            ...rows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);

        const selectedUser = users.find(u => u.id === filters.userId);
        const fileName = filters.userId !== 'all'
            ? `ledger_${selectedUser?.username || selectedUser?.email || 'user'}_${new Date().toISOString().split('T')[0]}.csv`
            : `ledger_all_users_${new Date().toISOString().split('T')[0]}.csv`;

        link.setAttribute('download', fileName);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        toast.showSuccess('Ledger downloaded successfully');
        setDownloading(false);
    };

    const downloadExcel = async () => {
        if (entries.length === 0) {
            toast.showWarning('No data to download');
            return;
        }

        setDownloading(true);

        // For Excel, we'll use a simple HTML table format that Excel can open
        const htmlContent = `
      <html>
        <head><meta charset="UTF-8"></head>
        <body>
          <table border="1">
            <thead>
              <tr>
                <th>Date</th>
                <th>User</th>
                <th>Email</th>
                <th>Type</th>
                <th>Category</th>
                <th>Description</th>
                <th>Debit (₹)</th>
                <th>Credit (₹)</th>
                <th>Charge (₹)</th>
                <th>Balance (₹)</th>
                <th>Status</th>
                <th>UTR</th>
                <th>Reference</th>
              </tr>
            </thead>
            <tbody>
              ${entries.map(entry => `
                <tr>
                  <td>${new Date(entry.date).toLocaleString()}</td>
                  <td>${entry.userName || 'N/A'}</td>
                  <td>${entry.userEmail || 'N/A'}</td>
                  <td>${entry.type}</td>
                  <td>${entry.category}</td>
                  <td>${entry.description}</td>
                  <td>${entry.debit.toFixed(5)}</td>
                  <td>${entry.credit.toFixed(5)}</td>
                  <td>${entry.charge.toFixed(5)}</td>
                  <td>${entry.openingBalance?.toFixed(5) || 'N/A'}</td>
                  <td>${entry.closingBalance?.toFixed(5) || 'N/A'}</td>
                  <td>${entry.status || 'N/A'}</td>
                  <td>${entry.utrNumber || 'N/A'}</td>
                  <td>${entry.referenceId || 'N/A'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;

        const blob = new Blob([htmlContent], { type: 'application/vnd.ms-excel' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);

        const selectedUser = users.find(u => u.id === filters.userId);
        const fileName = filters.userId !== 'all'
            ? `ledger_${selectedUser?.username || selectedUser?.email || 'user'}_${new Date().toISOString().split('T')[0]}.xls`
            : `ledger_all_users_${new Date().toISOString().split('T')[0]}.xls`;

        link.setAttribute('download', fileName);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        toast.showSuccess('Ledger downloaded as Excel');
        setDownloading(false);
    };

    const columns: Column<LedgerEntry>[] = [
        {
            key: 'date',
            label: 'Date',
            render: (_, entry) => (
                <div className="text-sm">
                    <div>{new Date(entry.date).toLocaleDateString()}</div>
                    <div className="text-xs text-gray-500">{new Date(entry.date).toLocaleTimeString()}</div>
                </div>
            ),
        },
        {
            key: 'userName',
            label: 'User',
            render: (_, entry) => (
                <div className="text-sm">
                    <div className="font-medium">{entry.userName || 'N/A'}</div>
                    <div className="text-xs text-gray-500">{entry.userEmail}</div>
                </div>
            ),
        },
        {
            key: 'type',
            label: 'Type',
            render: (_, entry) => (
                <span className={`px-2 py-1 rounded text-xs font-semibold ${entry.type === 'CREDIT' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                    {entry.type}
                </span>
            ),
        },
        {
            key: 'category',
            label: 'Category',
            render: (_, entry) => <span className="text-sm">{entry.category}</span>,
        },
        {
            key: 'description',
            label: 'Description',
            render: (_, entry) => (
                <div className="text-sm max-w-[200px] truncate" title={entry.description}>
                    {entry.description}
                </div>
            ),
        },
        {
            key: 'debit',
            label: 'Debit (₹)',
            render: (_, entry) => (
                <span className={`font-medium ${entry.debit > 0 ? 'text-red-600' : 'text-gray-400'}`}>
                    {entry.debit > 0 ? formatINR(entry.debit) : '-'}
                </span>
            ),
        },
        {
            key: 'credit',
            label: 'Credit (₹)',
            render: (_, entry) => (
                <span className={`font-medium ${entry.credit > 0 ? 'text-green-600' : 'text-gray-400'}`}>
                    {entry.credit > 0 ? formatINR(entry.credit) : '-'}
                </span>
            ),
        },
        {
            key: 'openingBalance',
            label: 'Opening (₹)',
            render: (_, entry) => (
                <span className="text-gray-700">
                    {entry.openingBalance !== null ? formatINR(entry.openingBalance) : '-'}
                </span>
            ),
        },
        {
            key: 'closingBalance',
            label: 'Closing (₹)',
            render: (_, entry) => (
                <span className="text-blue-600 font-medium">
                    {entry.closingBalance !== null ? formatINR(entry.closingBalance) : '-'}
                </span>
            ),
        },
        {
            key: 'charge',
            label: 'Charge (₹)',
            render: (_, entry) => (
                <span className="text-yellow-600">
                    {entry.charge > 0 ? formatINR(entry.charge) : '-'}
                </span>
            ),
        },
        {
            key: 'status',
            label: 'Status',
            render: (_, entry) => {
                const statusColors: Record<string, string> = {
                    success: 'bg-green-100 text-green-800',
                    pending: 'bg-yellow-100 text-yellow-800',
                    failed: 'bg-red-100 text-red-800',
                    processing: 'bg-blue-100 text-blue-800',
                };
                return (
                    <span className={`px-2 py-1 rounded text-xs font-semibold ${statusColors[entry.status || ''] || 'bg-gray-100 text-gray-800'}`}>
                        {entry.status || 'N/A'}
                    </span>
                );
            },
        },
    ];

    if (status === 'loading' || loading) {
        return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">📒 Admin Ledger</h1>
                    <p className="text-gray-600 mt-2">View all user transactions with filters and download options</p>
                </div>
                <div className="flex gap-2">
                    <button
                        onClick={downloadCSV}
                        disabled={downloading || entries.length === 0}
                        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400"
                    >
                        {downloading ? '...' : '📥 CSV'}
                    </button>
                    <button
                        onClick={downloadExcel}
                        disabled={downloading || entries.length === 0}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
                    >
                        {downloading ? '...' : '📊 Excel'}
                    </button>
                </div>
            </div>

            {/* Filters */}
            <div className="bg-white p-6 rounded-lg border shadow-sm">
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">User</label>
                        <select
                            value={filters.userId}
                            onChange={(e) => setFilters({ ...filters, userId: e.target.value })}
                            className="w-full px-3 py-2 border rounded-lg"
                        >
                            <option value="all">All Users</option>
                            {users.map((user) => (
                                <option key={user.id} value={user.id}>
                                    {user.name || user.username || user.email}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                        <input
                            type="date"
                            value={filters.startDate}
                            onChange={(e) => setFilters({ ...filters, startDate: e.target.value })}
                            className="w-full px-3 py-2 border rounded-lg"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                        <input
                            type="date"
                            value={filters.endDate}
                            onChange={(e) => setFilters({ ...filters, endDate: e.target.value })}
                            className="w-full px-3 py-2 border rounded-lg"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                        <select
                            value={filters.type}
                            onChange={(e) => setFilters({ ...filters, type: e.target.value })}
                            className="w-full px-3 py-2 border rounded-lg"
                        >
                            <option value="all">All Types</option>
                            <option value="CREDIT">Credit</option>
                            <option value="DEBIT">Debit</option>
                        </select>
                    </div>
                    <div className="flex items-end gap-2">
                        <button
                            onClick={handleApplyFilters}
                            className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                        >
                            Apply
                        </button>
                        <button
                            onClick={clearFilters}
                            className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                        >
                            Clear
                        </button>
                    </div>
                </div>
            </div>

            {/* Summary Cards */}
            {totals && (
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <div className="bg-white p-4 rounded-lg border shadow-sm">
                        <div className="text-sm text-gray-500">Total Entries</div>
                        <div className="text-2xl font-bold">{totals.totalEntries}</div>
                    </div>
                    <div className="bg-white p-4 rounded-lg border shadow-sm">
                        <div className="text-sm text-gray-500">Total Credit</div>
                        <div className="text-2xl font-bold text-green-600">{formatINR(totals.totalCredit)}</div>
                    </div>
                    <div className="bg-white p-4 rounded-lg border shadow-sm">
                        <div className="text-sm text-gray-500">Total Debit</div>
                        <div className="text-2xl font-bold text-red-600">{formatINR(totals.totalDebit)}</div>
                    </div>
                    <div className="bg-white p-4 rounded-lg border shadow-sm">
                        <div className="text-sm text-gray-500">Total Charges</div>
                        <div className="text-2xl font-bold text-yellow-600">{formatINR(totals.totalCharges)}</div>
                    </div>
                    <div className="bg-white p-4 rounded-lg border shadow-sm">
                        <div className="text-sm text-gray-500">Net Balance</div>
                        <div className={`text-2xl font-bold ${totals.netBalance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                            {formatINR(totals.netBalance)}
                        </div>
                    </div>
                </div>
            )}

            {/* Data Table */}
            <DataTable<LedgerEntry>
                data={entries}
                columns={columns}
                loading={loading}
            />
        </div>
    );
}

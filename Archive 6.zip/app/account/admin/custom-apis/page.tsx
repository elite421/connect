'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useGlobalToast } from '@/context/ToastContext';
import { useConfirm } from '@/hooks/useConfirm';

interface CustomApi {
  id: string;
  userId: string | null;
  adminProvided: boolean;
  apiName: string;
  apiBaseUrl: string;
  apiEndpoint: string;
  apiMethod: string;
  authType: string;
  apiKey: string | null;
  apiSecret: string | null;
  authHeader: string | null;
  contentType: string | null;
  requestFormat: any | null;
  responseFormat: any | null;
  apiPreset: string | null;
  isActive: boolean;
  isDefault: boolean;
  assignedServices: string[];
  apiNumber: string | null;
  callbackToken: string | null;
  createdAt: string;
}

interface ApiTestResponse {
  status: 'success' | 'error' | 'pending';
  statusCode?: number;
  data?: unknown;
  message?: string;
  error?: string;
}

// API Preset Configurations
const API_PRESETS = {
  custom: {
    name: 'Custom API',
    contentType: 'application/json',
    requestTemplate: '',
    responseMapping: ''
  },
  zyontic: {
    name: 'Zyontic Payout',
    contentType: 'application/json',
    requestTemplate: '',
    responseMapping: '',
    authType: 'bearer', // Only API Token needed, client_id is auto-generated from transaction ID
  },
  payatme: {
    name: 'PayAtMe',
    contentType: 'multipart/form-data',
    requestTemplate: JSON.stringify({
      mobile_number: "{{beneficiaryMobile || '9999999999'}}",
      account_number: "{{beneficiaryAccount}}",
      beneficiary_name: "{{beneficiaryName}}",
      ifsc: "{{beneficiaryIfsc}}",
      provider_id: "143",
      client_id: "{{transactionId}}",
      amount: "{{amount}}",
      wallet_id: "0",
      upi: "{{beneficiaryVpa}}"
    }, null, 2),
    responseMapping: JSON.stringify({
      statusField: "status_id",
      successValue: 1,
      failureValue: 2,
      pendingValue: 3,
      utrField: "utr",
      messageField: "message",
      transactionIdField: "report_id"
    }, null, 2)
  },
  fingrow: {
    name: 'Fingrow',
    contentType: 'application/json',
    requestTemplate: JSON.stringify({
      amount: "{{amount}}",
      beneficiary_name: "{{beneficiaryName}}",
      account_number: "{{beneficiaryAccount}}",
      ifsc_code: "{{beneficiaryIfsc}}",
      mode: "{{transferMode}}",
      reference_id: "{{transactionId}}"
    }, null, 2),
    responseMapping: JSON.stringify({
      statusField: "status",
      successValue: "success",
      failureValue: "failed",
      pendingValue: "pending",
      utrField: "utr_number",
      messageField: "message",
      transactionIdField: "transaction_id"
    }, null, 2)
  },
  kgipay: {
    name: 'KGIPay',
    contentType: 'application/json',
    requestTemplate: '',
    responseMapping: '',
    authType: 'custom_config',
  },
  gammingpay: {
    name: 'GammingPay',
    contentType: 'application/json',
    requestTemplate: '',
    responseMapping: '',
    authType: 'gammingpay',
  },
  rudraxpay: {
    name: 'RudraxPay',
    contentType: 'application/json',
    requestTemplate: '',
    responseMapping: '',
    authType: 'custom_config', // Using UserID + Token
    // We can pre-fill default URL if we want, but form doesn't seem to support preset URL well in the schema above? 
    // Actually `API_PRESETS` just has name/content/template.
    // The `onChange` handler sets fields.
  }
};

export default function CustomApisPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const { confirm, ConfirmProvider } = useConfirm();

  const toast = useGlobalToast();
  const [apis, setApis] = useState<CustomApi[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingApi, setEditingApi] = useState<CustomApi | null>(null);
  const [showTestModal, setShowTestModal] = useState(false);
  const [selectedApiForTest, setSelectedApiForTest] = useState<CustomApi | null>(null);
  const [testResponse, setTestResponse] = useState<ApiTestResponse | null>(null);
  const [testingApi, setTestingApi] = useState(false);
  const [apiHealthStatus, setApiHealthStatus] = useState<Record<string, Record<string, string>>>({});
  const [showRequirementsDoc, setShowRequirementsDoc] = useState(false);
  const [formData, setFormData] = useState({
    apiName: '',
    apiBaseUrl: '',
    apiEndpoint: '/api/transfer',
    apiMethod: 'POST',
    authType: 'bearer',
    apiKey: '',
    apiSecret: '',
    authHeader: '',
    contentType: 'application/json',
    requestTemplate: '',
    responseMapping: '',
    apiPreset: 'custom',
    isActive: true,
    isDefault: false,
    assignedServices: [] as string[],
    statusCheckUrl: '', // URL to check transaction status from provider
  });

  useEffect(() => {
    if (status === 'loading') return;
    if (status === 'unauthenticated') router.push('/login');
    const userRole = (session?.user as { role?: string })?.role;
    if (status === 'authenticated' && userRole !== 'ADMIN') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') {
      fetchApis();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, status]);

  const fetchApis = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/custom-apis');
      const data = await response.json();
      if (data.success) setApis(data.data);
    } catch (_error) {
      console.error('Failed to fetch APIs:', _error);
      toast.showError('Failed to load APIs');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const url = '/api/admin/custom-apis';
      const method = editingApi ? 'PATCH' : 'POST';

      // Parse template strings to JSON for storage
      let requestFormat = null;
      let responseFormat = null;

      try {
        if (formData.requestTemplate.trim()) {
          requestFormat = JSON.parse(formData.requestTemplate);
        }
      } catch {
        toast.showError('Invalid JSON in Request Body Template');
        return;
      }

      try {
        if (formData.responseMapping.trim()) {
          responseFormat = JSON.parse(formData.responseMapping);
        }
      } catch {
        toast.showError('Invalid JSON in Response Mapping');
        return;
      }

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: editingApi?.id,
          apiName: formData.apiName,
          apiBaseUrl: formData.apiBaseUrl,
          apiEndpoint: formData.apiEndpoint,
          apiMethod: formData.apiMethod,
          authType: formData.authType,
          apiKey: formData.apiKey,
          apiSecret: formData.apiSecret,
          authHeader: formData.authHeader,
          contentType: formData.contentType,
          apiPreset: formData.apiPreset,
          requestFormat,
          responseFormat,
          isActive: formData.isActive,
          isDefault: formData.isDefault,
          assignedServices: formData.assignedServices,
          adminProvided: true,
        }),
      });

      const data = await response.json();
      if (data.success) {
        toast.showSuccess(editingApi ? 'API updated!' : 'API created!');
        setShowModal(false);
        resetForm();
        fetchApis();
      } else {
        toast.showError(data.error || 'Failed to save API');
      }
    } catch {
      toast.showError('Failed to save API');
    }
  };

  const handleEdit = (api: CustomApi) => {
    setEditingApi(api);
    setFormData({
      apiName: api.apiName,
      apiBaseUrl: api.apiBaseUrl,
      apiEndpoint: api.apiEndpoint,
      apiMethod: api.apiMethod,
      authType: api.authType,
      apiKey: api.apiKey || '',
      apiSecret: api.apiSecret || '',
      authHeader: api.authHeader || '',
      contentType: api.contentType || 'application/json',
      requestTemplate: api.requestFormat ? JSON.stringify(api.requestFormat, null, 2) : '',
      responseMapping: api.responseFormat ? JSON.stringify(api.responseFormat, null, 2) : '',
      apiPreset: api.apiPreset || 'custom',
      isActive: api.isActive,
      isDefault: api.isDefault,
      assignedServices: api.assignedServices || [],
      statusCheckUrl: (api as any).statusCheckUrl || '',
    });
    setShowModal(true);
  };
  const handleDelete = async (id: string, name: string) => {
    const isConfirmed = await confirm({
      title: 'Delete API Configuration',
      message: `Are you sure you want to delete "${name}"? This action cannot be undone.`,
      confirmText: 'Delete API',
      cancelText: 'Cancel',
      isDangerous: true,
    });

    if (!isConfirmed) return;

    try {
      const response = await fetch(`/api/admin/custom-apis?id=${id}`, { method: 'DELETE' });
      const data = await response.json();
      if (data.success) {
        toast.showSuccess('API deleted');
        fetchApis();
      } else {
        toast.showError(data.error || 'Failed to delete');
      }
    } catch {
      toast.showError('Failed to delete API');
    }
  };

  const resetForm = () => {
    setFormData({
      apiName: '',
      apiBaseUrl: '',
      apiEndpoint: '/api/transfer',
      apiMethod: 'POST',
      authType: 'bearer',
      apiKey: '',
      apiSecret: '',
      authHeader: '',
      contentType: 'application/json',
      requestTemplate: '',
      responseMapping: '',
      apiPreset: 'custom',
      isActive: true,
      isDefault: false,
      assignedServices: [],
      statusCheckUrl: '',
    });
    setEditingApi(null);
  };

  const handleOpenTestModal = (api: CustomApi) => {
    setSelectedApiForTest(api);
    setShowTestModal(true);
    setTestResponse(null);
    checkApiHealth(api);
  };

  const checkApiHealth = async (api: CustomApi) => {
    setApiHealthStatus((prev: Record<string, Record<string, string>>) => ({
      ...prev,
      [api.id]: { status: 'checking', lastCheck: new Date().toLocaleTimeString() }
    }));

    try {
      const response = await fetch('/api/admin/test-api', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiId: api.id }),
      });

      const data = await response.json();
      setApiHealthStatus((prev: Record<string, Record<string, string>>) => ({
        ...prev,
        [api.id]: {
          status: data.isOnline ? 'online' : 'offline',
          lastCheck: new Date().toLocaleTimeString()
        }
      }));
    } catch {
      setApiHealthStatus((prev: Record<string, Record<string, string>>) => ({
        ...prev,
        [api.id]: { status: 'offline', lastCheck: new Date().toLocaleTimeString() }
      }));
    }
  };

  const performApiTest = async () => {
    if (!selectedApiForTest) return;

    setTestingApi(true);
    try {
      const testPayload = {
        amount: 100,
        beneficiaryName: 'Test User',
        beneficiaryAccount: '2029001700058769',
        beneficiaryIfsc: 'PUNB0202900',
        beneficiaryVpa: 'amansingh9532@okicici',
        mobile_number: '9756862551',
        transferMode: 'IMPS'
      };

      const response = await fetch('/api/admin/test-api', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ apiId: selectedApiForTest.id, testPayload }),
      });

      const data = await response.json();
      setTestResponse({
        status: data.success ? 'success' : 'error',
        statusCode: data.statusCode,
        data: data.response,
        message: data.message,
        error: data.error,
      });
    } catch (_error) {
      setTestResponse({
        status: 'error',
        message: 'Failed to send test request',
        error: String(_error),
      });
    } finally {
      setTestingApi(false);
    }
  };

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <>
      <ConfirmProvider />
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Provider Master (API Gateway Management)</h1>
            <p className="text-gray-600 mt-2">Manage payment API providers that can be linked to schemes and assigned to users</p>
          </div>
          <button
            onClick={() => { resetForm(); setShowModal(true); }}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
          >
            + Add Payment API
          </button>
        </div>

        <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 p-6 rounded-xl">
          <div className="flex items-start gap-3">
            <div className="text-2xl">🔌</div>
            <div>
              <h3 className="font-semibold text-purple-900 mb-2">Custom API Integration</h3>
              <p className="text-sm text-purple-800">
                Configure payment APIs that can be assigned to users. Users without their own APIs will use these default APIs for transactions. Supports Bearer, Basic Auth, and API Key authentication.
              </p>
            </div>
          </div>
        </div>

        {/* Global Callback URL Section */}
        <div className="bg-white border p-6 rounded-xl shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                🔗 Global Callback URL
                <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 text-xs font-normal">POST</span>
              </h3>
              <p className="text-gray-600 text-sm mt-1">
                Provide this URL to your API providers/gateways (e.g. Fingrow, PayAtMe) to receive real-time transaction updates.
                Support updates for both PayIns and Payouts.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-gray-50 p-2 rounded-lg border">
            <code className="bg-white p-2 rounded font-mono text-sm border flex-1 text-gray-700 overflow-x-auto">
              {typeof window !== 'undefined' ? window.location.origin : ''}/api/v1/callbacks
            </code>
            <button
              onClick={() => {
                const url = `${window.location.origin}/api/v1/callbacks`;
                navigator.clipboard.writeText(url);
                toast.showSuccess('Callback URL copied!');
              }}
              className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded hover:bg-gray-50 font-medium text-sm whitespace-nowrap shadow-sm transition-colors"
            >
              Copy URL
            </button>
          </div>

          <div className="mt-3">
            <p className="text-xs text-gray-500">
              <strong>Expected Payload:</strong> <code>{`{ "transactionId": "...", "status": "success|failed", "utr": "..." }`}</code>
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="text-2xl font-bold text-blue-600">{apis.length}</div>
            <div className="text-sm text-gray-600">Total APIs</div>
          </div>
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{apis.filter(a => a.isActive).length}</div>
            <div className="text-sm text-gray-600">Active</div>
          </div>
          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">{apis.filter(a => a.isDefault).length}</div>
            <div className="text-sm text-gray-600">Default</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {apis.length === 0 ? (
            <div className="col-span-full bg-white p-12 rounded-lg border text-center text-gray-500">
              No payment APIs configured yet. Add your first API.
            </div>
          ) : (
            apis.map((api) => (
              <div key={api.id} className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{api.apiName}</h3>
                    <code className="text-xs text-gray-500">{api.apiBaseUrl}</code>
                  </div>
                  <div className="flex gap-2">
                    {api.isDefault && (
                      <span className="px-2 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-800">
                        Default
                      </span>
                    )}
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${api.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                      }`}>
                      {api.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-sm mb-4">
                  <div>
                    <span className="text-gray-500">API Number:</span>
                    <span className="ml-2 font-mono text-blue-600">{api.apiNumber || 'N/A'}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">User:</span>
                    <span className="ml-2 font-medium">{api.adminProvided ? 'Admin' : 'User Submitted'}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Endpoint:</span>
                    <span className="ml-2 font-medium">{api.apiEndpoint}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Method:</span>
                    <span className="ml-2 font-medium">{api.apiMethod}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Auth:</span>
                    <span className="ml-2 font-medium capitalize">{api.authType}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Services:</span>
                    <span className="ml-2 font-medium">{api.assignedServices.length || 'All'}</span>
                  </div>
                </div>

                {/* API-Specific Callback URL */}
                <div className="mt-3 pt-3 border-t">
                  <div className="text-xs text-gray-500 mb-1">API Callback URL:</div>
                  <div className="flex items-center gap-2">
                    <code className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded font-mono flex-1 truncate">
                      {typeof window !== 'undefined' ? `${window.location.origin}/api/callback/${api.apiNumber}` : ''}
                    </code>
                    <button
                      onClick={() => {
                        const url = `${window.location.origin}/api/callback/${api.apiNumber}`;
                        navigator.clipboard.writeText(url);
                        toast.showSuccess('Callback URL copied!');
                      }}
                      className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
                    >
                      Copy
                    </button>
                  </div>
                </div>

                {/* Status Check URL */}
                {(api as any).statusCheckUrl && (
                  <div className="mt-3 pt-3 border-t">
                    <div className="text-xs text-gray-500 mb-1">Status Check URL:</div>
                    <code className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded font-mono block truncate">
                      {(api as any).statusCheckUrl}
                    </code>
                  </div>
                )}

                <div className="flex gap-2">
                  <button
                    onClick={() => handleOpenTestModal(api)}
                    className="flex-1 px-3 py-2 bg-green-100 text-green-700 rounded hover:bg-green-200 text-sm font-medium"
                  >
                    🧪 Test
                  </button>
                  <button
                    onClick={() => handleEdit(api)}
                    className="flex-1 px-3 py-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 text-sm font-medium"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(api.id, api.apiName)}
                    className="flex-1 px-3 py-2 bg-red-100 text-red-700 rounded hover:bg-red-200 text-sm font-medium"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-8 w-full max-w-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
              <h2 className="text-2xl font-bold mb-6">{editingApi ? 'Edit' : 'Add'} Payment API</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* API Preset Selector */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <label className="block text-sm font-semibold text-blue-900 mb-2">Quick Setup (API Preset)</label>
                  <select
                    value={formData.apiPreset}
                    onChange={(e) => {
                      const preset = e.target.value as keyof typeof API_PRESETS;
                      const config = API_PRESETS[preset];
                      if (config) {
                        setFormData({
                          ...formData,
                          apiPreset: preset,
                          apiName: preset === 'custom' ? formData.apiName : config.name,
                          contentType: config.contentType,
                          requestTemplate: config.requestTemplate,
                          responseMapping: config.responseMapping,
                          authType: (config as any).authType || formData.authType,
                          apiSecret: preset === 'kgipay' ? JSON.stringify({
                            clientKey: "",
                            secret: "",
                            accessToken: ""
                          }, null, 2) : formData.apiSecret
                        });
                      }
                    }}
                    className="w-full px-4 py-2 border border-blue-300 rounded-lg bg-white"
                  >
                    <option value="custom">Custom API (Manual Configuration)</option>
                    <option value="zyontic">Zyontic Payout</option>
                    <option value="payatme">PayAtMe (Auto-fill)</option>
                    <option value="fingrow">Fingrow (Auto-fill)</option>
                    <option value="gammingpay">GammingPay</option>
                    <option value="kgipay">KGIPay</option>
                    <option value="rudraxpay">RudraxPay</option>
                  </select>
                  <p className="text-xs text-blue-700 mt-2">Select a preset to auto-fill configuration for known APIs</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">API Name *</label>
                  <input
                    type="text"
                    value={formData.apiName}
                    onChange={(e) => setFormData({ ...formData, apiName: e.target.value })}
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder="My Payment Gateway API"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Base URL *</label>
                  <input
                    type="url"
                    value={formData.apiBaseUrl}
                    onChange={(e) => setFormData({ ...formData, apiBaseUrl: e.target.value })}
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder="https://api.paymentgateway.com"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Status Check URL (GET)</label>
                  <input
                    type="url"
                    value={formData.statusCheckUrl}
                    onChange={(e) => setFormData({ ...formData, statusCheckUrl: e.target.value })}
                    className="w-full px-4 py-2 border rounded-lg"
                    placeholder="https://api.provider.com/status?txnId="
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Provider's URL to check pending transaction status. System will append ?transactionId=xxx
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Endpoint *</label>
                    <input
                      type="text"
                      value={formData.apiEndpoint}
                      onChange={(e) => setFormData({ ...formData, apiEndpoint: e.target.value })}
                      className="w-full px-4 py-2 border rounded-lg"
                      placeholder="/api/transfer"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Method *</label>
                    <select
                      value={formData.apiMethod}
                      onChange={(e) => setFormData({ ...formData, apiMethod: e.target.value })}
                      className="w-full px-4 py-2 border rounded-lg"
                    >
                      <option value="POST">POST</option>
                      <option value="GET">GET</option>
                      <option value="PUT">PUT</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Authentication Type *</label>
                  <select
                    value={formData.authType}
                    onChange={(e) => setFormData({ ...formData, authType: e.target.value })}
                    className="w-full px-4 py-2 border rounded-lg"
                  >
                    <option value="bearer">Bearer Token</option>
                    <option value="basic">Basic Auth</option>
                    <option value="apikey">API Key</option>
                    <option value="gammingpay">GammingPay</option>
                    <option value="custom_config">Custom / Multiple Inputs</option>
                  </select>
                </div>

                {formData.authType === 'bearer' && (
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      {(formData.apiPreset === 'zyontic' || formData.apiName.toLowerCase().includes('zyontic')) ? 'API Token' : 'Bearer Token'}
                    </label>
                    <input
                      type="text"
                      value={formData.apiKey}
                      onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                      className="w-full px-4 py-2 border rounded-lg font-mono text-sm"
                      placeholder={(formData.apiPreset === 'zyontic' || formData.apiName.toLowerCase().includes('zyontic')) ? 'your_zyontic_api_token' : 'your_bearer_token_here'}
                    />
                  </div>
                )}

                {formData.authType === 'basic' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        {(formData.apiPreset === 'zyontic' || formData.apiName.toLowerCase().includes('zyontic')) ? 'Client ID' : 'Username'}
                      </label>
                      <input
                        type="text"
                        value={formData.apiKey}
                        onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                        className="w-full px-4 py-2 border rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        {(formData.apiPreset === 'zyontic' || formData.apiName.toLowerCase().includes('zyontic')) ? 'API Token' : 'Password'}
                      </label>
                      <input
                        type="password"
                        value={formData.apiSecret}
                        onChange={(e) => setFormData({ ...formData, apiSecret: e.target.value })}
                        className="w-full px-4 py-2 border rounded-lg"
                      />
                    </div>
                  </div>
                )}

                {formData.authType === 'gammingpay' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Secret Key</label>
                      <input
                        type="text"
                        value={formData.apiKey}
                        onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                        className="w-full px-4 py-2 border rounded-lg font-mono text-sm"
                        placeholder="************"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Salt Key</label>
                      <input
                        type="password"
                        value={formData.apiSecret}
                        onChange={(e) => setFormData({ ...formData, apiSecret: e.target.value })}
                        className="w-full px-4 py-2 border rounded-lg font-mono text-sm"
                        placeholder="**************"
                      />
                    </div>
                  </div>
                )}

                {formData.authType === 'apikey' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">Header Name</label>
                      <input
                        type="text"
                        value={formData.authHeader}
                        onChange={(e) => setFormData({ ...formData, authHeader: e.target.value })}
                        className="w-full px-4 py-2 border rounded-lg"
                        placeholder="X-API-Key"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">API Key</label>
                      <input
                        type="text"
                        value={formData.apiKey}
                        onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                        className="w-full px-4 py-2 border rounded-lg"
                      />
                    </div>
                  </div>
                )}

                {formData.authType === 'custom_config' && (
                  <div className="space-y-4 bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <div className="flex justify-between items-center mb-2">
                      <label className="block text-sm font-semibold text-blue-900">Custom Credentials (Multiple Inputs)</label>
                      <button
                        type="button"
                        onClick={() => {
                          try {
                            const current = formData.apiSecret ? JSON.parse(formData.apiSecret) : {};
                            const newKey = `Key ${Object.keys(current).length + 1}`;
                            const updated = { ...current, [newKey]: '' };
                            setFormData({ ...formData, apiSecret: JSON.stringify(updated, null, 2) });
                          } catch {
                            setFormData({ ...formData, apiSecret: JSON.stringify({ "Key 1": "" }, null, 2) });
                          }
                        }}
                        className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded hover:bg-blue-200"
                      >
                        + Add Field
                      </button>
                    </div>

                    {(() => {
                      let config = {};
                      try {
                        config = formData.apiSecret ? JSON.parse(formData.apiSecret) : {};
                      } catch (e) {
                        return <div className="text-red-500 text-sm">Error parsing configuration JSON. Please reset.</div>;
                      }

                      return Object.entries(config).map(([key, value], index) => (
                        <div key={index} className="flex gap-2 items-center mb-2">
                          <input
                            type="text"
                            value={key}
                            onChange={(e) => {
                              const newKey = e.target.value;
                              const newConfig: any = {};
                              Object.keys(config).forEach(k => {
                                if (k === key) newConfig[newKey] = value;
                                else newConfig[k] = (config as any)[k];
                              });
                              setFormData({ ...formData, apiSecret: JSON.stringify(newConfig, null, 2) });
                            }}
                            className="w-1/3 px-3 py-2 border rounded text-sm"
                            placeholder="Key (e.g. client_id)"
                          />
                          <input
                            type="text"
                            value={value as string}
                            onChange={(e) => {
                              const newValue = e.target.value;
                              const newConfig = { ...config, [key]: newValue };
                              setFormData({ ...formData, apiSecret: JSON.stringify(newConfig, null, 2) });
                            }}
                            className="flex-1 px-3 py-2 border rounded text-sm"
                            placeholder="Value"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              const newConfig = { ...config };
                              delete (newConfig as any)[key];
                              setFormData({ ...formData, apiSecret: JSON.stringify(newConfig, null, 2) });
                            }}
                            className="text-red-500 hover:text-red-700 px-2"
                          >
                            ×
                          </button>
                        </div>
                      ));
                    })()}

                    <div className="mt-2">
                      <p className="text-xs text-gray-500">
                        Raw Configuration JSON (Advanced):
                      </p>
                      <textarea
                        value={formData.apiSecret}
                        onChange={(e) => setFormData({ ...formData, apiSecret: e.target.value })}
                        className="w-full px-3 py-2 border rounded text-xs font-mono mt-1 h-24"
                        placeholder="{}"
                      />
                    </div>
                  </div>
                )}

                {/* Advanced Configuration Section */}
                <div className="border-t pt-4 mt-4">
                  <h4 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    Advanced Configuration
                  </h4>

                  {/* Content Type */}
                  <div className="mb-4">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Content Type</label>
                    <select
                      value={formData.contentType}
                      onChange={(e) => setFormData({ ...formData, contentType: e.target.value })}
                      className="w-full px-4 py-2 border rounded-lg"
                    >
                      <option value="application/json">JSON (application/json)</option>
                      <option value="multipart/form-data">Form Data (multipart/form-data)</option>
                      <option value="application/x-www-form-urlencoded">URL Encoded (x-www-form-urlencoded)</option>
                    </select>
                    <p className="text-xs text-gray-500 mt-1">How the request body should be formatted</p>
                  </div>

                  {/* Request Body Template */}
                  <div className="mb-4">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Request Body Template
                      <span className="text-xs text-gray-500 font-normal ml-2">(JSON format with placeholders)</span>
                    </label>
                    <textarea
                      value={formData.requestTemplate}
                      onChange={(e) => setFormData({ ...formData, requestTemplate: e.target.value })}
                      className="w-full px-4 py-2 border rounded-lg font-mono text-sm h-32"
                      placeholder={`{
  "amount": "{{amount}}",
  "account_number": "{{beneficiaryAccount}}",
  "beneficiary_name": "{{beneficiaryName}}",
  "ifsc": "{{beneficiaryIfsc}}"
}`}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Placeholders: <code className="bg-gray-100 px-1 rounded">{'{{amount}}'}</code>,
                      <code className="bg-gray-100 px-1 rounded ml-1">{'{{beneficiaryAccount}}'}</code>,
                      <code className="bg-gray-100 px-1 rounded ml-1">{'{{beneficiaryName}}'}</code>,
                      <code className="bg-gray-100 px-1 rounded ml-1">{'{{transactionId}}'}</code>
                    </p>
                  </div>

                  {/* Response Mapping */}
                  <div className="mb-4">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Response Field Mapping
                    </label>
                    <textarea
                      value={formData.responseMapping}
                      onChange={(e) => setFormData({ ...formData, responseMapping: e.target.value })}
                      className="w-full px-4 py-2 border rounded-lg font-mono text-sm h-32"
                      placeholder={`{
  "statusField": "status",
  "successValue": "success",
  "failureValue": "failed",
  "utrField": "utr_number",
  "messageField": "message"
}`}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Define how to extract status, UTR, and message from the API response
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="isActive"
                      checked={formData.isActive}
                      onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                      className="w-4 h-4"
                    />
                    <label htmlFor="isActive" className="text-sm font-medium text-gray-700">Active</label>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="isDefault"
                      checked={formData.isDefault}
                      onChange={(e) => setFormData({ ...formData, isDefault: e.target.checked })}
                      className="w-4 h-4"
                    />
                    <label htmlFor="isDefault" className="text-sm font-medium text-gray-700">Set as Default</label>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-medium"
                  >
                    {editingApi ? 'Update' : 'Add'} API
                  </button>
                  <button
                    type="button"
                    onClick={() => { setShowModal(false); resetForm(); }}
                    className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showTestModal && selectedApiForTest && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-8 w-full max-w-3xl shadow-2xl max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">Test API: {selectedApiForTest.apiName}</h2>
                <button
                  onClick={() => setShowTestModal(false)}
                  className="text-gray-500 hover:text-gray-700 text-2xl"
                >
                  ×
                </button>
              </div>

              <div className="space-y-6">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-900 mb-2">API Configuration</h3>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Base URL:</span>
                      <code className="block text-xs bg-white p-2 rounded mt-1">{selectedApiForTest.apiBaseUrl}</code>
                    </div>
                    <div>
                      <span className="text-gray-600">Endpoint:</span>
                      <code className="block text-xs bg-white p-2 rounded mt-1">{selectedApiForTest.apiEndpoint}</code>
                    </div>
                    <div>
                      <span className="text-gray-600">Method:</span>
                      <code className="block text-xs bg-white p-2 rounded mt-1">{selectedApiForTest.apiMethod}</code>
                    </div>
                    <div>
                      <span className="text-gray-600">Auth Type:</span>
                      <code className="block text-xs bg-white p-2 rounded mt-1">{selectedApiForTest.authType}</code>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">Health Status</h3>
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center gap-3">
                      {apiHealthStatus[selectedApiForTest.id]?.status === 'checking' && (
                        <span className="text-yellow-600">⏳ Checking...</span>
                      )}
                      {apiHealthStatus[selectedApiForTest.id]?.status === 'online' && (
                        <span className="text-green-600">✅ Online</span>
                      )}
                      {apiHealthStatus[selectedApiForTest.id]?.status === 'offline' && (
                        <span className="text-red-600">❌ Offline</span>
                      )}
                      <span className="text-xs text-gray-500">
                        Last check: {apiHealthStatus[selectedApiForTest.id]?.lastCheck || 'Never'}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">Test Payload</h3>
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                    <pre className="text-xs text-gray-700 whitespace-pre-wrap break-words">
                      {JSON.stringify({
                        amount: 100,
                        beneficiaryName: 'Test User',
                        beneficiaryAccount: '2029001700058769',
                        beneficiaryIfsc: 'PUNB0202900',
                        beneficiaryVpa: 'amansingh9532@okicici',
                        transferMode: 'IMPS'
                      }, null, 2)}
                    </pre>
                  </div>
                </div>

                <button
                  onClick={performApiTest}
                  disabled={testingApi}
                  className="w-full bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 disabled:bg-gray-400 font-semibold"
                >
                  {testingApi ? '⏳ Testing...' : '▶ Send Test Request'}
                </button>

                {testResponse && (
                  <div className={`border-2 rounded-lg p-4 ${testResponse.status === 'success'
                    ? 'bg-green-50 border-green-300'
                    : 'bg-red-50 border-red-300'
                    }`}>
                    <h3 className={`font-semibold mb-3 ${testResponse.status === 'success' ? 'text-green-900' : 'text-red-900'
                      }`}>
                      {testResponse.status === 'success' ? '✅ Success' : '❌ Error'} (Status: {testResponse.statusCode})
                    </h3>
                    <div className="space-y-2">
                      <div>
                        <span className="text-sm text-gray-600">Message:</span>
                        <p className="text-sm font-medium">{testResponse.message}</p>
                      </div>
                      {testResponse.error && (
                        <div>
                          <span className="text-sm text-gray-600">Error:</span>
                          <code className="block text-xs bg-white p-2 rounded mt-1 text-red-600">{testResponse.error}</code>
                        </div>
                      )}
                      {testResponse.data ? (() => {
                        const dataStr = typeof testResponse.data === 'string' ? testResponse.data : JSON.stringify(testResponse.data);
                        return (
                          <div>
                            <span className="text-sm text-gray-600">Response Data:</span>
                            <pre className="text-xs bg-white p-3 rounded mt-1 overflow-x-auto" style={{ whiteSpace: 'pre-wrap', wordWrap: 'break-word' }}>
                              {dataStr}
                            </pre>
                          </div>
                        );
                      })() : null}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex gap-3 pt-6">
                <button
                  onClick={() => setShowRequirementsDoc(true)}
                  className="flex-1 bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 font-medium"
                >
                  📋 View Requirements
                </button>
                <button
                  onClick={() => setShowTestModal(false)}
                  className="flex-1 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

        {showRequirementsDoc && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-8 w-full max-w-4xl shadow-2xl max-h-[90vh] overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">API Requirements & Documentation</h2>
                <button
                  onClick={() => setShowRequirementsDoc(false)}
                  className="text-gray-500 hover:text-gray-700 text-2xl"
                >
                  ×
                </button>
              </div>

              <div className="space-y-6 text-sm">
                <div>
                  <h3 className="font-semibold text-lg mb-3 text-gray-900">1. Required Request Fields</h3>
                  <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                    <div className="flex justify-between">
                      <code className="font-mono text-blue-600">amount</code>
                      <span className="text-gray-600">number (in paise, e.g., 10000 = ₹100)</span>
                    </div>
                    <div className="flex justify-between">
                      <code className="font-mono text-blue-600">beneficiaryName</code>
                      <span className="text-gray-600">string (required)</span>
                    </div>
                    <div className="flex justify-between">
                      <code className="font-mono text-blue-600">transferMode</code>
                      <span className="text-gray-600">string (upi, neft, imps, credit_card_bill)</span>
                    </div>
                    <div className="flex justify-between">
                      <code className="font-mono text-blue-600">beneficiaryAccount</code>
                      <span className="text-gray-600">string (required for bank transfers)</span>
                    </div>
                    <div className="flex justify-between">
                      <code className="font-mono text-blue-600">beneficiaryIfsc</code>
                      <span className="text-gray-600">string (required for bank transfers)</span>
                    </div>
                    <div className="flex justify-between">
                      <code className="font-mono text-blue-600">beneficiaryVpa</code>
                      <span className="text-gray-600">string (required for UPI transfers)</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-lg mb-3 text-gray-900">2. Expected Success Response Format</h3>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <pre className="text-xs text-green-900 whitespace-pre-wrap break-words">
                      {JSON.stringify({
                        transactionId: "txn_123456",
                        status: "success",
                        utrNumber: "314159265359",
                        amount: 10000,
                        timestamp: "2024-01-15T10:30:00Z"
                      }, null, 2)}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-lg mb-3 text-gray-900">3. Expected Error Response Format</h3>
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <pre className="text-xs text-red-900 whitespace-pre-wrap break-words">
                      {JSON.stringify({
                        status: "error",
                        code: "INSUFFICIENT_FUNDS",
                        message: "Insufficient funds for this transaction"
                      }, null, 2)}
                    </pre>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-lg mb-3 text-gray-900">4. Authentication Methods</h3>
                  <div className="space-y-4">
                    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Bearer Token</h4>
                      <code className="block text-xs bg-white p-2 rounded mb-2 text-gray-700">Authorization: Bearer YOUR_TOKEN_HERE</code>
                    </div>
                    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                      <h4 className="font-semibold text-gray-900 mb-2">API Key Header</h4>
                      <code className="block text-xs bg-white p-2 rounded mb-2 text-gray-700">X-API-Key: YOUR_API_KEY_HERE</code>
                      <p className="text-xs text-gray-600">(Header name is configurable)</p>
                    </div>
                    <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                      <h4 className="font-semibold text-gray-900 mb-2">Basic Auth</h4>
                      <code className="block text-xs bg-white p-2 rounded mb-2 text-gray-700">Authorization: Basic base64(username:password)</code>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-lg mb-3 text-gray-900">5. HTTP Status Codes</h3>
                  <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                    <div className="flex justify-between">
                      <code className="font-mono text-green-600">200</code>
                      <span className="text-gray-600">OK - Request successful</span>
                    </div>
                    <div className="flex justify-between">
                      <code className="font-mono text-yellow-600">400</code>
                      <span className="text-gray-600">Bad Request - Invalid parameters</span>
                    </div>
                    <div className="flex justify-between">
                      <code className="font-mono text-red-600">401</code>
                      <span className="text-gray-600">Unauthorized - Invalid credentials</span>
                    </div>
                    <div className="flex justify-between">
                      <code className="font-mono text-red-600">500</code>
                      <span className="text-gray-600">Server Error - API error</span>
                    </div>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowRequirementsDoc(false)}
                className="w-full mt-6 bg-gray-200 text-gray-700 py-2 rounded-lg hover:bg-gray-300 font-medium"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useGlobalToast } from '@/context/ToastContext';

interface FingrowApi {
  id: string;
  name: string;
  description?: string;
  baseUrl: string;
  apiKey: string;
  isActive: boolean;
  isDefault: boolean;
  createdAt: string;
}

export default function AdminFingrowApisPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const [apis, setApis] = useState<FingrowApi[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingApi, setEditingApi] = useState<FingrowApi | null>(null);
  const [formData, setFormData] = useState({
    name: 'Fingrow Default',
    description: 'Default Fingrow payment gateway for all users',
    baseUrl: 'https://pay.fingrowaitech.com/transaction/transactions/api/initiate',
    apiKey: '',
    isActive: true,
    isDefault: false,
  });
  const [showQuickSetup, setShowQuickSetup] = useState(apis.length === 0);

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    const userRole = (session?.user as { role?: string })?.role;
    if (userRole !== 'ADMIN') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') {
      fetchApis();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, status]);

  const fetchApis = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/fingrow-apis');
      const data = await response.json();
      if (data.success) setApis(data.data);
    } catch (_error) {
      toast.showError('Failed to load Fingrow APIs');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const url = editingApi
        ? `/api/admin/fingrow-apis/${editingApi.id}`
        : '/api/admin/fingrow-apis';
      const method = editingApi ? 'PATCH' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();
      if (response.ok) {
        toast.showSuccess(editingApi ? 'API updated successfully' : 'API created successfully');
        setShowModal(false);
        setEditingApi(null);
        setFormData({
          name: '',
          description: '',
          baseUrl: 'https://pay.fingrowaitech.com/transaction/transactions/api/initiate',
          apiKey: '',
          isActive: true,
          isDefault: false,
        });
        fetchApis();
      } else {
        toast.showError(data.error || 'Failed to save API');
      }
    } catch (_error) {
      toast.showError('Failed to save API');
    }
  };

  const handleEdit = (api: FingrowApi) => {
    setEditingApi(api);
    setFormData({
      name: api.name,
      description: api.description || '',
      baseUrl: api.baseUrl,
      apiKey: api.apiKey,
      isActive: api.isActive,
      isDefault: api.isDefault,
    });
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this API?')) return;
    try {
      const response = await fetch(`/api/admin/fingrow-apis/${id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        toast.showSuccess('API deleted successfully');
        fetchApis();
      } else {
        toast.showError('Failed to delete API');
      }
    } catch (_error) {
      toast.showError('Failed to delete API');
    }
  };

  if (loading) return <div className="p-6">Loading Fingrow APIs...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Fingrow API Management</h1>
          <p className="text-gray-600 mt-1">Configure Fingrow payment gateway instances for all users</p>
        </div>
        <button
          onClick={() => {
            setEditingApi(null);
            setFormData({
              name: 'Fingrow Default',
              description: 'Default Fingrow payment gateway for all users',
              baseUrl: 'https://pay.fingrowaitech.com/transaction/transactions/api/initiate',
              apiKey: '',
              isActive: true,
              isDefault: false,
            });
            setShowModal(true);
          }}
          className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
        >
          + Add Fingrow API
        </button>
      </div>

      {apis.length === 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <h3 className="font-semibold text-yellow-900 mb-2">⚠️ No Fingrow API Configured</h3>
          <p className="text-sm text-yellow-800 mb-3">
            Users cannot make payouts until you configure a Fingrow payment gateway. Add your Fingrow Merchant ID below to enable payouts for all users.
          </p>
          <button
            onClick={() => {
              setEditingApi(null);
              setFormData({
                name: 'Fingrow Default',
                description: 'Default Fingrow payment gateway for all users',
                baseUrl: 'https://pay.fingrowaitech.com/transaction/transactions/api/initiate',
                apiKey: '',
                isActive: true,
                isDefault: true,
              });
              setShowModal(true);
            }}
            className="bg-yellow-600 text-white px-4 py-2 rounded hover:bg-yellow-700 text-sm"
          >
            Configure Fingrow Now
          </button>
        </div>
      )}

      <div className="grid gap-4">
        {apis.length === 0 ? (
          <div className="bg-white rounded-lg p-6 text-center text-gray-600">
            No Fingrow APIs configured yet. Click "Add Fingrow API" to get started.
          </div>
        ) : (
          apis.map((api) => (
            <div key={api.id} className="bg-white rounded-lg p-6 shadow-sm border">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <h3 className="text-lg font-semibold text-gray-900">{api.name}</h3>
                    <span
                      className={`px-2 py-1 text-xs rounded-full ${api.isActive
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                        }`}
                    >
                      {api.isActive ? 'Active' : 'Inactive'}
                    </span>
                    {api.isDefault && (
                      <span className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full">
                        Default
                      </span>
                    )}
                  </div>
                  {api.description && (
                    <p className="text-gray-600 text-sm mt-1">{api.description}</p>
                  )}
                  <div className="mt-3 text-sm text-gray-500 space-y-1">
                    <p>
                      <strong>Endpoint:</strong> {api.baseUrl}
                    </p>
                    <p>
                      <strong>Merchant ID:</strong> {api.apiKey.substring(0, 8)}...
                    </p>
                    <p>
                      <strong>Created:</strong> {new Date(api.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2 ml-4">
                  <button
                    onClick={() => handleEdit(api)}
                    className="px-3 py-1 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(api.id)}
                    className="px-3 py-1 text-sm bg-red-100 text-red-700 rounded hover:bg-red-200"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4 max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-4">
              {editingApi ? 'Edit Fingrow API' : 'Add Fingrow API'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  API Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description (Optional)
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  rows={2}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Endpoint URL
                </label>
                <input
                  type="url"
                  value={formData.baseUrl}
                  onChange={(e) => setFormData({ ...formData, baseUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Merchant ID
                </label>
                <input
                  type="password"
                  value={formData.apiKey}
                  onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter your Fingrow Merchant ID"
                  required
                />
              </div>

              <div className="flex gap-4">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={formData.isActive}
                    onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                    className="rounded"
                  />
                  <span className="ml-2 text-sm">Active</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={formData.isDefault}
                    onChange={(e) => setFormData({ ...formData, isDefault: e.target.checked })}
                    className="rounded"
                  />
                  <span className="ml-2 text-sm">Set as default</span>
                </label>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setEditingApi(null);
                  }}
                  className="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  {editingApi ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}


    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Modal } from '@/components/modal';
import { useGlobalToast } from '@/context/ToastContext';
import { formatINR } from '@/lib/money';

interface PayIn {
  id: string;
  userId: string;
  userName: string | null;
  userEmail: string | null;
  amount: number;
  customerName: string | null;
  customerEmail: string | null;
  paymentMethod: string;
  utrNumber: string | null;
  status: string;
  createdAt: string;
}

export default function AdminPayinsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const [payins, setPayins] = useState<PayIn[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ status: 'all', dateFrom: '', dateTo: '' });
  const [stats, setStats] = useState({ total: 0, success: 0, pending: 0, totalAmount: 0 });
  const [selectedPayin, setSelectedPayin] = useState<PayIn | null>(null);
  const [showApprovalModal, setShowApprovalModal] = useState(false);
  const [utrNumber, setUtrNumber] = useState('');

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if ((session?.user as any)?.role !== 'ADMIN') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') fetchPayins();
  }, [session, status]);

  const fetchPayins = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/payins');
      const data = await response.json();
      if (data.success) {
        setPayins(data.data);
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Failed to fetch payins:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApproveClick = (payin: PayIn) => {
    setSelectedPayin(payin);
    setUtrNumber(payin.utrNumber || '');
    setShowApprovalModal(true);
  };

  const handleApprove = async () => {
    if (!selectedPayin) return;

    try {
      const response = await fetch('/api/admin/payins', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedPayin.id,
          status: 'success',
          utrNumber: utrNumber || selectedPayin.utrNumber
        }),
      });

      const data = await response.json();

      if (response.ok) {
        toast.showSuccess(data.message || 'PayIn approved and wallet credited');
        setShowApprovalModal(false);
        setSelectedPayin(null);
        setUtrNumber('');
        fetchPayins();
      } else {
        toast.showError(data.error || 'Failed to approve PayIn');
      }
    } catch (error) {
      toast.showError('Failed to approve PayIn');
    }
  };

  const handleReject = async (id: string) => {
    if (!confirm('Are you sure you want to reject this PayIn request?')) return;

    try {
      const response = await fetch('/api/admin/payins', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: 'failed' }),
      });

      const data = await response.json();

      if (response.ok) {
        toast.showSuccess('PayIn rejected');
        fetchPayins();
      } else {
        toast.showError(data.error || 'Failed to reject PayIn');
      }
    } catch (error) {
      toast.showError('Failed to reject PayIn');
    }
  };

  const filteredPayins = payins.filter(p => {
    if (filter.status !== 'all' && p.status !== filter.status) return false;
    if (filter.dateFrom && new Date(p.createdAt) < new Date(filter.dateFrom)) return false;
    if (filter.dateTo && new Date(p.createdAt) > new Date(filter.dateTo + 'T23:59:59')) return false;
    return true;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'processing': return 'bg-blue-100 text-blue-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">All PayIns</h1>
        <p className="text-gray-600 mt-2">View and manage all incoming payment transactions</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="text-2xl font-bold text-green-600">{stats.total}</div>
          <div className="text-sm text-gray-600">Total PayIns</div>
        </div>
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
          <div className="text-2xl font-bold text-emerald-600">{stats.success}</div>
          <div className="text-sm text-gray-600">Successful</div>
        </div>
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="text-2xl font-bold text-yellow-600">{stats.pending}</div>
          <div className="text-sm text-gray-600">Pending</div>
        </div>
        <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
          <div className="text-2xl font-bold text-purple-600">{formatINR(stats.totalAmount)}</div>
          <div className="text-sm text-gray-600">Total Volume</div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg border flex flex-wrap gap-4 items-end">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
          <select value={filter.status} onChange={(e) => setFilter({ ...filter, status: e.target.value })} className="px-3 py-2 border rounded-lg">
            <option value="all">All Status</option>
            <option value="success">Success</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="failed">Failed</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">From</label>
          <input type="date" value={filter.dateFrom} onChange={(e) => setFilter({ ...filter, dateFrom: e.target.value })} className="px-3 py-2 border rounded-lg" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">To</label>
          <input type="date" value={filter.dateTo} onChange={(e) => setFilter({ ...filter, dateTo: e.target.value })} className="px-3 py-2 border rounded-lg" />
        </div>
      </div>

      <div className="bg-white rounded-lg border overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Merchant</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Customer</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Amount</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Method</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">UTR</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {filteredPayins.length === 0 ? (
              <tr><td colSpan={8} className="px-4 py-12 text-center text-gray-500">No payins found</td></tr>
            ) : (
              filteredPayins.map((p) => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm">
                    <div>{new Date(p.createdAt).toLocaleDateString()}</div>
                    <div className="text-xs text-gray-500">{new Date(p.createdAt).toLocaleTimeString()}</div>
                  </td>
                  <td className="px-4 py-3 text-sm">
                    <div className="font-medium">{p.userName || 'N/A'}</div>
                    <div className="text-xs text-gray-500">{p.userEmail}</div>
                  </td>
                  <td className="px-4 py-3 text-sm">
                    <div>{p.customerName || 'N/A'}</div>
                    <div className="text-xs text-gray-500">{p.customerEmail || '-'}</div>
                  </td>
                  <td className="px-4 py-3 font-semibold text-green-600">+{formatINR(p.amount)}</td>
                  <td className="px-4 py-3"><span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs rounded uppercase">{p.paymentMethod}</span></td>
                  <td className="px-4 py-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(p.status)}`}>{p.status}</span></td>
                  <td className="px-4 py-3 text-sm font-mono">{p.utrNumber || '-'}</td>
                  <td className="px-4 py-3">
                    {p.status === 'pending' && (
                      <div className="flex gap-1">
                        <button onClick={() => handleApproveClick(p)} className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-xs font-medium transition-colors">Approve</button>
                        <button onClick={() => handleReject(p.id)} className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-xs font-medium transition-colors">Reject</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {showApprovalModal && selectedPayin && (
        <Modal
          isOpen={showApprovalModal}
          onClose={() => {
            setShowApprovalModal(false);
            setSelectedPayin(null);
            setUtrNumber('');
          }}
          title="Approve PayIn Request"
        >
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-lg space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">User:</span>
                <span className="text-sm font-medium">{selectedPayin.userName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Amount:</span>
                <span className="text-lg font-bold text-green-600">{formatINR(selectedPayin?.amount || 0)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Payment Method:</span>
                <span className="text-sm font-medium uppercase">{selectedPayin.paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Date:</span>
                <span className="text-sm">{new Date(selectedPayin.createdAt).toLocaleString()}</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                UTR Number (Optional)
              </label>
              <input
                type="text"
                value={utrNumber}
                onChange={(e) => setUtrNumber(e.target.value)}
                placeholder="Enter UTR number"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">Transaction reference number for tracking</p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-800">
                ⚠️ <strong>Note:</strong> Approving this request will credit the user's wallet after deducting applicable transaction charges.
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={handleApprove}
                className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-colors"
              >
                ✓ Approve & Credit Wallet
              </button>
              <button
                onClick={() => {
                  setShowApprovalModal(false);
                  setSelectedPayin(null);
                  setUtrNumber('');
                }}
                className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-700 font-medium rounded-lg transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

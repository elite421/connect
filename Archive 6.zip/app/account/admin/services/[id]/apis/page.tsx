'use client';

import { useEffect, useState, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter, useParams } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { FormBuilder, type FormField } from '@/components/form-builder';
import { useGlobalToast } from '@/context/ToastContext';
import { useConfirm } from '@/hooks/useConfirm';

interface ServiceApi {
  id: string;
  serviceId: string;
  apiId?: string; // Legacy
  customApiId?: string; // New
  api?: {
    id: string;
    code: string;
    name: string;
    provider: string;
  };
  customApi?: {
    id: string;
    apiName: string;
    apiBaseUrl: string;
    apiEndpoint: string;
  };
  isDefault: boolean;
  priority: number;
  createdAt: string;
}

interface PaymentGateway {
  id: string;
  code: string;
  name: string;
  provider: string;
  isActive: boolean;
}

interface CustomPaymentApi {
  id: string;
  apiName: string;
  apiBaseUrl: string;
  isActive: boolean;
}

interface Service {
  id: string;
  code: string;
  name: string;
}

export default function ServiceApisPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const params = useParams();
  const serviceId = params?.id as string;

  const toast = useGlobalToast();
  const { confirm, ConfirmProvider } = useConfirm();

  const [serviceApis, setServiceApis] = useState<ServiceApi[]>([]);
  const [gateways, setGateways] = useState<PaymentGateway[]>([]);
  const [customApis, setCustomApis] = useState<CustomPaymentApi[]>([]);
  const [service, setService] = useState<Service | null>(null);
  const [loading, setLoading] = useState(true);
  const [gatewaysLoading, setGatewaysLoading] = useState(false);
  const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedServiceApi, setSelectedServiceApi] = useState<ServiceApi | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    const userRole = (session?.user as { role?: string })?.role;
    if (userRole !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchServiceApis = useCallback(async (offset: number = 0) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        serviceId: serviceId,
        offset: offset.toString(),
        limit: '50',
      });
      const response = await fetch(`/api/admin/service-apis?${params}`);
      const data = await response.json();
      if (data.success) {
        setServiceApis(data.data);
        setPagination(data.pagination);
      } else {
        toast.showError('Failed to fetch service APIs');
      }
    } catch (error) {
      console.error('Failed to fetch service APIs:', error);
      toast.showError('Error fetching service APIs');
    } finally {
      setLoading(false);
    }
  }, [serviceId, toast]);

  const fetchGateways = useCallback(async () => {
    setGatewaysLoading(true);
    try {
      const response = await fetch('/api/admin/gateways?limit=1000&showInactive=true');
      const data = await response.json();
      if (data.success) {
        setGateways(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch gateways:', error);
    } finally {
      setGatewaysLoading(false);
    }
  }, []);

  const fetchCustomApis = useCallback(async () => {
    try {
      const response = await fetch('/api/admin/custom-apis');
      const data = await response.json();
      if (data.success) {
        setCustomApis(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch custom APIs:', error);
    }
  }, []);

  const fetchService = useCallback(async () => {
    try {
      const response = await fetch(`/api/admin/services?offset=0&limit=1000`);
      const data = await response.json();
      if (data.success) {
        const found = data.data.find((s: any) => s.id === serviceId);
        if (found) {
          setService(found);
        }
      }
    } catch (error) {
      console.error('Failed to fetch service:', error);
    }
  }, [serviceId]);

  useEffect(() => {
    if (serviceId) {
      fetchServiceApis();
      fetchGateways();
      fetchCustomApis();
      fetchService();
    }
  }, [serviceId, fetchServiceApis, fetchGateways, fetchCustomApis, fetchService]);

  const columns: Column<ServiceApi>[] = [
    {
      key: 'api.code',
      label: 'Provider Code',
      render: (_, item) => item.customApi ? 'CUSTOM' : item.api?.code || 'N/A'
    },
    {
      key: 'api.name',
      label: 'Provider Name',
      render: (_, item) => item.customApi ? item.customApi.apiName : item.api?.name || 'Unknown'
    },
    {
      key: 'api.provider',
      label: 'Type',
      render: (_, item) => item.customApi ? 'Custom API' : item.api?.provider || 'Gateway'
    },
    { key: 'priority', label: 'Priority' },
    {
      key: 'isDefault',
      label: 'Default',
      render: (isDefault) => (
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${isDefault ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
          }`}>
          {isDefault ? 'Yes' : 'No'}
        </span>
      ),
    },
  ];

  const getAvailableOptions = () => {
    const linkedApiIds = new Set(serviceApis.map(sa => sa.apiId || sa.customApiId));

    const customApiOptions = customApis
      .filter(api => !linkedApiIds.has(api.id))
      .map(api => ({
        label: `[Custom] ${api.apiName}`,
        value: `custom:${api.id}`
      }));

    const gatewayOptions = gateways
      .filter(gw => !linkedApiIds.has(gw.id))
      .map(gw => ({
        label: `[Legacy] ${gw.name} (${gw.provider})`,
        value: `legacy:${gw.id}`
      }));

    return [...customApiOptions, ...gatewayOptions];
  };

  const formFields: FormField[] = [
    {
      name: 'apiSelection',
      label: 'Select Provider (Gateway / Custom API)',
      type: 'select',
      required: true,
      options: getAvailableOptions(),
    },
    {
      name: 'priority',
      label: 'Priority (Lower = Higher Priority)',
      type: 'number',
      required: false,
      placeholder: '1',
    },
    {
      name: 'isDefault',
      label: 'Set as Default',
      type: 'checkbox',
      required: false,
    },
  ];

  const handleAddApi = () => {
    setSelectedServiceApi(null);
    setIsModalOpen(true);
  };

  const handleEditApi = (serviceApi: ServiceApi) => {
    setSelectedServiceApi(serviceApi);
    setIsModalOpen(true);
  };

  const handleSubmit = async (data: Record<string, any>) => {
    setSubmitting(true);
    try {
      if (selectedServiceApi) {
        const response = await fetch('/api/admin/service-apis', {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            serviceApiId: selectedServiceApi.id,
            isDefault: data.isDefault === true || data.isDefault === 'true',
            priority: parseInt(data.priority) || 1,
          }),
        });

        const result = await response.json();
        if (result.success) {
          toast.showSuccess('Service API updated successfully');
          setIsModalOpen(false);
          fetchServiceApis(pagination.offset);
        } else {
          toast.showError(result.error || 'Failed to update service API');
        }
      } else {
        const selection = data.apiSelection as string;
        const [type, id] = selection.split(':');

        const payload: any = {
          serviceId,
          isDefault: data.isDefault === true || data.isDefault === 'true',
          priority: parseInt(data.priority) || 1,
        };

        if (type === 'custom') {
          payload.customApiId = id;
        } else {
          payload.apiId = id;
        }

        const response = await fetch('/api/admin/service-apis', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });

        const result = await response.json();
        if (result.success) {
          toast.showSuccess('Gateway linked to service successfully');
          setIsModalOpen(false);
          fetchServiceApis(0);
        } else {
          toast.showError(result.error || 'Failed to link gateway');
        }
      }
    } catch (error) {
      console.error('Failed to save service API:', error);
      toast.showError('Error saving service API');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteServiceApi = async (serviceApi: ServiceApi) => {
    const name = serviceApi.customApi ? serviceApi.customApi.apiName : serviceApi.api?.name;
    const confirmed = await confirm({
      title: 'Unlink Gateway',
      message: `Are you sure you want to unlink ${name} from this service?`,
      confirmText: 'Unlink',
      cancelText: 'Cancel',
      isDangerous: true,
    });

    if (!confirmed) return;

    try {
      const response = await fetch(`/api/admin/service-apis?serviceApiId=${serviceApi.id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        toast.showSuccess('Gateway unlinked successfully');
        fetchServiceApis(pagination.offset);
      } else {
        toast.showError('Failed to unlink gateway');
      }
    } catch (error) {
      console.error('Failed to delete service API:', error);
      toast.showError('Error unlinking gateway');
    }
  };

  const handleSetDefault = async (serviceApi: ServiceApi) => {
    try {
      const response = await fetch('/api/admin/service-apis', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          serviceApiId: serviceApi.id,
          isDefault: true,
        }),
      });

      const result = await response.json();
      if (result.success) {
        toast.showSuccess('Default gateway updated');
        fetchServiceApis(pagination.offset);
      }
    } catch (error) {
      toast.showError('Error setting default gateway');
    }
  };

  if (!service && !loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-lg text-gray-600">Service not found</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">

      <ConfirmProvider />

      <div className="flex items-center gap-4">
        <button
          onClick={() => router.push('/account/admin/services')}
          className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          ← Back
        </button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            {service ? `${service.name} - Payment Providers` : 'Payment Providers'}
          </h1>
          <p className="text-gray-600 mt-2">Link Payment Gateways or Custom APIs to this service</p>
        </div>
      </div>

      {(gateways.length === 0 && customApis.length === 0) && !gatewaysLoading && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <p className="text-amber-800">
            No payment providers available. Please create some providers first in{' '}
            <button
              onClick={() => router.push('/account/admin/custom-apis')}
              className="font-semibold underline hover:no-underline"
            >
              Provider Master
            </button>
          </p>
        </div>
      )}

      {(gateways.length > 0 || customApis.length > 0) && (
        <button
          onClick={handleAddApi}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          + Link Provider
        </button>
      )}

      <DataTable<ServiceApi>
        data={serviceApis}
        columns={columns}
        loading={loading}
        pagination={{
          ...pagination,
          onPageChange: (offset) => fetchServiceApis(offset),
        }}
        actions={[
          {
            label: 'Set Default',
            onClick: handleSetDefault,
            variant: 'secondary',
            visible: (api) => !api.isDefault,
          },
          {
            label: 'Edit',
            onClick: handleEditApi,
            variant: 'primary',
          },
          {
            label: 'Unlink',
            onClick: handleDeleteServiceApi,
            variant: 'danger',
          },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={selectedServiceApi ? 'Edit Service Provider' : 'Link Payment Provider'}
        size="md"
      >
        {selectedServiceApi ? (
          <FormBuilder
            fields={[
              {
                name: 'priority',
                label: 'Priority',
                type: 'number',
                required: false,
                placeholder: '1',
              },
              {
                name: 'isDefault',
                label: 'Set as Default',
                type: 'checkbox',
                required: false,
              },
            ]}
            onSubmit={handleSubmit}
            initialValues={{
              priority: selectedServiceApi.priority,
              isDefault: selectedServiceApi.isDefault,
            }}
            loading={submitting}
          />
        ) : (
          <FormBuilder
            fields={formFields}
            onSubmit={handleSubmit}
            initialValues={{
              priority: 1,
              isDefault: false,
            }}
            loading={submitting}
          />
        )}
      </Modal>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { formatINR } from '@/lib/money';


interface PayOut {
  id: string;
  userId: string;
  userName: string | null;
  userEmail: string | null;
  amount: number;
  beneficiaryName: string;
  beneficiaryAccount: string;
  transferMode: string;
  utrNumber: string | null;
  status: string;
  createdAt: string;
  responseData: any;
}

export default function AdminPayoutsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [payouts, setPayouts] = useState<PayOut[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ status: 'all', dateFrom: '', dateTo: '' });
  const [stats, setStats] = useState({ total: 0, success: 0, pending: 0, failed: 0, processing: 0, totalAmount: 0 });

  // Modal State
  const [selectedPayout, setSelectedPayout] = useState<PayOut | null>(null);

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/login');
    if ((session?.user as any)?.role !== 'ADMIN') router.push('/account/dashboard');
  }, [session, status, router]);

  useEffect(() => {
    if (session && status === 'authenticated') fetchPayouts();
  }, [session, status]);

  const fetchPayouts = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/admin/payouts');
      const data = await response.json();
      if (data.success) {
        setPayouts(data.data);
        // Calculate stats
        const calculatedStats = {
          total: data.data.length,
          success: data.data.filter((p: PayOut) => p.status === 'success').length,
          pending: data.data.filter((p: PayOut) => p.status === 'pending' || p.status === 'pending_approval').length,
          failed: data.data.filter((p: PayOut) => p.status === 'failed' || p.status === 'rejected').length,
          processing: data.data.filter((p: PayOut) => p.status === 'processing').length,
          totalAmount: data.data.reduce((sum: number, p: PayOut) => sum + p.amount, 0),
        };
        setStats(data.stats || calculatedStats);
      }
    } catch (error) {
      console.error('Failed to fetch payouts:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredPayouts = payouts.filter(p => {
    if (filter.status !== 'all' && p.status !== filter.status) return false;
    if (filter.dateFrom && new Date(p.createdAt) < new Date(filter.dateFrom)) return false;
    if (filter.dateTo && new Date(p.createdAt) > new Date(filter.dateTo + 'T23:59:59')) return false;
    return true;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'pending_approval': return 'bg-orange-100 text-orange-800';
      case 'processing': return 'bg-blue-100 text-blue-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  

  if (status === 'loading' || loading) {
    return <div className="flex items-center justify-center p-12"><div className="text-gray-600">Loading...</div></div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">All Payouts</h1>
        <p className="text-gray-600 mt-2">View all payout transactions (read-only - payouts are processed automatically)</p>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center gap-3">
        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
          <span className="text-xl">ℹ️</span>
        </div>
        <div>
          <h3 className="font-semibold text-blue-900">Automatic Payout Processing</h3>
          <p className="text-sm text-blue-700">Payouts are now processed automatically. This page shows transaction status and API responses for monitoring purposes.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
          <div className="text-sm text-gray-600">Total Payouts</div>
        </div>
        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <div className="text-2xl font-bold text-green-600">{stats.success}</div>
          <div className="text-sm text-gray-600">Successful</div>
        </div>
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-2xl font-bold text-blue-600">{stats.processing}</div>
          <div className="text-sm text-gray-600">Processing</div>
        </div>
        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
          <div className="text-2xl font-bold text-red-600">{stats.failed}</div>
          <div className="text-sm text-gray-600">Failed</div>
        </div>
        <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
          <div className="text-2xl font-bold text-purple-600">{formatINR(stats.totalAmount)}</div>
          <div className="text-sm text-gray-600">Total Volume</div>
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg border flex flex-wrap gap-4 items-end">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
          <select value={filter.status} onChange={(e) => setFilter({ ...filter, status: e.target.value })} className="px-3 py-2 border rounded-lg">
            <option value="all">All Status</option>
            <option value="success">✓ Success</option>
            <option value="processing">⏳ Processing</option>
            <option value="pending">◐ Pending</option>
            <option value="failed">✗ Failed</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">From</label>
          <input type="date" value={filter.dateFrom} onChange={(e) => setFilter({ ...filter, dateFrom: e.target.value })} className="px-3 py-2 border rounded-lg" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">To</label>
          <input type="date" value={filter.dateTo} onChange={(e) => setFilter({ ...filter, dateTo: e.target.value })} className="px-3 py-2 border rounded-lg" />
        </div>
        <button
          onClick={fetchPayouts}
          className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"
        >
          Refresh
        </button>
      </div>

      <div className="bg-white rounded-lg border overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Date</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">User</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Beneficiary</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Amount</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Charges</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Mode</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">API Status</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">UTR</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {filteredPayouts.length === 0 ? (
              <tr><td colSpan={10} className="px-4 py-12 text-center text-gray-500">No payouts found</td></tr>
            ) : (
              filteredPayouts.map((p) => {
                const chargeInfo = p.responseData?.chargeInfo;
                const totalCharge = chargeInfo?.totalCharge || 0;
                const gatewayStatus = p.responseData?.raw?.statusCode || p.responseData?.raw?.status || p.responseData?.message || '-';

                return (
                  <tr key={p.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm">
                      <div>{new Date(p.createdAt).toLocaleDateString()}</div>
                      <div className="text-xs text-gray-500">{new Date(p.createdAt).toLocaleTimeString()}</div>
                    </td>
                    <td className="px-4 py-3 text-sm">
                      <div className="font-medium">{p.userName || 'N/A'}</div>
                      <div className="text-xs text-gray-500">{p.userEmail}</div>
                    </td>
                    <td className="px-4 py-3 text-sm">
                      <div>{p.beneficiaryName}</div>
                      <div className="text-xs text-gray-500">{p.beneficiaryAccount}</div>
                    </td>
                    <td className="px-4 py-3 font-semibold">{formatINR(p.amount)}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      {totalCharge > 0 ? formatINR(totalCharge) : '-'}
                    </td>
                    <td className="px-4 py-3"><span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded uppercase">{p.transferMode}</span></td>
                    <td className="px-4 py-3"><span className={`px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(p.status)}`}>{p.status}</span></td>
                    <td className="px-4 py-3 text-sm">
                      <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded font-mono">
                        {typeof gatewayStatus === 'string' ? gatewayStatus.substring(0, 30) : String(gatewayStatus)}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm font-mono">{p.utrNumber || '-'}</td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => setSelectedPayout(p)}
                        className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded text-xs hover:bg-indigo-100 font-medium"
                      >
                        View Details
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Transaction Details Modal */}
      {selectedPayout && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b flex justify-between items-center bg-gray-50 rounded-t-xl">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Transaction Details</h2>
                <p className="text-sm text-gray-500 font-mono mt-1">{selectedPayout.id}</p>
              </div>
              <button
                onClick={() => setSelectedPayout(null)}
                className="text-gray-400 hover:text-gray-600 text-2xl font-bold w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-200"
              >
                ×
              </button>
            </div>

            <div className="p-6 space-y-6">

              {/* Summary Card */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-xs text-gray-500 uppercase font-semibold">Amount</div>
                  <div className="text-lg font-bold text-gray-900">{formatINR(selectedPayout.amount)}</div>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-xs text-gray-500 uppercase font-semibold">Status</div>
                  <div className={`text-lg font-bold ${selectedPayout.status === 'success' ? 'text-green-600' : selectedPayout.status === 'failed' ? 'text-red-600' : 'text-blue-600'}`}>
                    {selectedPayout.status.toUpperCase()}
                  </div>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-xs text-gray-500 uppercase font-semibold">Mode</div>
                  <div className="text-lg font-bold text-gray-900 uppercase">{selectedPayout.transferMode}</div>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-xs text-gray-500 uppercase font-semibold">UTR</div>
                  <div className="text-sm font-bold text-gray-900 font-mono truncate">{selectedPayout.utrNumber || '-'}</div>
                </div>
              </div>

              {/* Charge Info */}
              {selectedPayout.responseData?.chargeInfo && (
                <div className="space-y-3">
                  <h3 className="font-semibold text-gray-900 border-b pb-2">Charge Details</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-gray-500 block">User Charge</span>
                      <span className="font-medium">{formatINR(selectedPayout.responseData.chargeInfo.userCharge || 0)}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">Scheme Charge</span>
                      <span className="font-medium">{formatINR(selectedPayout.responseData.chargeInfo.schemeCharge || 0)}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">Total Charge</span>
                      <span className="font-medium">{formatINR(Number(selectedPayout.responseData.chargeInfo.totalCharge) || 0)}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">Total Debit</span>
                      <span className="font-medium">{formatINR(Number(selectedPayout.responseData.chargeInfo.totalDebit || 0))}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Beneficiary Details */}
              <div className="space-y-3">
                <h3 className="font-semibold text-gray-900 border-b pb-2">Beneficiary Details</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500 block">Name</span>
                    <span className="font-medium">{selectedPayout.beneficiaryName}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 block">Account</span>
                    <span className="font-medium font-mono">{selectedPayout.beneficiaryAccount || '-'}</span>
                  </div>
                </div>
              </div>

              {/* API Response Data */}
              <div className="space-y-3">
                <h3 className="font-semibold text-gray-900 border-b pb-2 flex justify-between items-center">
                  <span>API Response Data</span>
                  <span className="text-xs text-gray-500 font-normal bg-gray-100 px-2 py-1 rounded">Raw JSON</span>
                </h3>
                <div className="bg-slate-900 rounded-lg p-4 overflow-x-auto shadow-inner">
                  {selectedPayout.responseData ? (
                    <pre className="text-xs text-green-400 font-mono whitespace-pre-wrap break-words">
                      {JSON.stringify(selectedPayout.responseData, null, 2)}
                    </pre>
                  ) : (
                    <div className="text-gray-400 text-sm italic py-4 text-center">
                      No API response data available for this transaction.
                    </div>
                  )}
                </div>
              </div>

            </div>

            <div className="p-6 bg-yellow-50 border-t border-yellow-200">
              <h3 className="font-semibold text-yellow-900 mb-3 flex items-center gap-2">
                <span>⚠️ Force Update Status</span>
              </h3>
              <p className="text-xs text-yellow-700 mb-4">
                Manually updating the status does not trigger refunds or wallet adjustments. Use with caution.
              </p>
              <div className="flex gap-3">
                <select
                  className="flex-1 rounded-lg border-yellow-300 bg-white text-sm"
                  defaultValue={selectedPayout.status}
                  id="newStatusSelect"
                >
                  <option value="pending">Pending</option>
                  <option value="processing">Processing</option>
                  <option value="success">Success</option>
                  <option value="failed">Failed</option>
                </select>
                <button
                  onClick={async () => {
                    const select = document.getElementById('newStatusSelect') as HTMLSelectElement;
                    const newStatus = select.value;
                    if (!confirm(`Are you sure you want to change status from ${selectedPayout.status} to ${newStatus}?`)) return;

                    try {
                      const res = await fetch('/api/admin/payouts', {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id: selectedPayout.id, status: newStatus }),
                      });
                      const data = await res.json();
                      if (data.success) {
                        alert('Status updated successfully');
                        setSelectedPayout(null);
                        fetchPayouts();
                      } else {
                        alert('Failed: ' + data.error);
                      }
                    } catch (err) {
                      alert('Error updating status');
                    }
                  }}
                  className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 text-sm font-medium"
                >
                  Update Status
                </button>
              </div>
            </div>

            <div className="p-6 border-t bg-gray-50 rounded-b-xl flex justify-end">
              <button
                onClick={() => setSelectedPayout(null)}
                className="px-6 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium shadow-sm"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

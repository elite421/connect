'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { FormBuilder, type FormField } from '@/components/form-builder';
import { useGlobalToast } from '@/context/ToastContext';

interface PaymentScheme {
  id: string;
  name: string;
  code: string;
  description?: string;
  payoutCharge: number;
  payinCharge: number;
  settlementCharge: number;
  chargeType: string;
  minCharge: number;
  maxCharge: number;
  gstPercentage: number;
  applyGst: boolean;
  minTransactionAmount: number;
  maxTransactionAmount: number;
  apiId?: string;
  serviceId?: string;
  isActive: boolean;
  schemeType: string;
  createdAt: string;
}

interface ServiceOption {
  id: string;
  code: string;
  name: string;
}

interface ApiOption {
  id: string;
  apiName: string;
  adminProvided: boolean;
}

export default function AdminSchemesPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const toast = useGlobalToast();
  const [schemes, setSchemes] = useState<PaymentScheme[]>([]);
  const [services, setServices] = useState<ServiceOption[]>([]);
  const [apis, setApis] = useState<ApiOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedScheme, setSelectedScheme] = useState<PaymentScheme | null>(null);
  const [activeTab, setActiveTab] = useState<'PAYIN' | 'PAYOUT' | 'BOTH'>('PAYOUT');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  useEffect(() => {
    if (session) {
      fetchSchemes();
    }
  }, [session, activeTab]);

  const fetchSchemes = async (offset: number = 0) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/admin/schemes?offset=${offset}&limit=${pagination.limit}&type=${activeTab}`);

      if (!response.ok) {
        throw new Error(`Server returned ${response.status} ${response.statusText}`);
      }

      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        // Log the text for debugging (optional)
        const text = await response.text();
        console.error('Expected JSON, got:', text.substring(0, 100)); // Log first 100 chars
        throw new Error("Received non-JSON response from server");
      }

      const data = await response.json();
      if (data.success) {
        setSchemes(data.data);
        setServices(data.services || []);
        setApis(data.apis || []);
        setPagination({ ...pagination, offset, total: data.pagination.total });
      } else {
        toast.showError(data.error || 'Failed to fetch schemes');
      }
    } catch (error: any) {
      console.error('Failed to fetch schemes:', error);
      toast.showError(error.message || 'Failed to fetch schemes');
    } finally {
      setLoading(false);
    }
  };

  const formatINR = (amount: string | number) => {
    return `₹${Number(amount).toLocaleString('en-IN', { minimumFractionDigits: 5, maximumFractionDigits: 5 })}`;
  };

  const getServiceName = (serviceId?: string) => {
    if (!serviceId) return '-';
    const service = services.find(s => s.id === serviceId);
    return service ? service.name : '-';
  };

  const getApiName = (apiId?: string) => {
    if (!apiId) return '-';
    const api = apis.find(a => a.id === apiId);
    return api ? api.apiName : '-';
  };

  const columns: Column<PaymentScheme>[] = [
    { key: 'name', label: 'Name' },
    { key: 'code', label: 'Code' },
    {
      key: 'schemeType',
      label: 'Type',
      render: (value, scheme) => (
        <span className={`px-2 py-1 rounded text-xs font-semibold ${scheme.schemeType === 'PAYOUT' ? 'bg-orange-100 text-orange-800' :
          scheme.schemeType === 'PAYIN' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
          }`}>
          {scheme.schemeType}
        </span>
      ),
    },
    {
      key: 'payoutCharge',
      label: 'Payout Charge',
      render: (value, scheme) => {
        if (!scheme) return '-';
        const base = scheme.payoutCharge;
        const gst = scheme.applyGst ? base * (scheme.gstPercentage / 100) : 0;
        return (
          <div>
            <div>{scheme.chargeType === 'percentage' ? `${base}%` : formatINR(base)}</div>
            {scheme.applyGst && <div className="text-xs text-gray-500">+GST: {formatINR(gst)}</div>}
          </div>
        );
      },
    },
    {
      key: 'gstPercentage',
      label: 'GST',
      render: (value, scheme) => {
        if (!scheme) return '-';
        return (
          <span className={`px-2 py-1 rounded text-xs ${scheme.applyGst ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
            {scheme.applyGst ? `${scheme.gstPercentage}%` : 'No GST'}
          </span>
        );
      },
    },
    {
      key: 'minTransactionAmount',
      label: 'Amount Limits',
      render: (value, scheme) => {
        if (!scheme) return '-';
        return (
          <div className="text-sm">
            <div>Min: {formatINR(scheme.minTransactionAmount)}</div>
            <div>Max: {formatINR(scheme.maxTransactionAmount)}</div>
          </div>
        );
      },
    },
    {
      key: 'serviceId',
      label: 'Service',
      render: (value, scheme) => scheme ? getServiceName(scheme.serviceId) : '-',
    },
    {
      key: 'apiId',
      label: 'API Provider',
      render: (value, scheme) => scheme ? getApiName(scheme.apiId) : '-',
    },
    {
      key: 'isActive',
      label: 'Status',
      render: (value, scheme) => {
        if (!scheme) return '-';
        return (
          <span className={`px-2 py-1 rounded-full text-xs font-semibold ${scheme.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
            {scheme.isActive ? 'Active' : 'Inactive'}
          </span>
        );
      },
    },
  ];

  const getFormFields = (isEdit: boolean): FormField[] => [
    {
      name: 'name',
      label: 'Scheme Name',
      type: 'text',
      required: true,
      placeholder: 'e.g., Standard Plan',
    },
    {
      name: 'code',
      label: 'Code',
      type: 'text',
      required: true,
      placeholder: 'e.g., STANDARD',
    },
    {
      name: 'schemeType',
      label: 'Scheme Type',
      type: 'select',
      required: true,
      options: [
        { value: 'PAYOUT', label: 'Payout' },
        { value: 'PAYIN', label: 'PayIn' },
        { value: 'BOTH', label: 'Both' },
      ],
    },
    {
      name: 'description',
      label: 'Description',
      type: 'textarea',
      required: false,
      placeholder: 'Optional scheme description',
    },
    {
      name: 'serviceId',
      label: 'Linked Service',
      type: 'select',
      required: false,
      options: (values) => {
        const type = values.schemeType;
        let filteredServices = services;
        if (type === 'PAYOUT') {
          filteredServices = services.filter(s => s.code.toLowerCase().includes('payout'));
        } else if (type === 'PAYIN') {
          filteredServices = services.filter(s => !s.code.toLowerCase().includes('payout')); // Assuming non-payout are payin/others
        }
        return [
          { value: '', label: '-- Select Service --' },
          ...filteredServices.map(s => ({ value: s.id, label: `${s.name} (${s.code})` })),
        ];
      },
      hidden: (values) => false, // Always show but options change
    },
    {
      name: 'apiId',
      label: 'API Provider',
      type: 'select',
      required: false,
      options: [
        { value: '', label: '-- Select API Provider --' },
        ...apis.map(a => ({ value: a.id, label: `${a.apiName}${a.adminProvided ? ' (Admin)' : ''}` })),
      ],
    },
    {
      name: 'chargeType',
      label: 'Charge Type',
      type: 'select',
      required: false,
      options: [
        { value: 'fixed', label: 'Fixed Amount' },
        { value: 'percentage', label: 'Percentage' },
        { value: 'both', label: 'Fixed + Percentage' },
      ],
    },
    {
      name: 'payoutCharge',
      label: 'Payout Charge',
      type: 'number',
      required: false,
      placeholder: '0.00',
      hidden: (values) => values.schemeType === 'PAYIN',
    },
    {
      name: 'payinCharge',
      label: 'PayIn Charge',
      type: 'number',
      required: false,
      placeholder: '0.00',
      hidden: (values) => values.schemeType === 'PAYOUT',
    },
    {
      name: 'settlementCharge',
      label: 'Settlement Charge',
      type: 'number',
      required: false,
      placeholder: '0.00',
    },
    {
      name: 'applyGst',
      label: 'Apply 18% GST on Charges',
      type: 'checkbox',
      required: false,
    },
    {
      name: 'gstPercentage',
      label: 'GST Percentage',
      type: 'number',
      required: false,
      placeholder: '18',
      disabled: (values) => !values.applyGst,
    },
    {
      name: 'minTransactionAmount',
      label: 'Min Transaction Amount',
      type: 'number',
      required: false,
      placeholder: '100',
    },
    {
      name: 'maxTransactionAmount',
      label: 'Max Transaction Amount',
      type: 'number',
      required: false,
      placeholder: '100000',
    },
    ...(isEdit ? [{
      name: 'isActive',
      label: 'Active',
      type: 'checkbox' as const,
      required: false,
    }] : []),
  ];

  const handleEditScheme = (scheme: PaymentScheme) => {
    setSelectedScheme(scheme);
    setIsModalOpen(true);
  };

  const handleCreateScheme = () => {
    setIsCreateModalOpen(true);
  };

  const handleSubmit = async (data: Record<string, any>) => {
    if (!selectedScheme) return;
    try {
      const response = await fetch('/api/admin/schemes', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ schemeId: selectedScheme.id, ...data }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status} ${response.statusText}`);
      }

      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        const text = await response.text();
        console.error('Expected JSON, got:', text.substring(0, 100));
        throw new Error("Received non-JSON response from server");
      }

      const result = await response.json();
      if (result.success) {
        setIsModalOpen(false);
        // await fetchSchemes(pagination.offset); // Refresh list
        // Update local state to avoid full refetch if possible, or just refetch
        fetchSchemes(pagination.offset); // fetchSchemes already has error handling now
        toast.showSuccess('Scheme updated successfully');
      } else {
        toast.showError(result.error || 'Failed to update scheme');
      }
    } catch (error: any) {
      console.error('Failed to update scheme:', error);
      toast.showError(error.message || 'Failed to update scheme');
    }
  };

  const handleCreate = async (data: Record<string, any>) => {
    try {
      const response = await fetch('/api/admin/schemes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status} ${response.statusText}`);
      }

      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        const text = await response.text();
        console.error('Expected JSON, got:', text.substring(0, 100));
        throw new Error("Received non-JSON response from server");
      }

      const result = await response.json();
      if (result.success) {
        setIsCreateModalOpen(false);
        fetchSchemes(pagination.offset);
        toast.showSuccess('Scheme created successfully');
      } else {
        toast.showError(result.error || 'Failed to create scheme');
      }
    } catch (error: any) {
      console.error('Failed to create scheme:', error);
      toast.showError(error.message || 'Failed to create scheme');
    }
  };

  const handleDeleteScheme = async (scheme: PaymentScheme) => {
    if (!confirm(`Delete scheme "${scheme.name}"?`)) return;
    try {
      const response = await fetch(`/api/admin/schemes?schemeId=${scheme.id}`, {
        method: 'DELETE',
      });
      const result = await response.json();
      if (result.success) {
        fetchSchemes(pagination.offset);
        toast.showSuccess('Scheme deleted successfully');
      } else {
        toast.showError(result.error || 'Failed to delete scheme');
      }
    } catch (error) {
      console.error('Failed to delete scheme:', error);
      toast.showError('Failed to delete scheme');
    }
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-gray-600">Loading schemes...</div>
      </div>
    );
  }

  if (status === 'unauthenticated') {
    return null;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Scheme Master</h1>
          <p className="text-gray-600 mt-2">Create and manage payment schemes with GST and transaction limits</p>
        </div>
        <button
          onClick={handleCreateScheme}
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          + Create Scheme
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 border-b border-gray-200">
        {(['PAYOUT', 'PAYIN', 'BOTH'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${activeTab === tab
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
          >
            {tab === 'BOTH' ? 'All / Both' : tab} Schemes
          </button>
        ))}
      </div>

      {/* Info Banner */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <span className="text-xl">ℹ️</span>
          <div>
            <h3 className="font-semibold text-blue-900">GST Auto-Calculation</h3>
            <p className="text-sm text-blue-700">When "Apply GST" is enabled, 18% GST is automatically added to all transaction charges. Final Charge = Base Charge + (Base Charge × 18%)</p>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="text-3xl font-bold text-blue-600">{pagination.total}</div>
            <div className="text-sm text-gray-600 mt-1">Total Schemes</div>
          </div>
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="text-3xl font-bold text-green-600">
              {schemes.filter(s => s.isActive).length}
            </div>
            <div className="text-sm text-gray-600 mt-1">Active Schemes</div>
          </div>
          <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
            <div className="text-3xl font-bold text-purple-600">
              {schemes.filter(s => s.applyGst).length}
            </div>
            <div className="text-sm text-gray-600 mt-1">With GST</div>
          </div>
          <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
            <div className="text-3xl font-bold text-orange-600">
              {schemes.filter(s => s.apiId).length}
            </div>
            <div className="text-sm text-gray-600 mt-1">API Linked</div>
          </div>
        </div>
      </div>

      <DataTable<PaymentScheme>
        data={schemes}
        columns={columns}
        loading={loading}
        pagination={{
          ...pagination,
          onPageChange: (offset) => fetchSchemes(offset),
        }}
        actions={[
          {
            label: 'Edit',
            onClick: handleEditScheme,
            variant: 'primary',
          },
          {
            label: 'Delete',
            onClick: handleDeleteScheme,
            variant: 'danger',
          },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`Edit Scheme: ${selectedScheme?.name}`}
        size="full"
      >
        {selectedScheme && (
          <FormBuilder
            fields={getFormFields(true)}
            onSubmit={handleSubmit}
            initialValues={{
              name: selectedScheme.name,
              code: selectedScheme.code,
              description: selectedScheme.description,
              schemeType: selectedScheme.schemeType,
              serviceId: selectedScheme.serviceId || '',
              apiId: selectedScheme.apiId || '',
              chargeType: selectedScheme.chargeType,
              payoutCharge: selectedScheme.payoutCharge,
              payinCharge: selectedScheme.payinCharge,
              settlementCharge: selectedScheme.settlementCharge,
              minCharge: selectedScheme.minCharge,
              maxCharge: selectedScheme.maxCharge,
              applyGst: selectedScheme.applyGst,
              gstPercentage: selectedScheme.gstPercentage,
              minTransactionAmount: selectedScheme.minTransactionAmount,
              maxTransactionAmount: selectedScheme.maxTransactionAmount,
              isActive: selectedScheme.isActive,
            }}
            submitLabel="Update Scheme"
          />
        )}
      </Modal>

      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Create New Scheme"
        size="full"
      >
        <FormBuilder
          fields={getFormFields(false)}
          onSubmit={handleCreate}
          initialValues={{
            schemeType: 'PAYOUT',
            chargeType: 'fixed',
            applyGst: true,
            gstPercentage: 18,
            minTransactionAmount: 100,
            maxTransactionAmount: 100000,
          }}
          submitLabel="Create Scheme"
        />
      </Modal>
    </div>
  );
}

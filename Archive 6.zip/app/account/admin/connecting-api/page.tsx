'use client';
import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useGlobalToast } from '@/context/ToastContext';
import { Loader2, Plus, RefreshCw, Save, Trash2, Edit, Search, User, Eye, EyeOff, Copy } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Types
interface CustomApi {
    id: string;
    apiName: string;
    apiBaseUrl: string;
    apiEndpoint: string;
    apiMethod: string;
    authType: string;
    apiKey?: string;
    apiSecret?: string;
    authHeader?: string;
    transactionCharge: number;
    transactionChargeType: 'fixed' | 'percentage';
    isActive: boolean;
    createdAt: string;
    apiNumber?: string;
}

interface UserWithApis {
    id: string;
    name: string;
    email: string;
    username: string;
    _count: {
        apis: number;
    };
}

export default function ConnectingApiPage() {
    const { data: session } = useSession();
    const { showToast } = useGlobalToast();

    const [users, setUsers] = useState<UserWithApis[]>([]);
    const [apis, setApis] = useState<CustomApi[]>([]);
    const [availableTemplates, setAvailableTemplates] = useState<CustomApi[]>([]); // System APIs for templates

    const [selectedUser, setSelectedUser] = useState<UserWithApis | null>(null);
    const [editingApi, setEditingApi] = useState<CustomApi | null>(null);
    const [iscreating, setIsCreating] = useState(false);

    const [loadingUsers, setLoadingUsers] = useState(false);
    const [loadingApis, setLoadingApis] = useState(false);
    const [saving, setSaving] = useState(false);
    const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});

    const [searchTerm, setSearchTerm] = useState('');

    // Fetch Users
    const fetchUsers = async () => {
        setLoadingUsers(true);
        try {
            const res = await fetch('/api/admin/connecting-api');
            const json = await res.json();
            if (json.success) {
                setUsers(json.data);
            } else {
                showToast(json.error || 'Failed to fetch users', 'error');
            }
        } catch (error) {
            showToast('Error fetching users', 'error');
        } finally {
            setLoadingUsers(false);
        }
    };

    // Fetch APIs for a User
    const fetchApis = async (userId: string) => {
        setLoadingApis(true);
        try {
            const res = await fetch(`/api/admin/connecting-api?userId=${userId}`);
            const json = await res.json();
            if (json.success) {
                setApis(json.data);
            } else {
                showToast(json.error || 'Failed to fetch APIs', 'error');
            }
        } catch (error) {
            showToast('Error fetching APIs', 'error');
        } finally {
            setLoadingApis(false);
        }
    };

    useEffect(() => {
        fetchUsers();
        fetchTemplates();
    }, []);

    const fetchTemplates = async () => {
        try {
            const res = await fetch('/api/admin/custom-apis');
            const json = await res.json();
            if (json.success) {
                setAvailableTemplates(json.data);
            }
        } catch (error) {
            console.error('Failed to fetch templates:', error);
        }
    };

    useEffect(() => {
        if (selectedUser) {
            fetchApis(selectedUser.id);
            setEditingApi(null); // Reset selection
            setIsCreating(false);
        } else {
            setApis([]);
        }
    }, [selectedUser]);

    const handleSave = async () => {
        if (!editingApi && !iscreating) return;

        setSaving(true);
        try {
            const method = iscreating ? 'POST' : 'PATCH';
            const body: any = { ...editingApi };

            if (iscreating && selectedUser) {
                body.userId = selectedUser.id;
            } else {
                body.id = editingApi?.id;
            }
            // Ensure numbers
            body.transactionCharge = Number(body.transactionCharge);

            const res = await fetch('/api/admin/connecting-api', {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });

            const json = await res.json();
            if (json.success) {
                showToast(`API ${iscreating ? 'Created' : 'Updated'} successfully`, 'success');
                if (selectedUser) fetchApis(selectedUser.id);
                setEditingApi(null);
                setIsCreating(false);
            } else {
                showToast(json.error || 'Failed to save API', 'error');
            }
        } catch (error) {
            console.error(error);
            showToast('Error saving API', 'error');
        } finally {
            setSaving(false);
        }
    };

    const handleCreateNew = () => {
        setEditingApi({
            id: '',
            apiName: 'New API',
            apiBaseUrl: 'https://api.example.com',
            apiEndpoint: '/v1/payout',
            apiMethod: 'POST',
            authType: 'bearer',
            apiKey: '',
            apiSecret: '',
            authHeader: '',
            transactionCharge: 0,
            transactionChargeType: 'fixed',
            isActive: true,
            createdAt: new Date().toISOString()
        });
        setIsCreating(true);
    };

    const toggleSecret = (id: string) => {
        setShowSecrets(prev => ({ ...prev, [id]: !prev[id] }));
    };

    const filteredUsers = users.filter(u =>
        u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.username.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">User API Configuration</h1>
                    <p className="text-gray-600 mt-2">Manage custom APIs, credentials, and charges for users</p>
                </div>
                <button
                    onClick={fetchUsers}
                    className="p-2 bg-white border border-gray-300 rounded-lg text-gray-600 hover:text-blue-600 hover:border-blue-300 transition-colors shadow-sm"
                    title="Refresh Data"
                >
                    <RefreshCw className={`w-5 h-5 ${loadingUsers ? 'animate-spin' : ''}`} />
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start h-[calc(100vh-200px)]">

                {/* User List Column */}
                <div className="lg:col-span-4 bg-white border border-gray-200 rounded-xl shadow-sm flex flex-col h-full overflow-hidden">
                    <div className="p-4 border-b border-gray-100 bg-gray-50/50">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <input
                                type="text"
                                placeholder="Search users..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="w-full bg-white border border-gray-300 rounded-lg pl-9 pr-3 py-2 text-sm text-gray-900 placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-colors"
                            />
                        </div>
                    </div>

                    <div className="flex-1 overflow-y-auto p-2 space-y-1">
                        {loadingUsers ? (
                            <div className="flex justify-center p-8"><Loader2 className="w-6 h-6 animate-spin text-blue-600" /></div>
                        ) : filteredUsers.length === 0 ? (
                            <div className="text-center text-gray-500 p-8 text-sm">No users found</div>
                        ) : (
                            filteredUsers.map(user => (
                                <div
                                    key={user.id}
                                    onClick={() => setSelectedUser(user)}
                                    className={`p-3 rounded-lg cursor-pointer transition-all border ${selectedUser?.id === user.id
                                        ? 'bg-blue-50 border-blue-200 shadow-sm'
                                        : 'bg-white border-transparent hover:bg-gray-50 hover:border-gray-200'
                                        }`}
                                >
                                    <div className="flex items-center gap-3">
                                        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold shadow-sm ${selectedUser?.id === user.id ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-500'
                                            }`}>
                                            {user.name.charAt(0).toUpperCase()}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <h3 className={`text-sm font-semibold truncate ${selectedUser?.id === user.id ? 'text-blue-900' : 'text-gray-900'}`}>
                                                {user.name}
                                            </h3>
                                            <p className="text-xs text-gray-500 truncate">{user.email}</p>
                                        </div>
                                        <div className={`text-xs font-mono font-medium px-2 py-0.5 rounded-full ${selectedUser?.id === user.id ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600'
                                            }`}>
                                            {user._count.apis}
                                        </div>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>

                {/* API Details Column */}
                <div className="lg:col-span-8 bg-white border border-gray-200 rounded-xl shadow-sm flex flex-col h-full overflow-hidden">
                    {!selectedUser ? (
                        <div className="flex flex-col items-center justify-center h-full text-gray-400 p-12 text-center">
                            <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4">
                                <User className="w-8 h-8 text-gray-300" />
                            </div>
                            <h3 className="text-lg font-medium text-gray-900">No User Selected</h3>
                            <p className="text-sm">Select a user from the list to view and manage their API configurations.</p>
                        </div>
                    ) : (
                        <>
                            <div className="p-6 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
                                <div>
                                    <h2 className="text-lg font-bold text-gray-900">
                                        {selectedUser.name}'s APIs
                                    </h2>
                                    <p className="text-sm text-gray-500">Manage transaction charges and status</p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <button
                                        onClick={handleCreateNew}
                                        className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-sm font-medium flex items-center gap-2 transition-all shadow-sm"
                                    >
                                        <Plus className="w-4 h-4" /> New API
                                    </button>
                                </div>
                            </div>

                            <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50/30">
                                {/* Create/Edit Form */}
                                <AnimatePresence>
                                    {(iscreating || (editingApi && editingApi.id)) && (
                                        <motion.div
                                            initial={{ opacity: 0, y: -20 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            exit={{ opacity: 0, y: -20 }}
                                            className="bg-white border-2 border-blue-500 rounded-xl overflow-hidden shadow-lg mb-6"
                                        >
                                            <div className="px-5 py-3 bg-blue-50 border-b border-blue-100 flex justify-between items-center">
                                                <h3 className="font-bold text-blue-900">
                                                    {iscreating ? 'Create New API' : `Editing: ${editingApi?.apiName}`}
                                                </h3>
                                                {iscreating && (
                                                    <div className="flex items-center gap-2">
                                                        <span className="text-xs text-blue-700 font-medium">Copy from:</span>
                                                        <select
                                                            className="text-xs border-blue-200 rounded px-2 py-1 bg-white text-blue-800 focus:ring-2 focus:ring-blue-500"
                                                            onChange={(e) => {
                                                                const template = availableTemplates.find(t => t.id === e.target.value);
                                                                if (template) {
                                                                    setEditingApi({
                                                                        ...editingApi!,
                                                                        apiName: template.apiName,
                                                                        apiBaseUrl: template.apiBaseUrl,
                                                                        apiEndpoint: template.apiEndpoint,
                                                                        apiMethod: template.apiMethod,
                                                                        authType: template.authType,
                                                                        apiKey: template.apiKey || '',
                                                                        apiSecret: template.apiSecret || '',
                                                                        authHeader: template.authHeader || '',
                                                                        transactionCharge: 0, // Reset charge for new user assignment
                                                                        transactionChargeType: 'fixed'
                                                                    });
                                                                }
                                                            }}
                                                            defaultValue=""
                                                        >
                                                            <option value="" disabled>Select API Template...</option>
                                                            {availableTemplates.map(t => (
                                                                <option key={t.id} value={t.id}>{t.apiName}</option>
                                                            ))}
                                                        </select>
                                                    </div>
                                                )}
                                            </div>
                                            <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-5">
                                                <div className="md:col-span-2">
                                                    <label className="text-xs font-semibold text-gray-700 uppercase tracking-wide">API Name</label>
                                                    <input
                                                        type="text"
                                                        value={editingApi?.apiName}
                                                        onChange={(e) => setEditingApi({ ...editingApi!, apiName: e.target.value })}
                                                        className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm"
                                                        placeholder="e.g. User Specific Gateway"
                                                    />
                                                </div>

                                                <div>
                                                    <label className="text-xs font-semibold text-gray-700 uppercase tracking-wide">Base URL</label>
                                                    <input
                                                        type="text"
                                                        value={editingApi?.apiBaseUrl}
                                                        onChange={(e) => setEditingApi({ ...editingApi!, apiBaseUrl: e.target.value })}
                                                        className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm"
                                                        placeholder="https://api.example.com"
                                                    />
                                                </div>
                                                <div>
                                                    <label className="text-xs font-semibold text-gray-700 uppercase tracking-wide">Endpoint</label>
                                                    <input
                                                        type="text"
                                                        value={editingApi?.apiEndpoint}
                                                        onChange={(e) => setEditingApi({ ...editingApi!, apiEndpoint: e.target.value })}
                                                        className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm"
                                                        placeholder="/v1/payment"
                                                    />
                                                </div>

                                                <div>
                                                    <label className="text-xs font-semibold text-gray-700 uppercase tracking-wide">Method</label>
                                                    <select
                                                        value={editingApi?.apiMethod}
                                                        onChange={(e) => setEditingApi({ ...editingApi!, apiMethod: e.target.value })}
                                                        className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm"
                                                    >
                                                        <option value="POST">POST</option>
                                                        <option value="GET">GET</option>
                                                        <option value="PUT">PUT</option>
                                                    </select>
                                                </div>

                                                <div>
                                                    <label className="text-xs font-semibold text-gray-700 uppercase tracking-wide">Auth Type</label>
                                                    <select
                                                        value={editingApi?.authType}
                                                        onChange={(e) => setEditingApi({ ...editingApi!, authType: e.target.value })}
                                                        className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm"
                                                    >
                                                        <option value="bearer">Bearer Token</option>
                                                        <option value="basic">Basic Auth</option>
                                                        <option value="apikey">API Key</option>
                                                        <option value="none">None</option>
                                                    </select>
                                                </div>

                                                <div className="md:col-span-2 space-y-2 border-t border-dashed pt-2">
                                                    <p className="text-xs font-bold text-gray-500">Credentials</p>
                                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                        <div>
                                                            <label className="text-xs text-gray-600">API Key / Client ID</label>
                                                            <input
                                                                type="text"
                                                                value={editingApi?.apiKey || ''}
                                                                onChange={(e) => setEditingApi({ ...editingApi!, apiKey: e.target.value })}
                                                                className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm font-mono"
                                                            />
                                                        </div>
                                                        <div>
                                                            <label className="text-xs text-gray-600">API Secret / Token</label>
                                                            <div className="relative">
                                                                <input
                                                                    type={showSecrets['new'] ? "text" : "password"}
                                                                    value={editingApi?.apiSecret || ''}
                                                                    onChange={(e) => setEditingApi({ ...editingApi!, apiSecret: e.target.value })}
                                                                    className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm font-mono pr-10"
                                                                />
                                                                <button
                                                                    type="button"
                                                                    onClick={() => toggleSecret('new')}
                                                                    className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                                                                >
                                                                    {showSecrets['new'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="border-t border-dashed pt-2 md:col-span-2 grid grid-cols-2 gap-5">
                                                    <div>
                                                        <label className="text-xs font-semibold text-gray-700 uppercase tracking-wide">Charge Amount</label>
                                                        <input
                                                            type="number"
                                                            value={editingApi?.transactionCharge}
                                                            onChange={(e) => setEditingApi({ ...editingApi!, transactionCharge: Number(e.target.value) })}
                                                            className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm"
                                                        />
                                                    </div>
                                                    <div>
                                                        <label className="text-xs font-semibold text-gray-700 uppercase tracking-wide">Charge Type</label>
                                                        <select
                                                            value={editingApi?.transactionChargeType}
                                                            onChange={(e) => setEditingApi({ ...editingApi!, transactionChargeType: e.target.value as any })}
                                                            className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm"
                                                        >
                                                            <option value="fixed">Fixed Amount (INR)</option>
                                                            <option value="percentage">Percentage (%)</option>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div className="md:col-span-2 flex items-center justify-between pt-4 border-t border-gray-200">
                                                    <label className="flex items-center gap-2 cursor-pointer select-none">
                                                        <input
                                                            type="checkbox"
                                                            checked={editingApi?.isActive}
                                                            onChange={(e) => setEditingApi({ ...editingApi!, isActive: e.target.checked })}
                                                            className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                                                        />
                                                        <span className="text-sm font-medium text-gray-700">Active</span>
                                                    </label>

                                                    <div className="flex gap-3">
                                                        <button
                                                            onClick={() => { setEditingApi(null); setIsCreating(false); }}
                                                            className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800 hover:bg-gray-200/50 rounded-lg transition-colors"
                                                        >
                                                            Cancel
                                                        </button>
                                                        <button
                                                            onClick={handleSave}
                                                            disabled={saving}
                                                            className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-all shadow-sm hover:shadow disabled:opacity-70 disabled:cursor-not-allowed"
                                                        >
                                                            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                                                            {iscreating ? 'Create API' : 'Save Changes'}
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </motion.div>
                                    )}
                                </AnimatePresence>

                                {apis.length === 0 && !loadingApis && !iscreating ? (
                                    <div className="bg-white border border-gray-200 rounded-lg p-8 text-center">
                                        <p className="text-gray-500">This user does not have any custom APIs configured yet.</p>
                                    </div>
                                ) : (
                                    apis.map(api => (
                                        <div
                                            key={api.id}
                                            className={`bg-white border rounded-xl overflow-hidden shadow-sm transition-all ${editingApi?.id === api.id && !iscreating
                                                ? 'ring-2 ring-blue-500 border-transparent shadow-md hidden' // Hide if editing
                                                : 'border-gray-200 hover:border-gray-300'
                                                }`}
                                        >
                                            <div className="p-5 flex justify-between items-start gap-4">
                                                <div className="space-y-2 flex-1">
                                                    <div className="flex items-center gap-3">
                                                        <h3 className="text-base font-bold text-gray-900">{api.apiName}</h3>
                                                        <span className={`px-2.5 py-0.5 text-[10px] rounded-full uppercase tracking-wider font-bold border ${api.isActive
                                                            ? 'bg-green-50 text-green-700 border-green-100'
                                                            : 'bg-red-50 text-red-700 border-red-100'
                                                            }`}>
                                                            {api.isActive ? 'Active' : 'Inactive'}
                                                        </span>
                                                        {api.apiNumber && (
                                                            <span className="text-[10px] font-mono text-gray-400 border px-1 rounded">{api.apiNumber}</span>
                                                        )}
                                                    </div>
                                                    <div className="font-mono text-xs text-gray-500 bg-gray-50 rounded px-2 py-1 inline-block border border-gray-200 break-all">
                                                        {api.apiMethod} {api.apiBaseUrl}{api.apiEndpoint}
                                                    </div>

                                                    <div className="flex flex-wrap items-center gap-4 mt-2 text-xs text-gray-500">
                                                        <div className="flex items-center gap-1.5">
                                                            <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                                                            Charge: <strong className="text-gray-900">{api.transactionCharge} {api.transactionChargeType === 'percentage' ? '%' : 'INR'}</strong>
                                                        </div>
                                                    </div>
                                                </div>

                                                <button
                                                    onClick={() => { setEditingApi(api); setIsCreating(false); }}
                                                    className="p-2 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-blue-600 transition-colors"
                                                >
                                                    <Edit className="w-4 h-4" />
                                                </button>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}

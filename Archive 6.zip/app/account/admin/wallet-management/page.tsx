'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useGlobalToast } from '@/context/ToastContext';

export default function AdminWalletManagementPage() {
    const { data: session, status } = useSession();
    const router = useRouter();
    const toast = useGlobalToast();

    const [formData, setFormData] = useState({
        username: '',
        amount: '',
        type: 'CREDIT',
        description: ''
    });
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.username || !formData.amount || !formData.description) {
            toast.showError('Please fill all fields');
            return;
        }

        setLoading(true);
        toast.showInfo('Processing wallet update... Please wait');
        try {
            const response = await fetch('/api/admin/wallet/manage', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    ...formData,
                    amount: Number(formData.amount)
                })
            });

            const data = await response.json();
            if (data.success) {
                toast.showSuccess(data.message || 'Wallet updated successfully');
                setFormData({ username: '', amount: '', type: 'CREDIT', description: '' });
            } else {
                toast.showError(data.error || 'Failed to update wallet');
            }
        } catch (error) {
            toast.showError('An error occurred');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    if (status === 'loading') return <div>Loading...</div>;
    if ((session?.user as any)?.role !== 'ADMIN') return <div>Access Denied</div>;

    return (
        <div className="max-w-2xl mx-auto p-6">
            <h1 className="text-3xl font-bold mb-8 text-gray-800">💼 Wallet Management</h1>

            <div className="bg-white rounded-xl shadow-md p-6 border border-gray-200">
                <h2 className="text-xl font-semibold mb-6 text-gray-700">Manual Credit/Debit</h2>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Username / Email</label>
                        <input
                            type="text"
                            value={formData.username}
                            onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                            placeholder="Enter user's username"
                            required
                        />
                    </div>

                    <div className="grid grid-cols-2 gap-6">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Amount (₹)</label>
                            <input
                                type="number"
                                min="1"
                                step="any"
                                value={formData.amount}
                                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                                placeholder="0.00"
                                required
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">Transaction Type</label>
                            <select
                                value={formData.type}
                                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                                className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white"
                            >
                                <option value="CREDIT">💰 Credit (Add Money)</option>
                                <option value="DEBIT">💸 Debit (Deduct Money)</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Description / Reason</label>
                        <textarea
                            value={formData.description}
                            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                            rows={3}
                            placeholder="Reason for adjustment..."
                            required
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={loading}
                        className={`w-full py-3 px-4 rounded-lg text-white font-medium transition-colors ${loading
                            ? 'bg-gray-400 cursor-not-allowed'
                            : formData.type === 'CREDIT'
                                ? 'bg-green-600 hover:bg-green-700'
                                : 'bg-red-600 hover:bg-red-700'
                            }`}
                    >
                        {loading ? 'Processing...' : `Confirm ${formData.type === 'CREDIT' ? 'Credit' : 'Debit'}`}
                    </button>
                </form>
            </div>

            <div className="mt-8 bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h3 className="font-semibold text-blue-800 mb-2">ℹ️ Note</h3>
                <ul className="list-disc list-inside text-sm text-blue-700 space-y-1">
                    <li>This action directly modifies the user's wallet balance.</li>
                    <li>For DEBIT transactions, the user must have sufficient balance.</li>
                    <li>All actions are logged in the database for audit purposes.</li>
                </ul>
            </div>
        </div>
    );
}

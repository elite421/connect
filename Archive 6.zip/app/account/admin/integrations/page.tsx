'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';

interface UserIntegration {
  id: string;
  code: string;
  baseUrl: string;
  createdAt: string;
  user?: {
    email: string;
    name: string;
  };
}

interface User {
  id: string;
  email: string;
  name: string;
  username: string;
}

export default function AdminIntegrationsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [integrations, setIntegrations] = useState<UserIntegration[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedIntegration, setSelectedIntegration] = useState<UserIntegration | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchIntegrations = async (search: string = '') => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        ...(search && { search }),
      });
      const response = await fetch(`/api/admin/integrations?${params}`);
      const data = await response.json();
      if (data.success) {
        setIntegrations(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch integrations:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIntegrations();
  }, []);

  const columns: Column<UserIntegration>[] = [
    { key: 'code', label: 'Integration Code' },
    { key: 'baseUrl', label: 'Base URL' },
    {
      key: 'user',
      label: 'User',
      render: (user) => user ? `${user.email} (${user.name})` : 'N/A',
    },
    {
      key: 'createdAt',
      label: 'Created',
      render: (date) => new Date(date).toLocaleDateString(),
    },
  ];

  const handleViewIntegration = (integration: UserIntegration) => {
    setSelectedIntegration(integration);
    setIsModalOpen(true);
  };

  const handleDeleteIntegration = async (integration: UserIntegration) => {
    if (!confirm(`Delete integration ${integration.code}?`)) return;
    try {
      const response = await fetch(`/api/admin/integrations?id=${integration.id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        fetchIntegrations(searchQuery);
      }
    } catch (error) {
      console.error('Failed to delete integration:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">API Integrations</h1>
        <p className="text-gray-600 mt-2">Manage all user API integrations</p>
      </div>

      <div className="flex gap-4">
        <input
          type="text"
          placeholder="Search integrations..."
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            fetchIntegrations(e.target.value);
          }}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <DataTable<UserIntegration>
        data={integrations}
        columns={columns}
        loading={loading}
        actions={[
          {
            label: 'View',
            onClick: handleViewIntegration,
            variant: 'secondary',
          },
          {
            label: 'Delete',
            onClick: handleDeleteIntegration,
            variant: 'danger',
          },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`Integration Details: ${selectedIntegration?.code}`}
        size="md"
      >
        {selectedIntegration && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Code</label>
              <p className="mt-1 text-gray-900">{selectedIntegration.code}</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Base URL</label>
              <p className="mt-1 text-gray-900 break-all">{selectedIntegration.baseUrl}</p>
            </div>
            {selectedIntegration.user && (
              <div>
                <label className="block text-sm font-medium text-gray-700">User</label>
                <p className="mt-1 text-gray-900">
                  {selectedIntegration.user.name} ({selectedIntegration.user.email})
                </p>
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-700">Created</label>
              <p className="mt-1 text-gray-900">
                {new Date(selectedIntegration.createdAt).toLocaleString()}
              </p>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

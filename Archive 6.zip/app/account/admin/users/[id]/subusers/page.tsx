'use client';

import { useEffect, useState, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter, useParams } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { FormBuilder, type FormField } from '@/components/form-builder';

interface Subuser {
  id: string;
  email: string;
  name: string;
  username: string;
  phone?: string;
  createdAt: string;
  parentUserId: string;
  isActive: boolean;
  assignedServices?: string[];
}

export default function AdminSubusersPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const params = useParams();
  const userId = params?.id as string;

  const [subusers, setSubusers] = useState<Subuser[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedSubuser, setSelectedSubuser] = useState<Subuser | null>(null);
  const [parentUserName, setParentUserName] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    const userRole = (session?.user as { role?: string })?.role;
    if (userRole !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchSubusersData = useCallback(
    async (offset: number = 0, search: string = '') => {
      setLoading(true);
      try {
        const params = new URLSearchParams({
          offset: offset.toString(),
          limit: '50',
          ...(search && { search }),
        });
        const response = await fetch(`/api/admin/users/${userId}/subusers?${params}`);
        const data = await response.json();
        if (data.success) {
          setSubusers(data.data);
          setPagination(data.pagination);
        }
      } catch (error) {
        console.error('Failed to fetch subusers:', error);
      } finally {
        setLoading(false);
      }
    },
    [userId]
  );

  useEffect(() => {
    const fetchParentUser = async () => {
      try {
        const response = await fetch(`/api/admin/users/${userId}`);
        const data = await response.json();
        if (data.success) {
          setParentUserName(data.data.name || data.data.email);
        }
      } catch (error) {
        console.error('Failed to fetch parent user:', error);
      }
    };

    if (userId) {
      fetchParentUser();
      fetchSubusersData();
    }
  }, [userId, fetchSubusersData]);

  const columns: Column<Subuser>[] = [
    { key: 'email', label: 'Email' },
    { key: 'name', label: 'Name' },
    { key: 'username', label: 'Username' },
    { key: 'phone', label: 'Phone' },
    {
      key: 'isActive',
      label: 'Status',
      render: (isActive) => (
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
          isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
        }`}>
          {isActive ? 'Active' : 'Inactive'}
        </span>
      ),
    },
    {
      key: 'createdAt',
      label: 'Created',
      render: (date) => new Date(date).toLocaleDateString(),
    },
  ];

  const formFields: FormField[] = [
    {
      name: 'isActive',
      label: 'Status',
      type: 'select',
      required: true,
      options: [
        { label: 'Active', value: 'true' },
        { label: 'Inactive', value: 'false' },
      ],
    },
    {
      name: 'assignedServices',
      label: 'Assigned Services (comma-separated IDs)',
      type: 'textarea',
      required: false,
      placeholder: 'e.g., service-id-1, service-id-2',
    },
  ];

  const handleEditSubuser = (subuser: Subuser) => {
    setSelectedSubuser(subuser);
    setIsModalOpen(true);
  };

  const handleSubmit = async (data: Record<string, unknown>) => {
    if (!selectedSubuser) return;
    try {
      const response = await fetch(`/api/admin/users/${userId}/subusers/${selectedSubuser.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (response.ok) {
        setIsModalOpen(false);
        fetchSubusersData(pagination.offset, searchQuery);
      }
    } catch (error) {
      console.error('Failed to update subuser:', error);
    }
  };

  const handleDeleteSubuser = async (subuser: Subuser) => {
    if (!confirm(`Delete subuser ${subuser.email}?`)) return;
    try {
      const response = await fetch(
        `/api/admin/users/${userId}/subusers/${subuser.id}`,
        { method: 'DELETE' }
      );
      if (response.ok) {
        fetchSubusersData(pagination.offset, searchQuery);
      }
    } catch (error) {
      console.error('Failed to delete subuser:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <button
          onClick={() => router.back()}
          className="text-blue-600 hover:text-blue-800 font-medium mb-4"
        >
          ← Back to Users
        </button>
        <h1 className="text-3xl font-bold text-gray-900">Subusers Management</h1>
        <p className="text-gray-600 mt-2">Manage subusers for {parentUserName}</p>
      </div>

      <div className="flex gap-4">
        <input
          type="text"
          placeholder="Search subusers..."
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            fetchSubusersData(0, e.target.value);
          }}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <DataTable<Subuser>
        data={subusers}
        columns={columns}
        loading={loading}
        pagination={{
          ...pagination,
          onPageChange: (offset) => fetchSubusersData(offset, searchQuery),
        }}
        actions={[
          {
            label: 'Edit',
            onClick: handleEditSubuser,
            variant: 'primary',
          },
          {
            label: 'Delete',
            onClick: handleDeleteSubuser,
            variant: 'danger',
          },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`Edit Subuser: ${selectedSubuser?.email}`}
        size="md"
      >
        {selectedSubuser && (
          <FormBuilder
            fields={formFields}
            onSubmit={handleSubmit}
            initialValues={{
              isActive: selectedSubuser.isActive ? 'true' : 'false',
              assignedServices: selectedSubuser.assignedServices || [],
            }}
            submitLabel="Update Subuser"
          />
        )}
      </Modal>
    </div>
  );
}

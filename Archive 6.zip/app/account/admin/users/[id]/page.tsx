'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter, useParams } from 'next/navigation';
import { useGlobalToast } from '@/context/ToastContext';
import { Modal } from '@/components/modal';

interface User {
    id: string;
    email: string;
    name: string;
    username: string;
    role: string;
    phone?: string;
    active: boolean; // Correct column name confirmed from context (will verify from schema)
    defaultApiId?: string;
    createdAt: string;
    _count: { subUsers: number };
}

interface ApiKey {
    id: string;
    name: string;
    keyValue?: string; // Only on create
    isActive: boolean;
    permissions: string[];
    expiresAt: string | null;
    lastUsedAt: string | null;
    createdAt: string;
}

interface Webhook {
    id: string;
    webhookUrl: string;
    events: string[];
    isActive: boolean;
    createdAt: string;
}

interface IpWhitelist {
    id: string;
    ipAddress: string;
    label: string | null;
    isActive: boolean;
    createdAt: string;
}

export default function AdminUserDetailPage() {
    const { data: session, status } = useSession();
    const router = useRouter();
    const params = useParams();
    const userId = params?.id as string;
    const toast = useGlobalToast();

    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<'overview' | 'developer' | 'subusers'>('overview');

    // Developer Data
    const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
    const [webhooks, setWebhooks] = useState<Webhook[]>([]);
    const [ips, setIps] = useState<IpWhitelist[]>([]);

    // Modals
    const [showKeyModal, setShowKeyModal] = useState(false);
    const [newKeyForm, setNewKeyForm] = useState({ name: '', permissions: ['read', 'write'], expiresAt: '' });
    const [createdKey, setCreatedKey] = useState<ApiKey | null>(null);

    useEffect(() => {
        if (status === 'unauthenticated') router.push('/login');
        if ((session?.user as any)?.role !== 'ADMIN') router.push('/account/dashboard');
    }, [session, status, router]);

    useEffect(() => {
        if (userId && status === 'authenticated') {
            fetchUser();
        }
    }, [userId, status]);

    useEffect(() => {
        if (activeTab === 'developer' && userId) {
            fetchApiKeys();
            fetchWebhooks();
            fetchIps();
        }
    }, [activeTab, userId]);

    const fetchUser = async () => {
        try {
            const res = await fetch(`/api/admin/users?userId=${userId}`);
            const data = await res.json();
            if (data.success) setUser(data.data);
            else toast.showError('Failed to fetch user');
        } catch {
            toast.showError('Error loading user');
        } finally {
            setLoading(false);
        }
    };

    const fetchApiKeys = async () => {
        const res = await fetch(`/api/admin/api-keys?userId=${userId}`);
        const data = await res.json();
        if (data.success) setApiKeys(data.data);
    };

    const fetchWebhooks = async () => {
        const res = await fetch(`/api/admin/webhooks?userId=${userId}`);
        const data = await res.json();
        if (data.success) setWebhooks(data.data);
    };

    const fetchIps = async () => {
        const res = await fetch(`/api/admin/ip-whitelist?userId=${userId}`);
        const data = await res.json();
        if (data.success) setIps(data.data);
    };

    const handleCreateKey = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            const res = await fetch('/api/admin/api-keys', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId, ...newKeyForm }),
            });
            const data = await res.json();
            if (data.success) {
                setCreatedKey(data.data);
                fetchApiKeys();
                toast.showSuccess('API Key Created');
            } else {
                toast.showError(data.error);
            }
        } catch {
            toast.showError('Error creating key');
        }
    };

    const handleRevokeKey = async (keyId: string) => {
        if (!confirm('Revoke this key?')) return;
        try {
            const res = await fetch('/api/admin/api-keys', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ apiKeyId: keyId, action: 'revoke', reason: 'Admin revoked' })
            });
            if ((await res.json()).success) {
                toast.showSuccess('Key revoked');
                fetchApiKeys();
            }
        } catch { toast.showError('Error revoking key'); }
    };

    const handleDeleteKey = async (keyId: string) => {
        if (!confirm('Delete this key permanently?')) return;
        try {
            const res = await fetch(`/api/admin/api-keys?id=${keyId}`, { method: 'DELETE' });
            if ((await res.json()).success) {
                toast.showSuccess('Key deleted');
                fetchApiKeys();
            }
        } catch { toast.showError('Error deleting key'); }
    };

    const handleDeleteWebhook = async (id: string) => {
        if (!confirm('Delete webhook?')) return;
        await fetch(`/api/admin/webhooks?id=${id}`, { method: 'DELETE' });
        fetchWebhooks();
    };

    const handleDeleteIp = async (id: string) => {
        if (!confirm('Remove IP?')) return;
        await fetch(`/api/admin/ip-whitelist?id=${id}`, { method: 'DELETE' });
        fetchIps();
    };

    if (loading) return <div className="p-8 text-center text-gray-500">Loading user...</div>;
    if (!user) return <div className="p-8 text-center text-red-500">User not found</div>;

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <button onClick={() => router.push('/account/admin/users')} className="text-sm text-blue-600 mb-2">← Back to Users</button>
                    <h1 className="text-3xl font-bold text-gray-900">{user.name || user.email}</h1>
                    <p className="text-gray-500 text-sm">ID: {user.id} • {user.role}</p>
                </div>
                <div className="flex gap-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${user.active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                        {user.active ? 'Active' : 'Inactive'}
                    </span>
                </div>
            </div>

            <div className="border-b flex gap-6">
                <button onClick={() => setActiveTab('overview')} className={`pb-2 px-1 ${activeTab === 'overview' ? 'border-b-2 border-blue-600 text-blue-600 font-medium' : 'text-gray-500'}`}>Overview</button>
                <button onClick={() => setActiveTab('developer')} className={`pb-2 px-1 ${activeTab === 'developer' ? 'border-b-2 border-blue-600 text-blue-600 font-medium' : 'text-gray-500'}`}>Developer Settings</button>
                <button
                    onClick={() => router.push(`/account/admin/users/${user.id}/subusers`)}
                    className="pb-2 px-1 text-gray-500 hover:text-blue-600"
                >
                    Subusers ({user._count?.subUsers || 0}) ↗
                </button>
            </div>

            {activeTab === 'overview' && (
                <div className="bg-white p-6 rounded-lg border shadow-sm max-w-2xl">
                    <h3 className="font-semibold text-lg mb-4">User Details</h3>
                    <dl className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <dt className="text-sm text-gray-500">Full Name</dt>
                            <dd className="font-medium">{user.name}</dd>
                        </div>
                        <div>
                            <dt className="text-sm text-gray-500">Email</dt>
                            <dd className="font-medium">{user.email}</dd>
                        </div>
                        <div>
                            <dt className="text-sm text-gray-500">Username</dt>
                            <dd className="font-medium">{user.username}</dd>
                        </div>
                        <div>
                            <dt className="text-sm text-gray-500">Role</dt>
                            <dd className="font-medium">{user.role}</dd>
                        </div>
                        <div>
                            <dt className="text-sm text-gray-500">Phone</dt>
                            <dd className="font-medium">{user.phone || '-'}</dd>
                        </div>
                        <div>
                            <dt className="text-sm text-gray-500">Joined</dt>
                            <dd className="font-medium">{new Date(user.createdAt).toLocaleDateString()}</dd>
                        </div>
                    </dl>
                </div>
            )}

            {activeTab === 'developer' && (
                <div className="space-y-8">
                    {/* API Keys */}
                    <div className="bg-white p-6 rounded-lg border shadow-sm">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="font-semibold text-lg">API Keys</h3>
                            <button onClick={() => { setShowKeyModal(true); setCreatedKey(null); }} className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700">+ Create Key</button>
                        </div>

                        {apiKeys.length === 0 ? (
                            <p className="text-gray-500 text-sm">No API keys found.</p>
                        ) : (
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm text-left">
                                    <thead className="bg-gray-50 text-gray-600 uppercase text-xs">
                                        <tr>
                                            <th className="px-4 py-2">Name</th>
                                            <th className="px-4 py-2">Status</th>
                                            <th className="px-4 py-2">Created</th>
                                            <th className="px-4 py-2 text-right">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y">
                                        {apiKeys.map(key => (
                                            <tr key={key.id}>
                                                <td className="px-4 py-3 font-medium">{key.name}</td>
                                                <td className="px-4 py-3">
                                                    <span className={`px-2 py-0.5 rounded text-xs ${key.isActive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                                        {key.isActive ? 'Active' : 'Revoked'}
                                                    </span>
                                                </td>
                                                <td className="px-4 py-3 text-gray-500">{new Date(key.createdAt).toLocaleDateString()}</td>
                                                <td className="px-4 py-3 text-right space-x-2">
                                                    {key.isActive && (
                                                        <button onClick={() => handleRevokeKey(key.id)} className="text-orange-600 hover:text-orange-800 text-xs">Revoke</button>
                                                    )}
                                                    <button onClick={() => handleDeleteKey(key.id)} className="text-red-600 hover:text-red-800 text-xs">Delete</button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>

                    {/* Webhooks */}
                    <div className="bg-white p-6 rounded-lg border shadow-sm">
                        <h3 className="font-semibold text-lg mb-4">Webhooks</h3>
                        {webhooks.length === 0 ? (
                            <p className="text-gray-500 text-sm">No webhooks configured.</p>
                        ) : (
                            <div className="space-y-2">
                                {webhooks.map(wh => (
                                    <div key={wh.id} className="flex justify-between items-center bg-gray-50 p-3 rounded">
                                        <div>
                                            <code className="text-sm block text-gray-800">{wh.webhookUrl}</code>
                                            <div className="flex gap-1 mt-1">
                                                {wh.events?.map(e => <span key={e} className="text-xs bg-gray-200 px-1 rounded">{e}</span>)}
                                            </div>
                                        </div>
                                        <button onClick={() => handleDeleteWebhook(wh.id)} className="text-red-600 text-xs hover:underline">Delete</button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* IP Whitelist */}
                    <div className="bg-white p-6 rounded-lg border shadow-sm">
                        <h3 className="font-semibold text-lg mb-4">IP Whitelist</h3>
                        {ips.length === 0 ? (
                            <p className="text-gray-500 text-sm">No IPs whitelisted.</p>
                        ) : (
                            <div className="flex flex-wrap gap-2">
                                {ips.map(ip => (
                                    <div key={ip.id} className="bg-gray-100 px-3 py-1 rounded flex items-center gap-2">
                                        <span className="font-mono text-sm">{ip.ipAddress}</span>
                                        <button onClick={() => handleDeleteIp(ip.id)} className="text-gray-500 hover:text-red-600">×</button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Create Key Modal */}
            {showKeyModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-xl p-6 w-full max-w-md shadow-lg">
                        <h2 className="text-xl font-bold mb-4">Create API Key</h2>
                        {createdKey ? (
                            <div className="space-y-4">
                                <div className="bg-green-50 text-green-800 p-3 rounded text-sm">Key Created Successfully</div>
                                <div className="bg-gray-100 p-3 rounded break-all font-mono text-sm">{createdKey.keyValue}</div>
                                <p className="text-xs text-red-500">Copy this key now. It won't be shown again.</p>
                                <button onClick={() => { setShowKeyModal(false); setCreatedKey(null); }} className="w-full bg-gray-900 text-white py-2 rounded">Done</button>
                            </div>
                        ) : (
                            <form onSubmit={handleCreateKey} className="space-y-3">
                                <div>
                                    <label className="text-sm font-medium">Name</label>
                                    <input className="w-full border rounded p-2" value={newKeyForm.name} onChange={e => setNewKeyForm({ ...newKeyForm, name: e.target.value })} required placeholder="e.g. Admin Generated" />
                                </div>
                                <div>
                                    <label className="text-sm font-medium">Expires At (Optional)</label>
                                    <input type="date" className="w-full border rounded p-2" value={newKeyForm.expiresAt} onChange={e => setNewKeyForm({ ...newKeyForm, expiresAt: e.target.value })} />
                                </div>
                                <div className="flex gap-2 pt-2">
                                    <button type="button" onClick={() => setShowKeyModal(false)} className="flex-1 border py-2 rounded">Cancel</button>
                                    <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded">Create</button>
                                </div>
                            </form>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { Modal } from '@/components/modal';
import { FormBuilder, type FormField } from '@/components/form-builder';

interface User {
  id: string;
  email: string;
  name: string;
  username: string;
  role: string;
  phone?: string;
  createdAt: string;
  _count: { subUsers: number };
  defaultApiId?: string;
  transactionCharge?: number;
  assignedServices?: string[];
}

export default function AdminUsersPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({ offset: 0, limit: 50, total: 0 });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [services, setServices] = useState<any[]>([]);
  const [userApis, setUserApis] = useState<any[]>([]);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
    }
    if ((session?.user as any)?.role !== 'ADMIN') {
      router.push('/account/dashboard');
    }
  }, [session, status, router]);

  const fetchUsers = async (offset: number = 0, search: string = '') => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        offset: offset.toString(),
        limit: '50',
        ...(search && { search }),
      });
      const response = await fetch(`/api/admin/users?${params}`);
      const data = await response.json();
      if (data.success) {
        setUsers(data.data);
        setPagination(data.pagination);
      }
    } catch (error) {
      console.error('Failed to fetch users:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const response = await fetch('/api/admin/services');
      const data = await response.json();
      if (data.success) {
        setServices(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch services:', error);
    }
  };

  const columns: Column<User>[] = [
    { key: 'email', label: 'Email' },
    { key: 'name', label: 'Name' },
    { key: 'username', label: 'Username' },
    { key: 'role', label: 'Role' },
    {
      key: '_count',
      label: 'SubUsers',
      render: (count) => count.subUsers,
    },
    {
      key: 'createdAt',
      label: 'Created',
      render: (date) => new Date(date).toLocaleDateString(),
    },
  ];

  const formFields: FormField[] = [
    { name: 'role', label: 'Role', type: 'select', required: true, options: [
      { label: 'User', value: 'USER' },
      { label: 'Admin', value: 'ADMIN' },
    ]},
    {
      name: 'transactionCharge',
      label: 'Transaction Charge (%)',
      type: 'number',
      required: false,
      placeholder: '0.00',
    },
    {
      name: 'assignedServices',
      label: 'Assigned Services (comma-separated IDs)',
      type: 'textarea',
      required: false,
      placeholder: 'e.g., service-id-1, service-id-2',
    },
    {
      name: 'defaultApiId',
      label: 'Default API (fallback for payouts)',
      type: 'select',
      required: false,
      options: [
        { label: '— None —', value: '' },
        ...userApis
          .filter((a) => a.userId === selectedUser?.id)
          .map((a) => ({
            value: a.id,
            label: `${a.name || 'API'} (${(a.key || '').slice(0, 8)}...)`,
          })),
      ],
    },
  ];

  const handleEditUser = async (user: User) => {
    setSelectedUser(user);
    setIsModalOpen(true);
    // fetch APIs and cache; filter by this user for select options
    try {
      const resp = await fetch('/api/admin/apis?limit=1000&offset=0');
      const data = await resp.json();
      if (data.success) {
        setUserApis(data.data || []);
      }
    } catch (e) {
      console.error('Failed to fetch user APIs:', e);
    }
  };

  const handleSubmit = async (data: Record<string, any>) => {
    if (!selectedUser) return;
    try {
      // Normalize defaultApiId empty selection to null
      const payload = { ...data } as any;
      if (payload.defaultApiId === '') payload.defaultApiId = null;

      const response = await fetch('/api/admin/users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: selectedUser.id, ...payload }),
      });
      if (response.ok) {
        setIsModalOpen(false);
        fetchUsers(pagination.offset, searchQuery);
      }
    } catch (error) {
      console.error('Failed to update user:', error);
    }
  };

  const handleDeleteUser = async (user: User) => {
    if (!confirm(`Delete user ${user.email}?`)) return;
    try {
      const response = await fetch(`/api/admin/users?userId=${user.id}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        fetchUsers(pagination.offset, searchQuery);
      }
    } catch (error) {
      console.error('Failed to delete user:', error);
    }
  };

  const handleViewSubusers = (user: User) => {
    router.push(`/account/admin/users/${user.id}/subusers`);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Users Management</h1>
        <p className="text-gray-600 mt-2">Manage all system users and their permissions</p>
      </div>

      <div className="flex gap-4">
        <input
          type="text"
          placeholder="Search users..."
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            fetchUsers(0, e.target.value);
          }}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
        />
      </div>

      <DataTable<User>
        data={users}
        columns={columns}
        loading={loading}
        pagination={{
          ...pagination,
          onPageChange: (offset) => fetchUsers(offset, searchQuery),
        }}
        actions={[
          {
            label: 'Edit',
            onClick: handleEditUser,
            variant: 'primary',
          },
          {
            label: 'View Subusers',
            onClick: handleViewSubusers,
            variant: 'secondary',
          },
          {
            label: 'Delete',
            onClick: handleDeleteUser,
            variant: 'danger',
          },
        ]}
      />

      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`Edit User: ${selectedUser?.email}`}
        size="md"
      >
        {selectedUser && (
          <FormBuilder
            fields={formFields}
            onSubmit={handleSubmit}
            initialValues={{
              role: selectedUser.role,
              transactionCharge: selectedUser.transactionCharge || 0,
              assignedServices: selectedUser.assignedServices || [],
              defaultApiId: selectedUser.defaultApiId || '',
            }}
            submitLabel="Update User"
          />
        )}
      </Modal>
    </div>
  );
}

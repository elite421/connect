'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { DataTable, type Column } from '@/components/data-table';
import { useGlobalToast } from '@/context/ToastContext';

interface PayInApi {
    id: string;
    apiName: string;
    apiBaseUrl: string;
    apiEndpoint: string;
    apiMethod: string;
    authType: string;
    apiKey: string | null;
    isActive: boolean;
    isDefault: boolean;
    allowedModes: string[];
    createdAt: string;
    updatedAt: string;
}

export default function AdminPayInApisPage() {
    const { data: session, status } = useSession();
    const router = useRouter();
    const toast = useGlobalToast();
    const [apis, setApis] = useState<PayInApi[]>([]);
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [editingApi, setEditingApi] = useState<PayInApi | null>(null);
    const [submitting, setSubmitting] = useState(false);
    const [formData, setFormData] = useState({
        apiName: '',
        apiBaseUrl: '',
        apiEndpoint: '',
        apiMethod: 'POST',
        authType: 'bearer',
        apiKey: '',
        apiSecret: '',
        authHeader: '',
        isActive: true,
        isDefault: false,
        allowedModes: ['UPI', 'CARD', 'NETBANKING', 'WALLET'],
    });

    useEffect(() => {
        if (status === 'unauthenticated') {
            router.push('/login');
        }
        if ((session?.user as any)?.role !== 'ADMIN') {
            router.push('/account/dashboard');
        }
    }, [session, status, router]);

    useEffect(() => {
        if (session && status === 'authenticated') {
            fetchApis();
        }
    }, [session, status]);

    const fetchApis = async () => {
        setLoading(true);
        try {
            const response = await fetch('/api/admin/payin-apis');
            const data = await response.json();
            if (data.success) {
                setApis(data.data);
            }
        } catch (error) {
            console.error('Failed to fetch PayIn APIs:', error);
            toast.showError('Failed to fetch PayIn APIs');
        } finally {
            setLoading(false);
        }
    };

    const handleOpenModal = (api?: PayInApi) => {
        if (api) {
            setEditingApi(api);
            setFormData({
                apiName: api.apiName,
                apiBaseUrl: api.apiBaseUrl,
                apiEndpoint: api.apiEndpoint,
                apiMethod: api.apiMethod,
                authType: api.authType,
                apiKey: api.apiKey || '',
                apiSecret: '',
                authHeader: '',
                isActive: api.isActive,
                isDefault: api.isDefault,
                allowedModes: api.allowedModes || ['UPI', 'CARD', 'NETBANKING', 'WALLET'],
            });
        } else {
            setEditingApi(null);
            setFormData({
                apiName: '',
                apiBaseUrl: '',
                apiEndpoint: '',
                apiMethod: 'POST',
                authType: 'bearer',
                apiKey: '',
                apiSecret: '',
                authHeader: '',
                isActive: true,
                isDefault: false,
                allowedModes: ['UPI', 'CARD', 'NETBANKING', 'WALLET'],
            });
        }
        setShowModal(true);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);

        try {
            const method = editingApi ? 'PUT' : 'POST';
            const body = editingApi ? { id: editingApi.id, ...formData } : formData;

            const response = await fetch('/api/admin/payin-apis', {
                method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });

            const data = await response.json();
            if (data.success) {
                toast.showSuccess(data.message || 'API saved successfully');
                setShowModal(false);
                fetchApis();
            } else {
                toast.showError(data.error || 'Failed to save API');
            }
        } catch (error) {
            console.error('Failed to save API:', error);
            toast.showError('Error saving API');
        } finally {
            setSubmitting(false);
        }
    };

    const handleDelete = async (id: string) => {
        if (!confirm('Are you sure you want to delete this PayIn API?')) return;

        try {
            const response = await fetch(`/api/admin/payin-apis?id=${id}`, {
                method: 'DELETE',
            });

            const data = await response.json();
            if (data.success) {
                toast.showSuccess('API deleted successfully');
                fetchApis();
            } else {
                toast.showError(data.error || 'Failed to delete API');
            }
        } catch (error) {
            console.error('Failed to delete API:', error);
            toast.showError('Error deleting API');
        }
    };

    const handleToggleActive = async (api: PayInApi) => {
        try {
            const response = await fetch('/api/admin/payin-apis', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: api.id, isActive: !api.isActive }),
            });

            const data = await response.json();
            if (data.success) {
                toast.showSuccess(`API ${api.isActive ? 'deactivated' : 'activated'} successfully`);
                fetchApis();
            } else {
                toast.showError(data.error || 'Failed to update API');
            }
        } catch (error) {
            console.error('Failed to toggle API:', error);
        }
    };

    const columns: Column<PayInApi>[] = [
        {
            key: 'apiName',
            label: 'API Name',
            render: (_, api) => (
                <div>
                    <div className="font-medium">{api.apiName}</div>
                    {api.isDefault && (
                        <span className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded">Default</span>
                    )}
                </div>
            ),
        },
        {
            key: 'apiBaseUrl',
            label: 'Base URL',
            render: (_, api) => (
                <div className="text-sm text-gray-600 truncate max-w-xs" title={api.apiBaseUrl}>
                    {api.apiBaseUrl}
                </div>
            ),
        },
        {
            key: 'apiEndpoint',
            label: 'Endpoint',
            render: (_, api) => (
                <code className="text-sm bg-gray-100 px-2 py-1 rounded">{api.apiEndpoint}</code>
            ),
        },
        {
            key: 'apiMethod',
            label: 'Method',
            render: (_, api) => (
                <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded text-xs font-semibold">
                    {api.apiMethod}
                </span>
            ),
        },
        {
            key: 'authType',
            label: 'Auth Type',
            render: (_, api) => (
                <span className="capitalize">{api.authType}</span>
            ),
        },
        {
            key: 'isActive',
            label: 'Status',
            render: (_, api) => (
                <button
                    onClick={() => handleToggleActive(api)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold ${api.isActive
                            ? 'bg-green-100 text-green-800 hover:bg-green-200'
                            : 'bg-red-100 text-red-800 hover:bg-red-200'
                        }`}
                >
                    {api.isActive ? 'Active' : 'Inactive'}
                </button>
            ),
        },
        {
            key: 'id',
            label: 'Actions',
            render: (_, api) => (
                <div className="flex gap-2">
                    <button
                        onClick={() => handleOpenModal(api)}
                        className="px-3 py-1 bg-blue-100 text-blue-800 rounded hover:bg-blue-200 text-sm"
                    >
                        Edit
                    </button>
                    <button
                        onClick={() => handleDelete(api.id)}
                        className="px-3 py-1 bg-red-100 text-red-800 rounded hover:bg-red-200 text-sm"
                    >
                        Delete
                    </button>
                </div>
            ),
        },
    ];

    if (status === 'loading' || loading) {
        return (
            <div className="flex items-center justify-center p-12">
                <div className="text-gray-600">Loading PayIn APIs...</div>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">PayIn APIs Management</h1>
                    <p className="text-gray-600 mt-2">Configure custom payment gateway APIs for PayIn transactions</p>
                </div>
                <button
                    onClick={() => handleOpenModal()}
                    className="px-6 py-2 rounded-lg transition-colors font-medium bg-green-600 text-white hover:bg-green-700"
                >
                    + Add PayIn API
                </button>
            </div>

            {/* Info Banner */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 p-6 rounded-xl shadow-sm">
                <div className="flex items-start gap-3">
                    <div className="text-2xl">💳</div>
                    <div>
                        <h3 className="font-semibold text-blue-900 mb-2">PayIn API Configuration</h3>
                        <p className="text-sm text-blue-800 leading-relaxed">
                            Configure payment gateway APIs that users can use for receiving payments. These APIs will be used
                            to process incoming payments via UPI, Cards, Net Banking, and Wallets.
                        </p>
                    </div>
                </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{apis.length}</div>
                    <div className="text-sm text-gray-600 mt-1">Total APIs</div>
                </div>
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">
                        {apis.filter(a => a.isActive).length}
                    </div>
                    <div className="text-sm text-gray-600 mt-1">Active</div>
                </div>
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="text-2xl font-bold text-yellow-600">
                        {apis.filter(a => a.isDefault).length}
                    </div>
                    <div className="text-sm text-gray-600 mt-1">Default</div>
                </div>
                <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">
                        {apis.filter(a => !a.isActive).length}
                    </div>
                    <div className="text-sm text-gray-600 mt-1">Inactive</div>
                </div>
            </div>

            <DataTable<PayInApi>
                data={apis}
                columns={columns}
                loading={loading}
            />

            {/* Create/Edit Modal */}
            {showModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-xl p-8 w-full max-w-2xl shadow-2xl max-h-[90vh] overflow-y-auto">
                        <h2 className="text-2xl font-bold mb-6">
                            {editingApi ? 'Edit PayIn API' : 'Add PayIn API'}
                        </h2>

                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                                        API Name <span className="text-red-500">*</span>
                                    </label>
                                    <input
                                        type="text"
                                        value={formData.apiName}
                                        onChange={(e) => setFormData({ ...formData, apiName: e.target.value })}
                                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                        placeholder="My Payment Gateway"
                                        required
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                                        HTTP Method
                                    </label>
                                    <select
                                        value={formData.apiMethod}
                                        onChange={(e) => setFormData({ ...formData, apiMethod: e.target.value })}
                                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    >
                                        <option value="POST">POST</option>
                                        <option value="GET">GET</option>
                                        <option value="PUT">PUT</option>
                                    </select>
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">
                                    Base URL <span className="text-red-500">*</span>
                                </label>
                                <input
                                    type="url"
                                    value={formData.apiBaseUrl}
                                    onChange={(e) => setFormData({ ...formData, apiBaseUrl: e.target.value })}
                                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    placeholder="https://api.gateway.com"
                                    required
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-semibold text-gray-700 mb-2">
                                    Endpoint <span className="text-red-500">*</span>
                                </label>
                                <input
                                    type="text"
                                    value={formData.apiEndpoint}
                                    onChange={(e) => setFormData({ ...formData, apiEndpoint: e.target.value })}
                                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    placeholder="/v1/payments/create"
                                    required
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                                        Auth Type
                                    </label>
                                    <select
                                        value={formData.authType}
                                        onChange={(e) => setFormData({ ...formData, authType: e.target.value })}
                                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    >
                                        <option value="bearer">Bearer Token</option>
                                        <option value="basic">Basic Auth</option>
                                        <option value="apikey">API Key</option>
                                        <option value="custom-header">Custom Header</option>
                                    </select>
                                </div>

                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                                        Custom Auth Header
                                    </label>
                                    <input
                                        type="text"
                                        value={formData.authHeader}
                                        onChange={(e) => setFormData({ ...formData, authHeader: e.target.value })}
                                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                        placeholder="X-API-Key"
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                                        API Key / Token
                                    </label>
                                    <input
                                        type="password"
                                        value={formData.apiKey}
                                        onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                        placeholder="Enter API Key"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                                        API Secret
                                    </label>
                                    <input
                                        type="password"
                                        value={formData.apiSecret}
                                        onChange={(e) => setFormData({ ...formData, apiSecret: e.target.value })}
                                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                        placeholder="Enter API Secret"
                                    />
                                </div>
                            </div>

                            <div className="flex gap-4">
                                <label className="flex items-center gap-2 cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={formData.isActive}
                                        onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                                        className="w-4 h-4"
                                    />
                                    <span className="text-sm text-gray-700">Active</span>
                                </label>

                                <label className="flex items-center gap-2 cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={formData.isDefault}
                                        onChange={(e) => setFormData({ ...formData, isDefault: e.target.checked })}
                                        className="w-4 h-4"
                                    />
                                    <span className="text-sm text-gray-700">Set as Default</span>
                                </label>
                            </div>

                            <div className="flex gap-3 pt-4">
                                <button
                                    type="submit"
                                    disabled={submitting}
                                    className="flex-1 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 font-medium disabled:bg-gray-400 disabled:cursor-not-allowed"
                                >
                                    {submitting ? 'Saving...' : (editingApi ? 'Update API' : 'Create API')}
                                </button>
                                <button
                                    type="button"
                                    onClick={() => setShowModal(false)}
                                    className="flex-1 bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 font-medium"
                                >
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}

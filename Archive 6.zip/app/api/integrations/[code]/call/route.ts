import { Decimal } from '@prisma/client/runtime/library';
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import crypto from 'crypto';

type JwtClaims = { sub: string; tenantId: string; role: 'admin'|'owner'|'child'; exp?: number; iat?: number; actAsChildId?: string };
type Credentials = { apiKey?: string };

function b64urlDecode(s: string) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  const pad = s.length % 4 ? 4 - (s.length % 4) : 0;
  return Buffer.from(s + '='.repeat(pad), 'base64');
}
function verifyJWT(token: string, secret: string): JwtClaims {
  const [h, p, sig] = token.split('.');
  if (!h || !p || !sig) throw new Error('Invalid token');
  const data = `${h}.${p}`;
  const expected = crypto.createHmac('sha256', secret).update(data).digest('base64url');
  if (expected !== sig) throw new Error('Invalid signature');
  const payload = JSON.parse(b64urlDecode(p).toString('utf8'));
  const now = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < now) throw new Error('Token expired');
  return payload;
}

function decryptSecret(encryptedJson: string, keyB64: string): Credentials {
  const { iv, tag, ct } = JSON.parse(encryptedJson);
  const key = Buffer.from(keyB64, 'base64');
  const ivBuf = Buffer.from(iv, 'base64');
  const tagBuf = Buffer.from(tag, 'base64');
  const ctBuf = Buffer.from(ct, 'base64');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, ivBuf);
  decipher.setAuthTag(tagBuf);
  const dec = Buffer.concat([decipher.update(ctBuf), decipher.final()]).toString('utf8');
  return JSON.parse(dec);
}

async function isIpAllowed(opts: { tenantId: string; userId?: string | null; childId?: string | null; integrationId?: string | null; ip: string; }) {
  const { tenantId, userId, childId, integrationId, ip } = opts;
  const rows = await prisma.$queryRaw<{ x: number }[]>`
    SELECT 1 as x
    FROM ip_allowlist
    WHERE (is_global = true
           OR tenant_id = ${tenantId}
           OR (subject_type = 'user' AND subject_id = ${userId ?? null})
           OR (subject_type = 'child' AND subject_id = ${childId ?? null})
           OR (subject_type = 'integration' AND subject_id = ${integrationId ?? null}))
      AND (${ip}::inet <<= CAST(cidr as cidr))
    LIMIT 1`;
  return rows.length > 0;
}

function getClientIp(req: NextRequest): string {
  const xff = req.headers.get('x-forwarded-for');
  if (xff) {
    const ip = xff.split(',')[0].trim();
    return ip;
  }
  return req.headers.get('x-real-ip') || '0.0.0.0';
}

export async function POST(req: NextRequest, { params }: { params: { code: string } | Promise<{ code: string }> }) {
  const realParams = typeof params === 'object' && 'then' in params ? await params : params;
  const auth = req.headers.get('authorization') || '';
  const idempoKey = req.headers.get('idempotency-key') || undefined;
  const jwtSecret = process.env.JWT_SECRET || '';
  const kmsKey = process.env.CRYPTO_KEY || '';

  if (!auth.startsWith('Bearer ')) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  let claims: JwtClaims;
  try {
    claims = verifyJWT(auth.slice(7), jwtSecret);
  } catch {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const body = await req.json().catch(() => ({}));
  const actAsChildId: string | null = body.actAsChildId || claims.actAsChildId || null;
  const clientIp = getClientIp(req);

  try {
    const integRows = await prisma.$queryRaw<{ id: string; base_url: string; endpoints: unknown }[]>`
      SELECT id, base_url, endpoints FROM integrations WHERE code = ${realParams.code} AND active = true LIMIT 1`;
    if (integRows.length === 0) return NextResponse.json({ error: 'Unknown integration' }, { status: 404 });
    const integrationId = integRows[0].id;
    const baseUrl: string = integRows[0].base_url;
    const endpoints = integRows[0].endpoints as unknown;

    const credRows = await prisma.$queryRaw<{ id: string; credentials_encrypted: string; rate_card: unknown }[]>`
      SELECT id, credentials_encrypted, rate_card
      FROM integration_credentials
      WHERE integration_id = ${integrationId}
        AND tenant_id = ${claims.tenantId}
        AND COALESCE(child_id::text,'') = COALESCE(${actAsChildId}::text,'')
        AND status = 'active'
      LIMIT 1`;
    if (credRows.length === 0) return NextResponse.json({ error: 'Missing credentials' }, { status: 400 });
    const credRow = credRows[0];
    const credentials = decryptSecret(credRow.credentials_encrypted, kmsKey);

    const allowed = await isIpAllowed({
      tenantId: claims.tenantId,
      userId: claims.sub,
      childId: actAsChildId,
      integrationId: integrationId,
      ip: clientIp,
    });
    if (!allowed) {
      await prisma.$executeRaw`
        INSERT INTO audit_logs(tenant_id, actor_user_id, actor_role, action, target_type, target_id, metadata, ip)
  VALUES (${claims.tenantId}, ${claims.sub}, ${claims.role}, 'ip.rejected', 'integration', NULL, ${JSON.stringify({ code: realParams.code })}::jsonb, ${clientIp}::inet)`;
      return NextResponse.json({ error: 'IP not allowed' }, { status: 403 });
    }

    const walletRows = await prisma.$queryRaw<{ id: string; currency: 'USD'|'INR'; balance: Decimal }[]>`
      SELECT w.id, w.currency, w.balance
        FROM wallets w
       WHERE ((w.owner_type = 'child' AND w.owner_id = ${actAsChildId}::uuid)
           OR (w.owner_type = 'user' AND w.owner_id = ${claims.sub}::uuid))
       ORDER BY CASE WHEN w.owner_type = 'child' THEN 0 ELSE 1 END
       LIMIT 1`;
    if (walletRows.length === 0) return NextResponse.json({ error: 'Wallet not found' }, { status: 400 });
    const walletId = walletRows[0].id;
    const currency: 'USD'|'INR' = walletRows[0].currency;

    const planRows = await prisma.$queryRaw<{ base_per_hit_price: Decimal; per_hit_modifier: number }[]>`
      SELECT p.base_per_hit_price, p.per_hit_modifier
        FROM subscriptions s
        JOIN plans p ON p.id = s.plan_id
       WHERE s.tenant_id = ${claims.tenantId}
         AND COALESCE(s.child_id::text,'') = COALESCE(${actAsChildId}::text,'')
         AND s.status = 'active'
       LIMIT 1`;
    const rateCard = credRow.rate_card as Record<string, unknown> | null;
    const rate = rateCard && typeof rateCard['per_hit_price_cents'] === 'number' ? (rateCard['per_hit_price_cents'] as number) : null;
    const base = planRows.length ? Number(planRows[0].base_per_hit_price) : 0;
    const mult = planRows.length ? Number(planRows[0].per_hit_modifier) : 1;
    const pricePerHit = rate ?? Math.round(base * mult);

    let apiCallId: string | null = null;
    if (idempoKey) {
      const inserted = await prisma.$queryRaw<{ id: string }[]>`
        INSERT INTO api_calls (tenant_id, child_id, user_id, integration_id, integration_credential_id, wallet_id, client_ip, request, price_per_hit, idempotency_key, success)
        VALUES (${claims.tenantId}, ${actAsChildId}, ${claims.sub}, ${integrationId}, ${credRow.id}, ${walletId}, ${clientIp}, ${JSON.stringify(body)}::jsonb, ${pricePerHit}, ${idempoKey}, false)
        ON CONFLICT (tenant_id, child_id, idempotency_key) DO NOTHING
        RETURNING id`;
      if (inserted.length) apiCallId = inserted[0].id;
      if (!apiCallId) {
        const existing = await prisma.$queryRaw<{ id: string; success: boolean; response: unknown; status_code: number }[]>`
          SELECT id, success, response, status_code FROM api_calls
           WHERE tenant_id = ${claims.tenantId}
             AND COALESCE(child_id::text,'') = COALESCE(${actAsChildId}::text,'')
             AND idempotency_key = ${idempoKey}
           LIMIT 1`;
        if (existing.length) {
          const row = existing[0];
          if (row.success) return new NextResponse(JSON.stringify(row.response ?? {}), { status: row.status_code ?? 200 });
          return NextResponse.json({ error: 'Processing', retry: true }, { status: 409 });
        }
      }
    } else {
      const inserted = await prisma.$queryRaw<{ id: string }[]>`
        INSERT INTO api_calls (tenant_id, child_id, user_id, integration_id, integration_credential_id, wallet_id, client_ip, request, price_per_hit, success)
        VALUES (${claims.tenantId}, ${actAsChildId}, ${claims.sub}, ${integrationId}, ${credRow.id}, ${walletId}, ${clientIp}, ${JSON.stringify(body)}::jsonb, ${pricePerHit}, false)
        RETURNING id`;
      apiCallId = inserted[0].id;
    }

    const endpointsObj = endpoints as Record<string, unknown> | null;
    const endpoint: string = endpointsObj && typeof endpointsObj['perform'] === 'string' ? (endpointsObj['perform'] as string) : '/';
    const url = new URL(endpoint, baseUrl).toString();
    const extHeaders: Record<string, string> = {
      'content-type': 'application/json',
      'authorization': credentials.apiKey ? `Bearer ${credentials.apiKey}` : '',
    };

    const extResp = await fetch(url, {
      method: 'POST',
      headers: extHeaders,
      body: JSON.stringify(body.payload ?? body),
    });

    const respJson = await extResp.json().catch(() => ({}));
    const success = extResp.ok;

    try {
      await prisma.$transaction(async (tx) => {
        let billedAmount = 0;
        if (success && pricePerHit > 0) {
          const updated = await tx.$queryRaw<{ balance: Decimal }[]>`
            UPDATE wallets
               SET balance = balance - ${pricePerHit}::decimal, updated_at = now()
             WHERE id = ${walletId} AND balance >= ${pricePerHit}::decimal
             RETURNING balance`;
          if (updated.length === 0) {
            throw Object.assign(new Error('Insufficient funds'), { code: 'INSUFFICIENT' });
          }
          await tx.$executeRaw`
            INSERT INTO wallet_transactions (wallet_id, tx_type, amount, balance_after, currency, reference_type, reference_id, idempotency_key, metadata)
            VALUES (${walletId}, 'debit', ${pricePerHit}::decimal, ${updated[0].balance}, ${currency}, 'api_call', ${apiCallId}, ${idempoKey ?? null}, ${JSON.stringify({ code: realParams.code })}::jsonb)`;
          billedAmount = pricePerHit;
        }
        await tx.$executeRaw`
          UPDATE api_calls
             SET success = ${success}, response = ${JSON.stringify(respJson)}::jsonb, status_code = ${extResp.status}, billed_amount = ${billedAmount}
           WHERE id = ${apiCallId}`;
        await tx.$executeRaw`
          INSERT INTO audit_logs(tenant_id, actor_user_id, actor_role, action, target_type, target_id, metadata, ip)
          VALUES (${claims.tenantId}, ${claims.sub}, ${claims.role}, 'integration.call', 'integration', ${integrationId}, ${JSON.stringify({ apiCallId, code: realParams.code })}::jsonb, ${clientIp}::inet)`;
      });
    } catch (e) {
      if (typeof e === 'object' && e && 'code' in e && (e as { code?: string }).code === 'INSUFFICIENT') {
        await prisma.$executeRaw`
          UPDATE api_calls SET success=false, response=${JSON.stringify({ error: 'Insufficient funds' })}::jsonb, status_code=402 WHERE id=${apiCallId}`;
        return NextResponse.json({ error: 'Insufficient wallet balance' }, { status: 402 });
      }
      await prisma.$executeRaw`
        UPDATE api_calls SET success=false, response=${JSON.stringify({ error: 'Internal error' })}::jsonb, status_code=500 WHERE id=${apiCallId}`;
      return NextResponse.json({ error: 'Internal error' }, { status: 500 });
    }

    return new NextResponse(JSON.stringify(respJson), { status: extResp.status });
  } catch {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}

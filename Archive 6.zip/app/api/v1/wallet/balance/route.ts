
import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { validateApiKeyWithIp, logApiRequest } from '@/lib/api-auth';


export async function GET(req: NextRequest) {
    const startTime = Date.now();

    // Authenticate with IP validation
    const auth = await validateApiKeyWithIp(req);

    if (!auth.success) {
        if (auth.error === 'INVALID_KEY') {
            return NextResponse.json(
                { success: false, error: 'Unauthorized: Invalid or expired API Key' },
                { status: 401 }
            );
        }
        if (auth.error === 'IP_NOT_WHITELISTED') {
            return NextResponse.json(
                {
                    success: false,
                    error: 'Unauthorized IP. Please add your IP address to the whitelist in Developer Portal.',
                    clientIp: auth.clientIp
                },
                { status: 403 }
            );
        }
    }

    const { user, apiKey } = auth as { success: true; user: any; apiKey: any; clientIp: string };

    try {
        const wallet = await prisma.wallet.findUnique({
            where: { userId: user.id }
        });

        const balance = wallet ? Number(wallet.balance) : 0;
        const frozen = wallet ? Number(wallet.frozenBalance || 0) : 0;

        const response = {
            success: true,
            data: {
                balance,
                frozenBalance: frozen,
                currency: 'INR',
                userId: user.id
            }
        };

        // Log success
        const duration = Date.now() - startTime;
        await logApiRequest(apiKey.id, user.id, req, 200, duration);

        return NextResponse.json(response);
    } catch (error: any) {
        console.error('Wallet Balance API Error:', error);

        // Log error
        const duration = Date.now() - startTime;
        await logApiRequest(apiKey.id, user.id, req, 500, duration, error.message);

        return NextResponse.json(
            { success: false, error: 'Internal Server Error' },
            { status: 500 }
        );
    }
}

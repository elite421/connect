import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await authMiddleware(req, ['ADMIN', 'USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { id } = await params;

    const transaction = await prisma.payment.findUnique({
      where: { id },
      include: {
        subUser: true,
        beneficiary: true,
      },
    });

    if (!transaction) {
      return NextResponse.json(
        { error: 'Transaction not found' },
        { status: 404 }
      );
    }

    if (user.role === 'USER' && transaction.userId !== user.id) {
      return NextResponse.json(
        { error: 'Unauthorized - You can only view your own transactions' },
        { status: 403 }
      );
    }

    await logActivity({
      user,
      action: 'view_transactions',
      resource: 'transaction',
      resourceId: id,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: {
        ...transaction,
        amount: Number(transaction.amount),
      },
    });
  } catch (error) {
    console.error('GET /api/admin/transactions/[id] error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch transaction details' },
      { status: 500 }
    );
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { id } = await params;
    const body = await req.json();
    const { status, createdAt, updatedAt, failureReason, metadata } = body;

    const transaction = await prisma.payment.findUnique({
      where: { id },
    });

    if (!transaction) {
      return NextResponse.json(
        { error: 'Transaction not found' },
        { status: 404 }
      );
    }

    if (status && !['pending', 'processing', 'completed', 'failed', 'cancelled'].includes(status)) {
      return NextResponse.json(
        { error: 'Invalid status. Must be one of: pending, processing, completed, failed, cancelled' },
        { status: 400 }
      );
    }

    const updateData: any = {};

    if (status) updateData.status = status;
    if (createdAt) {
      const parsedDate = new Date(createdAt);
      if (isNaN(parsedDate.getTime())) {
        return NextResponse.json(
          { error: 'Invalid createdAt date format' },
          { status: 400 }
        );
      }
      updateData.createdAt = parsedDate;
    }
    if (updatedAt) {
      const parsedDate = new Date(updatedAt);
      if (isNaN(parsedDate.getTime())) {
        return NextResponse.json(
          { error: 'Invalid updatedAt date format' },
          { status: 400 }
        );
      }
      updateData.updatedAt = parsedDate;
    }
    if (failureReason !== undefined) {
      updateData.failureReason = failureReason;
    }
    if (metadata) {
      updateData.metadata = {
        ...(typeof transaction.metadata === 'object' && transaction.metadata ? transaction.metadata : {}),
        ...metadata,
      };
    }

    const updatedTransaction = await prisma.payment.update({
      where: { id },
      data: updateData,
      include: {
        subUser: true,
        beneficiary: true,
      },
    });

    await logActivity({
      user,
      action: 'update_transaction',
      resource: 'transaction',
      resourceId: id,
      metadata: {
        oldStatus: transaction.status,
        newStatus: status || transaction.status,
        fieldsUpdated: Object.keys(updateData),
      },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      message: 'Transaction updated successfully',
      data: {
        ...updatedTransaction,
        amount: Number(updatedTransaction.amount),
      },
    });
  } catch (error) {
    console.error('PATCH /api/admin/transactions/[id] error:', error);
    return NextResponse.json(
      { error: 'Failed to update transaction' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { id } = await params;

    const transaction = await prisma.payment.findUnique({
      where: { id },
    });

    if (!transaction) {
      return NextResponse.json(
        { error: 'Transaction not found' },
        { status: 404 }
      );
    }

    if (transaction.status === 'completed') {
      return NextResponse.json(
        { error: 'Cannot delete completed transactions' },
        { status: 400 }
      );
    }

    await prisma.payment.delete({
      where: { id },
    });

    await logActivity({
      user,
      action: 'delete_transaction',
      resource: 'transaction',
      resourceId: id,
      metadata: {
        deletedStatus: transaction.status,
        deletedAmount: Number(transaction.amount),
      },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      message: 'Transaction deleted successfully',
    });
  } catch (error) {
    console.error('DELETE /api/admin/transactions/[id] error:', error);
    return NextResponse.json(
      { error: 'Failed to delete transaction' },
      { status: 500 }
    );
  }
}

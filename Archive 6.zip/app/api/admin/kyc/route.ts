import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');
    const type = searchParams.get('type');

    const whereClause: any = {};
    if (status) whereClause.kycStatus = status;
    if (type === 'user') whereClause.subUserId = null;
    if (type === 'subuser') whereClause.subUserId = { not: null };

    const submissions = await prisma.kycSubmission.findMany({
      where: whereClause,
      include: {
        user: { select: { id: true, email: true, name: true } },
        subUser: { select: { id: true, email: true, name: true } },
      },
      orderBy: { submittedAt: 'desc' },
      take: 100,
    });

    return NextResponse.json({ success: true, data: serializeBigInt(submissions) });
  } catch (error) {
    console.error('GET /api/admin/kyc error:', error);
    return NextResponse.json({ error: 'Failed to fetch KYC submissions' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { id, status, rejectionReason } = body;

    if (!id || !status) {
      return NextResponse.json({ error: 'ID and status required' }, { status: 400 });
    }

    const updateData: any = {
      kycStatus: status,
    };

    if (status === 'approved') {
      updateData.verifiedAt = new Date();
      updateData.expiryDate = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);
    } else if (status === 'rejected') {
      updateData.rejectionReason = rejectionReason;
    }

    await prisma.kycSubmission.update({
      where: { id },
      data: serializeBigInt(updateData),
    });

    return NextResponse.json({ success: true, message: 'KYC status updated' });
  } catch (error) {
    console.error('PATCH /api/admin/kyc error:', error);
    return NextResponse.json({ error: 'Failed to update KYC status' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'ID required' }, { status: 400 });
    }

    await prisma.kycSubmission.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: 'KYC submission deleted' });
  } catch (error) {
    console.error('DELETE /api/admin/kyc error:', error);
    return NextResponse.json({ error: 'Failed to delete KYC submission' }, { status: 500 });
  }
}

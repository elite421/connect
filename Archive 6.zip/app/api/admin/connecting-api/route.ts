import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN']);
    if (user instanceof NextResponse) return user;

    try {
        const { searchParams } = new URL(req.url);
        const userId = searchParams.get('userId');

        // If userId is provided, return APIs for that user
        if (userId) {
            const apis = await prisma.customPaymentApi.findMany({
                where: { userId: userId, adminProvided: false },
                orderBy: { createdAt: 'desc' },
                include: {
                    user: {
                        select: {
                            name: true,
                            email: true
                        }
                    }
                }
            }) as any[]; // Cast to any to avoid temporary type inference issues during generation
            return NextResponse.json({ success: true, data: serializeBigInt(apis) });
        }

        // Otherwise return list of Users (standard limit to avoid performance issues)
        const users = await prisma.user.findMany({
            where: {
                role: 'USER' // Only show regular users, not admins/subusers
            },
            take: 100,
            orderBy: { createdAt: 'desc' },
            select: {
                id: true,
                name: true,
                email: true,
                username: true
            }
        });

        // Manual join to avoid "Unknown nested field" error if client is stale
        const userIds = users.map(u => u.id);
        const relatedApis = await prisma.customPaymentApi.findMany({
            where: {
                userId: { in: userIds },
                adminProvided: false
            },
            select: {
                id: true,
                userId: true
            }
        });

        const formattedUsers = users.map(user => {
            const userApis = relatedApis.filter(api => api.userId === user.id);
            return {
                ...user,
                customApis: userApis,
                _count: { apis: userApis.length }
            };
        });

        return NextResponse.json({ success: true, data: serializeBigInt(formattedUsers) });
    } catch (error) {
        console.error('GET /api/admin/connecting-api error:', error);
        return NextResponse.json({ error: 'Failed to fetch data' }, { status: 500 });
    }
}

export async function POST(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN']);
    if (user instanceof NextResponse) return user;

    try {
        const body = await req.json();
        const {
            userId,
            apiName,
            apiBaseUrl,
            apiEndpoint,
            apiMethod,
            authType,
            apiKey,
            apiSecret,
            authHeader,
            transactionCharge,
            transactionChargeType,
            isActive
        } = body;

        if (!userId || !apiName || !apiBaseUrl) {
            return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
        }

        const newApi = await prisma.customPaymentApi.create({
            data: {
                userId,
                apiName,
                apiBaseUrl,
                apiEndpoint: apiEndpoint || '',
                apiMethod: apiMethod || 'POST',
                authType: authType || 'bearer',
                apiKey,
                apiSecret,
                authHeader,
                transactionCharge: transactionCharge || 0,
                transactionChargeType: transactionChargeType || 'fixed',
                isActive: isActive ?? true,
                adminProvided: false, // User-specific API
            }
        });

        return NextResponse.json({ success: true, data: serializeBigInt(newApi) });
    } catch (error) {
        console.error('POST /api/admin/connecting-api error:', error);
        return NextResponse.json({ error: 'Failed to create API' }, { status: 500 });
    }
}

export async function PATCH(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN']);
    if (user instanceof NextResponse) return user;

    try {
        const body = await req.json();
        const {
            id,
            apiName,
            apiBaseUrl,
            apiEndpoint,
            apiMethod,
            authType,
            apiKey,
            apiSecret,
            authHeader,
            transactionCharge,
            transactionChargeType,
            isActive
        } = body;

        if (!id) {
            return NextResponse.json({ error: 'API ID is required' }, { status: 400 });
        }

        const dataToUpdate: any = {
            transactionCharge,
            transactionChargeType,
            isActive
        };

        // Only update these if provided (allow partial updates if needed, but UI sends all)
        if (apiName !== undefined) dataToUpdate.apiName = apiName;
        if (apiBaseUrl !== undefined) dataToUpdate.apiBaseUrl = apiBaseUrl;
        if (apiEndpoint !== undefined) dataToUpdate.apiEndpoint = apiEndpoint;
        if (apiMethod !== undefined) dataToUpdate.apiMethod = apiMethod;
        if (authType !== undefined) dataToUpdate.authType = authType;
        if (apiKey !== undefined) dataToUpdate.apiKey = apiKey;
        if (apiSecret !== undefined) dataToUpdate.apiSecret = apiSecret;
        if (authHeader !== undefined) dataToUpdate.authHeader = authHeader;

        const updatedApi = await prisma.customPaymentApi.update({
            where: { id },
            data: serializeBigInt(dataToUpdate)
        });

        return NextResponse.json({ success: true, data: serializeBigInt(updatedApi) });
    } catch (error) {
        console.error('PATCH /api/admin/connecting-api error:', error);
        return NextResponse.json({ error: 'Failed to update API' }, { status: 500 });
    }
}

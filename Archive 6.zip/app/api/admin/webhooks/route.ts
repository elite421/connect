import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';



export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const offset = parseInt(searchParams.get('offset') || '0');
    const limit = parseInt(searchParams.get('limit') || '50');
    const search = searchParams.get('search') || '';
    const userId = searchParams.get('userId');

    let webhooks: unknown[];
    let total: string = '0';

    if (userId) {
      // Direct filtering by userId
      webhooks = await prisma.$queryRaw`
          SELECT w.*, u."name" as "userName", u."email" as "userEmail"
          FROM "WebhookConfig" w
          LEFT JOIN "User" u ON w."userId" = u."id"
          WHERE w."userId" = ${userId}
          ORDER BY w."createdAt" DESC
          LIMIT ${limit}
          OFFSET ${offset}
        `;

      const countResult: any[] = await prisma.$queryRaw`
          SELECT COUNT(*) as total FROM "WebhookConfig" w
          WHERE w."userId" = ${userId}
      `;
      total = countResult[0]?.total?.toString() || '0';

    } else {
      // Search behavior
      const searchPattern = search ? `%${search}%` : '';

      webhooks = search
        ? await prisma.$queryRaw`
          SELECT w.*, u."name" as "userName", u."email" as "userEmail"
          FROM "WebhookConfig" w
          LEFT JOIN "User" u ON w."userId" = u."id"
          WHERE u."email" ILIKE ${searchPattern} OR w."id" ILIKE ${searchPattern}
          ORDER BY w."createdAt" DESC
          LIMIT ${limit}
          OFFSET ${offset}
        `
        : await prisma.$queryRaw`
          SELECT w.*, u."name" as "userName", u."email" as "userEmail"
          FROM "WebhookConfig" w
          LEFT JOIN "User" u ON w."userId" = u."id"
          ORDER BY w."createdAt" DESC
          LIMIT ${limit}
          OFFSET ${offset}
        `;

      const countResult: any[] = search
        ? await prisma.$queryRaw`
          SELECT COUNT(*) as total FROM "WebhookConfig" w
          LEFT JOIN "User" u ON w."userId" = u."id"
          WHERE u."email" ILIKE ${searchPattern} OR w."id" ILIKE ${searchPattern}
        `
        : await prisma.$queryRaw`
          SELECT COUNT(*) as total FROM "WebhookConfig" w
        `;

      total = countResult[0]?.total?.toString() || '0';
    }

    return NextResponse.json({
      success: true,
      data: webhooks,
      pagination: {
        offset,
        limit,
        total: parseInt(total),
      },
    });
  } catch (error) {
    console.error('GET /api/admin/webhooks error:', error);
    return NextResponse.json({ error: 'Failed to fetch webhooks' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { id, isActive, events, retryCount, retryDelay } = body;

    // Note: Parameter name ID vs webhookId. Standardizing on 'id'.
    // Use 'id' to match other routes, but check body content.
    const targetId = id || body.webhookId;

    if (!targetId) {
      return NextResponse.json({ error: 'Webhook ID required' }, { status: 400 });
    }

    const updateData: any = {};
    if (isActive !== undefined) updateData.isActive = isActive;
    if (events !== undefined) updateData.events = events;
    if (retryCount !== undefined) updateData.retryCount = retryCount;
    if (retryDelay !== undefined) updateData.retryDelay = retryDelay;

    await prisma.webhookConfig.update({
      where: { id: targetId },
      data: updateData
    });

    return NextResponse.json({ success: true, message: 'Webhook updated' });
  } catch (error) {
    console.error('PATCH /api/admin/webhooks error:', error);
    return NextResponse.json({ error: 'Failed to update webhook' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const webhookId = searchParams.get('id') || searchParams.get('webhookId');

    if (!webhookId) {
      return NextResponse.json({ error: 'Webhook ID required' }, { status: 400 });
    }

    await prisma.webhookConfig.delete({
      where: { id: webhookId }
    });

    return NextResponse.json({ success: true, message: 'Webhook deleted' });
  } catch (error) {
    console.error('DELETE /api/admin/webhooks error:', error);
    return NextResponse.json({ error: 'Failed to delete webhook' }, { status: 500 });
  }
}

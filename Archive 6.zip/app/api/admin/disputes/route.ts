import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';

export async function PUT(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN']);
    if (user instanceof NextResponse) return user;

    try {
        const body = await req.json();
        const { id, status, adminComment } = body;

        if (!id || !status) {
            return NextResponse.json({ error: 'ID and status are required' }, { status: 400 });
        }

        if (!['OPEN', 'RESOLVED', 'REJECTED'].includes(status)) {
            return NextResponse.json({ error: 'Invalid status' }, { status: 400 });
        }

        await prisma.dispute.update({
            where: { id },
            data: {
                status,
                adminComment: adminComment || null,
                updatedAt: new Date()
            }
        });

        return NextResponse.json({ success: true, message: 'Dispute updated successfully' });
    } catch (error) {
        console.error('PUT /api/admin/disputes error:', error);
        return NextResponse.json({ error: 'Failed to update dispute' }, { status: 500 });
    }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';


export async function POST(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN']);
    if (user instanceof NextResponse) return user;

    try {
        const body = await req.json();
        const { userId, username, amount, type, description } = body;

        if ((!userId && !username) || !amount || !type) {
            return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
        }

        if (amount <= 0) {
            return NextResponse.json({ error: 'Amount must be greater than 0' }, { status: 400 });
        }

        if (!['CREDIT', 'DEBIT'].includes(type)) {
            return NextResponse.json({ error: 'Invalid transaction type' }, { status: 400 });
        }

        // Find user and wallet
        const targetUser = await prisma.user.findFirst({
            where: userId ? { id: userId } : { username },
            include: { wallet: true }
        });

        if (!targetUser) {
            return NextResponse.json({ error: 'User not found' }, { status: 404 });
        }

        if (!targetUser.wallet) {
            // Create wallet if not exists (should theoretically exist for all users)
            const newWallet = await prisma.wallet.create({
                data: { userId: targetUser.id }
            });
            targetUser.wallet = newWallet;
        }

        const amountInRupees = Number(amount);
        const walletId = targetUser.wallet!.id;

        await prisma.$transaction(async (tx) => {
            // Update wallet balance
            // For CREDIT, we increment balance
            // For DEBIT, we decrement balance
            let newBalance;

            if (type === 'CREDIT') {
                const updatedWallet = await tx.wallet.update({
                    where: { id: walletId },
                    data: { balance: { increment: amountInRupees } }
                });
                newBalance = updatedWallet.balance;
            } else {
                // Check sufficient balance for debit
                const currentBalance = targetUser.wallet!.balance;

                if (currentBalance < amountInRupees) {
                    throw new Error('Insufficient wallet balance');
                }
                const updatedWallet = await tx.wallet.update({
                    where: { id: walletId },
                    data: { balance: { decrement: amountInRupees } }
                });
                newBalance = updatedWallet.balance;
            }

            // Record transaction
            await tx.walletTransactionLocal.create({
                data: {
                    walletId,
                    userId: targetUser.id,
                    type: type === 'CREDIT' ? 'ADMIN_CREDIT' : 'ADMIN_DEBIT',
                    amount: amountInRupees,
                    balanceAfter: newBalance,
                    description: description || `Admin ${type} adjustment`,
                    referenceType: 'admin_adjustment',
                }
            });
        });

        return NextResponse.json({ success: true, message: 'Wallet updated successfully' });
    } catch (error: any) {
        console.error('POST /api/admin/wallet/manage error:', error);
        return NextResponse.json({ error: error.message || 'Failed to update wallet' }, { status: 500 });
    }
}

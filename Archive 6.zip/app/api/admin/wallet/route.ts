import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { toRupees } from '@/lib/money';

const serializeWallet = (wallet: any) => ({
  ...wallet,
  balance: wallet.balance,
  frozenBalance: wallet.frozenBalance || 0,
});

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'userId required' }, { status: 400 });
    }

    const wallet = await prisma.wallet.findUnique({
      where: { userId },
      include: { user: { select: { id: true, username: true, email: true } } },
    });

    if (!wallet) {
      return NextResponse.json({ error: 'Wallet not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: serializeWallet(wallet),
    });
  } catch (error) {
    console.error('GET /api/admin/wallet error:', error);
    return NextResponse.json({ error: 'Failed to fetch wallet' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { userId, action, amount } = body;

    if (!userId || !action || !amount) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    if (!['add', 'deduct', 'set'].includes(action)) {
      return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }

    let wallet = await prisma.wallet.findUnique({
      where: { userId },
    });

    if (!wallet) {
      wallet = await prisma.wallet.create({
        data: {
          userId,
          balance: 0,
        },
      });
    }

    const amountNum = Number(amount);
    let newBalance = Number(wallet.balance);

    if (action === 'add') {
      newBalance = Number(wallet.balance) + amountNum;
    } else if (action === 'deduct') {
      if (Number(wallet.balance) < amountNum) {
        return NextResponse.json({ error: 'Insufficient wallet balance' }, { status: 400 });
      }
      newBalance = Number(wallet.balance) - amountNum;
    } else if (action === 'set') {
      newBalance = amountNum;
    }

    const updatedWallet = await prisma.wallet.update({
      where: { userId },
      data: { balance: newBalance },
      include: { user: { select: { id: true, username: true, email: true } } },
    });

    return NextResponse.json({
      success: true,
      data: serializeWallet(updatedWallet),
    });
  } catch (error) {
    console.error('PATCH /api/admin/wallet error:', error);
    return NextResponse.json({ error: 'Failed to update wallet' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const wallets = await prisma.wallet.findMany({
      skip: offset,
      take: limit,
      include: { user: { select: { id: true, username: true, email: true } } },
      orderBy: { createdAt: 'desc' },
    });

    const total = await prisma.wallet.count();

    return NextResponse.json({
      success: true,
      data: wallets.map(serializeWallet),
      pagination: {
        limit,
        offset,
        total,
        hasMore: offset + limit < total,
      },
    });
  } catch (error) {
    console.error('POST /api/admin/wallet error:', error);
    return NextResponse.json({ error: 'Failed to fetch wallets' }, { status: 500 });
  }
}

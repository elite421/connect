import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress } from '@/lib/middleware';

import { callPayoutApi } from '@/lib/payout-integration';
import { callFingrowPayoutApi } from '@/lib/fingrow-integration';
import { logActivity } from '@/lib/audit';
import { getUserAgent } from '@/lib/middleware';
import { toRupees } from '@/lib/money';

export async function POST(req: NextRequest) {
    const admin = await authMiddleware(req, ['ADMIN']);
    if (admin instanceof NextResponse) return admin;

    try {
        const body = await req.json();
        const { id, action } = body; // action: 'approve' or 'reject'

        if (!id || !action) {
            return NextResponse.json({ error: 'Transaction ID and action required' }, { status: 400 });
        }

        // Find the transaction
        const transaction = await prisma.payOutTransaction.findUnique({
            where: { id },
        });

        if (!transaction) {
            return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
        }

        if (transaction.status !== 'pending_approval') {
            return NextResponse.json({
                error: `Cannot ${action} transaction with status: ${transaction.status}`
            }, { status: 400 });
        }

        // REJECT PATH
        if (action === 'reject') {
            const responseData = (transaction.responseData as any) || {};
            const chargeInfo = responseData?.chargeInfo || { totalDebit: String(transaction.amount) };

            // Allow totalDebit to be parsed as Number directly from the string
            const totalDebit = Number(chargeInfo.totalDebit || String(transaction.amount));

            // Refund the frozen amount back to balance
            await prisma.wallet.update({
                where: { userId: transaction.userId },
                data: {
                    balance: { increment: totalDebit },
                    frozenBalance: { decrement: totalDebit },
                },
            });

            const updatedTransaction = await prisma.payOutTransaction.update({
                where: { id },
                data: {
                    status: 'rejected',
                    responseData: {
                        ...(typeof transaction.responseData === 'object' ? transaction.responseData : {}),
                        rejectedAt: new Date().toISOString(),
                        rejectedBy: admin.id,
                        message: 'Payout rejected by admin. Amount refunded to wallet.',
                    },
                },
            });

            await logActivity({
                user: admin,
                action: 'reject_payment',
                resource: 'payout',
                resourceId: id,
                metadata: { previousStatus: 'pending_approval', newStatus: 'rejected' },
                ipAddress: extractIpAddress(req),
                userAgent: getUserAgent(req),
            });

            return NextResponse.json({
                success: true,
                message: 'Payout rejected',
                data: updatedTransaction,
            });
        }

        // APPROVE PATH
        if (action === 'approve') {
            // Get user's wallet
            const wallet = await prisma.wallet.findUnique({
                where: { userId: transaction.userId },
            });

            if (!wallet) {
                return NextResponse.json({ error: 'User wallet not found' }, { status: 404 });
            }

            // Get charge info from stored data
            const responseData = transaction.responseData as any;
            const chargeInfo = responseData?.chargeInfo || { totalDebit: String(transaction.amount) };
            const totalDebit = Number(chargeInfo.totalDebit || String(transaction.amount));

            // Verify frozen balance (optional sanity check)
            // We assume the amount was frozen when the transaction was created.
            // If we enforce (wallet.frozenBalance < totalDebit), we might block fixes for inconsistent states.
            // So we proceed, blindly trusting the flow to correct itself via decrement.

            // Find the appropriate API
            // transaction.amount is Number (Rupees)
            const payoutAmountMajor = Number(transaction.amount);

            let gatewayResponse: any;
            let usedGateway = 'custom';

            // Try custom payment APIs (user-level first, then admin-level)
            let customApi = await prisma.customPaymentApi.findFirst({
                where: {
                    userId: transaction.userId,
                    adminProvided: false,
                    isActive: true,
                },
                orderBy: { isDefault: 'desc' },
            });

            if (!customApi) {
                customApi = await prisma.customPaymentApi.findFirst({
                    where: {
                        adminProvided: true,
                        isDefault: true,
                        isActive: true,
                    },
                    orderBy: { createdAt: 'desc' },
                });
            }

            if (customApi) {
                const result = await callPayoutApi(transaction.userId, {
                    amount: payoutAmountMajor,
                    beneficiaryName: transaction.beneficiaryName || '',
                    beneficiaryAccount: transaction.beneficiaryAccount ?? undefined,
                    beneficiaryIfsc: transaction.beneficiaryIfsc ?? undefined,
                    beneficiaryVpa: transaction.beneficiaryVpa ?? undefined,
                    transferMode: transaction.transferMode,
                    merchantTransactionId: String(transaction.id),
                    metadata: { localTransactionId: transaction.id },
                });
                gatewayResponse = result.response;
                usedGateway = `custom (${customApi.apiName})`;
            } else {
                // Try Fingrow API
                const fingrowResult = await callFingrowPayoutApi(transaction.userId, {
                    amount: payoutAmountMajor,
                    beneficiaryName: transaction.beneficiaryName || '',
                    beneficiaryAccount: transaction.beneficiaryAccount ?? undefined,
                    beneficiaryIfsc: transaction.beneficiaryIfsc ?? undefined,
                    beneficiaryVpa: transaction.beneficiaryVpa ?? undefined,
                    transferMode: transaction.transferMode,
                    merchantTransactionId: String(transaction.id),
                    ipAddress: transaction.ipAddress ?? undefined,
                });

                gatewayResponse = fingrowResult.response;
                usedGateway = 'fingrow';

                if (!fingrowResult.response.success && fingrowResult.response.raw?.error === 'NO_API_CONFIGURED') {
                    const result = await callPayoutApi(transaction.userId, {
                        amount: payoutAmountMajor,
                        beneficiaryName: transaction.beneficiaryName || '',
                        beneficiaryAccount: transaction.beneficiaryAccount ?? undefined,
                        beneficiaryIfsc: transaction.beneficiaryIfsc ?? undefined,
                        beneficiaryVpa: transaction.beneficiaryVpa ?? undefined,
                        transferMode: transaction.transferMode,
                        merchantTransactionId: String(transaction.id),
                        metadata: { localTransactionId: transaction.id },
                    });
                    gatewayResponse = result.response;
                    usedGateway = 'default';
                }
            }

            // Handle failed gateway response
            if (!gatewayResponse.success && gatewayResponse.status === 'failed') {
                // Refund the frozen amount since the gateway failed
                await prisma.wallet.update({
                    where: { userId: transaction.userId },
                    data: {
                        balance: { increment: totalDebit },
                        frozenBalance: { decrement: totalDebit },
                    },
                });

                const failedTransaction = await prisma.payOutTransaction.update({
                    where: { id },
                    data: {
                        status: 'failed',
                        responseData: {
                            success: false,
                            message: gatewayResponse.message || 'Gateway rejected the payout request',
                            error: gatewayResponse.message,
                            raw: gatewayResponse.raw,
                            approvedBy: admin.id,
                            approvedAt: new Date().toISOString(),
                            gateway: usedGateway,
                            refunded: true,
                        },
                    },
                });

                return NextResponse.json({
                    success: false,
                    error: gatewayResponse.message || 'Payout request failed at gateway',
                    data: failedTransaction,
                    gatewayResponse,
                }, { status: 400 });
            }

            // Consuming frozen balance (it was already deducted from main balance)
            await prisma.wallet.update({
                where: { userId: transaction.userId },
                data: {
                    frozenBalance: { decrement: totalDebit }
                },
            });

            // Update transaction with success
            const updatedTransaction = await prisma.payOutTransaction.update({
                where: { id },
                data: {
                    status: gatewayResponse.status || 'processing',
                    utrNumber: gatewayResponse.utrNumber ? String(gatewayResponse.utrNumber) : null,
                    externalTransactionId: gatewayResponse.externalTransactionId ? String(gatewayResponse.externalTransactionId) : null,
                    responseData: {
                        success: gatewayResponse.success,
                        message: gatewayResponse.message,
                        utr: gatewayResponse.utrNumber,
                        externalTransactionId: gatewayResponse.externalTransactionId,
                        raw: gatewayResponse.raw,
                        approvedBy: admin.id,
                        approvedAt: new Date().toISOString(),
                        gateway: usedGateway,
                        chargeInfo,
                    },
                },
            });

            await logActivity({
                user: admin,
                action: 'approve_payment',
                resource: 'payout',
                resourceId: id,
                metadata: {
                    previousStatus: 'pending_approval',
                    newStatus: gatewayResponse.status,
                    gateway: usedGateway,
                    utr: gatewayResponse.utrNumber,
                },
                ipAddress: extractIpAddress(req),
                userAgent: getUserAgent(req),
            });

            return NextResponse.json({
                success: true,
                message: 'Payout approved and processed',
                data: updatedTransaction,
                gateway: usedGateway,
                gatewayResponse,
            });
        }

        return NextResponse.json({ error: 'Invalid action. Use "approve" or "reject"' }, { status: 400 });
    } catch (error) {
        console.error('POST /api/admin/payouts/approve error:', error);
        return NextResponse.json({ error: 'Failed to process approval' }, { status: 500 });
    }
}

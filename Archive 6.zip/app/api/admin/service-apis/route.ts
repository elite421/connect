import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const serviceId = searchParams.get('serviceId');
    const offset = parseInt(searchParams.get('offset') || '0');
    const limit = parseInt(searchParams.get('limit') || '50');

    if (!serviceId) {
      return NextResponse.json({ error: 'Service ID is required' }, { status: 400 });
    }

    const [serviceApis, total] = await Promise.all([
      prisma.serviceApi.findMany({
        where: { serviceId },
        include: {
          api: true,
          customApi: true,
          service: true,
        },
        orderBy: { priority: 'asc' },
        skip: offset,
        take: limit,
      }),
      prisma.serviceApi.count({ where: { serviceId } }),
    ]);

    return NextResponse.json({
      success: true,
      data: serviceApis,
      pagination: { offset, limit, total },
    });
  } catch (error) {
    console.error('GET /api/admin/service-apis error:', error);
    return NextResponse.json({ error: 'Failed to fetch service APIs' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { serviceId, apiId, customApiId, isDefault, priority } = await req.json();

    if (!serviceId) {
      return NextResponse.json(
        { error: 'Service ID is required' },
        { status: 400 }
      );
    }

    if (!apiId && !customApiId) {
      return NextResponse.json(
        { error: 'Either API Gateway ID or Custom API ID is required' },
        { status: 400 }
      );
    }

    // Check for existing link
    let existingLink = null;
    if (apiId) {
      existingLink = await prisma.serviceApi.findUnique({
        where: {
          serviceId_apiId: { serviceId, apiId },
        },
      });
    } else if (customApiId) {
      existingLink = await prisma.serviceApi.findFirst({
        where: {
          serviceId,
          customApiId,
        },
      });
    }

    if (existingLink) {
      return NextResponse.json(
        { error: 'This API is already linked to the service' },
        { status: 400 }
      );
    }

    if (isDefault) {
      await prisma.serviceApi.updateMany({
        where: { serviceId },
        data: { isDefault: false },
      });
    }

    const serviceApi = await prisma.serviceApi.create({
      data: {
        serviceId,
        apiId,
        customApiId,
        isDefault: isDefault || false,
        priority: priority || 1,
      },
      include: {
        api: true,
        customApi: true,
        service: true,
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(serviceApi) }, { status: 201 });
  } catch (error: any) {
    if (error.code === 'P2002') {
      return NextResponse.json(
        { error: 'This API is already linked to the service' },
        { status: 400 }
      );
    }
    console.error('POST /api/admin/service-apis error:', error);
    return NextResponse.json({ error: 'Failed to link API to service' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { serviceApiId, isDefault, priority } = await req.json();

    if (!serviceApiId) {
      return NextResponse.json({ error: 'Service API ID is required' }, { status: 400 });
    }

    const serviceApi = await prisma.serviceApi.findUnique({
      where: { id: serviceApiId },
    });

    if (!serviceApi) {
      return NextResponse.json({ error: 'Service API not found' }, { status: 404 });
    }

    if (isDefault) {
      await prisma.serviceApi.updateMany({
        where: { serviceId: serviceApi.serviceId },
        data: { isDefault: false },
      });
    }

    const updated = await prisma.serviceApi.update({
      where: { id: serviceApiId },
      data: {
        ...(isDefault !== undefined && { isDefault }),
        ...(priority && { priority }),
      },
      include: {
        api: true,
        service: true,
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(updated) });
  } catch (error) {
    console.error('PATCH /api/admin/service-apis error:', error);
    return NextResponse.json({ error: 'Failed to update service API' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const serviceApiId = searchParams.get('serviceApiId');

    if (!serviceApiId) {
      return NextResponse.json({ error: 'Service API ID is required' }, { status: 400 });
    }

    await prisma.serviceApi.delete({
      where: { id: serviceApiId },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/admin/service-apis error:', error);
    return NextResponse.json({ error: 'Failed to delete service API' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    let config = await prisma.systemConfiguration.findFirst();

    if (!config) {
      config = await prisma.systemConfiguration.create({
        data: {
          globalTransactionCharge: 0,
          globalTransactionChargeType: 'fixed',
          globalGstPercentage: 18,
          enableGst: true,
        },
      });
    }

    return NextResponse.json({
      success: true,
      data: config,
    });
  } catch (error) {
    console.error('GET /api/admin/system-config error:', error);
    return NextResponse.json({ error: 'Failed to fetch system configuration' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const {
      globalTransactionCharge,
      globalTransactionChargeType,
      globalGstPercentage,
      enableGst,
    } = await req.json();

    let config = await prisma.systemConfiguration.findFirst();

    if (!config) {
      config = await prisma.systemConfiguration.create({
        data: {
          globalTransactionCharge: globalTransactionCharge || 0,
          globalTransactionChargeType: globalTransactionChargeType || 'fixed',
          globalGstPercentage: globalGstPercentage || 18,
          enableGst: enableGst !== false,
        },
      });
    } else {
      config = await prisma.systemConfiguration.update({
        where: { id: config.id },
        data: {
          ...(globalTransactionCharge !== undefined && { globalTransactionCharge }),
          ...(globalTransactionChargeType && { globalTransactionChargeType }),
          ...(globalGstPercentage !== undefined && { globalGstPercentage }),
          ...(enableGst !== undefined && { enableGst }),
        },
      });
    }

    return NextResponse.json({
      success: true,
      data: config,
    });
  } catch (error) {
    console.error('PATCH /api/admin/system-config error:', error);
    return NextResponse.json({ error: 'Failed to update system configuration' }, { status: 500 });
  }
}

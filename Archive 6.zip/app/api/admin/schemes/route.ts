import { NextRequest, NextResponse } from 'next/server';
import { authMiddleware } from '@/lib/middleware';
import prisma from '@/lib/prisma';
import { safeJson } from '@/lib/safe-json';


export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const [schemes, total] = await Promise.all([
      prisma.paymentScheme.findMany({
        // @ts-ignore
        where: searchParams.get('type') ? { schemeType: searchParams.get('type') as string } : undefined,
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.paymentScheme.count({
        // @ts-ignore
        where: searchParams.get('type') ? { schemeType: searchParams.get('type') as string } : undefined,
      }),
    ]);

    // Fetch services and APIs for linking display
    const [services, apis] = await Promise.all([
      prisma.service.findMany({ where: { isActive: true }, select: { id: true, code: true, name: true } }),
      prisma.customPaymentApi.findMany({ where: { isActive: true }, select: { id: true, apiName: true, adminProvided: true } }),
    ]);

    return safeJson({
      success: true,
      data: schemes,
      services,
      apis,
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/admin/schemes error:', error);
    return safeJson({ error: 'Failed to fetch schemes' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      name,
      description,
      code,
      payoutCharge,
      payinCharge,
      settlementCharge,
      chargeType,
      minCharge,
      maxCharge,
      gstPercentage,
      applyGst,
      minTransactionAmount,
      maxTransactionAmount,
      apiId,
      serviceId,
    } = body;

    if (!name || !code) {
      return NextResponse.json({ error: 'Name and code required' }, { status: 400 });
    }

    // Check for existing code
    const existing = await prisma.paymentScheme.findUnique({ where: { code } });
    if (existing) {
      return NextResponse.json({ error: 'Scheme code already exists' }, { status: 400 });
    }

    const scheme = await prisma.paymentScheme.create({
      data: {
        name,
        description,
        code,
        payoutCharge: payoutCharge ? parseFloat(payoutCharge) : 0,
        payinCharge: payinCharge ? parseFloat(payinCharge) : 0,
        settlementCharge: settlementCharge ? parseFloat(settlementCharge) : 0,
        chargeType: chargeType || 'fixed',
        minCharge: minCharge ? parseFloat(minCharge) : 0,
        maxCharge: maxCharge ? parseFloat(maxCharge) : 0,
        gstPercentage: gstPercentage !== undefined ? parseFloat(gstPercentage) : 18,
        applyGst: applyGst !== undefined ? applyGst : true,
        // Safe validation
        minTransactionAmount: minTransactionAmount ? parseFloat(minTransactionAmount) : 100,
        maxTransactionAmount: maxTransactionAmount ? parseFloat(maxTransactionAmount) : 100000,
        apiId: apiId || null,
        serviceId: serviceId || null,
        isActive: true,
        // @ts-ignore
        schemeType: body.schemeType || 'BOTH',
      },
    });

    return safeJson({ success: true, data: scheme }, { status: 201 });
  } catch (error: any) {
    console.error('POST /api/admin/schemes error:', error);
    // Handle Prisma unique constraint error
    if (error.code === 'P2002') {
      return safeJson({ error: 'Scheme code already exists' }, { status: 400 });
    }
    return safeJson({ error: error.message || 'Failed to create scheme' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      schemeId,
      name,
      description,
      code,
      payoutCharge,
      payinCharge,
      settlementCharge,
      chargeType,
      minCharge,
      maxCharge,
      gstPercentage,
      applyGst,
      minTransactionAmount,
      maxTransactionAmount,
      apiId,
      serviceId,
      isActive,
    } = body;

    if (!schemeId) {
      return safeJson({ error: 'Scheme ID required' }, { status: 400 });
    }

    const updateData: any = {};
    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (code !== undefined) updateData.code = code;
    if (payoutCharge !== undefined) updateData.payoutCharge = parseFloat(payoutCharge);
    if (payinCharge !== undefined) updateData.payinCharge = parseFloat(payinCharge);
    if (settlementCharge !== undefined) updateData.settlementCharge = parseFloat(settlementCharge);
    if (chargeType !== undefined) updateData.chargeType = chargeType;
    if (minCharge !== undefined) updateData.minCharge = parseFloat(minCharge);
    if (maxCharge !== undefined) updateData.maxCharge = parseFloat(maxCharge);
    if (gstPercentage !== undefined) updateData.gstPercentage = parseFloat(gstPercentage);
    if (applyGst !== undefined) updateData.applyGst = applyGst;
    if (minTransactionAmount !== undefined) updateData.minTransactionAmount = parseFloat(minTransactionAmount);
    if (maxTransactionAmount !== undefined) updateData.maxTransactionAmount = parseFloat(maxTransactionAmount);
    if (apiId !== undefined) updateData.apiId = apiId || null;
    if (serviceId !== undefined) updateData.serviceId = serviceId || null;
    if (isActive !== undefined) updateData.isActive = isActive;
    // @ts-ignore
    if (body.schemeType !== undefined) updateData.schemeType = body.schemeType;

    const scheme = await prisma.paymentScheme.update({
      where: { id: schemeId },
      data: updateData,
    });

    return safeJson({ success: true, data: scheme });
  } catch (error: any) {
    console.error('PATCH /api/admin/schemes error:', error);
    if (error.code === 'P2002') {
      return safeJson({ error: 'Scheme code already exists' }, { status: 400 });
    }
    return safeJson({ error: error.message || 'Failed to update scheme' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const schemeId = searchParams.get('schemeId');

    if (!schemeId) {
      return NextResponse.json({ error: 'Scheme ID required' }, { status: 400 });
    }

    await prisma.paymentScheme.delete({
      where: { id: schemeId },
    });

    return safeJson({ success: true, message: 'Scheme deleted' });
  } catch (error) {
    console.error('DELETE /api/admin/schemes error:', error);
    return safeJson({ error: 'Failed to delete scheme' }, { status: 500 });
  }
}

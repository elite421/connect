import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { Prisma } from '@prisma/client';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const timeRange = searchParams.get('range') || '30d';

    let startDate = new Date(0);
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    if (timeRange === 'today') {
      startDate = todayStart;
    } else if (timeRange === 'yesterday') {
      const yesterday = new Date(todayStart);
      yesterday.setDate(yesterday.getDate() - 1);
      startDate = yesterday;
      // For yesterday, we also need an end date
    } else if (timeRange === 'this_week') {
      const dayOfWeek = now.getDay();
      const diff = now.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1); // Monday
      startDate = new Date(now.getFullYear(), now.getMonth(), diff);
    } else if (timeRange === 'this_month') {
      startDate = new Date(now.getFullYear(), now.getMonth(), 1);
    } else if (timeRange === 'previous_month') {
      const prevMonth = now.getMonth() === 0 ? 11 : now.getMonth() - 1;
      const prevYear = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();
      startDate = new Date(prevYear, prevMonth, 1);
    } else if (timeRange === '7d') {
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else if (timeRange === '30d') {
      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    }

    // Calculate end date for specific ranges
    let endDate = new Date();
    if (timeRange === 'yesterday') {
      endDate = todayStart;
    } else if (timeRange === 'previous_month') {
      endDate = new Date(now.getFullYear(), now.getMonth(), 1);
    }

    const dateFilter = timeRange === 'all'
      ? {}
      : { createdAt: { gte: startDate, ...(timeRange === 'yesterday' || timeRange === 'previous_month' ? { lt: endDate } : {}) } };

    const [
      totalUsers,
      totalSubUsers,
      activeUsers,
      totalApis,
      onlineApis,
      totalPayins,
      completedPayins,
      totalPayouts,
      completedPayouts,
      payinRevenue,
      payoutRevenue,
      monthlyPayins,
      monthlyPayouts,
      activityLogs,
      // New: Profit and GST calculations from successful payouts
      payoutChargeData,
    ] = await Promise.all([
      prisma.user.count({
        where: timeRange === 'all' ? {} : { createdAt: { gte: startDate } }
      }),
      prisma.subUser.count({
        where: timeRange === 'all' ? {} : { createdAt: { gte: startDate } }
      }),
      prisma.user.count({
        where: {
          activityLogs: {
            some: {
              createdAt: { gte: startDate },
            },
          },
        },
      }),
      prisma.userApi.count(),
      prisma.userApi.count({ where: { isActive: true } }),
      prisma.payInTransaction.count({
        where: timeRange === 'all' ? {} : dateFilter
      }),
      prisma.payInTransaction.count({
        where: {
          status: { in: ['completed', 'success'] },
          ...(timeRange === 'all' ? {} : dateFilter)
        }
      }),
      prisma.payOutTransaction.count({
        where: timeRange === 'all' ? {} : dateFilter
      }),
      prisma.payOutTransaction.count({
        where: {
          status: { in: ['completed', 'success'] },
          ...(timeRange === 'all' ? {} : dateFilter)
        }
      }),
      prisma.payInTransaction.aggregate({
        _sum: { amount: true },
        where: {
          status: { in: ['completed', 'success'] },
          ...(timeRange === 'all' ? {} : dateFilter)
        },
      }),
      prisma.payOutTransaction.aggregate({
        _sum: { amount: true },
        where: {
          status: { in: ['completed', 'success'] },
          ...(timeRange === 'all' ? {} : dateFilter)
        },
      }),
      prisma.payInTransaction.count({
        where: timeRange === 'all' ? {} : dateFilter,
      }),
      prisma.payOutTransaction.count({
        where: timeRange === 'all' ? {} : dateFilter,
      }),
      prisma.activityLog.findMany({
        orderBy: { createdAt: 'desc' },
        take: 10,
        select: {
          id: true,
          action: true,
          resource: true,
          status: true,
          user: { select: { email: true } },
          createdAt: true,
        },
      }),
      // Get charge data from wallet transactions for profit calculation - ONLY from successful payouts
      prisma.$queryRaw`
        SELECT COALESCE(SUM(wt."chargeAmount"), 0) as total_charges
        FROM "WalletTransactionLocal" wt
        INNER JOIN "PayOutTransaction" pt ON wt."referenceId" = pt."id"
        WHERE wt."type" = 'PAYOUT_DEBIT'
        AND wt."referenceType" = 'payout'
        AND pt."status" IN ('success', 'completed', 'SUCCESS', 'COMPLETED')
        ${timeRange === 'all' ? Prisma.empty : Prisma.sql`AND wt."createdAt" >= ${startDate}`}
      `,
    ]);

    // Calculate profit and GST from charges - only from successful transactions
    const chargeResult = payoutChargeData as any[];
    const totalChargesCollected = Number(chargeResult[0]?.total_charges || 0); // Already in Rupees


    // Get default payment scheme for GST percentage
    const defaultScheme = await prisma.paymentScheme.findFirst({
      where: { isActive: true },
      select: { gstPercentage: true, applyGst: true }
    });

    const gstPercentage = defaultScheme?.gstPercentage ? Number(defaultScheme.gstPercentage) : 18;
    const applyGst = defaultScheme?.applyGst !== false;

    // Calculate GST amount from total charges
    // Assumption: chargeAmount captured in wallet transactions is EXCLUSIVE of GST
    // Therefore, gstAmount = baseCharges * gstRate (when GST applies)
    let gstAmount = 0;
    const baseCharges = totalChargesCollected;

    if (applyGst && baseCharges > 0) {
      gstAmount = baseCharges * (gstPercentage / 100);
    }

    // Net Profit = Charges + GST (total collected amount)
    const netProfit = baseCharges + gstAmount;

    const totalTransactions = totalPayins + totalPayouts;
    const completedTransactions = completedPayins + completedPayouts;
    const totalRevenueAmount = (Number(payinRevenue._sum.amount || 0) + Number(payoutRevenue._sum.amount || 0));
    const monthlyTransactionsCount = monthlyPayins + monthlyPayouts;

    const analyticsData = {
      kpis: {
        totalUsers,
        totalSubUsers,
        activeUsers,
        userEngagementRate: totalUsers > 0 ? ((activeUsers / totalUsers) * 100).toFixed(2) : '0',
      },
      apis: {
        total: totalApis,
        online: onlineApis,
        offline: totalApis - onlineApis,
        healthPercentage: totalApis > 0 ? ((onlineApis / totalApis) * 100).toFixed(2) : '0',
      },
      transactions: {
        total: totalTransactions,
        completed: completedTransactions,
        pending: totalTransactions - completedTransactions,
        failed: 0,
        successRate: totalTransactions > 0 ? ((completedTransactions / totalTransactions) * 100).toFixed(2) : '0',
      },
      revenue: {
        total: totalRevenueAmount,
        monthlyCount: monthlyTransactionsCount,
        averageTransaction: totalTransactions > 0 ? (totalRevenueAmount / totalTransactions) : 0,
      },
      // New profit and GST data
      profit: {
        totalChargesCollected: totalChargesCollected,
        gstAmount: gstAmount,
        gstPercentage,
        netProfit: netProfit,
        applyGst,
      },
      recentActivity: activityLogs,
      dateRange: {
        start: startDate.toISOString(),
        end: endDate.toISOString(),
        filter: timeRange,
      }
    };

    await logActivity({
      user,
      action: 'view_analytics',
      resource: 'analytics',
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return safeJson({ success: true, data: analyticsData });
  } catch (error) {
    console.error('GET /api/admin/analytics error:', error);
    return safeJson({ error: 'Failed to fetch analytics' }, { status: 500 });
  }
}

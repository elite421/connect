import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { gatewayId, config } = await req.json();

    if (!gatewayId) {
      return NextResponse.json({ error: 'Gateway ID required' }, { status: 400 });
    }

    const gateway = await prisma.paymentGateway.findUnique({
      where: { id: gatewayId },
    });

    if (!gateway) {
      return NextResponse.json({ error: 'Gateway not found' }, { status: 404 });
    }

    const requestConfig = {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    };

    if (gateway.authType === 'bearer') {
      const authToken = config.apiKey || config.apiToken || gateway.apiKey;
      if (authToken) {
        (requestConfig.headers as Record<string, string>)['Authorization'] = `Bearer ${authToken}`;
      }
    } else if (gateway.authType === 'api-key') {
      const apiKey = config.apiKey || gateway.apiKey;
      if (apiKey) {
        (requestConfig.headers as Record<string, string>)['X-API-Key'] = apiKey;
      }
    } else if (gateway.authType === 'basic') {
      const apiKey = config.apiKey || gateway.apiKey;
      const apiSecret = config.apiSecret || gateway.apiSecret;
      if (apiKey && apiSecret) {
        const credentials = Buffer.from(`${apiKey}:${apiSecret}`).toString('base64');
        (requestConfig.headers as Record<string, string>)['Authorization'] = `Basic ${credentials}`;
      }
    }

    const testUrl = `${gateway.apiEndpoint}/health` || gateway.apiEndpoint;

    const response = await fetch(testUrl, requestConfig);
    const isSuccess = response.ok || response.status < 500;

    await logActivity({
      user,
      action: 'test_gateway_connection',
      resource: 'gateway',
      resourceId: gatewayId,
      metadata: { provider: gateway.provider, statusCode: response.status },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    if (isSuccess) {
      return NextResponse.json({
        success: true,
        message: 'Connection test successful',
        status: response.status,
      });
    } else {
      return NextResponse.json({
        success: false,
        error: `Connection failed with status ${response.status}`,
      }, { status: 400 });
    }
  } catch (error: any) {
    console.error('POST /api/admin/test-gateway-connection error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to test gateway connection' },
      { status: 500 }
    );
  }
}

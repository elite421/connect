import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';
import ApiDocumentationParser from '@/lib/ai-documentation-parser';
import GatewayIntegrationService from '@/lib/gateway-integration';

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || (session.user as any)?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { documentationId, userId, gatewayName, baseUrl, credentials, fieldMappings } = await req.json();

    if (!documentationId || !userId || !gatewayName || !baseUrl || !credentials) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const documentation = await prisma.apiDocumentation.findUnique({
      where: { id: documentationId },
    });

    if (!documentation || !documentation.parsedSchema) {
      return NextResponse.json(
        { error: 'Documentation not found or not parsed' },
        { status: 404 }
      );
    }

    const gatewayCode = gatewayName.toLowerCase().replace(/\s+/g, '_');

    const integrationService = new GatewayIntegrationService(prisma);
    
    const schema = documentation.parsedSchema as any;
    const parser = new ApiDocumentationParser();
    
    const extractedMappings = fieldMappings || await parser.extractFieldMappings(schema, [
      'amount',
      'utrNumber',
      'status',
      'transactionId',
      'customerName',
      'customerEmail',
    ]);

    const integration = await integrationService.registerGateway(
      userId,
      gatewayName,
      gatewayCode,
      baseUrl,
      credentials,
      {
        ...schema,
        fieldMappings: extractedMappings,
      } as any,
      true
    );

    const generateCode = async () => {
      try {
        return await parser.generateIntegrationCode(schema, gatewayName);
      } catch (error) {
        console.error('Failed to generate integration code:', error);
        return null;
      }
    };

    const integrationCode = await generateCode();

    await prisma.apiDocumentation.update({
      where: { id: documentationId },
      data: {
        status: 'approved',
        approvedBy: (session.user as any).id,
        approvedAt: new Date(),
      },
    });

    for (const endpoint of schema.endpoints || []) {
      await prisma.gatewayEndpointConfig.create({
        data: {
          integrationId: integration.id,
          endpoint: endpoint.path,
          method: endpoint.method,
          description: endpoint.description,
          requestSchema: endpoint.requestBody,
          responseSchema: endpoint.responses,
          mappings: extractedMappings,
        },
      });
    }

    return NextResponse.json({
      success: true,
      integration,
      integrationCode,
      fieldMappings: extractedMappings,
    });
  } catch (error: any) {
    console.error('Gateway integration error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to create gateway integration' },
      { status: 500 }
    );
  }
}

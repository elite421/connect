import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';
import ApiDocumentationParser from '@/lib/ai-documentation-parser';

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session || (session.user as any)?.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const formData = await req.formData();
    const file = formData.get('file') as File;
    const documentType = formData.get('documentType') as string;
    const name = formData.get('name') as string;
    const description = formData.get('description') as string;

    if (!file || !documentType || !name) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const fileContent = await file.text();
    const parser = new ApiDocumentationParser();
    let parseResult;

    if (documentType === 'openapi') {
      parseResult = await parser.parseOpenAPISpec(fileContent);
    } else if (documentType === 'json') {
      parseResult = await parser.parseJsonSchema(fileContent);
    } else if (documentType === 'markdown' || documentType === 'md') {
      parseResult = await parser.parseMarkdownDocumentation(fileContent);
    } else {
      return NextResponse.json(
        { error: 'Unsupported document type' },
        { status: 400 }
      );
    }

    if (!parseResult.success) {
      return NextResponse.json(
        { error: parseResult.error },
        { status: 400 }
      );
    }

    const enhancedSchema = await parser.validateAndEnhanceSchema(parseResult.schema!);

    const documentation = await prisma.apiDocumentation.create({
      data: {
        name,
        description,
        documentType,
        documentContent: fileContent.substring(0, 1000000),
        fileName: file.name,
        parsedSchema: enhancedSchema as any,
        status: 'pending',
      },
    });

    return NextResponse.json({
      success: true,
      data: documentation,
      schema: enhancedSchema,
    });
  } catch (error: any) {
    console.error('Documentation upload error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to process documentation' },
      { status: 500 }
    );
  }
}

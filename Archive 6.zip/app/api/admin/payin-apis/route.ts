import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN']);
    if (user instanceof NextResponse) return user;

    try {
        const payinApis = await prisma.customPaymentApi.findMany({
            where: {
                apiType: 'PAYIN',
                adminProvided: true,
            },
            orderBy: { createdAt: 'desc' },
        });

        return NextResponse.json({ success: true, data: serializeBigInt(payinApis) });
    } catch (error) {
        console.error('GET /api/admin/payin-apis error:', error);
        return NextResponse.json({ error: 'Failed to fetch PayIn APIs' }, { status: 500 });
    }
}

export async function POST(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN']);
    if (user instanceof NextResponse) return user;

    try {
        const body = await req.json();
        const {
            apiName,
            apiBaseUrl,
            apiEndpoint,
            apiMethod = 'POST',
            authType = 'bearer',
            apiKey,
            apiSecret,
            authHeader,
            isActive = true,
            isDefault = false,
            allowedModes = ['UPI', 'CARD', 'NETBANKING', 'WALLET'],
            requestFormat,
            responseFormat,
        } = body;

        if (!apiName || !apiBaseUrl || !apiEndpoint) {
            return NextResponse.json({ error: 'API Name, Base URL, and Endpoint are required' }, { status: 400 });
        }

        // If setting as default, unset other defaults
        if (isDefault) {
            await prisma.customPaymentApi.updateMany({
                where: {
                    apiType: 'PAYIN',
                    adminProvided: true,
                    isDefault: true,
                },
                data: { isDefault: false },
            });
        }

        const newApi = await prisma.customPaymentApi.create({
            data: {
                apiName,
                apiBaseUrl,
                apiEndpoint,
                apiMethod,
                authType,
                apiKey,
                apiSecret,
                authHeader,
                isActive,
                isDefault,
                adminProvided: true,
                apiType: 'PAYIN',
                allowedModes,
                requestFormat: requestFormat || null,
                responseFormat: responseFormat || null,
            },
        });

        return NextResponse.json({ success: true, data: serializeBigInt(newApi), message: 'PayIn API created successfully' }, { status: 201 });
    } catch (error) {
        console.error('POST /api/admin/payin-apis error:', error);
        return NextResponse.json({ error: 'Failed to create PayIn API' }, { status: 500 });
    }
}

export async function PUT(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN']);
    if (user instanceof NextResponse) return user;

    try {
        const body = await req.json();
        const { id, ...updateData } = body;

        if (!id) {
            return NextResponse.json({ error: 'API ID is required' }, { status: 400 });
        }

        // Check if API exists
        const existingApi = await prisma.customPaymentApi.findUnique({
            where: { id },
        });

        if (!existingApi) {
            return NextResponse.json({ error: 'PayIn API not found' }, { status: 404 });
        }

        // If setting as default, unset other defaults
        if (updateData.isDefault) {
            await prisma.customPaymentApi.updateMany({
                where: {
                    apiType: 'PAYIN',
                    adminProvided: true,
                    isDefault: true,
                    NOT: { id },
                },
                data: { isDefault: false },
            });
        }

        const updatedApi = await prisma.customPaymentApi.update({
            where: { id },
            data: {
                ...updateData,
                updatedAt: new Date(),
            },
        });

        return NextResponse.json({ success: true, data: serializeBigInt(updatedApi), message: 'PayIn API updated successfully' });
    } catch (error) {
        console.error('PUT /api/admin/payin-apis error:', error);
        return NextResponse.json({ error: 'Failed to update PayIn API' }, { status: 500 });
    }
}

export async function DELETE(req: NextRequest) {
    const user = await authMiddleware(req, ['ADMIN']);
    if (user instanceof NextResponse) return user;

    try {
        const { searchParams } = new URL(req.url);
        const id = searchParams.get('id');

        if (!id) {
            return NextResponse.json({ error: 'API ID is required' }, { status: 400 });
        }

        await prisma.customPaymentApi.delete({
            where: { id },
        });

        return NextResponse.json({ success: true, message: 'PayIn API deleted successfully' });
    } catch (error) {
        console.error('DELETE /api/admin/payin-apis error:', error);
        return NextResponse.json({ error: 'Failed to delete PayIn API' }, { status: 500 });
    }
}

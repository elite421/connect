import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import crypto from 'crypto';

function generateApiKey(): string {
  return 'sk_' + crypto.randomBytes(32).toString('hex');
}

export async function GET(req: NextRequest) {
  const admin = await authMiddleware(req, ['ADMIN']);
  if (admin instanceof NextResponse) return admin;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const userId = searchParams.get('userId');
    const isActive = searchParams.get('isActive');

    const whereClause: any = {};

    if (userId) {
      whereClause.userId = userId;
    }

    if (isActive !== null && isActive !== undefined) {
      whereClause.isActive = isActive === 'true';
    }

    const apiKeys = await prisma.apiKey.findMany({
      where: whereClause,
      skip: offset,
      take: limit,
      select: {
        id: true,
        name: true,
        userId: true,
        isActive: true,
        permissions: true,
        lastUsedAt: true,
        lastUsedIp: true,
        requestCount: true,
        expiresAt: true,
        createdAt: true,
        user: { select: { username: true, email: true } },
        keyAccess: { select: { action: true, reason: true, createdAt: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    const total = await prisma.apiKey.count({
      where: whereClause,
    });

    return NextResponse.json({
      success: true,
      data: apiKeys,
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/admin/api-keys error:', error);
    return NextResponse.json({ error: 'Failed to fetch API keys' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const admin = await authMiddleware(req, ['ADMIN']);
  if (admin instanceof NextResponse) return admin;

  try {
    const body = await req.json();
    // Check if this is a "search" POST from legacy code (unlikely, but handling just in case?)
    // No, we are defining this as Create now.

    const { userId, name, permissions = ['read', 'write'], expiresAt } = body;

    if (!userId || !name) {
      return NextResponse.json({ error: 'User ID and Key Name are required' }, { status: 400 });
    }

    const keyValue = generateApiKey();

    const apiKey = await prisma.apiKey.create({
      data: {
        userId,
        name,
        keyValue,
        permissions,
        expiresAt: expiresAt ? new Date(expiresAt) : null,
      },
      select: {
        id: true,
        name: true,
        keyValue: true, // Return key value once
        isActive: true,
        permissions: true,
        expiresAt: true,
        createdAt: true,
      },
    });

    return NextResponse.json(
      {
        success: true,
        data: apiKey,
        message: 'API Key created. Save it now.',
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('POST /api/admin/api-keys error:', error);
    return NextResponse.json({ error: 'Failed to create API key' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const admin = await authMiddleware(req, ['ADMIN']);
  if (admin instanceof NextResponse) return admin;

  try {
    const body = await req.json();
    const { apiKeyId, action, reason } = body;

    if (!apiKeyId || !action) {
      return NextResponse.json({ error: 'API key ID and action required' }, { status: 400 });
    }

    if (!['revoke', 'deny', 'suspend', 'activate'].includes(action)) {
      return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }

    const apiKey = await prisma.apiKey.findUnique({
      where: { id: apiKeyId },
    });

    if (!apiKey) {
      return NextResponse.json({ error: 'API key not found' }, { status: 404 });
    }

    if (action === 'revoke' || action === 'deny' || action === 'suspend') {
      await prisma.apiKeyAccess.create({
        data: {
          apiKeyId,
          userId: apiKey.userId,
          action,
          reason: reason || null,
          revokedBy: admin.id,
        },
      });

      await prisma.apiKey.update({
        where: { id: apiKeyId },
        data: { isActive: false },
      });
    } else if (action === 'activate') {
      await prisma.apiKey.update({
        where: { id: apiKeyId },
        data: { isActive: true },
      });
    }

    return NextResponse.json({
      success: true,
      message: `API key ${action === 'activate' ? 'activated' : 'deactivated'}`,
    });
  } catch (error) {
    console.error('PATCH /api/admin/api-keys error:', error);
    return NextResponse.json({ error: 'Failed to update API key' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const admin = await authMiddleware(req, ['ADMIN']);
  if (admin instanceof NextResponse) return admin;

  try {
    const { searchParams } = new URL(req.url);
    const apiKeyId = searchParams.get('id');

    if (!apiKeyId) {
      return NextResponse.json({ error: 'API key ID required' }, { status: 400 });
    }

    const apiKey = await prisma.apiKey.findUnique({
      where: { id: apiKeyId },
    });

    if (!apiKey) {
      return NextResponse.json({ error: 'API key not found' }, { status: 404 });
    }

    await prisma.apiKey.delete({
      where: { id: apiKeyId },
    });

    return NextResponse.json({
      success: true,
      message: 'API key deleted',
    });
  } catch (error) {
    console.error('DELETE /api/admin/api-keys error:', error);
    return NextResponse.json({ error: 'Failed to delete API key' }, { status: 500 });
  }
}

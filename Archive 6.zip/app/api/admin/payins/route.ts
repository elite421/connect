import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { applyPaymentScheme } from '@/lib/payment-scheme';
import { toRupees } from '@/lib/money';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const payins: any[] = await prisma.$queryRaw`
      SELECT p.*, u."name" as "userName", u."email" as "userEmail"
      FROM "PayInTransaction" p
      LEFT JOIN "User" u ON p."userId" = u."id"
      ORDER BY p."createdAt" DESC
      LIMIT 500
    `;

    // Convert Paise to Rupees for display
    const formattedPayins = payins.map(p => ({
      ...p,
      amount: toRupees(p.amount),
    }));

    const stats: any[] = await prisma.$queryRaw`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'success' THEN 1 END) as success,
        COUNT(CASE WHEN status = 'pending' OR status = 'processing' THEN 1 END) as pending,
        COALESCE(SUM(amount), 0) as "totalAmount"
      FROM "PayInTransaction"
    `;

    const statsData = stats[0] || {};
    // statsData.totalAmount is in Paise (BigInt)

    return safeJson({
      success: true,
      data: formattedPayins,
      stats: {
        total: Number(statsData.total || 0),
        success: Number(statsData.success || 0),
        pending: Number(statsData.pending || 0),
        totalAmount: Number(statsData.totalAmount || 0), // Already float in db
      }
    });
  } catch (error) {
    console.error('GET /api/admin/payins error:', error);
    return safeJson({ error: 'Failed to fetch payins' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { id, status, utrNumber } = body;

    if (!id || !status) {
      return safeJson({ error: 'ID and status required' }, { status: 400 });
    }

    // Fetch the PayIn transaction
    const payin = await prisma.payInTransaction.findUnique({
      where: { id },
      include: { user: true }
    });

    if (!payin) {
      return safeJson({ error: 'PayIn transaction not found' }, { status: 404 });
    }

    // Check for duplicate UTR if admin is providing/changing one
    if (utrNumber && utrNumber !== payin.utrNumber) {
      const existingPayin = await prisma.payInTransaction.findFirst({
        where: {
          utrNumber,
          id: { not: id } // Exclude current transaction
        }
      });

      if (existingPayin) {
        return safeJson({
          error: 'UTR number already exists. Please use a unique transaction reference.'
        }, { status: 400 });
      }
    }

    const previousStatus = payin.status;

    // If admin approves (status changes to 'success' or 'completed'), credit the wallet
    if ((status === 'success' || status === 'completed') && previousStatus !== 'success' && previousStatus !== 'completed') {

      const amount = Number(payin.amount);

      // Calculate charges (admin scheme charges for PayIn)
      const schemeInfo = await applyPaymentScheme(payin.userId, 'payin');
      const userChargeConfig = schemeInfo.userCharge ? Math.abs(Number(schemeInfo.userCharge)) : 0;
      const schemeCharge = Math.abs(schemeInfo.schemeCharge || 0);
      const totalBaseCharge = userChargeConfig + schemeCharge; // Rupees
      const gstPercentage = schemeInfo.gstPercentage ?? 18;
      const applyGst = schemeInfo.applyGst !== false;
      const gstAmount = applyGst ? (schemeInfo.gstAmount ?? (totalBaseCharge * (gstPercentage / 100))) : 0;
      const totalChargeWithGst = totalBaseCharge + gstAmount; // Rupees

      // Net amount to credit (amount - charges - GST)
      const netCreditAmount = amount - totalChargeWithGst;

      if (netCreditAmount <= 0) {
        return safeJson({
          error: 'Transaction charges exceed PayIn amount. Cannot credit wallet.',
          chargeAmount: totalChargeWithGst,
          payinAmount: amount
        }, { status: 400 });
      }

      // Use transaction to ensure atomicity
      const result = await prisma.$transaction(async (tx) => {
        // Update the PayIn transaction status
        await tx.payInTransaction.update({
          where: { id },
          data: {
            status,
            utrNumber: utrNumber || payin.utrNumber,
            updatedAt: new Date(),
          }
        });

        // Get or create wallet
        let wallet = await tx.wallet.findUnique({
          where: { userId: payin.userId }
        });

        if (!wallet) {
          wallet = await tx.wallet.create({
            data: {
              userId: payin.userId,
              balance: netCreditAmount,
            }
          });
        } else {
          wallet = await tx.wallet.update({
            where: { userId: payin.userId },
            data: {
              balance: Number(wallet.balance) + netCreditAmount
            }
          });
        }

        // Record wallet transaction
        await tx.walletTransactionLocal.create({
          data: {
            walletId: wallet.id,
            userId: payin.userId,
            type: 'PAYIN_CREDIT',
            amount: netCreditAmount,
            balanceAfter: wallet.balance,
            chargeAmount: totalChargeWithGst,
            referenceType: 'payin',
            referenceId: payin.id,
            description: `PayIn credited (UTR: ${utrNumber || payin.utrNumber || 'N/A'})`,
            metadata: {
              payinId: payin.id,
              originalAmount: amount,
              baseCharge: totalBaseCharge,
              gstAmount,
              chargeDeducted: totalChargeWithGst,
              netCredited: netCreditAmount,
              approvedBy: user.id,
              utrNumber: utrNumber || payin.utrNumber,
              paymentMethod: payin.paymentMethod,
            }
          }
        });

        return { wallet, netCreditAmount, chargeAmount: totalChargeWithGst };
      });

      console.log('PayIn approved:', {
        payinId: id,
        userId: payin.userId,
        originalAmount: amount,
        chargeDeducted: result.chargeAmount,
        netCredited: result.netCreditAmount,
        newBalance: result.wallet.balance
      });

      return safeJson({
        success: true,
        message: 'PayIn approved and wallet credited',
        walletCredited: result.netCreditAmount,
        chargeDeducted: result.chargeAmount,
        newBalance: result.wallet.balance
      });
    }

    // For non-approval status updates (reject, etc.)
    await prisma.payInTransaction.update({
      where: { id },
      data: {
        status,
        utrNumber: utrNumber || payin.utrNumber,
        updatedAt: new Date(),
      }
    });

    return safeJson({ success: true, message: 'PayIn status updated' });
  } catch (error) {
    console.error('PATCH /api/admin/payins error:', error);
    return safeJson({ error: 'Failed to update payin' }, { status: 500 });
  }
}

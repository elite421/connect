import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress } from '@/lib/middleware';
import { applyPaymentScheme } from '@/lib/payment-scheme';
import { logActivity } from '@/lib/audit';
import { getUserAgent } from '@/lib/middleware';
import { callPayoutApi, resolvePayoutApiForUser } from '@/lib/payout-integration';
import { callFingrowPayoutApi } from '@/lib/fingrow-integration';
import { toRupees } from '@/lib/money';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const transactions = await prisma.$queryRaw`
      SELECT * FROM "PayOutTransaction" 
      WHERE "userId" = ${user.id} 
      ORDER BY "createdAt" DESC 
      LIMIT 100
    `;

    const normalizedTransactions = (transactions as any[]).map((t: any) => ({
      ...t,
      amount: t.amount,
    }));

    return safeJson({ success: true, data: normalizedTransactions });
  } catch (error) {
    console.error('GET /api/user/payout error:', error);
    return safeJson({ error: 'Failed to fetch payouts' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { amount, beneficiaryName, beneficiaryAccount, beneficiaryIfsc, beneficiaryVpa, transferMode } = body;

    // Validate request amount (Rupees)
    if (!amount || amount <= 0) {
      return safeJson({ error: 'Invalid amount' }, { status: 400 });
    }

    if (!beneficiaryName || !transferMode) {
      return safeJson({ error: 'Missing required fields' }, { status: 400 });
    }

    if (transferMode === 'upi' && (!beneficiaryVpa || beneficiaryVpa.trim() === '')) {
      return safeJson({ error: 'VPA required for UPI transfers' }, { status: 400 });
    }

    if (transferMode !== 'upi' && (!beneficiaryAccount || beneficiaryAccount.trim() === '' || !beneficiaryIfsc || beneficiaryIfsc.trim() === '')) {
      return safeJson({ error: 'Account number and IFSC code required for bank transfers' }, { status: 400 });
    }

    const ipAddress = extractIpAddress(req);

    const currentUser = await prisma.user.findUnique({ where: { id: user.id } });
    if (!currentUser) {
      return safeJson({ error: 'User not found' }, { status: 404 });
    }

    // Amount is already in Rupees
    const amountFloat = Number(amount);

    // Resolve API early to determine charges
    const resolvedApi = await resolvePayoutApiForUser(user.id, transferMode);
    let customCharge: { amount: number; type: string } | null = null;

    if (resolvedApi && resolvedApi.transactionCharge && resolvedApi.transactionCharge > 0) {
      customCharge = {
        amount: Number(resolvedApi.transactionCharge),
        type: resolvedApi.transactionChargeType || 'fixed'
      };
    }

    // Calculate charges (admin scheme + user-specific charge + custom API override)
    // applyPaymentScheme returns charges in Rupees and includes GST details
    const schemeInfo = await applyPaymentScheme(user.id, 'payout', customCharge);
    const userCharge = currentUser.transactionCharge ? Math.abs(Number(currentUser.transactionCharge)) : 0;
    const schemeCharge = Math.abs(schemeInfo.schemeCharge || 0);
    const gstAmount = Math.abs(Number(schemeInfo.gstAmount || 0));

    // Total Charge in Rupees including GST
    const totalCharge = Math.abs(Number(schemeInfo.totalChargeWithGst ?? (userCharge + schemeCharge + gstAmount)));

    // Total Debit in Rupees
    const totalDebit = amountFloat + totalCharge;

    // Check wallet balance
    let wallet = await prisma.wallet.findUnique({
      where: { userId: user.id },
    });

    if (!wallet) {
      wallet = await prisma.wallet.create({
        data: {
          userId: user.id,
          balance: 0,
          frozenBalance: 0,
        },
      });
    }

    // Direct float balance check
    const walletBalance = toRupees(wallet.balance);
    const walletFrozen = toRupees(wallet.frozenBalance);

    // Check available balance
    const availableBalance = walletBalance - walletFrozen;

    if (availableBalance < totalDebit) {
      return safeJson({
        error: 'Insufficient wallet balance',
        requiredBalance: toRupees(totalDebit),
        currentBalance: toRupees(availableBalance),
        frozenBalance: toRupees(walletFrozen),
      }, { status: 400 });
    }

    // DEDUCT the amount immediately (no freezing - automatic processing)
    const newBalance = walletBalance - totalDebit;

    wallet = await prisma.wallet.update({
      where: { userId: user.id },
      data: {
        balance: newBalance,
      },
    });

    const gstPercentage = schemeInfo.gstPercentage || 18;

    console.log(`[Payout] Amount Flow Debug:`);
    console.log(`  - User entered: ₹${amount}`);
    console.log(`  - Amount (Rupees): ${amountFloat}`);
    console.log(`  - Scheme Charge: ₹${schemeCharge}`);
    console.log(`  - User Charge: ₹${userCharge}`);
    console.log(`  - Total Charge: ₹${totalCharge}`);
    console.log(`  - GST Amount: ₹${gstAmount}`);
    console.log(`  - Total Debit (Rupees): ${totalDebit}`);
    console.log(`  - Amount to API (Rupees): ${amount}`);

    // Create initial transaction with 'processing' status
    const transaction = await prisma.payOutTransaction.create({
      data: {
        userId: user.id,
        amount: amountFloat,
        beneficiaryName,
        beneficiaryAccount: beneficiaryAccount || null,
        beneficiaryIfsc: beneficiaryIfsc || null,
        beneficiaryVpa: beneficiaryVpa || null,
        transferMode,
        ipAddress,
        status: 'processing',
        responseData: {
          chargeInfo: {
            userCharge,
            schemeCharge,
            totalCharge: totalCharge,
            gstAmount,
            gstPercentage,
            totalDebit: totalDebit,
            amountToApi: amount,
          },
          message: 'Processing payout...',
        },
      },
    });

    // Record wallet debit transaction
    await prisma.walletTransactionLocal.create({
      data: {
        walletId: wallet.id,
        userId: user.id,
        type: 'PAYOUT_DEBIT',
        amount: totalDebit,
        balanceAfter: newBalance,
        chargeAmount: totalCharge,
        referenceType: 'payout',
        referenceId: transaction.id,
        description: `Payout to ${beneficiaryName} via ${transferMode.toUpperCase()}`,
        metadata: {
          beneficiaryName,
          beneficiaryAccount,
          beneficiaryVpa,
          transferMode,
        },
      },
    });

    // Call payment gateway API automatically
    // Gateway expects Rupees
    const payoutAmountMajor = Number(amount);

    let gatewayResponse: any;
    let usedGateway = 'custom';

    try {
      // Try custom payment APIs
      let customApi = await prisma.customPaymentApi.findFirst({
        where: {
          userId: user.id,
          adminProvided: false,
          isActive: true,
        },
        orderBy: { isDefault: 'desc' },
      });

      if (!customApi) {
        customApi = await prisma.customPaymentApi.findFirst({
          where: {
            adminProvided: true,
            isDefault: true,
            isActive: true,
          },
          orderBy: { createdAt: 'desc' },
        });
      }

      if (customApi) {
        const result = await callPayoutApi(user.id, {
          amount: payoutAmountMajor,
          beneficiaryName: beneficiaryName || '',
          beneficiaryAccount: beneficiaryAccount ?? undefined,
          beneficiaryIfsc: beneficiaryIfsc ?? undefined,
          beneficiaryVpa: beneficiaryVpa ?? undefined,
          transferMode,
          merchantTransactionId: String(transaction.id),
          metadata: { localTransactionId: transaction.id },
          userEmail: currentUser.email || undefined,
          userPhone: currentUser.phone || undefined,
        });
        gatewayResponse = result.response;
        usedGateway = `custom (${customApi.apiName})`;
      } else {
        // Try Fingrow API
        const fingrowResult = await callFingrowPayoutApi(user.id, {
          amount: payoutAmountMajor,
          beneficiaryName: beneficiaryName || '',
          beneficiaryAccount: beneficiaryAccount ?? undefined,
          beneficiaryIfsc: beneficiaryIfsc ?? undefined,
          beneficiaryVpa: beneficiaryVpa ?? undefined,
          transferMode,
          merchantTransactionId: String(transaction.id),
          ipAddress: ipAddress ?? undefined,
        });

        gatewayResponse = fingrowResult.response;
        usedGateway = 'fingrow';

        if (!fingrowResult.response.success && fingrowResult.response.raw?.error === 'NO_API_CONFIGURED') {
          const result = await callPayoutApi(user.id, {
            amount: payoutAmountMajor,
            beneficiaryName: beneficiaryName || '',
            beneficiaryAccount: beneficiaryAccount ?? undefined,
            beneficiaryIfsc: beneficiaryIfsc ?? undefined,
            beneficiaryVpa: beneficiaryVpa ?? undefined,
            transferMode,
            merchantTransactionId: String(transaction.id),
            metadata: { localTransactionId: transaction.id },
            userEmail: currentUser.email || undefined,
            userPhone: currentUser.phone || undefined,
          });
          gatewayResponse = result.response;
          usedGateway = 'default';
        }
      }
    } catch (apiError: any) {
      console.error('Gateway API error:', apiError);
      gatewayResponse = {
        success: false,
        status: 'failed',
        message: apiError?.message || 'Gateway connection failed',
        raw: { error: apiError?.message }
      };
    }

    // Handle gateway response
    if (!gatewayResponse.success && gatewayResponse.status === 'failed') {
      // REFUND: Credit the amount back to wallet

      // Re-fetch wallet for safety (concurrency) but usually okay
      // wallet.balance is stale? Ideally use atomic increment.

      await prisma.wallet.update({
        where: { userId: user.id },
        data: {
          balance: { increment: totalDebit as any },
        },
      });

      // Get updated wallet for logging
      const updatedWallet = await prisma.wallet.findUnique({ where: { userId: user.id } });
      const refundedBalance = toRupees(updatedWallet?.balance);

      // Record refund transaction
      await prisma.walletTransactionLocal.create({
        data: {
          walletId: wallet.id,
          userId: user.id,
          type: 'PAYOUT_REFUND',
          amount: totalDebit,
          balanceAfter: refundedBalance,
          chargeAmount: totalCharge,
          referenceType: 'payout',
          referenceId: transaction.id,
          description: `Refund: Payout failed - ${gatewayResponse.message || 'Gateway error'}`,
          metadata: {
            reason: 'gateway_failed',
            gatewayMessage: gatewayResponse.message,
            gateway: usedGateway,
          },
        },
      });

      // Update transaction to failed
      const failedTransaction = await prisma.payOutTransaction.update({
        where: { id: transaction.id },
        data: {
          status: 'failed',
          responseData: {
            success: false,
            message: gatewayResponse.message || 'Gateway rejected the payout request',
            error: gatewayResponse.message,
            raw: gatewayResponse.raw,
            gateway: usedGateway,
            refunded: true,
            chargeInfo: {
              userCharge,
              schemeCharge,
              totalCharge: totalCharge,
              totalDebit: totalDebit,
            },
          },
        },
      });

      // Log the activity
      try {
        await logActivity({
          user,
          action: 'payout_failed',
          resource: 'payout',
          resourceId: transaction.id,
          metadata: {
            amount,
            transferMode,
            gateway: usedGateway,
            error: gatewayResponse.message,
            refunded: true,
          },
          ipAddress,
          userAgent: getUserAgent(req),
        });
      } catch (e) {
        console.warn('Failed to log activity:', e);
      }

      return safeJson({
        success: false,
        error: gatewayResponse.message || 'Payout failed',
        data: failedTransaction,
        message: 'Payout failed. Amount has been refunded to your wallet.',
        refunded: true,
        charges: {
          userCharge,
          schemeCharge,
          totalCharge: totalCharge,
          chargeAmount: totalCharge,
          totalDebit: totalDebit,
        },
        gatewayResponse: {
          status: gatewayResponse.status,
          message: gatewayResponse.message,
        },
      }, { status: 400 });
    }

    // SUCCESS: Update transaction with gateway response
    const updatedTransaction = await prisma.payOutTransaction.update({
      where: { id: transaction.id },
      data: {
        status: gatewayResponse.status || 'processing',
        utrNumber: gatewayResponse.utrNumber ? String(gatewayResponse.utrNumber) : null,
        externalTransactionId: gatewayResponse.externalTransactionId ? String(gatewayResponse.externalTransactionId) : null,
        responseData: {
          success: gatewayResponse.success,
          message: gatewayResponse.message,
          utr: gatewayResponse.utrNumber,
          externalTransactionId: gatewayResponse.externalTransactionId,
          raw: gatewayResponse.raw,
          gateway: usedGateway,
          chargeInfo: {
            userCharge,
            schemeCharge,
            totalCharge: totalCharge,
            totalDebit: totalDebit,
          },
        },
      },
    });

    // Log the activity
    try {
      await logActivity({
        user,
        action: 'create_payment',
        resource: 'payout',
        resourceId: transaction.id,
        metadata: {
          amount,
          transferMode,
          beneficiaryAccount,
          beneficiaryIfsc,
          beneficiaryVpa,
          totalCharge: totalCharge,
          userCharge,
          schemeCharge,
          status: gatewayResponse.status,
          gateway: usedGateway,
        },
        ipAddress,
        userAgent: getUserAgent(req),
      });
    } catch (e) {
      console.warn('Failed to log activity for payout:', e);
    }

    return safeJson({
      success: true,
      data: updatedTransaction,
      message: 'Payout processed successfully.',
      status: gatewayResponse.status,
      charges: {
        userCharge,
        schemeCharge,
        totalCharge: totalCharge,
        chargeAmount: totalCharge,
        totalDebit: totalDebit,
      },
      gatewayResponse: {
        status: gatewayResponse.status,
        message: gatewayResponse.message,
        utrNumber: gatewayResponse.utrNumber,
      },
    }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/payout error:', error);
    return safeJson({ error: 'Failed to create payout' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';

// Simple wrapper to fetch user's APIs for the services page
export async function GET(req: NextRequest) {
    const user = await authMiddleware(req, ['USER']);
    if (user instanceof NextResponse) return user;

    try {
        const apis = await prisma.userApi.findMany({
            where: {
                OR: [
                    { userId: user.id },
                    { isShared: true }
                ]
            },
            select: {
                id: true,
                name: true,
                key: true,
                isActive: true,
                isDefault: true,
            },
            orderBy: { createdAt: 'desc' },
        });

        return NextResponse.json({
            success: true,
            data: apis,
        });
    } catch (error) {
        console.error('GET /api/user/apis error:', error);
        return NextResponse.json({ error: 'Failed to fetch APIs' }, { status: 500 });
    }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const userApis = await prisma.userApi.findMany({
      where: {
        userId: user.id,
        type: 'fingrow',
      },
      select: {
        id: true,
        name: true,
        baseUrl: true,
        apiKey: true,
        isActive: true,
        isDefault: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    const adminApis = await prisma.adminApi.findMany({
      where: {
        type: 'fingrow',
        isActive: true,
      },
      select: {
        id: true,
        name: true,
        baseUrl: true,
        description: true,
        isDefault: true,
        createdAt: true,
      },
    });

    return NextResponse.json({
      success: true,
      userApis,
      adminApis,
    });
  } catch (error) {
    console.error('GET /api/user/fingrow-apis error:', error);
    return NextResponse.json({ error: 'Failed to fetch Fingrow APIs' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { name, baseUrl, apiKey, scopes } = body;

    if (!name || !apiKey) {
      return NextResponse.json(
        { error: 'Name and Merchant ID (apiKey) are required' },
        { status: 400 },
      );
    }

    const api = await prisma.userApi.create({
      data: {
        userId: user.id,
        key: `fingrow_${user.id}_${Date.now()}`,
        type: 'fingrow',
        name,
        baseUrl: baseUrl || 'https://pay.fingrowaitech.com/transaction/transactions/api/initiate',
        apiKey, // Merchant ID
        scopes: typeof scopes === 'string' ? scopes : JSON.stringify(scopes || {}),
        isActive: true,
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(api) }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/fingrow-apis error:', error);
    return NextResponse.json({ error: 'Failed to create Fingrow API' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { id } = await params;
    const api = await prisma.userApi.findUnique({
      where: { id },
    });

    if (!api || api.userId !== user.id || api.type !== 'fingrow') {
      return NextResponse.json({ error: 'API not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: serializeBigInt(api) });
  } catch (error) {
    console.error('GET /api/user/fingrow-apis/[id] error:', error);
    return NextResponse.json({ error: 'Failed to fetch API' }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { id } = await params;
    const existingApi = await prisma.userApi.findUnique({
      where: { id },
    });

    if (!existingApi || existingApi.userId !== user.id || existingApi.type !== 'fingrow') {
      return NextResponse.json({ error: 'API not found' }, { status: 404 });
    }

    const body = await req.json();
    const { name, baseUrl, apiKey, scopes, isActive } = body;

    const api = await prisma.userApi.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(baseUrl && { baseUrl }),
        ...(apiKey && { apiKey }),
        ...(scopes && { scopes: typeof scopes === 'string' ? scopes : JSON.stringify(scopes) }),
        ...(isActive !== undefined && { isActive }),
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(api) });
  } catch (error) {
    console.error('PATCH /api/user/fingrow-apis/[id] error:', error);
    return NextResponse.json({ error: 'Failed to update API' }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { id } = await params;
    const existingApi = await prisma.userApi.findUnique({
      where: { id },
    });

    if (!existingApi || existingApi.userId !== user.id || existingApi.type !== 'fingrow') {
      return NextResponse.json({ error: 'API not found' }, { status: 404 });
    }

    await prisma.userApi.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: 'API deleted successfully' });
  } catch (error) {
    console.error('DELETE /api/user/fingrow-apis/[id] error:', error);
    return NextResponse.json({ error: 'Failed to delete API' }, { status: 500 });
  }
}

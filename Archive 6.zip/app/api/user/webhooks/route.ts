import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';
import crypto from 'crypto';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  const targetUserId = user.role === 'SUBUSER' ? user.userId : user.id;
  if (!targetUserId) return NextResponse.json({ error: 'Invalid user context' }, { status: 400 });

  try {
    const webhooks: any[] = await prisma.$queryRaw`
      SELECT w.*, m."merchantName" as "merchantName"
      FROM "WebhookConfig" w
      LEFT JOIN "MerchantConfig" m ON w."merchantId" = m."id"
      WHERE w."userId" = ${targetUserId} 
      ORDER BY w."createdAt" DESC
    `;

    return NextResponse.json({ success: true, data: serializeBigInt(webhooks) });
  } catch (error) {
    console.error('GET /api/user/webhooks error:', error);
    return NextResponse.json({ error: 'Failed to fetch webhooks' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  const targetUserId = user.role === 'SUBUSER' ? user.userId : user.id;
  if (!targetUserId) return NextResponse.json({ error: 'Invalid user context' }, { status: 400 });

  try {
    const body = await req.json();
    const { webhookUrl, merchantId, events, retryCount, retryDelay } = body;

    if (!webhookUrl) {
      return NextResponse.json({ error: 'Webhook URL is required' }, { status: 400 });
    }

    const webhookSecret = 'whsec_' + crypto.randomBytes(32).toString('hex');
    const eventsArray = events || ['payment.success', 'payment.failed', 'payout.success', 'payout.failed'];

    await prisma.webhookConfig.create({
      data: {
        userId: targetUserId,
        merchantId: merchantId || null,
        webhookUrl,
        webhookSecret,
        events: eventsArray,
        retryCount: retryCount || 3,
        retryDelay: retryDelay || 300,
        isActive: true,
      },
    });

    return NextResponse.json({
      success: true,
      data: { webhookSecret },
      message: 'Webhook created. Save your secret!'
    }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/webhooks error:', error);
    return NextResponse.json({ error: 'Failed to create webhook' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  const targetUserId = user.role === 'SUBUSER' ? user.userId : user.id;

  try {
    const body = await req.json();
    const { id, webhookUrl, events, retryCount, retryDelay, isActive } = body;

    if (!id) {
      return NextResponse.json({ error: 'Webhook ID is required' }, { status: 400 });
    }

    // Verify ownership
    const webhook = await prisma.webhookConfig.findUnique({ where: { id } });
    if (!webhook || webhook.userId !== targetUserId) {
      return NextResponse.json({ error: 'Webhook not found' }, { status: 404 });
    }

    const updateData: any = {};
    if (webhookUrl !== undefined) updateData.webhookUrl = webhookUrl;
    if (events !== undefined) updateData.events = events;
    if (retryCount !== undefined) updateData.retryCount = retryCount;
    if (retryDelay !== undefined) updateData.retryDelay = retryDelay;
    if (isActive !== undefined) updateData.isActive = isActive;

    await prisma.webhookConfig.update({
      where: { id },
      data: serializeBigInt(updateData),
    });

    return NextResponse.json({ success: true, message: 'Webhook updated' });
  } catch (error) {
    console.error('PATCH /api/user/webhooks error:', error);
    return NextResponse.json({ error: 'Failed to update webhook' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  const targetUserId = user.role === 'SUBUSER' ? user.userId : user.id;
  if (!targetUserId) return NextResponse.json({ error: 'Invalid user context' }, { status: 400 });

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Webhook ID is required' }, { status: 400 });
    }

    await prisma.webhookConfig.deleteMany({
      where: { id, userId: targetUserId },
    });

    return NextResponse.json({ success: true, message: 'Webhook deleted' });
  } catch (error) {
    console.error('DELETE /api/user/webhooks error:', error);
    return NextResponse.json({ error: 'Failed to delete webhook' }, { status: 500 });
  }
}

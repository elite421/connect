import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { toRupees } from '@/lib/money';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const settlements: any[] = await prisma.$queryRaw`
      SELECT s.*, b."bankName", b."accountNumber"
      FROM "Settlement" s
      LEFT JOIN "BankAccount" b ON s."bankAccountId" = b."id"
      WHERE s."userId" = ${user.id} 
      ORDER BY s."createdAt" DESC
      LIMIT 100
    `;

    // Convert values for display
    const formattedSettlements = settlements.map(s => ({
      ...serializeBigInt(s),
      amount: toRupees(s.amount),
      fee: toRupees(s.fee),
      netAmount: toRupees(s.netAmount),
    }));

    // Calculate totals
    const totals: any = await prisma.$queryRaw`
      SELECT 
        COUNT(*) as total_count,
        COALESCE(SUM(CASE WHEN status = 'completed' THEN "netAmount" ELSE 0 END), 0) as total_settled,
        COALESCE(SUM(CASE WHEN status = 'pending' THEN "netAmount" ELSE 0 END), 0) as pending_amount
      FROM "Settlement" 
      WHERE "userId" = ${user.id}
    `;

    const statsData = totals[0] || { total_count: 0, total_settled: 0, pending_amount: 0 };
    const stats = {
      total_count: Number(statsData.total_count),
      total_settled: toRupees(statsData.total_settled),
      pending_amount: toRupees(statsData.pending_amount)
    };

    return safeJson({
      success: true,
      data: formattedSettlements,
      stats: stats
    });
  } catch (error) {
    console.error('GET /api/user/settlements error:', error);
    return safeJson({ error: 'Failed to fetch settlements' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { amount, bankAccountId } = body;

    if (!amount || !bankAccountId) {
      return safeJson({ error: 'Amount and bank account required' }, { status: 400 });
    }

    const amountInRupees = Number(amount);

    if (amountInRupees < 100) {
      return safeJson({ error: 'Minimum settlement amount is ₹100' }, { status: 400 });
    }

    // Fee logic: 0.5% with min 5 Rupees
    const feePercent = 0.005;
    const calculatedFee = amountInRupees * feePercent;
    const minFee = 5;
    const fee = Math.max(calculatedFee, minFee);
    const netAmount = amountInRupees - fee;

    await prisma.settlement.create({
      data: {
        userId: user.id,
        amount: amountInRupees,
        fee: fee,
        netAmount: netAmount,
        bankAccountId,
        settlementType: 'on_demand',
        status: 'pending',
      },
    });

    return safeJson({ success: true, message: 'Settlement request created' }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/settlements error:', error);
    return safeJson({ error: 'Failed to create settlement' }, { status: 500 });
  }
}

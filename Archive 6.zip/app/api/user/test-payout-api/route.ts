import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

function safeJsonParse<T = any>(val?: string | null): T | undefined {
  if (!val) return undefined;
  try {
    return JSON.parse(val) as T;
  } catch {
    return undefined;
  }
}

function buildAuthHeaders(api: any): Record<string, string> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  const conf = safeJsonParse<any>(api.apiSecret);
  const explicitAuthHeader = api.authHeader || conf?.authHeader;
  const tokenCandidate = api.apiToken || api.apiKey || conf?.apiToken || conf?.apiKey;

  if (explicitAuthHeader && tokenCandidate) {
    headers[String(explicitAuthHeader)] = String(tokenCandidate);
  } else if (api.authHeader === 'bearer' || conf?.authType === 'bearer') {
    if (api.apiToken || conf?.apiToken) {
      headers['Authorization'] = `Bearer ${api.apiToken || conf?.apiToken}`;
    }
  } else if (api.apiKey || conf?.apiKey) {
    headers['X-API-Key'] = String(api.apiKey || conf?.apiKey);
  }

  if (conf?.headers && typeof conf.headers === 'object') {
    for (const [k, v] of Object.entries(conf.headers)) {
      if (typeof v === 'string') headers[k] = v;
    }
  }

  return headers;
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { apiId, amount, beneficiaryName, beneficiaryAccount, beneficiaryIfsc, beneficiaryVpa, transferMode } = body;

    if (!apiId) {
      return NextResponse.json({ error: 'API ID is required' }, { status: 400 });
    }

    const api = await prisma.userApi.findFirst({
      where: {
        id: apiId,
        OR: [
          { userId: user.id },
          { user: { role: 'ADMIN' } },
        ],
      },
    });

    if (!api) {
      return NextResponse.json({ error: 'API not found or unauthorized' }, { status: 404 });
    }

    if (!api.baseUrl) {
      return NextResponse.json({
        error: 'API base URL is not configured',
        details: 'Please add a base URL to your API configuration',
      }, { status: 400 });
    }

    const authHeaders = buildAuthHeaders(api);
    const scopes = safeJsonParse<any>(api.scopes);
    let baseUrl = api.baseUrl;

    if (scopes?.payoutEndpoint) baseUrl = String(scopes.payoutEndpoint).replace(/\s+/g, '');
    else baseUrl = baseUrl?.replace(/\s+/g, '') || '';

    let payload: Record<string, any> = {
      amount: amount || 100,
      beneficiaryName: beneficiaryName || 'Test User',
      beneficiaryAccount: beneficiaryAccount || '1234567890',
      beneficiaryIfsc: beneficiaryIfsc || 'SBIN0001234',
      beneficiaryVpa: beneficiaryVpa || 'test@upi',
      transferMode: transferMode || 'neft',
      merchantTransactionId: `test_${Date.now()}`,
    };

    const payoutTemplate = scopes?.payoutRequestTemplate ?? scopes?.requestTemplate;
    if (payoutTemplate) {
      const templateObj = safeJsonParse<any>(payoutTemplate) || {};
      payload = { ...templateObj, ...payload };
    }

    const secretConf = safeJsonParse<any>(api.apiSecret);
    if (secretConf?.bodyTemplate) {
      let tpl = secretConf.bodyTemplate;
      if (typeof tpl === 'string') {
        tpl = safeJsonParse<any>(tpl) || {};
      }
      if (typeof tpl === 'object') {
        payload = { ...tpl, ...payload };
      }
    }

    const maps: Array<Record<string, string>> = [];
    if (scopes?.payoutFieldMap && typeof scopes.payoutFieldMap === 'object') maps.push(scopes.payoutFieldMap);
    if (secretConf?.payoutFieldMap && typeof secretConf.payoutFieldMap === 'object') maps.push(secretConf.payoutFieldMap);
    if (secretConf?.fieldMap && typeof secretConf.fieldMap === 'object') maps.push(secretConf.fieldMap);

    if (maps.length) {
      const mapped: Record<string, any> = {};
      for (const key of Object.keys(payload)) {
        let mappedKey = key;
        for (const m of maps) {
          if (m[key]) {
            mappedKey = m[key];
            break;
          }
        }
        mapped[mappedKey] = (payload as any)[key];
      }
      payload = mapped;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);

    const res = await fetch(baseUrl, {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    clearTimeout(timeout);

    const text = await res.text();
    let data: any;
    try {
      data = JSON.parse(text);
    } catch {
      data = { raw: text };
    }

    const isSuccess = res.ok || (data?.success === true) || (String(data?.status || '').toLowerCase() === 'success');

    await logActivity({
      user,
      action: 'test_gateway_connection',
      resource: 'api',
      resourceId: api.id,
      metadata: {
        apiName: api.name,
        endpoint: baseUrl,
        requestPayload: payload,
        responseStatus: res.status,
        success: isSuccess,
      },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      test: {
        status: isSuccess ? 'success' : 'failed',
        statusCode: res.status,
        message: isSuccess ? 'API test successful' : 'API returned an error',
        warnings: !isSuccess ? ['API test failed. Check your configuration.'] : [],
      },
      request: {
        url: baseUrl,
        method: 'POST',
        headers: authHeaders,
        payload,
      },
      response: {
        status: res.status,
        statusText: res.statusText,
        data,
      },
      suggestions: !isSuccess ? [
        '✓ Verify API Key/Token is correct',
        '✓ Check if your IP is whitelisted by the gateway',
        '✓ Confirm the endpoint URL is correct',
        '✓ Review field mapping if gateway uses different field names',
        '✓ Check gateway documentation for required headers',
      ] : [],
    });
  } catch (error: any) {
    return NextResponse.json({
      success: false,
      error: error?.message || 'Test failed',
      details: error?.code === 'ECONNREFUSED'
        ? 'Connection refused. Check if the URL is correct.'
        : error?.message,
    }, { status: 500 });
  }
}

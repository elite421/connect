import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: any = {
      subUser: {
        userId: user.id,
      },
    };

    if (status) {
      where.kycStatus = status;
    }

    const [kycSubmissions, total] = await Promise.all([
      prisma.kycSubmission.findMany({
        where,
        include: {
          subUser: {
            select: {
              id: true,
              name: true,
              email: true,
            },
          },
        },
        orderBy: { submittedAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.kycSubmission.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: kycSubmissions,
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/user/subuser-kyc error:', error);
    return NextResponse.json({ error: 'Failed to fetch subuser KYC submissions' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { kycSubmissionId, status, rejectionReason } = body;

    if (!kycSubmissionId || !status) {
      return NextResponse.json({ error: 'KYC submission ID and status are required' }, { status: 400 });
    }

    if (!['approved', 'rejected', 'pending'].includes(status)) {
      return NextResponse.json({ error: 'Invalid status' }, { status: 400 });
    }

    const kycSubmission = await prisma.kycSubmission.findUnique({
      where: { id: kycSubmissionId },
      include: {
        subUser: true,
      },
    });

    if (!kycSubmission) {
      return NextResponse.json({ error: 'KYC submission not found' }, { status: 404 });
    }

    if (!kycSubmission.subUser || kycSubmission.subUser.userId !== user.id) {
      return NextResponse.json({ error: 'Unauthorized. You can only approve KYC for your own subusers.' }, { status: 403 });
    }

    const updateData: any = {
      kycStatus: status,
    };

    if (status === 'approved') {
      updateData.verifiedAt = new Date();
      updateData.expiryDate = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000);
    } else if (status === 'rejected') {
      updateData.rejectionReason = rejectionReason || 'Rejected by parent user';
    }

    const updatedKyc = await prisma.kycSubmission.update({
      where: { id: kycSubmissionId },
      data: updateData,
      include: {
        subUser: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
    });

    await logActivity({
      user,
      action: `approve_subuser_kyc`,
      resource: 'kyc',
      resourceId: kycSubmissionId,
      metadata: {
        subUserId: kycSubmission.subUserId,
        status,
        rejectionReason: rejectionReason || null,
      },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: updatedKyc,
      message: `KYC ${status === 'approved' ? 'approved' : 'rejected'} for subuser`,
    });
  } catch (error) {
    console.error('PATCH /api/user/subuser-kyc error:', error);
    return NextResponse.json({ error: 'Failed to update subuser KYC status' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';
import GatewayIntegrationService from '@/lib/gateway-integration';
import { toPaise, toRupees } from '@/lib/money';

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const {
      amount,
      customerName,
      customerEmail,
      customerPhone,
      paymentMethod,
      gatewayId,
      metadata,
    } = await req.json();

    if (!amount || amount <= 0) {
      return NextResponse.json({ error: 'Invalid amount' }, { status: 400 });
    }

    if (!customerEmail) {
      return NextResponse.json({ error: 'Customer email is required' }, { status: 400 });
    }

    // Get user's primary gateway or specified gateway
    let gateway;
    if (gatewayId) {
      gateway = await prisma.gatewayIntegration.findFirst({
        where: { id: gatewayId, userId: user.id, isActive: true },
      });
    } else {
      gateway = await prisma.gatewayIntegration.findFirst({
        where: { userId: user.id, isPrimary: true, isActive: true },
      });
    }

    if (!gateway) {
      return NextResponse.json(
        { error: 'No active payment gateway configured' },
        { status: 400 }
      );
    }

    // Create transaction record
    const transaction = await prisma.payInTransaction.create({
      data: {
        userId: user.id,
        amount: toPaise(amount), // Store as Paise
        customerName: customerName || '',
        customerEmail,
        customerPhone: customerPhone || '',
        paymentMethod: paymentMethod || 'card',
        status: 'pending',
        gatewayId: gateway.id,
      },
    });

    // Initiate payment with gateway
    const integrationService = new GatewayIntegrationService(prisma);

    const paymentResponse = await integrationService.initiatePayment(
      gateway.id,
      {
        amount,
        customerName: customerName || '',
        customerEmail,
        customerPhone: customerPhone || '',
        paymentMethod: paymentMethod || 'card',
        metadata: {
          ...metadata,
          transactionId: transaction.id,
        },
      }
    );

    // Update transaction with response
    const updatedTransaction = await prisma.payInTransaction.update({
      where: { id: transaction.id },
      data: {
        status: paymentResponse.success ? 'processing' : 'failed',
        externalTransactionId: paymentResponse.transactionId,
        utrNumber: paymentResponse.utrNumber,
        responseData: paymentResponse.raw || paymentResponse,
      },
      include: {
        gateway: {
          select: {
            gatewayName: true,
            gatewayCode: true,
          },
        },
      },
    });

    // Log the transaction
    await integrationService.logTransaction(
      gateway.id,
      transaction.id,
      {
        amount,
        customerEmail,
        customerPhone,
        paymentMethod,
      },
      paymentResponse,
      paymentResponse.utrNumber,
      updatedTransaction.status
    );

    return NextResponse.json({
      success: paymentResponse.success,
      transaction: {
        id: updatedTransaction.id,
        amount: toRupees(updatedTransaction.amount),
        status: updatedTransaction.status,
        utrNumber: updatedTransaction.utrNumber,
        externalTransactionId: updatedTransaction.externalTransactionId,
        gateway: updatedTransaction.gateway,
        createdAt: updatedTransaction.createdAt,
      },
      gateway: {
        paymentLink: paymentResponse.paymentLink,
        message: paymentResponse.message,
      },
    });
  } catch (error: any) {
    console.error('Payment initiation error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to initiate payment' },
      { status: 500 }
    );
  }
}

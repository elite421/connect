import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';

import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const transactions = await prisma.$queryRaw`
      SELECT * FROM "PayInTransaction" 
      WHERE "userId" = ${user.id} 
      ORDER BY "createdAt" DESC 
      LIMIT 100
    `;

    const normalizedTransactions = (transactions as any[]).map((t) => ({
      ...t,
      amount: t.amount,
    }));

    return safeJson({ success: true, data: serializeBigInt(normalizedTransactions) });
  } catch (error) {
    console.error('GET /api/user/payin error:', error);
    return safeJson({ error: 'Failed to fetch payins' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      amount,
      customerName,
      customerEmail,
      customerPhone,
      paymentMethod,
      merchantTransactionId,
      utrNumber,
      externalTransactionId,
      responseData,
    } = body;

    if (!amount || !paymentMethod) {
      return safeJson({ error: 'Amount and payment method required' }, { status: 400 });
    }

    // Check for duplicate UTR number if provided
    if (utrNumber) {
      const existingPayin = await prisma.payInTransaction.findFirst({
        where: { utrNumber }
      });

      if (existingPayin) {
        return safeJson({
          error: 'UTR number already exists. Please use a unique transaction reference.'
        }, { status: 400 });
      }
    }

    const ipAddress = extractIpAddress(req);

    // Create PayIn transaction with 'pending' status - requires admin approval
    // For manual deposits, gatewayId is null (not linked to any gateway)
    const transaction = await prisma.payInTransaction.create({
      data: {
        userId: user.id,
        amount: Number(amount),
        customerName: customerName || null,
        customerEmail: customerEmail || null,
        customerPhone: customerPhone || null,
        paymentMethod,
        merchantTransactionId: merchantTransactionId || null,
        ipAddress,
        status: 'pending', // Always pending, admin must approve
        utrNumber: utrNumber || null,
        externalTransactionId: externalTransactionId || null,
        gatewayId: null, // Manual deposits don't use a gateway
        responseData: responseData || null,
      },
    });

    try {
      await logActivity({
        user,
        action: 'create_payment',
        resource: 'payin',
        resourceId: transaction.id,
        metadata: {
          amount,
          paymentMethod,
          customerName,
          customerEmail,
          status: 'pending',
          utrNumber,
        },
        ipAddress,
        userAgent: getUserAgent(req),
      });
    } catch (e) {
      console.warn('Failed to log activity for payin:', e);
    }

    const responseTransaction = transaction;

    return safeJson({
      success: true,
      data: serializeBigInt(responseTransaction),
      message: 'PayIn request created. Awaiting admin approval.'
    }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/payin error:', error);
    return safeJson({ error: 'Failed to create payin' }, { status: 500 });
  }
}

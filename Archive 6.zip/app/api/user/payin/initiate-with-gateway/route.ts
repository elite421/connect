import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';
import GatewayIntegrationService from '@/lib/gateway-integration';
import { toPaise } from '@/lib/money';

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const userId = (session.user as any).id;
    const {
      amount,
      customerName,
      customerEmail,
      customerPhone,
      paymentMethod,
      merchantTransactionId,
      gatewayId,
    } = await req.json();

    if (!amount || !gatewayId) {
      return NextResponse.json(
        { error: 'Amount and gateway are required' },
        { status: 400 }
      );
    }

    const integration = await prisma.gatewayIntegration.findUnique({
      where: { id: gatewayId },
      include: { endpointConfigs: true },
    });

    if (!integration || integration.userId !== userId) {
      return NextResponse.json(
        { error: 'Gateway not found or unauthorized' },
        { status: 404 }
      );
    }

    const integrationService = new GatewayIntegrationService(prisma);

    const transactionRecord = await prisma.payInTransaction.create({
      data: {
        userId,
        amount: toPaise(amount), // Store as Paise
        customerName,
        customerEmail,
        customerPhone,
        paymentMethod: paymentMethod || 'upi',
        merchantTransactionId,
        gatewayId,
        status: 'pending',
      },
    });

    const response = await integrationService.initiatePayment(
      gatewayId,
      {
        amount,
        customerName,
        customerEmail,
        customerPhone,
        paymentMethod,
        metadata: {
          transactionId: transactionRecord.id,
          merchantTransactionId,
        },
      },
      (integration.apiSchema as any)?.fieldMappings
    );

    if (response.success) {
      await prisma.payInTransaction.update({
        where: { id: transactionRecord.id },
        data: {
          externalTransactionId: response.transactionId,
          utrNumber: response.utrNumber,
          responseData: response.raw,
          status: response.status || 'pending',
        },
      });

      await integrationService.logTransaction(
        gatewayId,
        transactionRecord.id,
        {
          amount,
          customerName,
          customerEmail,
          customerPhone,
          paymentMethod,
        },
        response.raw,
        response.utrNumber,
        response.status
      );

      return NextResponse.json({
        success: true,
        transactionId: transactionRecord.id,
        paymentLink: response.paymentLink,
        externalTransactionId: response.transactionId,
        utrNumber: response.utrNumber,
        status: response.status,
      });
    } else {
      await prisma.payInTransaction.update({
        where: { id: transactionRecord.id },
        data: {
          status: 'failed',
          responseData: { error: response.message },
        },
      });

      return NextResponse.json(
        {
          success: false,
          error: response.message,
          gatewayError: response.message,
        },
        { status: 400 }
      );
    }
  } catch (error: any) {
    console.error('Payment initiation error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to initiate payment' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { PrismaClient } from '@prisma/client';
import { toRupees } from '@/lib/money';
import { safeJson } from '@/lib/safe-json';

const prisma = new PrismaClient();

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user?.email) {
      return safeJson({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return safeJson({ error: 'User not found' }, { status: 404 });
    }

    const status = req.nextUrl.searchParams.get('status');
    const limit = parseInt(req.nextUrl.searchParams.get('limit') || '50');
    const offset = parseInt(req.nextUrl.searchParams.get('offset') || '0');

    const where: any = { userId: user.id };
    if (status && status !== 'all') {
      where.status = status.toLowerCase();
    }

    const [transactions, total] = await Promise.all([
      prisma.payInTransaction.findMany({
        where,
        include: {
          gateway: {
            select: {
              id: true,
              gatewayName: true,
              gatewayCode: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.payInTransaction.count({ where }),
    ]);

    return safeJson({
      success: true,
      transactions: transactions.map((tx) => ({
        id: tx.id,
        amount: toRupees(tx.amount),
        utrNumber: tx.utrNumber,
        status: tx.status,
        externalTransactionId: tx.externalTransactionId,
        gatewayId: tx.gatewayId,
        gatewayName: tx.gateway?.gatewayName,
        gatewayCode: tx.gateway?.gatewayCode,
        customerName: tx.customerName,
        customerEmail: tx.customerEmail,
        customerPhone: tx.customerPhone,
        paymentMethod: tx.paymentMethod,
        merchantTransactionId: tx.merchantTransactionId,
        responseData: tx.responseData,
        createdAt: tx.createdAt,
        updatedAt: tx.updatedAt,
      })),
      pagination: {
        total,
        limit,
        offset,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error: any) {
    console.error('Failed to fetch payment transactions:', error);
    return safeJson(
      { error: error.message || 'Failed to fetch transactions' },
      { status: 500 }
    );
  }
}

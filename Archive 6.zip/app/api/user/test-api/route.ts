import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { executeFingrowTransaction } from '@/lib/fingrow-integration';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { apiId, testPayload } = body;

    if (!apiId) {
      return NextResponse.json({ error: 'API ID required' }, { status: 400 });
    }

    const customApi = await prisma.customPaymentApi.findUnique({
      where: { id: apiId },
    });

    if (!customApi) {
      return NextResponse.json({ error: 'API not found' }, { status: 404 });
    }

    if (customApi.userId && customApi.userId !== user.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    if (!testPayload) {
      const fullUrl = `${customApi.apiBaseUrl}${customApi.apiEndpoint}`.replace(/\s+/g, '');

      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 5000);

        const healthCheckResponse = await fetch(fullUrl, {
          method: 'HEAD',
          signal: controller.signal,
        }).catch(() =>
          fetch(fullUrl, {
            method: customApi.apiMethod as 'GET' | 'POST' | 'PUT',
            signal: controller.signal,
          })
        );

        clearTimeout(timeout);
        const isOnline = healthCheckResponse?.ok || healthCheckResponse?.status !== 0;
        return NextResponse.json({ isOnline, message: 'Health check completed' });
      } catch {
        return NextResponse.json({ isOnline: false, message: 'API unreachable' });
      }
    }

    const fullUrl = `${customApi.apiBaseUrl}${customApi.apiEndpoint}`.replace(/\s+/g, '');

    // Check if this is a Fingrow API
    if (fullUrl.includes('fingrow') || fullUrl.includes('pay.fingrowaitech.com')) {
      const merchantId = customApi.apiKey;
      if (!merchantId) {
        return NextResponse.json({
          success: false,
          statusCode: 400,
          message: 'Fingrow API detected but Merchant ID (API Key) is missing',
          error: 'MISSING_MERCHANT_ID'
        }, { status: 400 });
      }

      // Extract channel from apiSecret JSON config (e.g., {"channel": "FNZ"})
      let channel = 'FNZ';
      try {
        if (customApi.apiSecret) {
          const config = JSON.parse(customApi.apiSecret);
          channel = config.channel || 'FNZ';
        }
      } catch (e) {
        // Keep default FNZ if parsing fails
      }

      try {
        const fingrowResponse = await executeFingrowTransaction(merchantId, fullUrl, {
          amount: testPayload?.amount ? Math.round(Number(testPayload.amount)) : 100,
          beneficiaryName: testPayload?.beneficiaryName || 'Test User',
          beneficiaryAccount: testPayload?.beneficiaryAccount || '2029001700058769',
          beneficiaryIfsc: testPayload?.beneficiaryIfsc || 'PUNB0202900',
          beneficiaryVpa: testPayload?.beneficiaryVpa || 'amansingh9532@okicici',
          transferMode: testPayload?.transferMode || 'IMPS',
          merchantTransactionId: `TEST_${Date.now()}`,
          ipAddress: '127.0.0.1',
          userAgent: 'API Test Tool',
          channel
        });

        return NextResponse.json({
          success: fingrowResponse.success,
          statusCode: fingrowResponse.success ? 200 : 400,
          response: fingrowResponse.raw,
          message: fingrowResponse.message,
        });
      } catch (error) {
        return NextResponse.json({
          success: false,
          statusCode: 500,
          message: 'Fingrow API test failed',
          error: String(error)
        }, { status: 500 });
      }
    }

    // Standard custom API request
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (customApi.authType === 'bearer' && customApi.apiKey) {
      headers['Authorization'] = `Bearer ${customApi.apiKey}`;
    } else if (customApi.authType === 'basic' && customApi.apiKey && customApi.apiSecret) {
      const credentials = Buffer.from(`${customApi.apiKey}:${customApi.apiSecret}`).toString('base64');
      headers['Authorization'] = `Basic ${credentials}`;
    } else if (customApi.authType === 'apikey' && customApi.authHeader && customApi.apiKey) {
      headers[customApi.authHeader] = customApi.apiKey;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);

    const response = await fetch(fullUrl, {
      method: customApi.apiMethod as 'GET' | 'POST' | 'PUT',
      headers,
      body: testPayload ? JSON.stringify(testPayload) : undefined,
      signal: controller.signal,
    });

    clearTimeout(timeout);
    const responseText = await response.text();
    let responseData;
    try {
      responseData = JSON.parse(responseText);
    } catch {
      responseData = responseText;
    }

    return NextResponse.json({
      success: response.ok,
      statusCode: response.status,
      response: responseData,
      message: response.ok ? 'API test successful' : 'API returned error',
    });
  } catch (error) {
    console.error('POST /api/user/test-api error:', error);
    return NextResponse.json(
      {
        success: false,
        error: String(error),
        message: 'Failed to test API',
      },
      { status: 500 }
    );
  }
}

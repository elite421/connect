import { NextRequest, NextResponse } from 'next/server';
import { authMiddleware } from '@/lib/middleware';
import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';
import { safeJson } from '@/lib/safe-json';

const MAX_FILE_SIZE = 250 * 1024;
const UPLOAD_DIR = 'public/uploads/kyc';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const formData = await req.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return safeJson({ error: 'No file provided' }, { status: 400 });
    }

    if (file.size > MAX_FILE_SIZE) {
      return safeJson(
        { error: `File size must be less than 250 KB. Current size: ${(file.size / 1024).toFixed(2)} KB` },
        { status: 400 }
      );
    }

    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      return safeJson(
        { error: 'Only JPEG, PNG, and WebP images are allowed' },
        { status: 400 }
      );
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    const uploadDir = join(process.cwd(), UPLOAD_DIR);
    await mkdir(uploadDir, { recursive: true });

    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(7);
    const fileName = `${user.id}-${timestamp}-${random}-${file.name}`;
    const filePath = join(uploadDir, fileName);

    await writeFile(filePath, buffer);

    const fileUrl = `/uploads/kyc/${fileName}`;

    return safeJson({ success: true, url: fileUrl, fileName });
  } catch (error) {
    console.error('File upload error:', error);
    return safeJson({ error: 'Failed to upload file' }, { status: 500 });
  }
}

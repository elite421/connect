import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';
import crypto from 'crypto';
import { toPaise, toRupees } from '@/lib/money';

const serializeMerchant = (merchant: any) => ({
  ...merchant,
  minAmount: toRupees(merchant.minAmount).toString(),
  maxAmount: toRupees(merchant.maxAmount).toString(),
  dailyLimit: merchant.dailyLimit ? toRupees(merchant.dailyLimit).toString() : null,
  monthlyLimit: merchant.monthlyLimit ? toRupees(merchant.monthlyLimit).toString() : null,
});

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const merchants: any[] = await prisma.$queryRaw`
      SELECT * FROM "MerchantConfig" 
      WHERE "userId" = ${user.id} 
      ORDER BY "createdAt" DESC
    `;

    return NextResponse.json({ success: true, data: merchants.map(serializeMerchant) });
  } catch (error) {
    console.error('GET /api/user/merchants error:', error);
    return NextResponse.json({ error: 'Failed to fetch merchants' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { merchantName, transactionMode, minAmount, maxAmount, dailyLimit, monthlyLimit, allowedIPs } = body;

    if (!merchantName) {
      return NextResponse.json({ error: 'Merchant name is required' }, { status: 400 });
    }

    const merchantKey = 'mk_' + crypto.randomBytes(16).toString('hex');
    const merchantSecret = 'ms_' + crypto.randomBytes(32).toString('hex');
    const ipsArray = allowedIPs ? allowedIPs.split(',').map((ip: string) => ip.trim()) : [];

    const merchant = await prisma.merchantConfig.create({
      data: {
        userId: user.id,
        merchantName,
        merchantKey,
        merchantSecret,
        transactionMode: transactionMode || 'both',
        minAmount: minAmount ? toPaise(minAmount) : toPaise(1), // Default 1 Rupee min
        maxAmount: maxAmount ? toPaise(maxAmount) : toPaise(1000000), // Default 10 Lakh max
        dailyLimit: dailyLimit ? toPaise(dailyLimit) : null,
        monthlyLimit: monthlyLimit ? toPaise(monthlyLimit) : null,
        allowedIPs: ipsArray,
        isActive: true,
      },
    });

    return NextResponse.json({
      success: true,
      data: {
        ...serializeMerchant(merchant),
        merchantKey,
        merchantSecret
      },
      message: 'Merchant created. Save your credentials!'
    }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/merchants error:', error);
    return NextResponse.json({ error: 'Failed to create merchant' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { id, merchantName, transactionMode, minAmount, maxAmount, dailyLimit, monthlyLimit, allowedIPs, isActive } = body;

    if (!id) {
      return NextResponse.json({ error: 'Merchant ID is required' }, { status: 400 });
    }

    const updateData: any = {};
    if (merchantName !== undefined) updateData.merchantName = merchantName;
    if (transactionMode !== undefined) updateData.transactionMode = transactionMode;
    if (minAmount !== undefined) updateData.minAmount = toPaise(minAmount);
    if (maxAmount !== undefined) updateData.maxAmount = toPaise(maxAmount);
    if (dailyLimit !== undefined) updateData.dailyLimit = dailyLimit ? toPaise(dailyLimit) : null;
    if (monthlyLimit !== undefined) updateData.monthlyLimit = monthlyLimit ? toPaise(monthlyLimit) : null;
    if (allowedIPs !== undefined) updateData.allowedIPs = allowedIPs ? allowedIPs.split(',').map((ip: string) => ip.trim()) : [];
    if (isActive !== undefined) updateData.isActive = isActive;

    await prisma.merchantConfig.update({
      where: { id },
      data: serializeBigInt(updateData),
    });

    return NextResponse.json({ success: true, message: 'Merchant updated' });
  } catch (error) {
    console.error('PATCH /api/user/merchants error:', error);
    return NextResponse.json({ error: 'Failed to update merchant' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Merchant ID is required' }, { status: 400 });
    }

    await prisma.merchantConfig.deleteMany({
      where: { id, userId: user.id },
    });

    return NextResponse.json({ success: true, message: 'Merchant deleted' });
  } catch (error) {
    console.error('DELETE /api/user/merchants error:', error);
    return NextResponse.json({ error: 'Failed to delete merchant' }, { status: 500 });
  }
}

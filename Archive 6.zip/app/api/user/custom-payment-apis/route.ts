import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const myApis = await prisma.customPaymentApi.findMany({
      where: {
        userId: user.id,
        adminProvided: false,
      },
      orderBy: { createdAt: 'desc' },
    });

    const adminApis: any[] = [];

    return NextResponse.json({ success: true, myApis, adminApis });
  } catch (error) {
    console.error('GET /api/user/custom-payment-apis error:', error);
    return NextResponse.json({ error: 'Failed to fetch APIs' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      apiName,
      apiBaseUrl,
      apiEndpoint,
      apiMethod,
      authType,
      apiKey,
      apiSecret,
      authHeader,
      contentType,
      apiPreset,
      requestFormat,
      responseFormat,
      isDefault,
    } = body;

    if (!apiName || !apiBaseUrl || !apiEndpoint) {
      return NextResponse.json({ error: 'API name, base URL, and endpoint are required' }, { status: 400 });
    }

    if (isDefault) {
      await prisma.customPaymentApi.updateMany({
        where: { userId: user.id, isDefault: true },
        data: { isDefault: false },
      });
    }

    const api = await prisma.customPaymentApi.create({
      data: {
        userId: user.id,
        apiName,
        apiBaseUrl,
        apiEndpoint,
        apiMethod: apiMethod || 'POST',
        authType: authType || 'bearer',
        apiKey: apiKey || null,
        apiSecret: apiSecret || null,
        authHeader: authHeader || null,
        requestFormat: requestFormat || null,
        responseFormat: responseFormat || null,
        isActive: false, // Enforce inactive on creation
        isDefault: isDefault || false,
        adminProvided: false,
        // @ts-ignore
        apiType: body.apiType || 'PAYOUT',
        // @ts-ignore
        allowedModes: body.allowedModes || ['IMPS', 'NEFT', 'UPI', 'RTGS'],
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(api), message: 'API submitted for approval' }, { status: 201 });
  } catch (error) {
    console.error('POST /api/user/custom-payment-apis error:', error);
    return NextResponse.json({ error: 'Failed to create API' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      id,
      apiName,
      apiBaseUrl,
      apiEndpoint,
      apiMethod,
      authType,
      apiKey,
      apiSecret,
      authHeader,
      contentType,
      apiPreset,
      requestFormat,
      responseFormat,
      isDefault
    } = body;

    if (!id) {
      return NextResponse.json({ error: 'API ID is required' }, { status: 400 });
    }

    const existing = await prisma.customPaymentApi.findFirst({
      where: { id, userId: user.id },
    });

    if (!existing) {
      return NextResponse.json({ error: 'API not found' }, { status: 404 });
    }

    // If API is active, prevent user modifications (must contact admin)
    if (existing.isActive) {
      return NextResponse.json({ error: 'Cannot modify an active API. Contact admin.' }, { status: 403 });
    }

    if (isDefault) {
      await prisma.customPaymentApi.updateMany({
        where: { userId: user.id, isDefault: true, NOT: { id } },
        data: { isDefault: false },
      });
    }

    const api = await prisma.customPaymentApi.update({
      where: { id },
      data: {
        apiName,
        apiBaseUrl,
        apiEndpoint,
        apiMethod,
        authType,
        apiKey: apiKey || null,
        apiSecret: apiSecret || null,
        authHeader: authHeader || null,
        requestFormat: requestFormat || null,
        responseFormat: responseFormat || null,
        // isActive is excluded, user cannot change it
        isDefault,
        // @ts-ignore
        apiType: body.apiType,
        // @ts-ignore
        allowedModes: body.allowedModes,
      },
    });

    return NextResponse.json({ success: true, data: serializeBigInt(api) });
  } catch (error) {
    console.error('PATCH /api/user/custom-payment-apis error:', error);
    return NextResponse.json({ error: 'Failed to update API' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['USER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'API ID is required' }, { status: 400 });
    }

    await prisma.customPaymentApi.deleteMany({
      where: { id, userId: user.id },
    });

    return NextResponse.json({ success: true, message: 'API deleted' });
  } catch (error) {
    console.error('DELETE /api/user/custom-payment-apis error:', error);
    return NextResponse.json({ error: 'Failed to delete API' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const kycSubmission = await prisma.kycSubmission.findFirst({
      where: {
        OR: [
          { userId: user.id },
          { subUser: { userId: user.id } }
        ]
      }
    });

    return NextResponse.json({ success: true, data: serializeBigInt(kycSubmission) });
  } catch (error) {
    console.error('GET /api/user/kyc error:', error);
    return NextResponse.json({ error: 'Failed to fetch KYC submission' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      firstName,
      lastName,
      dateOfBirth,
      email,
      phone,
      addressLine1,
      addressLine2,
      city,
      state,
      postalCode,
      country,
      idType,
      idNumber,
      panNumber,
      aadharNumber,
      idPhotoUrl,
      panPhotoUrl,
      aadharPhotoUrl
    } = body;

    let userId = user.id;
    let subUserId: string | null = null;

    if (user.role === 'SUBUSER') {
      const subUser = await prisma.subUser.findUnique({
        where: { id: user.id }
      });
      if (subUser) {
        userId = subUser.userId;
        subUserId = user.id;
      }
    }

    const existingKyc = await prisma.kycSubmission.findFirst({
      where: { userId }
    });

    const kycData = {
      firstName,
      lastName,
      dateOfBirth: dateOfBirth ? new Date(dateOfBirth) : null,
      email,
      phone,
      addressLine1,
      addressLine2,
      city,
      state,
      postalCode,
      country,
      idType,
      idNumber,
      idPhotoUrl: idPhotoUrl || null,
      panNumber,
      panPhotoUrl: panPhotoUrl || null,
      aadharNumber,
      aadharPhotoUrl: aadharPhotoUrl || null,
      kycStatus: 'pending',
      submittedAt: new Date()
    };

    let kycSubmission;
    if (existingKyc) {
      kycSubmission = await prisma.kycSubmission.update({
        where: { id: existingKyc.id },
        data: kycData
      });
    } else {
      const createData: any = {
        ...kycData,
        userId
      };
      if (subUserId) {
        createData.subUserId = subUserId;
      }
      kycSubmission = await prisma.kycSubmission.create({
        data: createData
      });
    }

    await logActivity({
      user,
      action: 'submit_kyc',
      resource: 'kyc',
      resourceId: kycSubmission.id,
      metadata: { firstName, lastName, idType },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req)
    });

    return NextResponse.json({ success: true, data: serializeBigInt(kycSubmission) });
  } catch (error) {
    console.error('POST /api/user/kyc error:', error);
    return NextResponse.json({ error: 'Failed to submit KYC' }, { status: 500 });
  }
}

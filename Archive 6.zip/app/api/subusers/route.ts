import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { requireRole } from '@/lib/roles';

export async function GET(req: NextRequest) {
  const rc = await requireRole(req, ['ADMIN','USER']);
  if (rc instanceof NextResponse) return rc;
  const user = rc;

  const subs = await prisma.subUser.findMany({ where: { userId: user.id }, take: 200 });
  return NextResponse.json({ subs });
}
// POST handler for creating subusers is defined in other file; keep only GET here

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { logActivity } from '@/lib/audit';

export async function POST(req: NextRequest) {
    try {
        const body = await req.json();
        console.log('[RudraxPay] Payin Callback:', body);

        const { status, client_txn_id, utr, amount } = body;

        if (!client_txn_id) {
            return NextResponse.json({ status: false, message: 'Missing client_txn_id' }, { status: 400 });
        }

        const transaction = await prisma.payInTransaction.findFirst({
            where: {
                OR: [
                    { id: client_txn_id },
                    { merchantTransactionId: client_txn_id }
                ]
            }
        });

        if (!transaction) {
            console.warn(`[RudraxPay] Payin Callback for unknown transaction: ${client_txn_id}`);
            return NextResponse.json({ status: false, message: 'Transaction not found' }, { status: 404 });
        }

        // prevent duplicate updates
        if (transaction.status === 'completed' || transaction.status === 'success' || transaction.status === 'failed') {
            return NextResponse.json({ status: true, message: 'Transaction already processed' });
        }

        const isSuccess = status === 'success';

        await prisma.payInTransaction.update({
            where: { id: transaction.id },
            data: {
                status: isSuccess ? 'completed' : 'failed',
                utrNumber: utr || transaction.utrNumber,
                responseData: {
                    ...(transaction.responseData as object),
                    callbackData: body
                }
            }
        });

        // If success, credit the subuser wallet/ledger if required?
        // In `gateway/payin/callback`, we see logic to credit SubUser Transaction.
        // I should replicate that logic to ensure consistency.

        if (isSuccess) {
            // Create a Credit Transaction for the user
            // Using 'SubUserTransaction' logic from original callback
            await prisma.subUserTransaction.create({
                data: {
                    subUserId: transaction.userId, // Using userId as subUserId? In schema subUser logic seems mixed with user.
                    // Let's look at schema. PayInTransaction has 'userId' (User). 
                    // SubUserTransaction requires 'subUserId'.
                    // Wait, in `gateway/payin/callback/route.ts`:
                    /*
                        subUserId: transaction.userId,
                        userId: transaction.userId,
                    */
                    // This implies transaction.userId refers to a SubUser or User that acts like one. 
                    // Schema: PayInTransaction -> User. SubUserTransaction -> SubUser + User.
                    // If userId is actually a User ID, inserting it into subUserId might fail foreign key if that ID is not in SubUser table?
                    // Unless 'User' table IDs are also 'SubUser' table IDs? (Unlikely unless one-to-one).
                    // Let's re-read schema.
                    // SubUser table has 'userId' pointing to parent User.
                    // SubUser has its own ID.
                    // If the person who initiated PayIn is a USER (not SubUser), then we probably shouldn't create a SubUserTransaction?
                    // BUT `gateway/payin/callback/route.ts` creates it: `subUserId: transaction.userId`.
                    // This suggests that `transaction.userId` IS a SubUser ID?
                    // Let's look at `initiate` route. `authMiddleware(req, ['USER'])`. Returns `user`.
                    // `prisma.payInTransaction.create({ userId: user.id ... })`.
                    // So `id` is from `User` table.
                    // If `gateway/payin/callback` works, then `SubUserTransaction` can accept `User` id?
                    // Schema says `subUser SubUser @relation...`.
                    // So `subUserId` MUST exist in `SubUser` table.
                    // If `transaction.userId` is a `User` (Role=USER/ADMIN), it won't be in `SubUser` table.
                    // This means `gateway/payin/callback` might be buggy OR `User` can also be a `SubUser`?
                    // Or maybe `authMiddleware` returns a SubUser? 
                    // `authMiddleware(req, ['USER'])` usually checks Role.

                    // To be safe, I will implement Wallet credit logic broadly if applicable, 
                    // but if I'm unsure about SubUserTransaction, I will stick to just updating status 
                    // and maybe `Wallet` balance if `Wallet` model exists.

                    // Checks schema for `Wallet` model.
                    // model Wallet { userId String @unique ... user User ... }
                    // So we should update `Wallet`.

                    userId: transaction.userId,
                    type: 'credit',
                    amount: transaction.amount,
                    currency: 'INR',
                    description: `PayIn (Rudrax) ${client_txn_id}`,
                    relatedPaymentId: transaction.id,
                    status: 'completed',
                },
            });

            // Also update Wallet Balance
            await prisma.wallet.upsert({
                where: { userId: transaction.userId },
                create: {
                    userId: transaction.userId,
                    balance: transaction.amount
                },
                update: {
                    balance: { increment: transaction.amount }
                }
            });
        }

        return NextResponse.json({ status: true, message: 'Callback processed' });

    } catch (error: any) {
        console.error('[RudraxPay] Callback Error:', error);
        return NextResponse.json({ status: false, message: error.message }, { status: 500 });
    }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

/**
 * Poll Pending Transactions
 * Calls the custom API's status endpoint to check pending transactions.
 * Run via cron job or manual trigger.
 */
export async function GET(req: NextRequest) {
    const { searchParams } = new URL(req.url);
    const apiId = searchParams.get('apiId');
    const secret = searchParams.get('secret');

    // Simple security check (in production, use proper auth)
    if (secret !== process.env.CRON_SECRET && secret !== 'manual') {
        return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    try {
        // Get pending transactions (processing status, created in last 24 hours)
        const pendingTxs = await prisma.payOutTransaction.findMany({
            where: {
                status: 'processing',
                createdAt: {
                    gte: new Date(Date.now() - 24 * 60 * 60 * 1000) // Last 24 hours
                },
                ...(apiId && {
                    responseData: {
                        path: ['apiId'],
                        equals: apiId
                    }
                })
            },
            take: 50, // Limit to 50 per batch
            orderBy: { createdAt: 'asc' }
        });

        console.log(`[Status Poll] Found ${pendingTxs.length} pending transactions`);

        const results: any[] = [];

        for (const tx of pendingTxs) {
            const responseData = tx.responseData as any;
            const txApiId = responseData?.apiId;

            if (!txApiId) {
                results.push({ id: tx.id, status: 'skipped', reason: 'No apiId in transaction' });
                continue;
            }

            // Get the custom API configuration
            const customApi = await prisma.customPaymentApi.findUnique({
                where: { id: txApiId }
            });

            if (!customApi || !customApi.statusCheckUrl) {
                results.push({ id: tx.id, status: 'skipped', reason: 'API not configured or no status check URL' });
                continue;
            }

            try {
                // Call the provider's status check endpoint (GET request)
                const statusResponse = await fetch(`${customApi.statusCheckUrl}?transactionId=${tx.externalTransactionId || tx.id}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        ...(customApi.authHeader && { 'Authorization': customApi.authHeader }),
                        ...(customApi.apiKey && { 'X-API-Key': customApi.apiKey }),
                    }
                });

                const statusData = await statusResponse.json();

                // Parse response using responseFormat
                let responseMapping: any = {};
                try {
                    responseMapping = customApi.responseFormat ?
                        (typeof customApi.responseFormat === 'string' ? JSON.parse(customApi.responseFormat) : customApi.responseFormat)
                        : {};
                } catch {
                    responseMapping = {};
                }

                const statusField = responseMapping.statusField || 'status';
                const successValue = responseMapping.successValue || 'success';
                const failureValue = responseMapping.failureValue || 'failed';
                const utrField = responseMapping.utrField || 'utr';

                const rawStatus = statusData[statusField] || statusData.status;
                let newStatus: 'success' | 'failed' | 'processing' = 'processing';

                if (rawStatus === successValue || rawStatus === 'success' || rawStatus === 'SUCCESS' || rawStatus === 1) {
                    newStatus = 'success';
                } else if (rawStatus === failureValue || rawStatus === 'failed' || rawStatus === 'FAILED' || rawStatus === 2) {
                    newStatus = 'failed';
                }

                const utr = statusData[utrField] || statusData.utr;

                // Update transaction if status changed
                if (newStatus !== 'processing') {
                    await prisma.payOutTransaction.update({
                        where: { id: tx.id },
                        data: {
                            status: newStatus,
                            utrNumber: utr || tx.utrNumber,
                            responseData: {
                                ...(tx.responseData as object || {}),
                                polledAt: new Date().toISOString(),
                                polledStatus: newStatus,
                                polledData: statusData
                            }
                        }
                    });

                    // Refund if failed
                    if (newStatus === 'failed') {
                        const wallet = await prisma.wallet.findUnique({
                            where: { userId: tx.userId }
                        });

                        if (wallet) {
                            const chargeInfo = (tx.responseData as any)?.chargeInfo;
                            const totalDebit = chargeInfo?.totalDebit
                                ? Number(chargeInfo.totalDebit)
                                : Number(tx.amount);

                            await prisma.wallet.update({
                                where: { userId: tx.userId },
                                data: { balance: { increment: Number(totalDebit) } }
                            });

                            const updatedWallet = await prisma.wallet.findUnique({ where: { userId: tx.userId } });

                            await prisma.walletTransactionLocal.create({
                                data: {
                                    walletId: wallet.id,
                                    userId: tx.userId,
                                    type: 'PAYOUT_REFUND',
                                    amount: Number(totalDebit),
                                    balanceAfter: updatedWallet?.balance || 0,
                                    chargeAmount: chargeInfo?.totalCharge ? Number(chargeInfo.totalCharge) : 0,
                                    referenceType: 'payout',
                                    referenceId: tx.id,
                                    description: `Status Poll Refund: Transaction failed`,
                                    metadata: { reason: 'status_poll_failed', polledData: statusData }
                                }
                            });
                        }
                    }
                }

                results.push({
                    id: tx.id,
                    previousStatus: tx.status,
                    newStatus,
                    utr: utr || null
                });

            } catch (pollError: any) {
                results.push({
                    id: tx.id,
                    status: 'error',
                    error: pollError.message
                });
            }
        }

        return NextResponse.json({
            success: true,
            polled: pendingTxs.length,
            results
        });

    } catch (error: any) {
        console.error('[Status Poll] Error:', error);
        return NextResponse.json({
            success: false,
            error: 'Failed to poll transactions',
            details: error.message
        }, { status: 500 });
    }
}

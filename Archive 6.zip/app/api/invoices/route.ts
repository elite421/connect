import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { auth } from "@/lib/auth";

export async function GET() {
  const session = await auth();
  const userId = (session as { user?: { id?: string } }).user?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const items = await prisma.invoice.findMany({ where: { userId }, orderBy: { issuedAt: "desc" } });
  return NextResponse.json(items.map(i => ({ id: i.id, number: i.number, amount: i.amount.toString(), currency: i.currency, status: i.status, issuedAt: i.issuedAt })));
}

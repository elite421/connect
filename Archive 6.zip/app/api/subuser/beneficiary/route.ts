import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const subUserId = searchParams.get('subUserId');
    const targetSubUserId = user.role === 'ADMIN' ? (subUserId || user.id) : user.id;

    const beneficiaries = await prisma.beneficiary.findMany({
      where: { subUserId: targetSubUserId },
      select: {
        id: true,
        accountName: true,
        accountNumber: true,
        bankName: true,
        ifscCode: true,
        upiId: true,
        beneficiaryType: true,
        isVerified: true,
      },
    });

    await logActivity({
      user,
      action: 'view_transactions',
      resource: 'beneficiary',
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: targetSubUserId,
    });

    return NextResponse.json({
      success: true,
      beneficiaries,
    });
  } catch (error) {
    console.error('GET /api/subuser/beneficiary error:', error);
    return NextResponse.json({ error: 'Failed to fetch beneficiaries' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const subUserId = searchParams.get('subUserId');
    const targetSubUserId = user.role === 'ADMIN' ? (subUserId || user.id) : user.id;

    const body = await req.json();
    const { name, account, ifsc } = body;

    if (!name || !account) {
      return NextResponse.json({ error: 'Name and account required' }, { status: 400 });
    }

    const sub = await prisma.subUser.findUnique({
      where: { id: targetSubUserId },
    });

    if (!sub) {
      return NextResponse.json({ error: 'SubUser not found' }, { status: 404 });
    }

    const beneficiary = await prisma.beneficiary.create({
      data: {
        subUserId: targetSubUserId,
        accountName: name,
        accountNumber: account,
        ifscCode: ifsc || '',
        bankName: '',
        beneficiaryType: ifsc ? 'bank' : 'upi',
      },
    });

    await logActivity({
      user,
      action: 'add_beneficiary',
      resource: 'beneficiary',
      resourceId: beneficiary.id,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: targetSubUserId,
    });

    return NextResponse.json({
      success: true,
      id: beneficiary.id,
      name: beneficiary.accountName,
      account: beneficiary.accountNumber,
      ifsc: beneficiary.ifscCode,
      isVerified: beneficiary.isVerified,
    });
  } catch (error) {
    console.error('POST /api/subuser/beneficiary error:', error);
    return NextResponse.json({ error: 'Failed to add beneficiary' }, { status: 500 });
  }
}

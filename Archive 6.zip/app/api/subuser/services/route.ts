import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { extractIpAddress, getUserAgent } from '@/lib/middleware';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const subUserId = searchParams.get('subUserId');

    if (!subUserId) {
      return NextResponse.json({ error: 'SubUser ID required' }, { status: 400 });
    }

    const services = await prisma.subUserService.findMany({
      where: { subUserId },
      include: {
        service: {
          select: {
            id: true,
            code: true,
            name: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      success: true,
      data: services,
    });
  } catch (error) {
    console.error('GET /api/subuser/services error:', error);
    return NextResponse.json({ error: 'Failed to fetch services' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { subUserId, serviceId, isActive, transactionCharge, transactionChargeType } = body;

    if (!subUserId || !serviceId) {
      return NextResponse.json({ error: 'SubUser ID and Service ID required' }, { status: 400 });
    }

    const existingService = await prisma.subUserService.findUnique({
      where: {
        subUserId_serviceId: { subUserId, serviceId },
      },
    });

    if (existingService) {
      return NextResponse.json(
        { error: 'Service already assigned to this subuser' },
        { status: 400 }
      );
    }

    const service = await prisma.subUserService.create({
      data: {
        subUserId,
        serviceId,
        isActive: isActive ?? true,
        transactionCharge: transactionCharge ?? 0,
        transactionChargeType: transactionChargeType ?? 'fixed',
      },
      include: {
        service: {
          select: {
            id: true,
            code: true,
            name: true,
          },
        },
      },
    });

    await logActivity({
      user,
      action: 'activate_service',
      resource: 'subuser_service',
      resourceId: service.id,
      metadata: { subUserId, serviceId, isActive },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: service,
      message: 'Service assigned successfully',
    });
  } catch (error) {
    console.error('POST /api/subuser/services error:', error);
    return NextResponse.json({ error: 'Failed to assign service' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { id, isActive, transactionCharge, transactionChargeType } = body;

    if (!id) {
      return NextResponse.json({ error: 'Service assignment ID required' }, { status: 400 });
    }

    const service = await prisma.subUserService.update({
      where: { id },
      data: {
        ...(isActive !== undefined && { isActive }),
        ...(transactionCharge !== undefined && { transactionCharge }),
        ...(transactionChargeType !== undefined && { transactionChargeType }),
      },
      include: {
        service: {
          select: {
            id: true,
            code: true,
            name: true,
          },
        },
      },
    });

    await logActivity({
      user,
      action: 'update_service_charges',
      resource: 'subuser_service',
      resourceId: id,
      metadata: { isActive, transactionCharge, transactionChargeType },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: service,
      message: 'Service updated successfully',
    });
  } catch (error) {
    console.error('PATCH /api/subuser/services error:', error);
    return NextResponse.json({ error: 'Failed to update service' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Service assignment ID required' }, { status: 400 });
    }

    await prisma.subUserService.delete({
      where: { id },
    });

    await logActivity({
      user,
      action: 'deactivate_service',
      resource: 'subuser_service',
      resourceId: id,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      message: 'Service removed successfully',
    });
  } catch (error) {
    console.error('DELETE /api/subuser/services error:', error);
    return NextResponse.json({ error: 'Failed to remove service' }, { status: 500 });
  }
}

import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { auth } from '@/lib/auth';
import { toRupees } from '@/lib/money';

export async function GET() {
  const session = await auth();
  const userId = (session?.user as { id?: string })?.id;

  if (!userId || (session?.user as { role?: string })?.role !== 'SUBUSER') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const subUserId = userId;

  try {
    let wallet = await prisma.walletsDb.findFirst({
      where: {
        ownerType: 'child' as any,
        ownerId: subUserId
      },
    });

    if (!wallet) {
      wallet = await prisma.walletsDb.create({
        data: {
          ownerType: 'child' as any,
          ownerId: subUserId,
          currency: 'INR',
          balance: 0
        },
      });
    }

    const [payouts, payins, pendingTransactions, transactions] = await Promise.all([
      prisma.payOutTransaction.aggregate({
        where: { subUserId, status: 'completed' },
        _sum: { amount: true },
      }),
      prisma.payOutTransaction.aggregate({
        where: { subUserId, status: 'success' },
        _sum: { amount: true },
      }),
      prisma.payOutTransaction.aggregate({
        where: { subUserId, status: { in: ['pending', 'processing'] } },
        _sum: { amount: true },
      }),
      prisma.walletTransaction.findMany({
        where: { walletId: wallet.id },
        orderBy: { createdAt: 'desc' },
        take: 10,
      }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        walletBalance: toRupees(wallet.balance),
        totalPayouts: toRupees(payouts._sum.amount || 0),
        totalPayins: toRupees(payins._sum.amount || 0),
        totalPending: toRupees(pendingTransactions._sum.amount || 0),
        currency: wallet.currency,
      },
      transactions: transactions.map((t) => ({
        id: t.id,
        txType: t.txType,
        amount: toRupees(t.amount).toString(),
        balanceAfter: toRupees(t.balanceAfter).toString(),
        currency: t.currency,
        createdAt: t.createdAt,
        referenceType: t.referenceType,
        referenceId: t.referenceId,
      })),
    });
  } catch (error: any) {
    console.error('Failed to fetch subuser wallet:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to fetch wallet' },
      { status: 500 }
    );
  }
}

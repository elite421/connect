import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { serializeBigInt } from '@/lib/bigint-serializer';
import { safeJson } from '@/lib/safe-json';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const timeRange = searchParams.get('range') || '30d';

    let startDate = new Date(0);
    const now = new Date();

    if (timeRange === 'today') {
      startDate = new Date(now.setHours(0, 0, 0, 0));
    } else if (timeRange === '7d') {
      startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else if (timeRange === '30d') {
      startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    }

    const [
      totalPayments,
      completedPayments,
      failedPayments,
      totalBeneficiaries,
      verifiedBeneficiaries,
      totalRevenue,
      monthlyPayments,
    ] = await Promise.all([
      prisma.payOutTransaction.count({
        where: {
          subUserId: user.id,
          createdAt: { gte: startDate }
        }
      }),
      prisma.payOutTransaction.count({
        where: {
          subUserId: user.id,
          status: { in: ['completed', 'success'] },
          createdAt: { gte: startDate }
        },
      }),
      prisma.payOutTransaction.count({
        where: {
          subUserId: user.id,
          status: { in: ['failed', 'rejected'] },
          createdAt: { gte: startDate }
        },
      }),
      prisma.beneficiary.count({
        where: {
          subUserId: user.id,
          createdAt: { gte: startDate }
        }
      }),
      prisma.beneficiary.count({
        where: {
          subUserId: user.id,
          isVerified: true,
          createdAt: { gte: startDate }
        },
      }),
      prisma.payOutTransaction.aggregate({
        _sum: { amount: true },
        where: {
          subUserId: user.id,
          status: { in: ['completed', 'success'] },
          createdAt: { gte: startDate }
        },
      }),
      prisma.payOutTransaction.count({
        where: {
          subUserId: user.id,
          createdAt: { gte: startDate },
        },
      }),
    ]);

    const paymentsByService = await prisma.payOutTransaction.groupBy({
      by: ['transferMode'],
      _count: true,
      _sum: { amount: true },
      where: {
        subUserId: user.id,
        createdAt: { gte: startDate }
      },
    });

    const analyticsData = {
      payments: {
        total: totalPayments,
        completed: completedPayments,
        failed: failedPayments,
        pending: totalPayments - completedPayments - failedPayments,
        successRate: totalPayments > 0 ? ((completedPayments / totalPayments) * 100).toFixed(2) : '0',
        monthlyCount: monthlyPayments,
      },
      beneficiaries: {
        total: totalBeneficiaries,
        verified: verifiedBeneficiaries,
        unverified: totalBeneficiaries - verifiedBeneficiaries,
      },
      revenue: {
        total: Number(totalRevenue._sum.amount || 0),
        averageTransaction: totalPayments > 0 ? (Number(totalRevenue._sum.amount || 0) / totalPayments) : 0,
      },
      paymentsByService: paymentsByService.map(item => ({
        serviceType: item.transferMode, // Map transferMode back to serviceType field expected by UI
        _count: item._count,
        _sum: {
          amount: Number(item._sum.amount || 0),
        },
      })),
    };

    await logActivity({
      user,
      action: 'view_analytics',
      resource: 'analytics',
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: user.id,
    });

    return safeJson({ success: true, data: serializeBigInt(analyticsData) });
  } catch (error) {
    console.error('GET /api/subuser/analytics error:', error);
    return safeJson(
      { error: 'Failed to fetch analytics' },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { generateTransactionReference } from '@/lib/security';
import { calculateTransactionCharge, deductChargeFromWallet, getWalletForService } from '@/lib/charge-calculator';
import { toPaise, toRupees } from '@/lib/money';

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const status = searchParams.get('status');

    const where: any = { subUserId: user.id };
    if (status) where.status = status;

    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where,
        include: {
          beneficiary: true,
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset,
      }),
      prisma.payment.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: payments.map((p) => ({
        ...p,
        amount: toRupees(p.amount), // Convert Paise to Rupees for display
        amountPaise: p.amount.toString(),
      })),
      pagination: { limit, offset, total, hasMore: offset + limit < total },
    });
  } catch (error) {
    console.error('GET /api/subuser/payments error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch payments' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { beneficiaryId, serviceType, amount, description } = body;

    if (!beneficiaryId || !serviceType || !amount) {
      return NextResponse.json(
        { error: 'Beneficiary ID, service type, and amount required' },
        { status: 400 }
      );
    }

    if (amount <= 0) {
      return NextResponse.json(
        { error: 'Amount must be greater than 0' },
        { status: 400 }
      );
    }

    const beneficiary = await prisma.beneficiary.findUnique({
      where: { id: beneficiaryId, subUserId: user.id },
    });

    if (!beneficiary) {
      return NextResponse.json(
        { error: 'Beneficiary not found' },
        { status: 404 }
      );
    }

    const subUser = await prisma.subUser.findUnique({
      where: { id: user.id },
    });

    if (!subUser) {
      return NextResponse.json({ error: 'SubUser not found' }, { status: 404 });
    }

    // Identify if amount is Rupees or Paise? Usually API input is Rupees.
    // So store as Paise.
    const amountInPaise = toPaise(amount);

    const payment = await prisma.payment.create({
      data: {
        subUserId: user.id,
        beneficiaryId,
        userId: subUser.userId,
        serviceType,
        amount: amountInPaise,
        currency: 'INR',
        status: 'pending',
        referenceId: generateTransactionReference(),
        metadata: {
          description,
          createdAt: new Date().toISOString(),
          originalAmountRupees: amount,
        },
      },
      include: { beneficiary: true },
    });

    await logActivity({
      user,
      action: 'create_payment',
      resource: 'payment',
      resourceId: payment.id,
      metadata: { serviceType, amount },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: user.id,
    });

    return NextResponse.json({
      success: true,
      data: {
        ...payment,
        amount: toRupees(payment.amount), // Return Rupees
        amountPaise: payment.amount.toString(),
      }
    }, { status: 201 });
  } catch (error) {
    console.error('POST /api/subuser/payments error:', error);
    return NextResponse.json(
      { error: 'Failed to create payment' },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { paymentId, status } = body;

    if (!paymentId || !status) {
      return NextResponse.json(
        { error: 'Payment ID and status required' },
        { status: 400 }
      );
    }

    if (!['pending', 'processing', 'completed', 'failed', 'cancelled'].includes(status)) {
      return NextResponse.json(
        { error: 'Invalid status' },
        { status: 400 }
      );
    }

    const payment = await prisma.payment.findUnique({
      where: { id: paymentId, subUserId: user.id },
      include: { subUser: true },
    });

    if (!payment) {
      return NextResponse.json(
        { error: 'Payment not found' },
        { status: 404 }
      );
    }

    const updatedPayment = await prisma.payment.update({
      where: { id: paymentId, subUserId: user.id },
      data: { status },
      include: { beneficiary: true },
    });

    let chargeResult: { success: boolean; error?: string } = { success: true };
    if (status === 'completed') {
      const parentUser = await prisma.user.findUnique({
        where: { id: payment.userId },
      });

      if (parentUser) {
        const userService = await prisma.userService.findFirst({
          where: {
            userId: payment.userId,
            service: { code: payment.serviceType.toUpperCase() },
          },
        });

        if (userService && userService.transactionCharge) {
          // Calculate charge on Paise amount directly?
          // calculateTransactionCharge expects amount (BigInt? No, it expects number usually previously).
          // But I updated `calculateTransactionCharge` to expect BigInt?
          // Let's check `lib/charge-calculator.ts` Step 105 summary: "Refactored ... to operate with bigint".
          // So I should pass Paise (BigInt).
          const transactionAmount = payment.amount; // BigInt
          const { charge } = await calculateTransactionCharge(userService.id, transactionAmount);

          if (charge > BigInt(0)) {
            const walletId = await getWalletForService(payment.userId, payment.serviceType.toUpperCase());

            if (walletId) {
              chargeResult = await deductChargeFromWallet(
                payment.userId,
                walletId,
                charge,
                payment.id,
                userService.transactionChargeType || 'fixed',
                parentUser,
                extractIpAddress(req),
                getUserAgent(req),
              );
            }
          }
        }
      }
    }

    const metadata: any = { status };
    if (!chargeResult.success && chargeResult.error) {
      metadata.chargeDeductionError = chargeResult.error;
    }

    await logActivity({
      user,
      action: 'update_payment',
      resource: 'payment',
      resourceId: paymentId,
      metadata,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
      subUserId: user.id,
    });

    return NextResponse.json({
      success: true,
      data: {
        ...updatedPayment,
        amount: toRupees(updatedPayment.amount),
        amountPaise: updatedPayment.amount.toString(),
      },
      chargeDeduction: chargeResult
    });
  } catch (error) {
    console.error('PATCH /api/subuser/payments error:', error);
    return NextResponse.json(
      { error: 'Failed to update payment' },
      { status: 500 }
    );
  }
}

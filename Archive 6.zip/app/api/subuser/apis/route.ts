import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { extractIpAddress, getUserAgent } from '@/lib/middleware';

interface SubUserAPI {
  id: string;
  code: string;
  baseUrl: string;
  apiKey?: string;
  apiSalt?: string;
  integrationMethod: 'manual' | 'ai';
  aiUrl?: string;
  aiApiKey?: string;
  isConfigured: boolean;
  status: 'ACTIVE' | 'INACTIVE' | 'ERROR';
  createdAt: Date;
}

export async function GET(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const subUserId = searchParams.get('subUserId');

    if (!subUserId) {
      return NextResponse.json({ error: 'SubUser ID required' }, { status: 400 });
    }

    const userApis = await prisma.userApi.findMany({
      where: {
        userId: subUserId,
      },
      select: {
        id: true,
        name: true,
        baseUrl: true,
        apiKey: true,
        apiSecret: true,
        isActive: true,
        createdAt: true,
      },
    });

    const apis = userApis.map((api: any) => ({
      id: api.id,
      code: api.name || 'unknown',
      baseUrl: api.baseUrl || '',
      isConfigured: !!api.apiKey || !!api.apiSecret,
      status: api.isActive ? 'ACTIVE' : 'INACTIVE',
      integrationMethod: 'manual' as const,
      createdAt: api.createdAt,
    }));

    return NextResponse.json({
      success: true,
      data: apis,
    });
  } catch (error) {
    console.error('GET /api/subuser/apis error:', error);
    return NextResponse.json({ error: 'Failed to fetch APIs' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      subUserId,
      code,
      baseUrl,
      apiKey,
      apiSalt,
      integrationMethod,
      aiUrl,
      aiApiKey,
    } = body;

    if (!subUserId || !code) {
      return NextResponse.json({ error: 'SubUser ID and code required' }, { status: 400 });
    }

    const apiData: any = {
      userId: subUserId,
      name: code,
      baseUrl: baseUrl || '',
      isActive: true,
    };

    if (integrationMethod === 'ai') {
      apiData.apiKey = aiUrl || '';
      apiData.apiSecret = aiApiKey || '';
    } else {
      apiData.apiKey = apiKey || '';
      apiData.apiSecret = apiSalt || '';
    }

    const newApi = await prisma.userApi.create({
      data: apiData,
    });

    await logActivity({
      user,
      action: 'add_api',
      resource: 'subuser_api',
      resourceId: newApi.id,
      metadata: { subUserId, code, integrationMethod },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: {
        id: newApi.id,
        code: newApi.name,
        baseUrl: newApi.baseUrl,
        isConfigured: !!newApi.apiKey || !!newApi.apiSecret,
        status: newApi.isActive ? 'ACTIVE' : 'INACTIVE',
        integrationMethod,
      },
      message: 'API integration added successfully',
    });
  } catch (error) {
    console.error('POST /api/subuser/apis error:', error);
    return NextResponse.json({ error: 'Failed to add API' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { id, baseUrl, apiKey, apiSalt, aiUrl, aiApiKey, integrationMethod } = body;

    if (!id) {
      return NextResponse.json({ error: 'API ID required' }, { status: 400 });
    }

    const updateData: any = {};

    if (baseUrl !== undefined) updateData.baseUrl = baseUrl;
    if (integrationMethod === 'ai') {
      if (aiUrl !== undefined) updateData.apiKey = aiUrl;
      if (aiApiKey !== undefined) updateData.apiSecret = aiApiKey;
    } else {
      if (apiKey !== undefined) updateData.apiKey = apiKey;
      if (apiSalt !== undefined) updateData.apiSecret = apiSalt;
    }

    const updatedApi = await prisma.userApi.update({
      where: { id },
      data: updateData,
    });

    await logActivity({
      user,
      action: 'update_api',
      resource: 'subuser_api',
      resourceId: id,
      metadata: { integrationMethod },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: {
        id: updatedApi.id,
        code: updatedApi.name,
        baseUrl: updatedApi.baseUrl,
        isConfigured: !!updatedApi.apiKey || !!updatedApi.apiSecret,
        status: updatedApi.isActive ? 'ACTIVE' : 'INACTIVE',
        integrationMethod,
      },
      message: 'API integration updated successfully',
    });
  } catch (error) {
    console.error('PATCH /api/subuser/apis error:', error);
    return NextResponse.json({ error: 'Failed to update API' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const user = await authMiddleware(req, ['ADMIN']);
  if (user instanceof NextResponse) return user;

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'API ID required' }, { status: 400 });
    }

    await prisma.userApi.delete({
      where: { id },
    });

    await logActivity({
      user,
      action: 'delete_api',
      resource: 'subuser_api',
      resourceId: id,
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      message: 'API integration removed successfully',
    });
  } catch (error) {
    console.error('DELETE /api/subuser/apis error:', error);
    return NextResponse.json({ error: 'Failed to remove API' }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const { memberId, gatewayName = 'marketingllp' } = body;

    if (!memberId) {
      return NextResponse.json(
        { error: 'Member ID required' },
        { status: 400 }
      );
    }

    const userApis = await prisma.userApi.findMany({
      where: { userId: user.id, isActive: true },
    });

    const selectedApi = userApis.find(api => api.name?.toLowerCase().includes(gatewayName.toLowerCase()));
    if (!selectedApi || !selectedApi.apiKey) {
      return NextResponse.json(
        { error: 'Payment gateway not configured' },
        { status: 400 }
      );
    }

    const gatewayUrl = selectedApi.baseUrl || 'https://marketingllp.in/Api/Balance';
    const token = selectedApi.apiKey;

    const balanceResponse = await fetch(gatewayUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Token': token,
      },
      body: JSON.stringify({ MerchantId: memberId }),
    });

    const gatewayData = await balanceResponse.json();

    if (!balanceResponse.ok || gatewayData.resultFlag !== 1) {
      return NextResponse.json(
        { error: gatewayData.message || 'Failed to fetch balance' },
        { status: 400 }
      );
    }

    await logActivity({
      user,
      action: 'view_wallet',
      resource: 'gateway',
      metadata: { gateway: gatewayName, memberId, balance: gatewayData.data?.balance },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: {
        balance: gatewayData.data?.balance || 0,
        currency: 'INR',
        message: gatewayData.message,
      },
    });
  } catch (error) {
    console.error('POST /api/gateway/balance error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch balance' },
      { status: 500 }
    );
  }
}

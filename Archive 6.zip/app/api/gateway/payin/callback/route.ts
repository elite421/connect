import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { statusCode, message, orderId, Utr, PayerAmount, PayerVA } = body;

    const transaction = await prisma.payInTransaction.findFirst({
      where: { merchantTransactionId: orderId },
    });

    if (!transaction) {
      console.warn(`PayIn callback received for unknown transaction: ${orderId}`);
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
    }

    const isSuccess = statusCode === 200 && message === 'SUCCESS';

    const existingData = typeof transaction.responseData === 'object' && transaction.responseData ? transaction.responseData : {};
    
    await prisma.payInTransaction.update({
      where: { id: transaction.id },
      data: {
        status: isSuccess ? 'completed' : 'failed',
        utrNumber: Utr,
        responseData: {
          ...(existingData as Record<string, any>),
          callbackResponse: {
            statusCode,
            message,
            orderId,
            Utr,
            PayerAmount,
            PayerVA,
            receivedAt: new Date().toISOString(),
          },
        },
      },
    });

    if (isSuccess) {
      await prisma.subUserTransaction.create({
        data: {
          subUserId: transaction.userId,
          userId: transaction.userId,
          type: 'credit',
          amount: transaction.amount,
          currency: 'INR',
          description: `PayIn from ${PayerVA} for ₹${PayerAmount}`,
          relatedPaymentId: transaction.id,
          status: 'completed',
        },
      });
    }

    return NextResponse.json({
      success: true,
      message: 'Callback processed',
    });
  } catch (error) {
    console.error('POST /api/gateway/payin/callback error:', error);
    return NextResponse.json(
      { error: 'Failed to process callback' },
      { status: 500 }
    );
  }
}

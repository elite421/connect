import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { authMiddleware, extractIpAddress, getUserAgent } from '@/lib/middleware';
import { logActivity } from '@/lib/audit';
import { toPaise } from '@/lib/money';

export async function POST(req: NextRequest) {
  const user = await authMiddleware(req, ['USER', 'SUBUSER']);
  if (user instanceof NextResponse) return user;

  try {
    const body = await req.json();
    const {
      memberId,
      accountNumber,
      ifscCode,
      name,
      amount,
      email,
      mobile,
      bankName,
      orderId,
      address = '',
      gatewayName = 'marketingllp'
    } = body;

    if (!memberId || !accountNumber || !ifscCode || !name || !amount || !bankName || !orderId) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const userApis = await prisma.userApi.findMany({
      where: { userId: user.id, isActive: true },
    });

    const selectedApi = userApis.find(api => api.name?.toLowerCase().includes(gatewayName.toLowerCase()));
    if (!selectedApi || !selectedApi.apiKey) {
      return NextResponse.json(
        { error: 'Payment gateway not configured' },
        { status: 400 }
      );
    }

    const gatewayUrl = selectedApi.baseUrl || 'https://marketingllp.in/api/Payout/Payment';
    const token = selectedApi.apiKey;

    const payoutResponse = await fetch(gatewayUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Token': token,
      },
      body: JSON.stringify({
        MemberId: memberId,
        account_number: accountNumber,
        ifsc_code: ifscCode,
        name,
        amount, // Sending Rupees to gateway
        email: email || '',
        mobile_number: mobile || '',
        BankName: bankName,
        merchant_order_id: orderId,
        address: address || '',
      }),
    });

    const gatewayData = await payoutResponse.json();

    if (!payoutResponse.ok) {
      await logActivity({
        user,
        action: 'update_payment',
        resource: 'payout',
        status: 'failure',
        metadata: { error: gatewayData.message, orderId },
        ipAddress: extractIpAddress(req),
        userAgent: getUserAgent(req),
      });

      return NextResponse.json(
        { error: gatewayData.message || 'Payout initiation failed' },
        { status: 400 }
      );
    }

    const payoutTransaction = await prisma.payOutTransaction.create({
      data: {
        userId: user.id,
        subUserId: user.role === 'SUBUSER' ? user.id : undefined,
        amount: toPaise(amount),
        beneficiaryName: name,
        beneficiaryAccount: accountNumber,
        beneficiaryIfsc: ifscCode,
        transferMode: 'neft',
        status: gatewayData.data?.status === 1 ? 'processing' : 'pending',
        ipAddress: extractIpAddress(req),
        updatedAt: new Date(),
      },
    });

    await logActivity({
      user,
      action: 'update_payment',
      resource: 'payout',
      resourceId: payoutTransaction.id,
      status: 'success',
      metadata: { orderId, amount, accountNumber, gatewayName },
      ipAddress: extractIpAddress(req),
      userAgent: getUserAgent(req),
    });

    return NextResponse.json({
      success: true,
      data: {
        transactionId: payoutTransaction.id,
        externalTransactionId: gatewayData.data?.trxId,
        orderId,
        amount,
        status: payoutTransaction.status,
      },
    });
  } catch (error) {
    console.error('POST /api/gateway/payout/initiate error:', error);
    return NextResponse.json(
      { error: 'Failed to initiate payout' },
      { status: 500 }
    );
  }
}

import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { auth } from "@/lib/auth";

export async function GET() {
  const session = await auth();
  const userId = (session as { user?: { id?: string } }).user?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const items = await prisma.allowedIp.findMany({ where: { userId } });
  return NextResponse.json(items.map(i => ({ id: i.id, cidr: i.cidr })));
}

export async function POST(req: Request) {
  const session = await auth();
  const userId = (session as { user?: { id?: string } }).user?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const ip = typeof body.ip === "string" ? body.ip.trim() : "";
  if (!ip) return NextResponse.json({ error: "Invalid" }, { status: 400 });
  const cidr = `${ip}/32`;
  const created = await prisma.allowedIp.create({ data: { userId, cidr } });
  return NextResponse.json({ id: created.id }, { status: 201 });
}

export async function DELETE(req: Request) {
  const session = await auth();
  const userId = (session as { user?: { id?: string } }).user?.id;
  if (!userId) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id") || "";
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });
  const item = await prisma.allowedIp.findFirst({ where: { id, userId } });
  if (!item) return NextResponse.json({ error: "Not found" }, { status: 404 });
  await prisma.allowedIp.delete({ where: { id } });
  return NextResponse.json({ success: true });
}

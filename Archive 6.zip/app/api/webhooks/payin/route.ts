import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { logActivity } from '@/lib/audit';

import { getUserAgent, extractIpAddress } from '@/lib/middleware';

function normalizeStatus(payload: any) {
  const status =
    payload?.status ||
    payload?.Status ||
    payload?.state ||
    payload?.payment_status ||
    payload?.paymentStatus ||
    payload?.result ||
    '';
  const message =
    (payload?.message ||
      payload?.msg ||
      payload?.response ||
      payload?.status_text ||
      '') + '';

  const combined = `${status}`.toLowerCase() + message.toLowerCase();

  if (combined.includes('success') || combined.includes('completed') || combined.includes('paid')) {
    return 'completed';
  }
  if (combined.includes('processing') || combined.includes('pending')) {
    return 'processing';
  }
  return 'failed';
}

function extractReference(payload: any) {
  return (
    payload?.orderId ||
    payload?.orderid ||
    payload?.merchantTransactionId ||
    payload?.transactionId ||
    payload?.trxId ||
    payload?.referenceId ||
    payload?.reference ||
    payload?.payment_id ||
    null
  );
}

export async function POST(req: NextRequest) {
  try {
    const payload = await req.json();
    const reference = extractReference(payload);

    if (!reference) {
      return NextResponse.json(
        { success: false, error: 'Missing transaction reference (orderId/transactionId)' },
        { status: 400 }
      );
    }

    const transaction =
      (await prisma.payInTransaction.findFirst({
        where: { merchantTransactionId: reference },
      })) ||
      (await prisma.payInTransaction.findUnique({
        where: { id: reference },
      }));

    if (!transaction) {
      return NextResponse.json(
        { success: false, error: 'Transaction not found' },
        { status: 404 }
      );
    }

    const finalStatus = normalizeStatus(payload);

    await prisma.payInTransaction.update({
      where: { id: transaction.id },
      data: {
        status: finalStatus,
        merchantTransactionId: transaction.merchantTransactionId || reference,
      },
    });

    const user = await prisma.user.findUnique({ where: { id: transaction.userId } });
    if (user) {
      await logActivity({
        user,
        action: 'payin_callback',
        resource: 'payin',
        resourceId: transaction.id,
        status: finalStatus === 'completed' ? 'success' : 'failure',
        metadata: { reference, payload },
        ipAddress: extractIpAddress(req),
        userAgent: getUserAgent(req),
      });
    }

    return NextResponse.json({
      success: true,
      status: finalStatus,
      transaction: { ...transaction, status: finalStatus },
      message:
        finalStatus === 'completed'
          ? payload?.message || 'Payment completed'
          : payload?.message || 'Payment failed',
    });
  } catch (error: any) {
    console.error('POST /api/webhooks/payin error:', error);
    return NextResponse.json(
      { success: false, error: error.message || 'Failed to process callback' },
      { status: 500 }
    );
  }
}

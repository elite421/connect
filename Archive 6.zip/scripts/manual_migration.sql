-- Manual Migration Script: Convert Decimal Columns to BigInt (Paise)
-- This script multiplies existing Decimal values by 100 to convert Rupees to Paise
-- and changes the column type to BIGINT.

BEGIN;

-- AdminWallet
ALTER TABLE "AdminWallet" ALTER COLUMN "balance" TYPE BIGINT USING ("balance" * 100)::BIGINT;

-- Invoice
ALTER TABLE "Invoice" ALTER COLUMN "amount" TYPE BIGINT USING ("amount" * 100)::BIGINT;

-- MerchantConfig
ALTER TABLE "MerchantConfig" ALTER COLUMN "minAmount" TYPE BIGINT USING ("minAmount" * 100)::BIGINT;
ALTER TABLE "MerchantConfig" ALTER COLUMN "maxAmount" TYPE BIGINT USING ("maxAmount" * 100)::BIGINT;
ALTER TABLE "MerchantConfig" ALTER COLUMN "dailyLimit" TYPE BIGINT USING ("dailyLimit" * 100)::BIGINT;
ALTER TABLE "MerchantConfig" ALTER COLUMN "monthlyLimit" TYPE BIGINT USING ("monthlyLimit" * 100)::BIGINT;

-- PayInTransaction
ALTER TABLE "PayInTransaction" ALTER COLUMN "amount" TYPE BIGINT USING ("amount" * 100)::BIGINT;

-- PayOutTransaction
ALTER TABLE "PayOutTransaction" ALTER COLUMN "amount" TYPE BIGINT USING ("amount" * 100)::BIGINT;

-- Payment
ALTER TABLE "Payment" ALTER COLUMN "amount" TYPE BIGINT USING ("amount" * 100)::BIGINT;

-- PaymentLink
ALTER TABLE "PaymentLink" ALTER COLUMN "amount" TYPE BIGINT USING ("amount" * 100)::BIGINT;

-- Payout
ALTER TABLE "Payout" ALTER COLUMN "amount" TYPE BIGINT USING ("amount" * 100)::BIGINT;

-- Settlement
ALTER TABLE "Settlement" ALTER COLUMN "amount" TYPE BIGINT USING ("amount" * 100)::BIGINT;
ALTER TABLE "Settlement" ALTER COLUMN "fee" TYPE BIGINT USING ("fee" * 100)::BIGINT;
ALTER TABLE "Settlement" ALTER COLUMN "netAmount" TYPE BIGINT USING ("netAmount" * 100)::BIGINT;

-- SubUserTransaction
ALTER TABLE "SubUserTransaction" ALTER COLUMN "amount" TYPE BIGINT USING ("amount" * 100)::BIGINT;

-- TransactionFeeLog
ALTER TABLE "TransactionFeeLog" ALTER COLUMN "feeAmount" TYPE BIGINT USING ("feeAmount" * 100)::BIGINT;
ALTER TABLE "TransactionFeeLog" ALTER COLUMN "originalAmount" TYPE BIGINT USING ("originalAmount" * 100)::BIGINT;
ALTER TABLE "TransactionFeeLog" ALTER COLUMN "netAmount" TYPE BIGINT USING ("netAmount" * 100)::BIGINT;

-- VirtualAccount
ALTER TABLE "VirtualAccount" ALTER COLUMN "balance" TYPE BIGINT USING ("balance" * 100)::BIGINT;

-- Wallet
ALTER TABLE "Wallet" ALTER COLUMN "balance" TYPE BIGINT USING ("balance" * 100)::BIGINT;
ALTER TABLE "Wallet" ALTER COLUMN "frozenBalance" TYPE BIGINT USING ("frozenBalance" * 100)::BIGINT;

-- plans (mapped table name)
ALTER TABLE "plans" ALTER COLUMN "base_per_hit_price" TYPE BIGINT USING ("base_per_hit_price" * 100)::BIGINT;

-- wallets (mapped table name for WalletsDb)
ALTER TABLE "wallets" ALTER COLUMN "balance" TYPE BIGINT USING ("balance" * 100)::BIGINT;

-- wallet_transactions (mapped table name for WalletTransaction)
ALTER TABLE "wallet_transactions" ALTER COLUMN "amount" TYPE BIGINT USING ("amount" * 100)::BIGINT;
ALTER TABLE "wallet_transactions" ALTER COLUMN "balance_after" TYPE BIGINT USING ("balance_after" * 100)::BIGINT;

COMMIT;

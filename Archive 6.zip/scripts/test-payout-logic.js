
// Mock logic manually since we can't import TS files in Node easily without compilation
// Copy-pasting logic from lib/money.ts

function toPaise(rupees) {
    const value = typeof rupees === 'string' ? parseFloat(rupees) : rupees;
    if (isNaN(value)) return 0n;
    // Multiply by 100 and round to handle floating point errors like 10.5 * 100 = 104.9999...
    return BigInt(Math.round(value * 100));
}

function toRupees(paise) {
    if (paise === null || paise === undefined) return 0;
    const value = typeof paise === 'bigint' ? Number(paise) : paise;
    return value / 100;
}

function simulatePayout(amount) {
    console.log(`\n--- Simulation for Input: ${amount} (${typeof amount}) ---`);

    // 1. Logic from route.ts
    const amountInPaise = toPaise(amount);
    console.log(`Stored in DB (Paise): ${amountInPaise}n`);

    const charge = 2; // Assume 2 Rs charge
    const chargeInPaise = toPaise(charge);
    const totalDebit = amountInPaise + chargeInPaise;
    console.log(`Wallet Debit (Paise): ${totalDebit}n`);
    console.log(`Wallet Debit (Rupees): ${toRupees(totalDebit)}`);

    const payoutAmountMajor = Number(amount);
    console.log(`Sent to API (Rupees): ${payoutAmountMajor}`);

    if (payoutAmountMajor !== Number(amount)) {
        console.error("ALARM: API Amount matches entered amount? NO!");
    } else {
        console.log("Check: API Amount matches entered amount? YES");
    }
}

simulatePayout(100);
simulatePayout("100");
simulatePayout(100.50);
simulatePayout("100.50");
simulatePayout("100.123456");

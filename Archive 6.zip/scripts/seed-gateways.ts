import { PrismaClient } from '@prisma/client';
import { PRESET_GATEWAYS } from '../lib/preset-gateways';

const prisma = new PrismaClient();

async function seedGateways() {
  console.log('🌱 Seeding payment gateways...');

  try {
    for (const gateway of PRESET_GATEWAYS) {
      const existing = await prisma.paymentGateway.findUnique({
        where: { code: gateway.code },
      });

      if (existing) {
        console.log(`⏭️  Gateway ${gateway.code} already exists, skipping...`);
        continue;
      }

      const created = await prisma.paymentGateway.create({
        data: gateway,
      });

      console.log(`✅ Created gateway: ${created.name} (${created.code})`);
    }

    console.log(`\n✨ Successfully seeded ${PRESET_GATEWAYS.length} payment gateways!`);
  } catch (error) {
    console.error('❌ Error seeding gateways:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

seedGateways();


import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function checkApi() {
    const userId = 'cmj13r86w0000m0rqaqdat942'; // From previous logs
    console.log(`Checking APIs for user: ${userId}`);

    const customPaymentApis = await prisma.customPaymentApi.findMany({
        where: { userId },
    });
    console.log('CustomPaymentApis:', JSON.stringify(customPaymentApis, null, 2));

    const adminApis = await prisma.adminApi.findMany({
        where: { isActive: true },
    });
    console.log('AdminApis:', JSON.stringify(adminApis, null, 2));
}

checkApi()
    .catch(e => console.error(e))
    .finally(async () => {
        await prisma.$disconnect();
    });

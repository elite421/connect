import fetch from 'node-fetch';

const BASE_DOMAIN = 'https://pay.fingrowaitech.com/transaction';
const MERCHANT_ID = 'TEST_MERCHANT';

// We explicitly list the paths relative to the BASE_DOMAIN
// Fingrow uses: BASE + /transactions/api/initiate
// This results in: https://pay.fingrowaitech.com/transaction/transactions/api/initiate
const commonPaths = [
    // Verify if the base works AT ALL using the status check endpoint
    '/transactions/chkTxnstatus',
    '/chkTxnstatus',

    // New guesses based on 'chkTxnstatus' naming style
    '/transactions/initTxn',
    '/transactions/initiateTxn',
    '/transactions/initiateTransaction',
    '/api/initTxn',

    '/transactions/api/initiate', // The documented one (Double transaction?)
    '/api/initiate',
    '/initiate',
    '/transactions/initiate',
    '/api/v1/initiate',
    '/pnbtransaction/api/initiateMerchantTxn',
    '/transactions/api/v1/initiate',

    // Common Payout Variations
    '/transactions/initiatePayout',
    '/api/initiatePayout',
    '/transactions/payout',
    '/api/payout',
    '/transactions/transfer',
    '/api/transfer',
    '/transactions/pay',
];

// Secondary Base to test (Removing the first /transaction)
const ALT_BASE_DOMAIN = 'https://pay.fingrowaitech.com';
const API_BASE_DOMAIN = 'https://api.fingrowaitech.com';

async function probe() {
    console.log(`Starting probe...\n`);

    const bases = [BASE_DOMAIN, ALT_BASE_DOMAIN, API_BASE_DOMAIN];

    for (const base of bases) {
        console.log(`Testing against base: ${base}`);
        for (const path of commonPaths) {
            const url = `${base}${path}`;
            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'text/plain',
                        'channel': 'FNZ', // Updated to FNZ
                        'merchantId': MERCHANT_ID,
                        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    },
                    body: 'DUMMY_ENCRYPTED_PAYLOAD'
                });

                const status = response.status;
                const text = await response.text();
                const isHtml = text.trim().toLowerCase().startsWith('<!doctype html') || text.trim().toLowerCase().startsWith('<html');

                let result = `[${status}] ${url}`; // Log full URL now

                if (status === 200 && isHtml) {
                    result += ' (Likely Frontend Page)';
                } else if (status === 405) {
                    // result += ' (Method Not Allowed)';
                } else if (status === 404) {
                    // result += ' (Not Found)';
                } else {
                    // INTERESTING RESULT
                    console.log(`\n🎉 POSSIBLE MATCH FOUND: ${result}`);
                    console.log(`Response Preview: ${text.substring(0, 100)}\n`);
                }

                // Log everything for now
                console.log(result);

            } catch (err) {
                console.log(`[ERR] ${url}: ${(err as any)?.message || String(err)}`);
            }
        }
    }
    console.log('\nProbe complete.');
}

probe();

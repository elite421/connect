
import { executeFingrowTransaction } from '../lib/fingrow-integration';

async function testLive() {
    console.log('--- Starting Fingrow LIVE Test ---');

    const merchantId = 'TEST_MERCHANT_123'; // Replace with actual if user provided one, or keep generic for 401 check
    // Note: User provided 'MERCHXKXLA992925' in previous logs. Let's use that one for a better test?
    // User Log: merchantId: MERCHXKXLA992925
    const REAL_MERCHANT_ID = 'MERCHXKXLA992925';

    // We purposely use the WRONG URL to test the AUTO-FIX logic
    const WRONG_URL = 'https://pay.fingrowaitech.com/transaction/transactions/api/initiate';

    // We can also test with the RIGHT URL to be sure
    const RIGHT_URL = 'https://pay.fingrowaitech.com/transaction/api/initiate';

    const payload = {
        amount: 100,
        beneficiaryName: 'Test Verify User',
        beneficiaryAccount: '999988887777', // Dummy
        beneficiaryIfsc: 'SBIN0001234',
        beneficiaryVpa: 'test@upi', // Should be ignored/mapped properly
        transferMode: 'IMPS', // This triggers 'paymentMode: IMPS' header
        merchantTransactionId: `TEST_LIVE_${Date.now()}`,
        channel: 'FNZ',
        // mobile_number provided in recent request: 9756862551
        // But our function doesn't take 'mobile_number' directly in the 'request' arg, it takes 'beneficiaryVpa' which we overload?
        // Wait, looking at executeFingrowTransaction signature:
        // request: { amount, beneficiaryName, beneficiaryAccount, beneficiaryIfsc, beneficiaryVpa, transferMode, merchantTransactionId, ipAddress ... }
        // It does NOT have a separate mobile number field in the signature?
        // Let's check lib/fingrow-integration.ts again.
        // It maps `mobileNo` from `mobileNoCandidate = request.beneficiaryVpa || '';`
        // So for the test to work with a mobile number, we must pass it in `beneficiaryVpa`.
        // But user provided a distinct `mobile_number` in the Admin UI test payload.
        // I need to check how `custom-apis/page.tsx` calls `executeFingrowTransaction`.
        // If it passes `mobile_number` from the UI into `executeFingrowTransaction`?
        // I might have missed updating the specific signature of `executeFingrowTransaction` to accept `mobileNumber`.
    };

    console.log('Testing with Merchant ID:', REAL_MERCHANT_ID);

    // Check signature before running...
    // I suspect I need to update the signature of executeFingrowTransaction first if I want to pass a dedicated mobile number.
    // But for now, let's try running it as is.

    // Use the WRONG URL to prove the auto-fix works
    console.log('\n[Test 1] Executing with potentially WRONG URL (expecting Auto-Fix)...');
    try {
        const result = await executeFingrowTransaction(
            REAL_MERCHANT_ID,
            WRONG_URL,
            {
                ...payload,
                beneficiaryVpa: '9756862551' // Passing mobile number here as fallback?
            }
        );
        console.log('\nResult:', JSON.stringify(result, null, 2));
    } catch (err) {
        console.error('Test Failed:', err);
    }
}

testLive();

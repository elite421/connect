
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

// Basic .env parser
function loadEnv() {
    try {
        const envPath = path.join(__dirname, '..', '.env');
        if (fs.existsSync(envPath)) {
            const content = fs.readFileSync(envPath, 'utf8');
            const lines = content.split('\n');
            for (const line of lines) {
                const trimmed = line.trim();
                if (!trimmed || trimmed.startsWith('#')) continue;
                const [key, ...valParts] = trimmed.split('=');
                if (key && valParts.length > 0) {
                    let val = valParts.join('=');
                    // Remove quotes if present
                    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
                        val = val.slice(1, -1);
                    }
                    if (!process.env[key]) {
                        process.env[key] = val;
                    }
                }
            }
        }
    } catch (e) {
        console.warn('Failed to load .env', e);
    }
}

loadEnv();

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
    console.error('DATABASE_URL not found in environment');
    process.exit(1);
}

console.log('Running manual migration...');
const psql = spawn('psql', [databaseUrl, '-f', 'scripts/manual_migration.sql'], {
    stdio: 'inherit'
});

psql.on('close', (code) => {
    if (code !== 0) {
        console.error(`Migration failed with exit code ${code}`);
        process.exit(code);
    }
    console.log('Migration completed successfully.');
    process.exit(0);
});


import { FingrowEncryption } from '@/lib/fingrow-encryption';

// CONFIGURATION
const MERCHANT_ID = 'TEST_MERCHANT_123';
const API_URL = 'https://pay.fingrowaitech.com/transaction/api/initiate'; // Corrected URL

// 1. Define the Plain JSON Payload (Spec Compliant)
const plainPayload = {
    merchantTxnOrderId: `TEST_${Date.now()}`,
    transactionType: 'IMPS',
    creditAccountNumber: '1234567890',
    amount: '100.00',
    beneficiaryName: 'Test Beneficiary',
    beneficiaryIFSC: 'SBIN0001234',
    mobileNo: '9999999999',
    paymentDescription: 'Test Payout Transaction',
    currency: 'INR'
};

console.log('\n--- 1. Plain Payload (Before Encryption) ---');
console.log(JSON.stringify(plainPayload, null, 2));

// 2. Encrypt the Payload
// Use proper key derivation as per Fingrow specs (SHA-256 of merchantId -> AES-256-CBC)
const encryptedData = FingrowEncryption.encryptMerchantSec(
    JSON.stringify(plainPayload),
    MERCHANT_ID
);

if (!encryptedData) {
    console.error('Encryption failed!');
    process.exit(1);
}

// 3. Generate the Curl Command
const curlCommand = `curl -v -X POST '${API_URL}' \\
  -H 'merchantId: ${MERCHANT_ID}' \\
  -H 'channel: FNZ' \\
  -H 'paymentMode: IMPS' \\
  -H 'Content-Type: text/plain' \\
  --data-raw '${encryptedData}'`;

console.log('\n--- 2. Generated CURL Command ---');
console.log(curlCommand);
console.log('\n---------------------------------\n');

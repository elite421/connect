import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Silence root detection warning when multiple lockfiles exist in parent dirs
  // See: https://nextjs.org/docs/app/api-reference/config/next-config-js/turbopack#root-directory
  turbopack: {
    root: __dirname,
  },
  async redirects() {
    return [
      {
        source: "/",
        destination: "/account/dashboard",
        permanent: false,
      },
      {
        source: "/dashboard",
        destination: "/account/dashboard",
        permanent: false,
      },
      {
        source: "/banking",
        destination: "/account/banking",
        permanent: false,
      },
      {
        source: "/account/admin/gateway-management",
        destination: "/account/admin/gateways",
        permanent: true,
      },
    ];
  },
};

export default nextConfig;
// Force restart: 1

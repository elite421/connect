-- Enable useful extensions
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

-- Enums
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'wallet_tx_type') THEN
    CREATE TYPE wallet_tx_type AS ENUM ('credit','debit','refund','hold','release');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'subscription_status') THEN
    CREATE TYPE subscription_status AS ENUM ('active','past_due','canceled','incomplete');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'invoice_status') THEN
    CREATE TYPE invoice_status AS ENUM ('draft','open','paid','void','uncollectible','refunded');
  END IF;
END$$;

-- Tenants
CREATE TABLE IF NOT EXISTS tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Roles
CREATE TABLE IF NOT EXISTS roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT UNIQUE NOT NULL, -- admin, owner, child
  description TEXT
);

-- Users
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
  email CITEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role_id UUID REFERENCES roles(id),
  mfa_enabled BOOLEAN NOT NULL DEFAULT false,
  mfa_totp_secret_encrypted TEXT, -- AES-GCM JSON string
  parent_user_id UUID REFERENCES users(id), -- optional linkage
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_login_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role_id);

-- Children (client profiles; may link to a child-role user)
CREATE TABLE IF NOT EXISTS children (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  user_id UUID REFERENCES users(id), -- optional bound user
  owner_user_id UUID REFERENCES users(id),
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_children_tenant ON children(tenant_id);

-- Wallets
CREATE TABLE IF NOT EXISTS wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_type TEXT NOT NULL CHECK (owner_type IN ('tenant','user','child')),
  owner_id UUID NOT NULL,
  currency CHAR(3) NOT NULL CHECK (currency IN ('USD','INR')),
  balance BIGINT NOT NULL DEFAULT 0, -- minor units
  version INT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (owner_type, owner_id, currency)
);
CREATE INDEX IF NOT EXISTS idx_wallets_owner ON wallets(owner_type, owner_id);

-- Wallet Transactions (ledger)
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id UUID NOT NULL REFERENCES wallets(id) ON DELETE CASCADE,
  tx_type wallet_tx_type NOT NULL,
  amount BIGINT NOT NULL CHECK (amount >= 0),
  balance_after BIGINT NOT NULL,
  currency CHAR(3) NOT NULL CHECK (currency IN ('USD','INR')),
  reference_type TEXT, -- e.g. 'api_call','invoice','refund','webhook'
  reference_id UUID,
  idempotency_key TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (wallet_id, idempotency_key) -- ensures idempotency per wallet
);
CREATE INDEX IF NOT EXISTS idx_wallet_tx_wallet ON wallet_transactions(wallet_id, created_at);

-- Integrations (definitions reused)
CREATE TABLE IF NOT EXISTS integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL, -- stable slug e.g., 'transfer_api_v1'
  name TEXT NOT NULL,
  base_url TEXT NOT NULL,
  endpoints JSONB NOT NULL, -- { perform: "/v1/payouts", ... }
  request_mapping JSONB NOT NULL DEFAULT '{}'::jsonb,
  response_mapping JSONB NOT NULL DEFAULT '{}'::jsonb,
  webhook_config JSONB NOT NULL DEFAULT '{}'::jsonb,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Integration Credentials (per tenant/child)
CREATE TABLE IF NOT EXISTS integration_credentials (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  integration_id UUID NOT NULL REFERENCES integrations(id) ON DELETE CASCADE,
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  child_id UUID REFERENCES children(id) ON DELETE CASCADE,
  credentials_encrypted TEXT NOT NULL, -- AES-GCM JSON
  kms_key_version INT NOT NULL DEFAULT 1,
  rate_card JSONB NOT NULL DEFAULT '{}'::jsonb, -- { per_hit_price_cents: 50 }
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (integration_id, tenant_id, child_id)
);
CREATE INDEX IF NOT EXISTS idx_intcred_tenant ON integration_credentials(tenant_id, child_id);

-- API Calls (audit + billing linkage)
CREATE TABLE IF NOT EXISTS api_calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  child_id UUID REFERENCES children(id) ON DELETE SET NULL,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  integration_id UUID NOT NULL REFERENCES integrations(id),
  integration_credential_id UUID REFERENCES integration_credentials(id),
  wallet_id UUID REFERENCES wallets(id),
  client_ip INET,
  request JSONB NOT NULL,
  response JSONB,
  status_code INT,
  success BOOLEAN,
  price_per_hit BIGINT,  -- planned charge
  billed_amount BIGINT,  -- finalized charge
  idempotency_key TEXT,
  external_id TEXT, -- provider ref
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, child_id, idempotency_key)
);
CREATE INDEX IF NOT EXISTS idx_api_calls_tenant_time ON api_calls(tenant_id, created_at DESC);

-- Plans
CREATE TABLE IF NOT EXISTS plans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT UNIQUE NOT NULL, -- Free/Starter/Business/Enterprise
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  monthly_quota INT NOT NULL DEFAULT 1000,
  per_tx_cap BIGINT NOT NULL DEFAULT 0, -- 0 means unlimited per-tx cap
  base_per_hit_price BIGINT NOT NULL DEFAULT 0,
  overage_price_per_hit BIGINT NOT NULL DEFAULT 0,
  allowed_integrations TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  per_hit_modifier NUMERIC(6,3) NOT NULL DEFAULT 1.000, -- multiplier
  features JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Subscriptions
CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  child_id UUID REFERENCES children(id) ON DELETE CASCADE,
  plan_id UUID NOT NULL REFERENCES plans(id),
  status subscription_status NOT NULL DEFAULT 'active',
  current_period_start DATE NOT NULL,
  current_period_end DATE NOT NULL,
  cancel_at_period_end BOOLEAN NOT NULL DEFAULT false,
  quota_override INT,
  overage_multiplier NUMERIC(6,3) NOT NULL DEFAULT 1.000,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, child_id)
);

-- Invoices
CREATE TABLE IF NOT EXISTS invoices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  subscription_id UUID REFERENCES subscriptions(id),
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  currency CHAR(3) NOT NULL,
  amount_due BIGINT NOT NULL DEFAULT 0,
  status invoice_status NOT NULL DEFAULT 'draft',
  line_items JSONB NOT NULL DEFAULT '[]'::jsonb, -- {type, qty, unit_price, amount}
  external_invoice_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  paid_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_invoices_tenant ON invoices(tenant_id, period_start);

-- IP Allowlist (global + scoped)
CREATE TABLE IF NOT EXISTS ip_allowlist (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
  subject_type TEXT NOT NULL CHECK (subject_type IN ('tenant','user','child','integration')),
  subject_id UUID,
  cidr CIDR NOT NULL,
  is_global BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_ip_allowlist_subject ON ip_allowlist(subject_type, subject_id);
CREATE INDEX IF NOT EXISTS idx_ip_allowlist_tenant ON ip_allowlist(tenant_id);

-- Webhooks (endpoints + secrets)
CREATE TABLE IF NOT EXISTS webhooks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
  integration_id UUID REFERENCES integrations(id),
  event_type TEXT NOT NULL,
  url TEXT NOT NULL,
  secret_encrypted TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT true,
  last_delivery_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Auth Tokens (refresh + revocation/rotation)
CREATE TABLE IF NOT EXISTS auth_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  family_id UUID NOT NULL, -- rotation family
  token_hash TEXT NOT NULL UNIQUE, -- store hash, never raw token
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  replaced_by UUID REFERENCES auth_tokens(id),
  ip INET,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_auth_tokens_user ON auth_tokens(user_id, expires_at);

-- Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES tenants(id) ON DELETE CASCADE,
  actor_user_id UUID REFERENCES users(id),
  actor_role TEXT,
  action TEXT NOT NULL, -- e.g., 'integration.call','wallet.topup'
  target_type TEXT,
  target_id UUID,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  ip INET,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_tenant_time ON audit_logs(tenant_id, created_at DESC);

BEGIN;
-- ensure idempotency via unique (wallet_id, idempotency_key)
WITH up AS (
  UPDATE wallets
     SET balance = balance + $amount, updated_at = now()
   WHERE id = $wallet_id
   RETURNING balance
)
INSERT INTO wallet_transactions(wallet_id, tx_type, amount, balance_after, currency, reference_type, reference_id, idempotency_key, metadata)
SELECT $wallet_id, 'credit', $amount, up.balance, $currency, 'webhook', $provider_event_uuid, $idempotency_key, $metadata::jsonb
FROM up
ON CONFLICT (wallet_id, idempotency_key) DO NOTHING;
COMMIT;
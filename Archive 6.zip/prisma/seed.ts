import { PrismaClient } from '@prisma/client';
import { hash } from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  const adminPassword = await hash('Admin@123', 10);
  
  await prisma.user.upsert({
    where: { email: 'admin@fintech.com' },
    update: {},
    create: {
      email: 'admin@fintech.com',
      username: 'admin',
      name: 'Admin User',
      password: adminPassword,
      role: 'ADMIN',
      emailVerified: true,
    },
  });

  console.log('✅ Admin user created: admin@fintech.com / Admin@123');
  const services = [
    {
      code: 'WALLET',
      name: 'Virtual Account / Wallet',
      description: 'Create and manage virtual accounts for payments',
    },
    {
      code: 'UPI',
      name: 'UPI Payments',
      description: 'Send and receive payments via UPI',
    },
    {
      code: 'NEFT',
      name: 'NEFT Transfer',
      description: 'National Electronic Funds Transfer',
    },
    {
      code: 'IMPS',
      name: 'IMPS Transfer',
      description: 'Immediate Payment Service',
    },
    {
      code: 'BILL_PAY',
      name: 'Bill Payments',
      description: 'Pay bills and utility payments',
    },
    {
      code: 'CREDIT_CARD',
      name: 'Credit Card Payments',
      description: 'Credit card payment processing',
    },
    {
      code: 'REPORTS',
      name: 'Reporting & Analytics',
      description: 'View transaction reports and analytics',
    },
  ];

  for (const service of services) {
    await prisma.service.upsert({
      where: { code: service.code },
      update: service,
      create: service,
    });
  }

  console.log('✅ Services seeded successfully');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

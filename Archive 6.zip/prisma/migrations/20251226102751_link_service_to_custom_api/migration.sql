/*
  Warnings:

  - A unique constraint covering the columns `[serviceId,customApiId]` on the table `ServiceApi` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE "ServiceApi" ADD COLUMN     "customApiId" TEXT,
ALTER COLUMN "apiId" DROP NOT NULL;

-- CreateIndex
CREATE INDEX "ServiceApi_customApiId_idx" ON "ServiceApi"("customApiId");

-- CreateIndex
CREATE UNIQUE INDEX "ServiceApi_serviceId_customApiId_key" ON "ServiceApi"("serviceId", "customApiId");

-- AddForeignKey
ALTER TABLE "ServiceApi" ADD CONSTRAINT "ServiceApi_customApiId_fkey" FOREIGN KEY ("customApiId") REFERENCES "CustomPaymentApi"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Convert PaymentScheme min/max transaction amount from paise (BIGINT) to rupees with paise (DECIMAL)
-- Existing BIGINT values are assumed to be in paise; divide by 100 during conversion

ALTER TABLE "PaymentScheme"
  ALTER COLUMN "minTransactionAmount" TYPE DECIMAL(12,2)
    USING (CASE WHEN "minTransactionAmount" IS NULL THEN NULL ELSE ("minTransactionAmount"::numeric / 100.0) END),
  ALTER COLUMN "maxTransactionAmount" TYPE DECIMAL(12,2)
    USING (CASE WHEN "maxTransactionAmount" IS NULL THEN NULL ELSE ("maxTransactionAmount"::numeric / 100.0) END);

-- Set sensible defaults in rupees
ALTER TABLE "PaymentScheme"
  ALTER COLUMN "minTransactionAmount" SET DEFAULT 100,
  ALTER COLUMN "maxTransactionAmount" SET DEFAULT 100000;

-- Add type field to UserApi (optional for backward compatibility)
ALTER TABLE "UserApi" ADD COLUMN "type" TEXT NOT NULL DEFAULT 'custom';
CREATE INDEX "UserApi_type_idx" ON "UserApi"("type");

-- Create AdminApi table for admin-level payment gateway configurations
CREATE TABLE "AdminApi" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "name" TEXT NOT NULL,
  "type" TEXT NOT NULL DEFAULT 'custom',
  "description" TEXT,
  "baseUrl" TEXT,
  "apiKey" TEXT,
  "apiToken" TEXT,
  "apiSecret" TEXT,
  "authHeader" TEXT,
  "scopes" TEXT,
  "assignedServices" TEXT[] DEFAULT ARRAY[]::TEXT[],
  "isDefault" BOOLEAN NOT NULL DEFAULT false,
  "isActive" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX "AdminApi_type_idx" ON "AdminApi"("type");
CREATE INDEX "AdminApi_isActive_idx" ON "AdminApi"("isActive");

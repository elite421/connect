-- This migration originally attempted to CREATE TABLE "Wallet" again.
-- The "Wallet" table is created in an earlier migration. Convert this to additive ALTERs.

-- Add missing columns if they do not exist
ALTER TABLE "Wallet" ADD COLUMN IF NOT EXISTS "balance" BIGINT NOT NULL DEFAULT 0;
ALTER TABLE "Wallet" ADD COLUMN IF NOT EXISTS "currency" TEXT NOT NULL DEFAULT 'INR';
ALTER TABLE "Wallet" ADD COLUMN IF NOT EXISTS "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE "Wallet" ADD COLUMN IF NOT EXISTS "updatedAt" TIMESTAMP(3) NOT NULL;

-- Ensure unique index exists
CREATE UNIQUE INDEX IF NOT EXISTS "Wallet_userId_key" ON "Wallet"("userId");

-- Do not re-add foreign key here; it is defined in the initial migration

/*
  Warnings:

  - You are about to drop the `Dispute` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `IpWhitelist` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `KycDocument` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `Notification` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `Refund` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `Settlement` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `UserLimit` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `VpaAddress` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "Dispute" DROP CONSTRAINT "Dispute_userId_fkey";

-- DropForeignKey
ALTER TABLE "IpWhitelist" DROP CONSTRAINT "IpWhitelist_userId_fkey";

-- DropForeignKey
ALTER TABLE "KycDocument" DROP CONSTRAINT "KycDocument_userId_fkey";

-- DropForeignKey
ALTER TABLE "Notification" DROP CONSTRAINT "Notification_userId_fkey";

-- DropForeignKey
ALTER TABLE "Refund" DROP CONSTRAINT "Refund_userId_fkey";

-- DropForeignKey
ALTER TABLE "Settlement" DROP CONSTRAINT "Settlement_userId_fkey";

-- DropForeignKey
ALTER TABLE "UserLimit" DROP CONSTRAINT "UserLimit_userId_fkey";

-- DropForeignKey
ALTER TABLE "VpaAddress" DROP CONSTRAINT "VpaAddress_userId_fkey";

-- DropIndex
DROP INDEX "BankAccount_userId_idx";

-- DropTable
DROP TABLE "Dispute";

-- DropTable
DROP TABLE "IpWhitelist";

-- DropTable
DROP TABLE "KycDocument";

-- DropTable
DROP TABLE "Notification";

-- DropTable
DROP TABLE "Refund";

-- DropTable
DROP TABLE "Settlement";

-- DropTable
DROP TABLE "UserLimit";

-- DropTable
DROP TABLE "VpaAddress";

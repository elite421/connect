-- AlterTable
ALTER TABLE "UserService" ADD COLUMN     "transactionCharge" DECIMAL(10,2) DEFAULT 0,
ADD COLUMN     "transactionChargeType" TEXT DEFAULT 'fixed',
ADD COLUMN     "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

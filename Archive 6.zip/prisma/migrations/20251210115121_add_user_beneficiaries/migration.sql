-- AlterTable
ALTER TABLE "UserService" ALTER COLUMN "updatedAt" DROP DEFAULT;

-- CreateTable
CREATE TABLE "UserBeneficiary" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "accountName" TEXT NOT NULL,
    "accountNumber" TEXT NOT NULL,
    "bankName" TEXT NOT NULL,
    "bankCode" TEXT,
    "ifscCode" TEXT,
    "upiId" TEXT,
    "beneficiaryType" TEXT NOT NULL DEFAULT 'bank',
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "UserBeneficiary_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "UserBeneficiary_userId_idx" ON "UserBeneficiary"("userId");

-- CreateIndex
CREATE INDEX "UserBeneficiary_accountNumber_idx" ON "UserBeneficiary"("accountNumber");

-- AddForeignKey
ALTER TABLE "UserBeneficiary" ADD CONSTRAINT "UserBeneficiary_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;

BEGIN;
CREATE TABLE IF NOT EXISTS api_calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  child_id UUID REFERENCES children(id) ON DELETE SET NULL,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  integration_id UUID NOT NULL REFERENCES integrations(id),
  integration_credential_id UUID REFERENCES integration_credentials(id),
  wallet_id UUID REFERENCES wallets(id),
  client_ip INET,
  request JSONB NOT NULL,
  response JSONB,
  status_code INT,
  success BOOLEAN,
  price_per_hit BIGINT,
  billed_amount BIGINT,
  idempotency_key TEXT,
  external_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, child_id, idempotency_key)
);
COMMIT;
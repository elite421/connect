-- Comprehensive Banking System Database Schema Extension
-- Add IP Whitelist, KYC, Settlements, Notifications, and more

-- IP Whitelist Management
CREATE TABLE IF NOT EXISTS "IpWhitelist" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "ipAddress" TEXT NOT NULL,
    "label" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "IpWhitelist_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
    CONSTRAINT "IpWhitelist_unique_ip" UNIQUE ("userId", "ipAddress")
);

-- KYC Documents and Verification
CREATE TABLE IF NOT EXISTS "KycDocument" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "documentType" TEXT NOT NULL, -- aadhaar, pan, gst, business_license, bank_statement
    "documentNumber" TEXT NOT NULL,
    "documentUrl" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending', -- pending, verified, rejected
    "verifiedBy" TEXT,
    "verifiedAt" TIMESTAMP(3),
    "rejectionReason" TEXT,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "KycDocument_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
);

-- Settlement Records
CREATE TABLE IF NOT EXISTS "Settlement" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "amount" BIGINT NOT NULL,
    "fee" BIGINT NOT NULL DEFAULT 0,
    "netAmount" BIGINT NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'INR',
    "settlementType" TEXT NOT NULL DEFAULT 'auto', -- auto, manual, on_demand
    "bankAccountId" TEXT,
    "utrNumber" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending', -- pending, processing, completed, failed
    "failureReason" TEXT,
    "settledAt" TIMESTAMP(3),
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Settlement_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
);

-- Bank Accounts for Users (for settlements)
CREATE TABLE IF NOT EXISTS "BankAccount" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "accountHolderName" TEXT NOT NULL,
    "accountNumber" TEXT NOT NULL,
    "ifscCode" TEXT NOT NULL,
    "bankName" TEXT NOT NULL,
    "branchName" TEXT,
    "accountType" TEXT NOT NULL DEFAULT 'current', -- savings, current
    "isPrimary" BOOLEAN NOT NULL DEFAULT false,
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "BankAccount_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
);

-- VPA Addresses for Users (for UPI)
CREATE TABLE IF NOT EXISTS "VpaAddress" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "vpaAddress" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "isPrimary" BOOLEAN NOT NULL DEFAULT false,
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "dailyLimit" BIGINT DEFAULT 100000000,
    "currentDailyUsage" BIGINT NOT NULL DEFAULT 0,
    "lastResetDate" DATE NOT NULL DEFAULT CURRENT_DATE,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "VpaAddress_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
    CONSTRAINT "VpaAddress_unique_vpa" UNIQUE ("vpaAddress")
);

-- Notifications for Users
CREATE TABLE IF NOT EXISTS "Notification" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "type" TEXT NOT NULL, -- transaction, kyc, settlement, security, system
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "isRead" BOOLEAN NOT NULL DEFAULT false,
    "actionUrl" TEXT,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
);

-- User Limits and Settings
CREATE TABLE IF NOT EXISTS "UserLimit" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL UNIQUE,
    "dailyPayoutLimit" BIGINT NOT NULL DEFAULT 1000000000,
    "dailyPayinLimit" BIGINT NOT NULL DEFAULT 1000000000,
    "perTransactionLimit" BIGINT NOT NULL DEFAULT 100000000,
    "monthlyVolume" BIGINT NOT NULL DEFAULT 0,
    "currentDailyPayout" BIGINT NOT NULL DEFAULT 0,
    "currentDailyPayin" BIGINT NOT NULL DEFAULT 0,
    "lastResetDate" DATE NOT NULL DEFAULT CURRENT_DATE,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "UserLimit_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
);

-- Dispute/Chargeback Management
CREATE TABLE IF NOT EXISTS "Dispute" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "transactionId" TEXT NOT NULL,
    "transactionType" TEXT NOT NULL, -- payin, payout
    "amount" BIGINT NOT NULL,
    "reason" TEXT NOT NULL,
    "description" TEXT,
    "status" TEXT NOT NULL DEFAULT 'open', -- open, under_review, resolved, rejected
    "resolution" TEXT,
    "resolvedBy" TEXT,
    "resolvedAt" TIMESTAMP(3),
    "evidenceUrls" TEXT[],
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Dispute_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
);

-- Refund Management
CREATE TABLE IF NOT EXISTS "Refund" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "payinTransactionId" TEXT NOT NULL,
    "amount" BIGINT NOT NULL,
    "reason" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending', -- pending, processing, completed, failed
    "utrNumber" TEXT,
    "failureReason" TEXT,
    "processedAt" TIMESTAMP(3),
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Refund_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
);

-- Create Indexes
CREATE INDEX IF NOT EXISTS "IpWhitelist_userId_idx" ON "IpWhitelist"("userId");
CREATE INDEX IF NOT EXISTS "IpWhitelist_ipAddress_idx" ON "IpWhitelist"("ipAddress");

CREATE INDEX IF NOT EXISTS "KycDocument_userId_idx" ON "KycDocument"("userId");
CREATE INDEX IF NOT EXISTS "KycDocument_status_idx" ON "KycDocument"("status");

CREATE INDEX IF NOT EXISTS "Settlement_userId_idx" ON "Settlement"("userId");
CREATE INDEX IF NOT EXISTS "Settlement_status_idx" ON "Settlement"("status");
CREATE INDEX IF NOT EXISTS "Settlement_createdAt_idx" ON "Settlement"("createdAt");

CREATE INDEX IF NOT EXISTS "BankAccount_userId_idx" ON "BankAccount"("userId");
CREATE INDEX IF NOT EXISTS "VpaAddress_userId_idx" ON "VpaAddress"("userId");

CREATE INDEX IF NOT EXISTS "Notification_userId_idx" ON "Notification"("userId");
CREATE INDEX IF NOT EXISTS "Notification_isRead_idx" ON "Notification"("isRead");
CREATE INDEX IF NOT EXISTS "Notification_createdAt_idx" ON "Notification"("createdAt");

CREATE INDEX IF NOT EXISTS "UserLimit_userId_idx" ON "UserLimit"("userId");

CREATE INDEX IF NOT EXISTS "Dispute_userId_idx" ON "Dispute"("userId");
CREATE INDEX IF NOT EXISTS "Dispute_status_idx" ON "Dispute"("status");

CREATE INDEX IF NOT EXISTS "Refund_userId_idx" ON "Refund"("userId");
CREATE INDEX IF NOT EXISTS "Refund_status_idx" ON "Refund"("status");

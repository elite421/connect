-- Fix UserService updatedAt column to have default value
-- This ensures the column is never NULL when creating new records

ALTER TABLE "UserService" ALTER COLUMN "updatedAt" SET DEFAULT NOW();

-- Update any existing NULL values (should be none, but safety check)
UPDATE "UserService" SET "updatedAt" = "createdAt" WHERE "updatedAt" IS NULL;

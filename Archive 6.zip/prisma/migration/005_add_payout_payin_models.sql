-- Add comprehensive payout and payin system with IP whitelist, priority, limits, merchants, and webhooks

-- Merchant Configuration for Users
CREATE TABLE "MerchantConfig" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "merchantName" TEXT NOT NULL,
    "merchantKey" TEXT NOT NULL UNIQUE,
    "merchantSecret" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "allowedIPs" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "minAmount" BIGINT NOT NULL DEFAULT 100,
    "maxAmount" BIGINT NOT NULL DEFAULT 100000000,
    "dailyLimit" BIGINT,
    "monthlyLimit" BIGINT,
    "transactionMode" TEXT NOT NULL DEFAULT 'both', -- payin, payout, both
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "MerchantConfig_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
);

-- Webhook Configuration
CREATE TABLE "WebhookConfig" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "merchantId" TEXT,
    "webhookUrl" TEXT NOT NULL,
    "webhookSecret" TEXT NOT NULL,
    "events" TEXT[] NOT NULL DEFAULT ARRAY['payment.success', 'payment.failed', 'payout.success', 'payout.failed']::TEXT[],
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "retryCount" INTEGER NOT NULL DEFAULT 3,
    "retryDelay" INTEGER NOT NULL DEFAULT 300,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "WebhookConfig_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
    CONSTRAINT "WebhookConfig_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "MerchantConfig"("id") ON DELETE SET NULL
);

-- Account Priority System
CREATE TABLE "AccountPriority" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "accountType" TEXT NOT NULL, -- 'vpa' or 'bank'
    "accountId" TEXT NOT NULL, -- VPA ID or Bank Account ID
    "accountNumber" TEXT,
    "vpaAddress" TEXT,
    "bankName" TEXT,
    "ifscCode" TEXT,
    "priority" INTEGER NOT NULL DEFAULT 1,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "minAmount" BIGINT NOT NULL DEFAULT 100,
    "maxAmount" BIGINT NOT NULL DEFAULT 100000000,
    "dailyLimit" BIGINT,
    "currentDailyUsage" BIGINT NOT NULL DEFAULT 0,
    "lastResetDate" DATE NOT NULL DEFAULT CURRENT_DATE,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AccountPriority_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
    CONSTRAINT "AccountPriority_unique_priority" UNIQUE ("userId", "priority")
);

-- PayIn Transactions
CREATE TABLE "PayInTransaction" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "merchantId" TEXT,
    "amount" BIGINT NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'INR',
    "customerName" TEXT,
    "customerEmail" TEXT,
    "customerPhone" TEXT,
    "paymentMethod" TEXT NOT NULL, -- upi, card, netbanking, wallet
    "utrNumber" TEXT UNIQUE,
    "merchantTransactionId" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending', -- pending, processing, success, failed
    "failureReason" TEXT,
    "ipAddress" TEXT,
    "webhookSent" BOOLEAN NOT NULL DEFAULT false,
    "webhookAttempts" INTEGER NOT NULL DEFAULT 0,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "PayInTransaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
    CONSTRAINT "PayInTransaction_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "MerchantConfig"("id") ON DELETE SET NULL
);

-- PayOut Transactions
CREATE TABLE "PayOutTransaction" (
    "id" TEXT NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "userId" TEXT NOT NULL,
    "subUserId" TEXT,
    "merchantId" TEXT,
    "accountPriorityId" TEXT,
    "amount" BIGINT NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'INR',
    "beneficiaryName" TEXT NOT NULL,
    "beneficiaryAccount" TEXT NOT NULL,
    "beneficiaryIfsc" TEXT,
    "beneficiaryVpa" TEXT,
    "transferMode" TEXT NOT NULL, -- neft, imps, upi
    "utrNumber" TEXT UNIQUE,
    "merchantTransactionId" TEXT,
    "status" TEXT NOT NULL DEFAULT 'pending', -- pending, processing, success, failed
    "failureReason" TEXT,
    "priorityUsed" INTEGER,
    "ipAddress" TEXT,
    "webhookSent" BOOLEAN NOT NULL DEFAULT false,
    "webhookAttempts" INTEGER NOT NULL DEFAULT 0,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "PayOutTransaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
    CONSTRAINT "PayOutTransaction_subUserId_fkey" FOREIGN KEY ("subUserId") REFERENCES "SubUser"("id") ON DELETE SET NULL,
    CONSTRAINT "PayOutTransaction_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "MerchantConfig"("id") ON DELETE SET NULL,
    CONSTRAINT "PayOutTransaction_accountPriorityId_fkey" FOREIGN KEY ("accountPriorityId") REFERENCES "AccountPriority"("id") ON DELETE SET NULL
);

-- Create Indexes
CREATE INDEX "MerchantConfig_userId_idx" ON "MerchantConfig"("userId");
CREATE INDEX "MerchantConfig_isActive_idx" ON "MerchantConfig"("isActive");

CREATE INDEX "WebhookConfig_userId_idx" ON "WebhookConfig"("userId");
CREATE INDEX "WebhookConfig_merchantId_idx" ON "WebhookConfig"("merchantId");
CREATE INDEX "WebhookConfig_isActive_idx" ON "WebhookConfig"("isActive");

CREATE INDEX "AccountPriority_userId_idx" ON "AccountPriority"("userId");
CREATE INDEX "AccountPriority_priority_idx" ON "AccountPriority"("userId", "priority");

CREATE INDEX "PayInTransaction_userId_idx" ON "PayInTransaction"("userId");
CREATE INDEX "PayInTransaction_status_idx" ON "PayInTransaction"("status");
CREATE INDEX "PayInTransaction_createdAt_idx" ON "PayInTransaction"("createdAt");
CREATE INDEX "PayInTransaction_merchantId_idx" ON "PayInTransaction"("merchantId");

CREATE INDEX "PayOutTransaction_userId_idx" ON "PayOutTransaction"("userId");
CREATE INDEX "PayOutTransaction_subUserId_idx" ON "PayOutTransaction"("subUserId");
CREATE INDEX "PayOutTransaction_status_idx" ON "PayOutTransaction"("status");
CREATE INDEX "PayOutTransaction_createdAt_idx" ON "PayOutTransaction"("createdAt");
CREATE INDEX "PayOutTransaction_merchantId_idx" ON "PayOutTransaction"("merchantId");

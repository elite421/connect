'use client';

import React, { useState, useEffect } from 'react';

export type FormFieldType = 'text' | 'email' | 'password' | 'number' | 'textarea' | 'select' | 'checkbox';

export interface FormField {
  name: string;
  label: string;
  type: FormFieldType;
  placeholder?: string;
  required?: boolean;
  pattern?: string;
  options?: { label: string; value: string }[] | ((values: Record<string, any>) => { label: string; value: string }[]);
  minLength?: number;
  maxLength?: number;
  hidden?: boolean | ((values: Record<string, any>) => boolean);
  onChange?: (value: any) => void;
  disabled?: boolean | ((values: Record<string, any>) => boolean);
}

export interface FormBuilderProps {
  fields: FormField[];
  onSubmit: (data: Record<string, any>) => void;
  submitLabel?: string;
  loading?: boolean;
  initialValues?: Record<string, any>;
}

export function FormBuilder({
  fields,
  onSubmit,
  submitLabel = 'Submit',
  loading = false,
  initialValues = {},
}: FormBuilderProps) {
  const [formData, setFormData] = useState<Record<string, any>>(initialValues);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Only reset form when initialValues change significantly (JSON comparison to avoid ref issues)
  useEffect(() => {
    setFormData(initialValues);
    setErrors({});
  }, [JSON.stringify(initialValues)]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const newValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;

    setFormData((prev) => ({
      ...prev,
      [name]: newValue,
    }));
    setErrors((prev) => ({ ...prev, [name]: '' }));

    // Trigger field-specific onChange if defined
    const field = fields.find((f) => f.name === name);
    if (field?.onChange) {
      field.onChange(newValue);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    fields.forEach((field) => {
      // Check visibility before validating
      const isHidden = typeof field.hidden === 'function' ? field.hidden(formData) : field.hidden;
      if (isHidden) return;

      if (field.required && !formData[field.name]) {
        newErrors[field.name] = `${field.label} is required`;
      }
      if (field.pattern && formData[field.name] && !new RegExp(field.pattern).test(formData[field.name])) {
        newErrors[field.name] = `${field.label} is invalid`;
      }
    });

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // Filter out hidden fields from submission
    const submittedData = { ...formData };
    fields.forEach((field) => {
      const isHidden = typeof field.hidden === 'function' ? field.hidden(formData) : field.hidden;
      if (isHidden) {
        delete submittedData[field.name];
      }
    });

    onSubmit(submittedData);
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col">
      <div className="grid grid-cols-2 gap-4">
        {fields.map((field) => {
          const isHidden = typeof field.hidden === 'function' ? field.hidden(formData) : field.hidden;
          if (isHidden) return null;

          const isDisabled = typeof field.disabled === 'function' ? field.disabled(formData) : field.disabled;
          const options = typeof field.options === 'function' ? field.options(formData) : field.options;

          return (
            <div key={field.name} className={field.type === 'textarea' ? 'col-span-2' : ''}>
              <label htmlFor={field.name} className="block text-sm font-medium text-gray-700 mb-1">
                {field.label}
                {field.required && <span className="text-red-500"> *</span>}
              </label>

              {field.type === 'textarea' ? (
                <textarea
                  id={field.name}
                  name={field.name}
                  value={formData[field.name] || ''}
                  onChange={handleChange}
                  disabled={!!isDisabled}
                  placeholder={field.placeholder}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-500"
                  rows={4}
                />
              ) : field.type === 'select' ? (
                <select
                  id={field.name}
                  name={field.name}
                  value={formData[field.name] || ''}
                  onChange={handleChange}
                  disabled={!!isDisabled}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-500"
                >
                  <option value="">Select {field.label}</option>
                  {options?.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              ) : field.type === 'checkbox' ? (
                <div className="flex items-center h-full pt-6">
                  <input
                    id={field.name}
                    type="checkbox"
                    name={field.name}
                    checked={!!formData[field.name]}
                    onChange={handleChange}
                    disabled={!!isDisabled}
                    className="w-4 h-4 border-gray-300 rounded focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
                  />
                  <span className="ml-2 text-sm text-gray-600">{field.placeholder || ''}</span>
                </div>
              ) : (
                <input
                  id={field.name}
                  type={field.type}
                  name={field.name}
                  value={formData[field.name] || ''}
                  onChange={handleChange}
                  disabled={!!isDisabled}
                  placeholder={field.placeholder}
                  minLength={field.minLength}
                  maxLength={field.maxLength}
                  pattern={field.pattern}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-100 disabled:text-gray-500"
                />
              )}

              {errors[field.name] && <p className="text-red-500 text-xs mt-1">{errors[field.name]}</p>}
            </div>
          );
        })}
      </div>

      {/* Sticky submit button */}
      <div className="sticky bottom-0 pt-4 mt-4 border-t border-gray-200 bg-white z-10">
        <button
          type="submit"
          disabled={loading}
          className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 font-medium text-lg"
        >
          {loading ? 'Loading...' : submitLabel}
        </button>
      </div>
    </form>
  );
}

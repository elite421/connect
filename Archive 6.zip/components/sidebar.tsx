'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession, signOut } from 'next-auth/react';
import { useEffect, useState } from 'react';

const CURRENT_PAGE_KEY = 'lastVisitedPage';

interface MenuItem {
  name: string;
  link: string;
  roles: ('ADMIN' | 'USER' | 'SUBUSER')[];
  icon?: string;
}

interface MenuSection {
  title: string;
  roles: ('ADMIN' | 'USER' | 'SUBUSER')[];
  items: MenuItem[];
}

export default function Sidebar() {
  const path = usePathname();
  const { data: session } = useSession();
  const [mounted, setMounted] = useState(false);
  const [collapsedSections, setCollapsedSections] = useState<Set<string>>(new Set());
  const [currentSearch, setCurrentSearch] = useState('');

  useEffect(() => {
    setMounted(true);
    if (typeof window !== 'undefined' && path) {
      localStorage.setItem(CURRENT_PAGE_KEY, path);
    }
  }, [path]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const updateSearch = () => {
        setCurrentSearch(window.location.search);
      };
      updateSearch();
      window.addEventListener('popstate', updateSearch);

      const observer = new MutationObserver(updateSearch);
      observer.observe(document, { subtree: true, childList: true });

      return () => {
        window.removeEventListener('popstate', updateSearch);
        observer.disconnect();
      };
    }
  }, [path]);

  const toggleSection = (sectionTitle: string) => {
    const newCollapsed = new Set(collapsedSections);
    if (newCollapsed.has(sectionTitle)) {
      newCollapsed.delete(sectionTitle);
    } else {
      newCollapsed.add(sectionTitle);
    }
    setCollapsedSections(newCollapsed);
  };

  if (!mounted || !session?.user) return null;

  const userRole = (session.user as any).role || 'USER';

  const menuSections: MenuSection[] = [
    {
      title: '',
      roles: ['ADMIN', 'USER', 'SUBUSER'],
      items: [{ name: '📊 Dashboard', link: '/account/dashboard', roles: ['ADMIN', 'USER', 'SUBUSER'] }],
    },
    {
      title: 'Admin Management',
      roles: ['ADMIN'],
      items: [
        { name: '👥 Users', link: '/account/admin/users', roles: ['ADMIN'] },
        { name: '👤 Subuser Management', link: '/account/admin/subuser-management', roles: ['ADMIN'] },
        { name: '📋 KYC Management', link: '/account/admin/kyc', roles: ['ADMIN'] },
        { name: '⚙️ Services', link: '/account/admin/services', roles: ['ADMIN'] },
        { name: '🎯 Service Assignments', link: '/account/admin/service-assignments', roles: ['ADMIN'] },
        // Payment Gateways removed as per request
        { name: '💳 Custom APIs', link: '/account/admin/custom-apis', roles: ['ADMIN'] },
        { name: '🔌 Connecting APIs', link: '/account/admin/connecting-api', roles: ['ADMIN'] },
        { name: '💰 PayIn APIs', link: '/account/admin/payin-apis', roles: ['ADMIN'] },
        { name: '🔑 API Keys', link: '/account/admin/api-keys', roles: ['ADMIN'] },
        { name: '💎 Payment Schemes', link: '/account/admin/schemes', roles: ['ADMIN'] },
        { name: '📈 Analytics', link: '/account/admin/analytics', roles: ['ADMIN'] },
        { name: '💸 All Payouts', link: '/account/admin/payouts', roles: ['ADMIN'] },
        { name: '💰 All PayIns', link: '/account/admin/payins', roles: ['ADMIN'] },
        { name: '🏦 All Settlements', link: '/account/admin/settlements', roles: ['ADMIN'] },
        { name: '📝 Reports', link: '/account/reports', roles: ['ADMIN'] },
        { name: '📒 Admin Ledger', link: '/account/admin/ledger', roles: ['ADMIN'] },
        { name: '🔔 Webhooks', link: '/account/admin/webhooks', roles: ['ADMIN'] },
        { name: '⚙️ System Config', link: '/account/admin/system-config', roles: ['ADMIN'] },
        { name: '🔒 IP Whitelist', link: '/account/admin/ip-whitelist', roles: ['ADMIN'] },
        { name: '💼 Manual Wallet', link: '/account/admin/wallet-management', roles: ['ADMIN'] },
        { name: '🚨 Disputes', link: '/account/disputes', roles: ['ADMIN'] },
      ],
    },
    {
      title: 'Services',
      roles: ['USER'],
      items: [
        { name: '💸 Payout', link: '/account/user/payout', roles: ['USER'] },
        { name: '💰 Payin', link: '/account/user/payin', roles: ['USER'] },
        { name: '⚙️ Services', link: '/account/user/services', roles: ['USER'] },
        { name: '📋 KYC Verification', link: '/account/user/kyc', roles: ['USER'] },
        { name: '🚨 Disputes', link: '/account/disputes', roles: ['USER'] },
      ],
    },
    {
      title: 'Transactions',
      roles: ['USER'],
      items: [
        { name: '➕ Add Beneficiary', link: '/account/user/beneficiaries', roles: ['USER'] },
        { name: '🏦 Bank Accounts', link: '/account/user/bank-accounts', roles: ['USER'] },
        { name: '📋 Transactions', link: '/account/user/transactions', roles: ['USER'] },
        { name: '📝 Reports', link: '/account/reports', roles: ['USER'] },
        { name: '📒 Ledger', link: '/account/reports/ledger', roles: ['USER'] },
      ],
    },
    {
      title: 'Merchant',
      roles: ['USER'],
      items: [
        { name: '🏠 Merchant Configuration', link: '/account/user/merchants', roles: ['USER'] },
        { name: '👤 Subusers', link: '/account/user/subusers', roles: ['USER'] },
      ],
    },
    {
      title: 'Developer',
      roles: ['USER', 'SUBUSER'],
      items: [
        { name: '🔑 API Keys', link: '/account/user/developer', roles: ['USER'] }, // Keep USER path
        { name: '🔑 API Keys', link: '/account/subuser/developer', roles: ['SUBUSER'] }, // Add SUBUSER path
        { name: '💳 Custom Payment APIs', link: '/account/user/custom-payment-apis', roles: ['USER'] },
      ],
    },
    {
      title: 'Subuser Operations',
      roles: ['SUBUSER'],
      items: [
        { name: '💸 Payout', link: '/account/subuser/payout', roles: ['SUBUSER'] },
        { name: '💰 PayIn', link: '/account/subuser/payin', roles: ['SUBUSER'] },
        { name: '➕ Beneficiaries', link: '/account/subuser/beneficiaries', roles: ['SUBUSER'] },
        { name: '📋 Transactions', link: '/account/subuser/transactions', roles: ['SUBUSER'] },
        { name: '📝 Reports', link: '/account/reports', roles: ['SUBUSER'] },
        { name: '📒 Ledger', link: '/account/reports/ledger', roles: ['SUBUSER'] },
        { name: '📋 KYC Verification', link: '/account/subuser/kyc', roles: ['SUBUSER'] },
        { name: '🔒 IP Whitelist', link: '/account/subuser/ip-whitelist', roles: ['SUBUSER'] },
        { name: '🚨 Disputes', link: '/account/disputes', roles: ['SUBUSER'] },
      ],
    },
    {
      title: 'Account',
      roles: ['ADMIN', 'USER', 'SUBUSER'],
      items: [
        { name: '⚙️ Settings', link: '/account/settings', roles: ['ADMIN', 'USER', 'SUBUSER'] },
        { name: '👤 Profile', link: '/account/profile', roles: ['ADMIN', 'USER', 'SUBUSER'] },
      ],
    },
  ];

  const filteredSections = menuSections
    .map(section => {
      // Filter items by role
      let items = section.items.filter((item) => item.roles.includes(userRole as any));

      // Special check for Subuser Developer menu
      if (userRole === 'SUBUSER' && section.title === 'Developer') {
        // Check custom permission
        const canAccessApi = (session.user as any).isApiEnabled;
        if (!canAccessApi) {
          return { ...section, items: [] };
        }
      }

      // Also, if I am a subuser, I should see the Developer section if allowed. 
      // Wait, the Developer section in the array above has roles: ['USER'].
      // I need to update the roles for the Developer section to include SUBUSER first, 
      // or duplicate it for SUBUSER.

      return { ...section, items };
    })
    .filter(section => section.roles.includes(userRole as any) && section.items.length > 0);

  const handleLogout = async () => {
    await signOut({ redirect: true, callbackUrl: '/login' });
  };

  return (
    <aside className="w-64 bg-gradient-to-b from-gray-900 to-gray-800 text-white h-screen flex flex-col sticky top-0">
      <div className="p-6 border-b border-gray-700 flex-shrink-0">
        <h1 className="text-xl font-bold">Connect</h1>
        <p className="text-xs text-gray-400 mt-1">
          {userRole === 'ADMIN' ? '🔵 Admin Panel' : userRole === 'USER' ? '🟢 User Panel' : '🟡 Subuser Panel'}
        </p>
      </div>

      <nav className="flex-1 p-4 space-y-4 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-600 scrollbar-track-gray-700">
        {filteredSections.map((section, idx) => {
          const isCollapsed = collapsedSections.has(section.title);
          return (
            <div key={idx}>
              {section.title && (
                <button
                  onClick={() => toggleSection(section.title)}
                  className="w-full px-4 py-2 text-xs font-semibold text-gray-400 uppercase tracking-wider hover:text-gray-200 transition-colors flex items-center justify-between"
                >
                  <span>{section.title}</span>
                  <span className={`transform transition-transform ${isCollapsed ? '-rotate-90' : ''}`}>
                    ▼
                  </span>
                </button>
              )}
              {!isCollapsed && (
                <div className="space-y-1">
                  {section.items.map((item) => {
                    const [itemPath, itemQuery] = item.link.split('?');
                    const currentUrl = `${path}${currentSearch}`;
                    const isActive = currentUrl === item.link || (itemQuery && path === itemPath && currentSearch.includes(itemQuery));
                    return (
                      <Link
                        key={item.link}
                        href={item.link}
                        className={`block px-4 py-2 rounded-lg transition-all font-medium text-sm ${isActive
                          ? 'bg-blue-600 text-white shadow-lg'
                          : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                          }`}
                      >
                        {item.name}
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      <div className="p-4 border-t border-gray-700 space-y-2 flex-shrink-0">
        <div className="px-4 py-2 bg-gray-700 rounded-lg text-xs text-gray-300">
          <p className="font-semibold truncate">{session.user?.name}</p>
          <p className="truncate text-xs">{session.user?.email}</p>
        </div>
        <button
          onClick={handleLogout}
          className="w-full px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors font-medium text-sm"
        >
          🚪 Logout
        </button>
      </div>
    </aside>
  );
}

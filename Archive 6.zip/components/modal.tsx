'use client';

import React from 'react';

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
}

export function Modal({
  isOpen,
  onClose,
  title,
  children,
  footer,
  size = 'lg',
}: ModalProps) {
  if (!isOpen) return null;

  const sizeMap = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
    full: 'max-w-6xl',
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/50" onClick={onClose} />
      <div className={`relative bg-white rounded-lg shadow-lg ${sizeMap[size]} w-full max-h-[90vh] flex flex-col`}>
        {/* Fixed Header */}
        <div className="flex items-center justify-between border-b border-gray-200 p-4 shrink-0">
          <h2 className="text-lg font-semibold text-gray-900">{title}</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors text-xl leading-none"
          >
            ✕
          </button>
        </div>
        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto flex-1">{children}</div>
        {/* Fixed Footer */}
        {footer && <div className="border-t border-gray-200 p-4 bg-gray-50 rounded-b-lg shrink-0">{footer}</div>}
      </div>
    </div>
  );
}

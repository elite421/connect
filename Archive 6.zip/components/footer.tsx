export default function Footer() {
  return (
    <footer className="bg-gray-800 p-4 mt-8">
      <p className="text-center text-white">
        &copy; {new Date().getFullYear()} Connect. All rights reserved.
      </p>
    </footer>
  );
}
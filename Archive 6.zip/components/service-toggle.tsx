'use client';

import React, { useState } from 'react';

export interface ServiceToggleProps {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  onToggle: (id: string, isActive: boolean) => void;
  onConfigure?: (id: string) => void;
  loading?: boolean;
  icon?: string;
  showConfig?: boolean;
}

export function ServiceToggle({
  id,
  name,
  description,
  isActive,
  onToggle,
  onConfigure,
  loading = false,
  icon,
  showConfig = false,
}: ServiceToggleProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleToggle = async () => {
    setIsLoading(true);
    try {
      await onToggle(id, !isActive);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
      <div className="flex items-start gap-3 flex-1">
        {icon && <div className="text-2xl mt-1">{icon}</div>}
        <div>
          <h3 className="font-semibold text-gray-900">{name}</h3>
          {description && <p className="text-sm text-gray-500 mt-1">{description}</p>}
        </div>
      </div>
      <div className="flex items-center gap-2">
        {showConfig && isActive && onConfigure && (
          <button
            onClick={() => onConfigure(id)}
            className="px-3 py-1 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded transition-colors"
            title="Configure service"
          >
            ⚙️ Config
          </button>
        )}
        <button
          onClick={handleToggle}
          disabled={isLoading || loading}
          className={`relative w-12 h-7 rounded-full transition-colors ${
            isActive ? 'bg-green-500' : 'bg-gray-300'
          } ${isLoading || loading ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
        >
          <div
            className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-transform ${
              isActive ? 'translate-x-6' : 'translate-x-1'
            }`}
          />
        </button>
      </div>
    </div>
  );
}

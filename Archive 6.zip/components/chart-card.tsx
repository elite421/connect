'use client';

import React from 'react';

export interface ChartData {
  label: string;
  value: number;
  percentage?: number;
}

export interface ChartCardProps {
  title: string;
  data: ChartData[];
  type?: 'bar' | 'pie' | 'line';
  height?: number;
}

function SimpleBarChart({ data }: { data: ChartData[] }) {
  const maxValue = Math.max(...data.map((d) => d.value), 1);

  return (
    <div className="space-y-3">
      {data.map((item) => (
        <div key={item.label}>
          <div className="flex justify-between text-sm mb-1">
            <span className="font-medium text-gray-700">{item.label}</span>
            <span className="text-gray-600">{item.value}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all"
              style={{ width: `${(item.value / maxValue) * 100}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

function SimplePieChart({ data }: { data: ChartData[] }) {
  const total = data.reduce((sum, item) => sum + item.value, 0) || 1;
  const colors = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#14B8A6'];
  const bgColors = ['bg-blue-500', 'bg-green-500', 'bg-yellow-500', 'bg-red-500', 'bg-purple-500', 'bg-pink-500', 'bg-teal-500'];

  // Calculate stroke dasharray and dashoffset for each segment
  const circumference = 2 * Math.PI * 40; // radius = 40
  let cumulativePercentage = 0;

  return (
    <div className="flex items-center gap-8">
      <div className="w-40 h-40 relative">
        <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
          {/* Background circle */}
          <circle
            cx="50"
            cy="50"
            r="40"
            fill="none"
            stroke="#e5e7eb"
            strokeWidth="12"
          />
          {/* Data segments */}
          {data.map((item, idx) => {
            const percentage = (item.value / total) * 100;
            const strokeDasharray = (percentage / 100) * circumference;
            const strokeDashoffset = -(cumulativePercentage / 100) * circumference;
            cumulativePercentage += percentage;

            return (
              <circle
                key={item.label}
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke={colors[idx % colors.length]}
                strokeWidth="12"
                strokeDasharray={`${strokeDasharray} ${circumference}`}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
              />
            );
          })}
        </svg>
        {/* Center text */}
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-lg font-semibold text-gray-700">{total}</span>
        </div>
      </div>
      <div className="space-y-2">
        {data.map((item, idx) => {
          const percentage = total > 0 ? ((item.value / total) * 100).toFixed(1) : '0';
          return (
            <div key={item.label} className="flex items-center gap-2 text-sm">
              <div className={`w-3 h-3 rounded-full ${bgColors[idx % bgColors.length]}`} />
              <span className="font-medium">{item.label}</span>
              <span className="text-gray-500">({item.value})</span>
              <span className="text-gray-400">{percentage}%</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function SimpleLineChart({ data }: { data: ChartData[] }) {
  const maxValue = Math.max(...data.map((d) => d.value), 1);
  const points = data.map((item, idx) => {
    const x = (idx / Math.max(data.length - 1, 1)) * 280 + 10;
    const y = 150 - (item.value / maxValue) * 130;
    return { x, y, label: item.label, value: item.value };
  });

  const pathD = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

  return (
    <div className="w-full">
      <svg viewBox="0 0 300 180" className="w-full h-48">
        {/* Grid lines */}
        {[0, 1, 2, 3, 4].map((i) => (
          <line
            key={i}
            x1="10"
            y1={20 + i * 32.5}
            x2="290"
            y2={20 + i * 32.5}
            stroke="#e5e7eb"
            strokeWidth="1"
          />
        ))}
        {/* Line */}
        <path d={pathD} fill="none" stroke="#3B82F6" strokeWidth="2" />
        {/* Points */}
        {points.map((p, idx) => (
          <g key={idx}>
            <circle cx={p.x} cy={p.y} r="4" fill="#3B82F6" />
            <text x={p.x} y="170" textAnchor="middle" className="text-xs fill-gray-500">
              {p.label.slice(0, 3)}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

export function ChartCard({ title, data, type = 'bar', height = 200 }: ChartCardProps) {
  const renderChart = () => {
    if (!data || data.length === 0) {
      return (
        <div className="flex items-center justify-center h-32 text-gray-400">
          No data available
        </div>
      );
    }

    switch (type) {
      case 'pie':
        return <SimplePieChart data={data} />;
      case 'line':
        return <SimpleLineChart data={data} />;
      default:
        return <SimpleBarChart data={data} />;
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">{title}</h3>
      <div style={{ minHeight: `${height}px` }}>
        {renderChart()}
      </div>
    </div>
  );
}

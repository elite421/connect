import { z } from 'zod';

/**
 * Common validation schemas for the application
 * All API endpoints should use these schemas for input validation
 */

// Amount validation (in paisa, so minimum 1 paisa = 0.01 rupees)
export const amountSchema = z
  .number()
  .int()
  .min(100, 'Minimum amount is ₹1.00')
  .max(5000000, 'Maximum amount is ₹50,000');

// Email validation
export const emailSchema = z
  .string()
  .email('Invalid email format')
  .max(254, 'Email is too long')
  .toLowerCase();

// Phone number validation (Indian format)
export const phoneSchema = z
  .string()
  .regex(/^[6-9]\d{9}$/, 'Invalid phone number format')
  .length(10, 'Phone number must be 10 digits');

// Name validation
export const nameSchema = z
  .string()
  .min(2, 'Name must be at least 2 characters')
  .max(100, 'Name must be less than 100 characters')
  .regex(/^[a-zA-Z\s'-]+$/, 'Name contains invalid characters');

// UPI validation
export const upiSchema = z
  .string()
  .regex(/^[a-zA-Z0-9._-]+@[a-zA-Z]{2,}$/, 'Invalid UPI format')
  .max(255, 'UPI is too long');

// Bank account validation
export const bankAccountSchema = z
  .string()
  .regex(/^\d{9,18}$/, 'Bank account must be 9-18 digits')
  .max(20, 'Bank account is too long');

// IFSC code validation
export const ifscSchema = z
  .string()
  .regex(/^[A-Z]{4}0[A-Z0-9]{6}$/, 'Invalid IFSC code format')
  .length(11, 'IFSC code must be 11 characters');

// PAN validation
export const panSchema = z
  .string()
  .regex(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, 'Invalid PAN format')
  .length(10, 'PAN must be 10 characters');

// Aadhaar validation
export const aadhaarSchema = z
  .string()
  .regex(/^\d{12}$/, 'Invalid Aadhaar format')
  .length(12, 'Aadhaar must be 12 digits');

// URL validation
export const urlSchema = z
  .string()
  .url('Invalid URL format')
  .startsWith('https://', 'URL must use HTTPS')
  .max(2048, 'URL is too long');

// API Key validation
export const apiKeySchema = z
  .string()
  .min(20, 'API key must be at least 20 characters')
  .max(500, 'API key must be less than 500 characters');

// Payment method validation
export const paymentMethodSchema = z
  .enum(['upi', 'card', 'netbanking', 'wallet', 'bank_transfer'])
  .default('upi');

// Transaction ID validation
export const transactionIdSchema = z
  .string()
  .min(5, 'Transaction ID must be at least 5 characters')
  .max(100, 'Transaction ID must be less than 100 characters')
  .regex(/^[a-zA-Z0-9_-]+$/, 'Transaction ID contains invalid characters');

// Status validation
export const statusSchema = z
  .enum(['pending', 'processing', 'success', 'failed', 'cancelled'])
  .optional();

// PayIn initiation schema
export const payinInitiateSchema = z.object({
  amount: amountSchema,
  customerName: nameSchema.optional(),
  customerEmail: emailSchema.optional(),
  customerPhone: phoneSchema.optional(),
  paymentMethod: paymentMethodSchema,
  merchantTransactionId: transactionIdSchema.optional(),
  serviceId: z.string().cuid().optional(),
});

// Payout initiation schema
export const payoutInitiateSchema = z.object({
  amount: amountSchema,
  beneficiaryName: nameSchema,
  beneficiaryPhone: phoneSchema,
  beneficiaryEmail: emailSchema,
  bankAccountNumber: bankAccountSchema,
  ifscCode: ifscSchema,
  merchantTransactionId: transactionIdSchema.optional(),
});

// KYC verification schema
export const kycSchema = z.object({
  fullName: nameSchema,
  dateOfBirth: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Invalid date format (YYYY-MM-DD)')
    .refine(date => {
      const d = new Date(date);
      const age = new Date().getFullYear() - d.getFullYear();
      return age >= 18 && age <= 120;
    }, 'Age must be between 18 and 120'),
  email: emailSchema,
  phone: phoneSchema,
  pan: panSchema,
  aadhaar: aadhaarSchema,
  address: z
    .string()
    .min(10, 'Address must be at least 10 characters')
    .max(500, 'Address must be less than 500 characters'),
  city: z
    .string()
    .min(2, 'City name must be at least 2 characters')
    .max(50, 'City name must be less than 50 characters'),
  state: z
    .string()
    .min(2, 'State name must be at least 2 characters')
    .max(50, 'State name must be less than 50 characters'),
  pincode: z
    .string()
    .regex(/^\d{6}$/, 'Pincode must be 6 digits')
    .length(6, 'Pincode must be 6 digits'),
});

// Login schema
export const loginSchema = z.object({
  email: emailSchema,
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/\d/, 'Password must contain at least one digit')
    .regex(/[^a-zA-Z0-9]/, 'Password must contain at least one special character'),
});

// Gateway creation schema
export const gatewaySchema = z.object({
  code: z
    .string()
    .min(3, 'Code must be at least 3 characters')
    .max(50, 'Code must be less than 50 characters')
    .regex(/^[A-Z_]+$/, 'Code must contain only uppercase letters and underscores'),
  name: nameSchema,
  provider: z
    .string()
    .min(2, 'Provider must be at least 2 characters')
    .max(50, 'Provider must be less than 50 characters'),
  description: z
    .string()
    .max(500, 'Description must be less than 500 characters')
    .optional(),
  apiEndpoint: urlSchema,
  apiKey: z
    .string()
    .optional(),
  apiSecret: z
    .string()
    .optional(),
  authType: z
    .enum(['bearer', 'basic', 'api-key'])
    .default('bearer'),
});

// Pagination schema
export const paginationSchema = z.object({
  offset: z
    .number()
    .int()
    .min(0, 'Offset must be non-negative')
    .default(0),
  limit: z
    .number()
    .int()
    .min(1, 'Limit must be at least 1')
    .max(100, 'Limit must be at most 100')
    .default(50),
});

// Search schema
export const searchSchema = z.object({
  query: z
    .string()
    .max(100, 'Search query must be less than 100 characters')
    .optional(),
  ...paginationSchema.shape,
});

// Error response schema
export const errorResponseSchema = z.object({
  error: z.string(),
  details: z.any().optional(),
  timestamp: z.number().optional(),
});

// Success response schema
export const successResponseSchema = z.object({
  success: z.literal(true),
  data: z.any().optional(),
  pagination: z.object({
    offset: z.number(),
    limit: z.number(),
    total: z.number(),
  }).optional(),
});

/**
 * Validate and parse input against a schema
 */
export function validateInput<T>(schema: z.ZodSchema<T>, data: unknown): { valid: boolean; data?: T; error?: string } {
  try {
    const validated = schema.parse(data);
    return { valid: true, data: validated };
  } catch (error) {
    if (error instanceof z.ZodError) {
      const message = (error as any).issues
        .map((err: any) => `${err.path?.join('.') || 'field'}: ${err.message}`)
        .join('; ');
      return { valid: false, error: message };
    }
    return { valid: false, error: 'Validation failed' };
  }
}

/**
 * Type inference helper
 */
export type PayInInitiate = z.infer<typeof payinInitiateSchema>;
export type PayoutInitiate = z.infer<typeof payoutInitiateSchema>;
export type KYC = z.infer<typeof kycSchema>;
export type Login = z.infer<typeof loginSchema>;
export type Gateway = z.infer<typeof gatewaySchema>;
export type Pagination = z.infer<typeof paginationSchema>;
export type Search = z.infer<typeof searchSchema>;

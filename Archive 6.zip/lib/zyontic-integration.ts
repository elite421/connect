
import { PaymentApi, PayoutRequest, PayoutResponse } from './payout-integration';

export async function executeZyonticTransaction(
    api: PaymentApi,
    request: PayoutRequest
): Promise<{ apiUsed: PaymentApi; response: PayoutResponse }> {

    // 1. Validate Configuration
    // Zyontic needs: api_token (static credential), client_id (per-transaction unique ID)
    // api_token: Stored in apiKey OR apiSecret (the main credential from Zyontic dashboard)
    // client_id: Our transaction ID (unique per request)

    const apiToken = api.apiKey || api.customPaymentApiSecret || api.apiSecret || api.apiToken;
    const clientId = request.merchantTransactionId; // This is unique per transaction

    // Construct full endpoint URL by combining baseUrl and endpoint path
    let endpoint = "https://partner.zyontic.in/api/payout/v2/transfer-now"; // Default fallback
    if (api.baseUrl && api.customPaymentApiEndpoint) {
        // Combine baseUrl + endpoint (handle trailing/leading slashes)
        const base = api.baseUrl.replace(/\/$/, ''); // Remove trailing slash
        const path = api.customPaymentApiEndpoint.startsWith('/') ? api.customPaymentApiEndpoint : '/' + api.customPaymentApiEndpoint;
        endpoint = base + path;
    } else if (api.baseUrl && api.baseUrl.includes('/api/')) {
        // If baseUrl already contains the full path
        endpoint = api.baseUrl;
    }

    if (!apiToken) {
        return {
            apiUsed: api,
            response: {
                success: false,
                status: 'failed',
                message: 'Zyontic Configuration Error: Missing API Token. Please configure the API Token in the Custom API settings.',
                raw: { error: 'MISSING_API_TOKEN' }
            }
        };
    }

    if (!clientId) {
        return {
            apiUsed: api,
            response: {
                success: false,
                status: 'failed',
                message: 'Zyontic Error: Missing Transaction ID (client_id)',
                raw: { error: 'MISSING_CLIENT_ID' }
            }
        };
    }

    // 2. Map Transfer Mode to Channel ID
    // 1 = NEFT, 2 = IMPS
    let channelId = '';
    const mode = request.transferMode?.toLowerCase() || 'imps';

    if (mode === 'neft') channelId = '1';
    else if (mode === 'imps') channelId = '2';
    else {
        return {
            apiUsed: api,
            response: {
                success: false,
                status: 'failed',
                message: `Zyontic API only supports NEFT and IMPS. Selected mode: ${mode}`,
                raw: { error: 'UNSUPPORTED_TRANSFER_MODE' }
            }
        };
    }

    // 3. Prepare Payload
    // Required: api_token, mobile_number, email, beneficiary_name, ifsc_code, account_number, amount, channel_id, client_id

    const payload = {
        api_token: apiToken,
        client_id: clientId,
        mobile_number: request.userPhone || '9999999999', // Fallback as we don't collect beneficiary phone
        email: request.userEmail || 'user@example.com',
        beneficiary_name: request.beneficiaryName,
        account_number: request.beneficiaryAccount,
        ifsc_code: request.beneficiaryIfsc,
        amount: request.amount, // Major units (Rupees)
        channel_id: channelId
    };

    // console.log('[Zyontic] Executing Transaction:', { ...payload, api_token: '***' });

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            data = { raw: text, message: 'Invalid JSON response' };
        }

        // console.log('[Zyontic] Response:', data);

        // 4. Map Response
        // Success: {"status":"success","message":"...","utr":"...","payid":"..."}
        // Pending: {"status":"pending", ...}
        // Failure: {"status":"failure", ...}

        let status: 'pending' | 'processing' | 'success' | 'failed' = 'processing';
        const rawStatus = String(data.status || '').toLowerCase();

        if (rawStatus === 'success') status = 'success';
        else if (rawStatus === 'failure' || rawStatus === 'failed') status = 'failed';
        else if (rawStatus === 'pending') status = 'processing'; // Internal 'processing' usually maps to pending at gateway

        // Check if network failure (response not ok)
        if (!response.ok) {
            status = 'failed';
        }

        return {
            apiUsed: api,
            response: {
                success: status === 'success' || status === 'processing', // Processing is considered successful submission
                status: status,
                message: data.message || 'Transaction processed',
                utrNumber: data.utr || null,
                externalTransactionId: data.payid || null,
                raw: data
            }
        };

    } catch (error: any) {
        console.error('[Zyontic] Request Failed:', error);
        return {
            apiUsed: api,
            response: {
                success: false,
                status: 'failed',
                message: error.message || 'Network request failed',
                raw: { error: error.message }
            }
        };
    }
}

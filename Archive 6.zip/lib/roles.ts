import prisma from './prisma';
import { NextRequest, NextResponse } from 'next/server';
import type { User } from '@prisma/client';

// Simple demo helpers: in production, replace with real auth/session
export async function getUserFromRequest(req: NextRequest): Promise<User | null> {
  const id = req.headers.get('x-user-id') || '';
  if (!id) return null;
  const user = await prisma.user.findUnique({ where: { id } });
  return user;
}

// Return User or NextResponse to return immediately from handler
export async function requireRole(req: NextRequest, allowed: Array<User['role']>) {
  const user = await getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  if (!allowed.includes(user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  return user;
}

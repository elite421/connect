// Preset gateways are disabled in favor of admin-defined custom APIs.
// This array intentionally remains empty.
export const PRESET_GATEWAYS: Array<any> = [];

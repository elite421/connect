import prisma from './prisma';

import { Decimal } from '@prisma/client/runtime/library';

export interface SchemeResult {
  schemeCharge: number;
  userCharge: number;
  chargeType: string;
  minCharge?: number;
  maxCharge?: number;
  gstPercentage?: number;
  applyGst?: boolean;
  gstAmount?: number;
  totalChargeWithGst?: number;
  minTransactionAmount?: number;
  maxTransactionAmount?: number;
  schemeId?: string;
  schemeName?: string;
}

export async function getDefaultPaymentScheme() {
  try {
    const scheme = await prisma.paymentScheme.findFirst({
      where: { isActive: true },
      orderBy: { createdAt: 'asc' },
    });
    return scheme;
  } catch (error) {
    console.error('Error fetching default payment scheme:', error);
    return null;
  }
}

import { toRupees } from '@/lib/money';
import { formatINR } from '@/lib/money';

export function calculateTransactionCharge(
  amount: number,
  schemeCharge: number | null | undefined,
  userCharge: number | null | undefined,
  chargeType: string = 'fixed'
): number {
  if (!schemeCharge && !userCharge) {
    return 0;
  }

  const totalCharge = (schemeCharge || 0) + (userCharge || 0);

  if (chargeType === 'percentage') {
    const chargeAmount = (amount * totalCharge) / 100;
    return Math.ceil(chargeAmount);
  } else if (chargeType === 'fixed') {
    // Fixed charge is in Rupees
    return totalCharge;
  } else if (chargeType === 'both') {
    const percentageCharge = (amount * totalCharge) / 100;
    return Math.ceil(percentageCharge);
  }

  return 0;
}

/**
 * Calculate charge with GST
 * @param baseCharge - Base charge amount (Rupees)
 * @param gstPercentage - GST percentage (default 18)
 * @param applyGst - Whether to apply GST
 * @returns Object with base, GST, and total (Rupees)
 */
export function calculateChargeWithGst(
  baseCharge: number,
  gstPercentage: number = 18,
  applyGst: boolean = true
) {
  const gstAmount = applyGst ? baseCharge * (gstPercentage / 100) : 0;
  const totalCharge = baseCharge + gstAmount;

  return {
    baseCharge,
    gstAmount,
    totalCharge,
    gstPercentage: applyGst ? gstPercentage : 0,
  };
}

/**
 * Validate transaction amount against scheme limits (Paise)
 * @param amount - Transaction amount in Paise
 * @param minAmount - Minimum allowed amount (Paise)
 * @param maxAmount - Maximum allowed amount (Paise)
 * @returns Object with validity and error message if invalid
 */
export function validateTransactionAmount(
  amount: number,
  minAmount?: number | null,
  maxAmount?: number | null
): { valid: boolean; error?: string } {
  const min = minAmount || 1.00; // Default ₹1
  const max = maxAmount || 100000.00; // Default ₹1,00,000

  if (amount < min) {
    return {
      valid: false,
      error: `Transaction amount must be at least ${formatINR(min)}`
    };
  }

  if (amount > max) {
    return {
      valid: false,
      error: `Transaction amount cannot exceed ${formatINR(max)}`
    };
  }

  return { valid: true };
}

export async function applyPaymentScheme(
  userId: string,
  transactionType: 'payout' | 'payin' | 'settlement',
  customCharge?: { amount: number; type: string } | null
): Promise<SchemeResult> {
  try {
    const [user, scheme] = await Promise.all([
      prisma.user.findUnique({ where: { id: userId } }),
      getDefaultPaymentScheme(),
    ]);

    if (!user || !scheme) {
      return {
        schemeCharge: 0,
        userCharge: user?.transactionCharge ? Number(user.transactionCharge) : 0,
        chargeType: 'fixed',
      };
    }

    let schemeCharge = 0;

    // Check if there is a custom override (from Custom API)
    if (customCharge && customCharge.amount > 0) {
      schemeCharge = customCharge.amount;
      // If custom charge is provided, we use its type. 
      // Note: The rest of the function applies 'scheme.chargeType' logic later.
      // We should probably override the charge type in the return object or handle calculation here if mixed types?
      // For now, let's assume the basic calculation logic handles it if we return the correct type.
    } else {
      if (transactionType === 'payout') {
        schemeCharge = scheme.payoutCharge ? Number(scheme.payoutCharge) : 0;
      } else if (transactionType === 'payin') {
        schemeCharge = scheme.payinCharge ? Number(scheme.payinCharge) : 0;
      } else if (transactionType === 'settlement') {
        schemeCharge = scheme.settlementCharge ? Number(scheme.settlementCharge) : 0;
      }
    }

    const userCharge = user.transactionCharge ? Number(user.transactionCharge) : 0;
    const totalBaseCharge = schemeCharge + userCharge;

    // Apply GST
    const gstPercentage = scheme.gstPercentage ? Number(scheme.gstPercentage) : 18;
    const applyGst = scheme.applyGst !== false;
    const gstAmount = applyGst ? totalBaseCharge * (gstPercentage / 100) : 0;
    const totalChargeWithGst = totalBaseCharge + gstAmount;

    return {
      schemeCharge,
      userCharge,
      chargeType: (customCharge?.type) || scheme.chargeType || 'fixed',
      minCharge: scheme.minCharge ? Number(scheme.minCharge) : 0,
      maxCharge: scheme.maxCharge ? Number(scheme.maxCharge) : 0,
      gstPercentage,
      applyGst,
      gstAmount,
      totalChargeWithGst,
      minTransactionAmount: scheme.minTransactionAmount ? Number(scheme.minTransactionAmount) : undefined,
      maxTransactionAmount: scheme.maxTransactionAmount ? Number(scheme.maxTransactionAmount) : undefined,
      schemeId: scheme.id,
      schemeName: scheme.name,
    };
  } catch (error) {
    console.error('Error applying payment scheme:', error);
    return {
      schemeCharge: 0,
      userCharge: 0,
      chargeType: 'fixed',
    };
  }
}

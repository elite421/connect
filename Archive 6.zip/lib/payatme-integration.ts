
import type { PayoutRequest, PayoutResponse } from './payout-integration';

// ----------------------------------------------------------------------
// PAYATME INTEGRATION (Re-implemented based on Postman JSON)
// ----------------------------------------------------------------------

/**
 * Interface for API Config extracted from the User's Custom API settings
 */
interface PayAtMeConfig {
    baseUrl: string;
    apiKey: string;      // Could be Email (for Basic Auth) OR key (for Bearer)
    apiSecret: string;   // Password (for Basic Auth) or empty
    authType: string;    // 'basic' or 'bearer'
}

/**
 * Helper: Parse JSON safely
 */
function safeJsonParse<T = any>(val?: string | null): T | undefined {
    if (!val) return undefined;
    try {
        return JSON.parse(val) as T;
    } catch {
        return undefined;
    }
}

/**
 * HARDCODED BASE URL - PayAtMe API always at this address
 */
const PAYATME_API_BASE = 'https://api.payatme.com/api';

/**
 * 1. GET ACCESS TOKEN
 * Method: POST
 * URL: https://api.payatme.com/api/token
 * Body: formdata (email, password)
 */
async function getPayAtMeToken(email: string, pass: string): Promise<{ token?: string; error?: string }> {
    const tokenUrl = `${PAYATME_API_BASE}/token`;

    console.log(`[PayAtMe] Getting Token. URL: ${tokenUrl}, Email: ${email}`);

    const formData = new FormData();
    formData.append('email', email);
    formData.append('password', pass);

    try {
        const res = await fetch(tokenUrl, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'User-Agent': 'PostmanRuntime/7.28.0' // Mimic Postman
            },
            body: formData
        });

        const text = await res.text();

        // Handle HTML Errors (WAF, 404, etc)
        if (!res.ok) {
            console.error(`[PayAtMe] Login Request Failed. Status: ${res.status}. Body: ${text.substring(0, 200)}`);
            return { error: `Login Failed (HTTP ${res.status}). Server returned: ${text.substring(0, 100)}...` };
        }

        let data: any;
        try {
            data = JSON.parse(text);
        } catch {
            return { error: `Login Failed. Server returned non-JSON response. Valid URL?` };
        }

        // Check Logic from JSON: "status_id = 1 : this is for success"
        if (data.status_id === 1) {
            const token = data.token || data.access_token || data.data?.token || data?.bearer?.[0]?.value;
            if (token) return { token };
        } else if (data.status_id === 2) {
            return { error: `Login Failed (API): ${data.message || 'Unknown Error'}` };
        }

        // Fallback search for token
        const token = data.token || data.access_token || data.data?.token;
        if (token) return { token };

        return { error: `Token not found in login response. Response: ${JSON.stringify(data)}` };

    } catch (err: any) {
        console.error(`[PayAtMe] Login Exception: ${err.message}`);
        return { error: `Connection Error: ${err.message}` };
    }
}

/**
 * 2. EXECUTE PAYOUT (Bank or UPI)
 * Method: POST
 * URL: https://api.payatme.com/api/v1/payout/bank_transfer OR /upi_transfer
 * Header: Authorization: Bearer <token>
 * Body: formdata (mobile_number, account_number/upi, ifsc, etc.)
 */
export async function callPayAtMePayoutApi(userId: string, api: any, request: PayoutRequest): Promise<{ apiUsed?: any; response: PayoutResponse }> {

    // A. CONFIGURATION EXTRACTION
    // ---------------------------------------------------
    const authTypeRaw = (api.customPaymentApiAuthType || api.authType || '').toLowerCase();
    const apiKey = api.apiKey || ''; // Email or Token
    const apiSecret = api.customPaymentApiSecret || api.apiSecret || ''; // Password

    let authToken = '';

    // LOG INPUT for debugging
    console.log(`[PayAtMe] Input baseUrl from config: "${api.baseUrl || api.customPaymentApiEndpoint || 'NOT SET'}"`);

    // AUTH FLOW
    if (authTypeRaw.includes('bearer')) {
        // Mode: Static Token
        console.log('[PayAtMe] Using Static Bearer Token mode.');
        // We use apiKey if present, otherwise fallback to the hardcoded token provided by user
        authToken = apiKey || "2583|t4102klgBsjFoheRthcFLUYPQRNlfS3E5MBoVMDP816b456d";

        if (!authToken) {
            return { response: { success: false, status: 'failed', message: 'Bearer Token missing.', raw: { error: 'MISSING_TOKEN' } } };
        }
    } else {
        // Mode: Dynamic Login (Basic)
        console.log('[PayAtMe] Using Dynamic Login (Basic Auth) mode.');
        if (!apiKey || !apiSecret) {
            return { response: { success: false, status: 'failed', message: 'Email and Password required for PayAtMe Basic Auth.', raw: { error: 'MISSING_CREDENTIALS' } } };
        }

        const tokenResult = await getPayAtMeToken(apiKey, apiSecret);
        if (tokenResult.error || !tokenResult.token) {
            return {
                response: {
                    success: false,
                    status: 'failed',
                    message: `PayAtMe Login Failed: ${tokenResult.error}`,
                    raw: { error: 'AUTH_FAILED', details: tokenResult.error }
                }
            };
        }
        authToken = tokenResult.token;
    }

    // B. PAYLOAD CONSTRUCTION
    // ---------------------------------------------------
    const isUpi = request.transferMode && ['upi', 'vpa'].includes(request.transferMode.toLowerCase());

    // Endpoints & Provider IDs
    // User Update: Bank Transfer Provider ID is 143
    // UPI: /v1/payout/upi_transfer (Provider: 383)

    const endpointPath = isUpi ? '/v1/payout/upi_transfer' : '/v1/payout/bank_transfer';
    const providerId = isUpi ? '383' : '160'; // Fixed: Provider ID is 160 for Bank Transfer as per docs

    // USE HARDCODED BASE - this guarantees correct URL
    const fullUrl = `${PAYATME_API_BASE}${endpointPath}`;

    console.log(`[PayAtMe] Final Payout URL: ${fullUrl}`);

    const formData = new FormData();

    // 1. mobile_number (Required)
    const mobile = request.metadata?.mobile_number || request.metadata?.mobile || '9999999999';
    formData.append('mobile_number', mobile);

    // 2. provider_id (Fixed)
    formData.append('provider_id', providerId);

    // 3. client_id (Unique ID)
    // User Requirement: "every time client id is unique"
    const uniqueId = `TXN_${Date.now()}_${Math.floor(Math.random() * 100000)}`;
    formData.append('client_id', request.merchantTransactionId || uniqueId);

    // 4. amount
    formData.append('amount', String(request.amount));

    // 5. wallet_id (Fixed: 0)
    formData.append('wallet_id', '0');

    // 6. beneficiary_name
    formData.append('beneficiary_name', request.beneficiaryName || 'User');

    // 7. Type Specific Fields
    if (isUpi) {
        formData.append('upi', request.beneficiaryVpa || '');
    } else {
        formData.append('account_number', request.beneficiaryAccount || '');
        formData.append('ifsc', request.beneficiaryIfsc || '');
    }

    // 8. Optional fields from JSON (lat, long)
    formData.append('lat', '');
    formData.append('long', '');


    // C. EXECUTE REQUEST
    // ---------------------------------------------------
    try {
        console.log(`[PayAtMe] Executing Payout to ${fullUrl}`);
        const res = await fetch(fullUrl, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Accept': 'application/json',
                'User-Agent': 'PostmanRuntime/7.28.0' // Vital for some WAFs
            },
            body: formData
        });

        const text = await res.text();

        // Debug Headers/Status
        console.log(`[PayAtMe] Response Status: ${res.status}`);

        let data: any;
        try {
            data = JSON.parse(text);
        } catch {
            // HTML Error Handling
            const isRedirect = res.url && res.url !== fullUrl;
            const preview = text.substring(0, 500).replace(/\s+/g, ' ');
            console.error(`[PayAtMe] Invalid JSON. Redirected: ${isRedirect}. Preview: ${preview}`);

            return {
                apiUsed: api,
                response: {
                    success: false,
                    status: 'failed',
                    message: `PayAtMe API returned HTML (HTTP ${res.status}). Verify Base URL.`,
                    raw: { error: 'INVALID_JSON', html: preview, originalUrl: fullUrl, finalUrl: res.url }
                }
            };
        }

        console.log(`[PayAtMe] Parsed Response:`, JSON.stringify(data).substring(0, 100) + '...');

        // D. MAP RESPONSE
        // ---------------------------------------------------
        // JSON: status_id = 1 (Success), 2 (Failure), 3 (Pending)

        let status: 'success' | 'failed' | 'processing' = 'processing';
        let success = false;
        const statusId = parseInt(String(data.status_id));

        if (statusId === 1) {
            status = 'success';
            success = true;
        } else if (statusId === 2) {
            status = 'failed';
        } else if (statusId === 3) {
            status = 'processing';
        } else if (statusId === 4) {
            // Refunded
            status = 'failed';
        } else {
            status = 'failed';
        }

        return {
            apiUsed: api,
            response: {
                success,
                status,
                message: data.message || (success ? 'Transaction Successful' : 'Transaction Failed'),
                utrNumber: data.utr || data.data?.utr,
                externalTransactionId: data.order_id || data.report_id,
                raw: data
            }
        };

    } catch (err: any) {
        console.error(`[PayAtMe] Exception: ${err.message}`);
        return {
            apiUsed: api,
            response: {
                success: false,
                status: 'failed',
                message: 'Internal Connection Error',
                raw: { error: err.message }
            }
        };
    }
}

import { NextRequest, NextResponse } from 'next/server';
import {
  addSecurityHeaders,
  isValidOrigin,
  isValidContentType,
  sanitizeInput,
} from './security-headers';
import {
  isRateLimited,
  getRemainingRequests,
  getResetTime,
  checkBruteForceLogin,
  checkSuspiciousPayment,
  checkUnusualAPIAccess,
} from './rate-limit';

/**
 * Main security middleware that combines all security checks
 * Apply this to all API routes
 */
export async function applySecurityMiddleware(
  request: NextRequest,
  endpoint: string,
  userId?: string
): Promise<{ passed: boolean; response?: NextResponse }> {
  // 1. Check request method is allowed
  const allowedMethods = ['GET', 'POST', 'PATCH', 'DELETE', 'PUT'];
  if (!allowedMethods.includes(request.method)) {
    const response = NextResponse.json(
      { error: 'Method not allowed' },
      { status: 405 }
    );
    return { passed: false, response: addSecurityHeaders(response) };
  }

  // 2. Validate origin (CSRF protection)
  if (!isValidOrigin(request)) {
    const response = NextResponse.json(
      { error: 'Invalid origin' },
      { status: 403 }
    );
    return { passed: false, response: addSecurityHeaders(response) };
  }

  // 3. Validate Content-Type for POST/PATCH/PUT
  if (['POST', 'PATCH', 'PUT'].includes(request.method)) {
    if (!isValidContentType(request)) {
      const response = NextResponse.json(
        { error: 'Content-Type must be application/json' },
        { status: 400 }
      );
      return { passed: false, response: addSecurityHeaders(response) };
    }
  }

  // 4. Rate limiting check
  if (isRateLimited(request, endpoint, userId)) {
    const remaining = getRemainingRequests(request, endpoint, userId);
    const resetTime = getResetTime(request, endpoint, userId);

    const response = NextResponse.json(
      {
        error: 'Too many requests. Please try again later.',
        retryAfter: resetTime,
      },
      { status: 429 }
    );

    response.headers.set('Retry-After', resetTime.toString());
    response.headers.set('X-RateLimit-Remaining', remaining.toString());
    response.headers.set('X-RateLimit-Reset', Math.ceil(Date.now() / 1000 + resetTime).toString());

    return { passed: false, response: addSecurityHeaders(response) };
  }

  // 5. Add rate limit headers to response (will be added later)
  return { passed: true };
}

/**
 * Sanitize request body recursively
 */
export function sanitizeRequestBody(body: any): any {
  if (typeof body === 'string') {
    return sanitizeInput(body);
  }

  if (typeof body === 'object' && body !== null) {
    if (Array.isArray(body)) {
      return body.map(item => sanitizeRequestBody(item));
    }

    const sanitized: any = {};
    for (const [key, value] of Object.entries(body)) {
      sanitized[key] = sanitizeRequestBody(value);
    }
    return sanitized;
  }

  return body;
}

/**
 * Add rate limit headers to response
 */
export function addRateLimitHeaders(
  response: NextResponse,
  request: NextRequest,
  endpoint: string,
  userId?: string
): NextResponse {
  const remaining = getRemainingRequests(request, endpoint, userId);
  const resetTime = getResetTime(request, endpoint, userId);

  response.headers.set('X-RateLimit-Remaining', remaining.toString());
  response.headers.set('X-RateLimit-Reset', Math.ceil(Date.now() / 1000 + resetTime).toString());

  return response;
}

/**
 * Log security event
 */
export async function logSecurityEvent(
  event: string,
  severity: 'low' | 'medium' | 'high' | 'critical',
  details: Record<string, any>
): Promise<void> {
  const timestamp = new Date().toISOString();
  const logEntry = {
    timestamp,
    event,
    severity,
    ...details,
  };

  console.log(`[SECURITY] ${severity.toUpperCase()}: ${event}`, logEntry);

  // TODO: Send to centralized logging service (ELK, DataDog, etc.)
  if (severity === 'critical') {
    // TODO: Alert security team
    console.error('🚨 CRITICAL SECURITY EVENT:', logEntry);
  }
}

/**
 * Monitor endpoint for suspicious patterns
 */
export async function monitorEndpoint(
  endpoint: string,
  request: NextRequest,
  userId?: string,
  details?: Record<string, any>
): Promise<void> {
  const ip = request.headers.get('x-forwarded-for') || (request as any).ip || 'unknown';

  // Check for unusual access patterns
  if (userId && endpoint.includes('/admin')) {
    checkUnusualAPIAccess(userId, endpoint, ip);
  }

  // Log all sensitive operations
  if (endpoint.includes('/payin') || endpoint.includes('/payout') || endpoint.includes('/kyc')) {
    await logSecurityEvent(
      `Sensitive operation: ${endpoint}`,
      'low',
      {
        endpoint,
        userId,
        ip,
        ...details,
      }
    );
  }
}

/**
 * Validate API request complete flow
 */
export async function validateAPIRequest(
  request: NextRequest,
  endpoint: string,
  userId?: string
): Promise<{
  valid: boolean;
  response?: NextResponse;
}> {
  // Apply all security checks
  const securityCheck = await applySecurityMiddleware(request, endpoint, userId);

  if (!securityCheck.passed) {
    return { valid: false, response: securityCheck.response };
  }

  // Monitor the endpoint
  await monitorEndpoint(endpoint, request, userId);

  return { valid: true };
}

/**
 * Create secure response
 */
export function createSecureResponse(
  data: any,
  status: number = 200,
  request?: NextRequest,
  endpoint?: string,
  userId?: string
): NextResponse {
  let response = NextResponse.json(data, { status });

  // Add security headers
  response = addSecurityHeaders(response);

  // Add rate limit headers
  if (request && endpoint) {
    response = addRateLimitHeaders(response, request, endpoint, userId);
  }

  return response;
}

/**
 * Handle security violation
 */
export async function handleSecurityViolation(
  violation: string,
  severity: 'low' | 'medium' | 'high' | 'critical',
  request: NextRequest,
  userId?: string
): Promise<NextResponse> {
  const ip = request.headers.get('x-forwarded-for') || (request as any).ip || 'unknown';

  await logSecurityEvent(violation, severity, {
    ip,
    userId,
    timestamp: new Date().toISOString(),
  });

  const response = NextResponse.json(
    { error: 'Security violation detected' },
    { status: 403 }
  );

  return addSecurityHeaders(response);
}

/**
 * Configuration for sensitive endpoints
 */
export const SENSITIVE_ENDPOINTS = {
  // Authentication
  '/api/auth/login': { rateLimit: 5, window: 900 },
  '/api/auth/signup': { rateLimit: 3, window: 3600 },
  '/api/auth/password-reset': { rateLimit: 3, window: 3600 },

  // Payments
  '/api/user/payin/initiate': { rateLimit: 100, window: 3600 },
  '/api/user/payout/initiate': { rateLimit: 50, window: 3600 },
  '/api/subuser/payin/initiate': { rateLimit: 100, window: 3600 },

  // Admin
  '/api/admin/gateways': { rateLimit: 1000, window: 3600 },
  '/api/admin/users': { rateLimit: 500, window: 3600 },
  '/api/admin/webhooks': { rateLimit: 500, window: 3600 },

  // KYC
  '/api/user/kyc': { rateLimit: 10, window: 3600 },

  // Webhooks (generally should be unlimited, but rate limit for safety)
  '/api/webhooks/payin': { rateLimit: 10000, window: 3600 },
  '/api/webhooks/payout': { rateLimit: 10000, window: 3600 },
};

import crypto from 'crypto';

export class FingrowEncryption {
  private static readonly AES_ALGORITHM = 'aes-256-cbc';
  private static readonly IV_LENGTH = 16;

  /**
   * Encrypt plaintext using AES/CBC/PKCS5 with a hex key
   */
  static encrypt(plainText: string, hexKey: string): string | null {
    try {
      if (!hexKey || hexKey.length % 2 !== 0) {
        throw new Error('Invalid hex key: must be non-null and have even length');
      }

      const iv = crypto.randomBytes(this.IV_LENGTH);
      const keyBytes = Buffer.from(hexKey, 'hex');
      const cipher = crypto.createCipheriv(this.AES_ALGORITHM, keyBytes, iv);

      let encryptedBytes = cipher.update(plainText, 'utf8');
      encryptedBytes = Buffer.concat([encryptedBytes, cipher.final()]);

      const encryptedWithIV = Buffer.concat([iv, encryptedBytes]);
      return encryptedWithIV.toString('base64');
    } catch (error) {
      console.error('Encryption failed:', error);
      return null;
    }
  }

  /**
   * Decrypt base64-encoded ciphertext using AES/CBC/PKCS5 with a hex key
   */
  static decrypt(encryptedText: string, hexKey: string): string | null {
    try {
      const encryptedBytes = Buffer.from(encryptedText, 'base64');
      const iv = encryptedBytes.slice(0, this.IV_LENGTH);
      const encryptedData = encryptedBytes.slice(this.IV_LENGTH);

      const keyBytes = Buffer.from(hexKey, 'hex');
      const decipher = crypto.createDecipheriv(this.AES_ALGORITHM, keyBytes, iv);

      let decryptedBytes = decipher.update(encryptedData);
      decryptedBytes = Buffer.concat([decryptedBytes, decipher.final()]);

      return decryptedBytes.toString('utf8');
    } catch (error: any) {
      // If the error is "wrong final block length", it usually means the input wasn't encrypted (e.g. HTML error page)
      if (error.reason === 'wrong final block length' || error.code === 'ERR_OSSL_WRONG_FINAL_BLOCK_LENGTH') {
        console.warn('Decryption failed: Input does not appear to be a valid encrypted string (likely plaintext error).');
      } else {
        console.error('Decryption failed:', error);
      }
      return null;
    }
  }

  /**
   * Derive encryption key from merchant ID using SHA-256
   */
  static deriveKeyFromMerchantId(merchantId: string): string {
    try {
      const hash = crypto.createHash('sha256');
      hash.update(merchantId, 'utf8');
      return hash.digest('hex');
    } catch (error) {
      console.error(`Failed to derive key from merchantId ${merchantId}:`, error);
      return '00'.repeat(32); // fallback to zeroed key
    }
  }

  /**
   * Encrypt plaintext using merchant-specific key (derived from merchantId)
   */
  static encryptMerchantSec(plainText: string, merchantId: string): string | null {
    try {
      const hexKey = this.deriveKeyFromMerchantId(merchantId);
      return this.encrypt(plainText, hexKey);
    } catch (error) {
      console.error(`Merchant encryption failed for merchantId ${merchantId}:`, error);
      return null;
    }
  }

  /**
   * Decrypt base64-encoded ciphertext using merchant-specific key
   */
  static decryptMerchantSec(encryptedText: string, merchantId: string): string | null {
    try {
      const hexKey = this.deriveKeyFromMerchantId(merchantId);
      return this.decrypt(encryptedText, hexKey);
    } catch (error) {
      console.error(`Merchant decryption failed for merchantId ${merchantId}:`, error);
      return null;
    }
  }

  /**
   * Generate a unique order ID (for reference)
   */
  static generateUniqueOrderId(): string {
    const timestamp = Date.now();
    const randomNum = Math.floor(Math.random() * 9000) + 1000;
    return `ORD${timestamp}${randomNum}`;
  }
}

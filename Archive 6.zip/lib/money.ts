/**
 * Money Utility Library
 * Handles standardized money formatting.
 * Storage is now in Rupees (Float), so conversions are minimal.
 */

/**
 * Ensures value is a number for storage.
 * Formerly 'toPaise', now just ensures valid float.
 */
export function toPaise(rupees: number | string): number {
    const value = typeof rupees === 'string' ? parseFloat(rupees) : rupees;
    if (isNaN(value)) return 0;
    return value;
}

/**
 * Ensures value is a number for display.
 * Formerly 'toRupees', now just pass-through.
 */
export function toRupees(value: number | null | undefined | any): number {
    if (value === null || value === undefined) return 0;
    return Number(value);
}

/**
 * Formats a value to Indian Rupees with two decimals and proper grouping.
 * Examples: 1234.5 -> "₹1,234.50"
 */
export function formatINR(value: number | string | null | undefined): string {
    const num = Number(value ?? 0);
    if (!isFinite(num)) return '₹0.00000';
    return '₹' + num.toLocaleString('en-IN', { minimumFractionDigits: 5, maximumFractionDigits: 5 });
}

/**
 * Backward-named helper; now actually formats to INR string.
 */
export function formatRupees(value: number | string | null | undefined): string {
    return formatINR(value);
}

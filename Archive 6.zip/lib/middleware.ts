import { NextRequest, NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';
import prisma from './prisma';

export type AuthUser = {
  id: string;
  email: string;
  name: string;
  role: 'ADMIN' | 'USER' | 'SUBUSER';
  userId?: string; // For SUBUSER: Parent User ID
};

export async function getAuthUser(req: NextRequest): Promise<AuthUser | null> {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

  if (!token || !token.id) return null;

  if (token.role === 'SUBUSER') {
    const subUser = await prisma.subUser.findUnique({
      where: { id: token.id as string },
    });
    if (!subUser) return null;
    return {
      id: subUser.id,
      email: subUser.email,
      name: subUser.name,
      role: 'SUBUSER',
      userId: subUser.userId,
    };
  }

  const user = await prisma.user.findUnique({
    where: { id: token.id as string },
  });
  if (!user) return null;
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role as 'ADMIN' | 'USER' | 'SUBUSER',
  };
}

export function requireRole(allowedRoles: Array<'ADMIN' | 'USER' | 'SUBUSER'>) {
  return async (req: NextRequest) => {
    const user = await getAuthUser(req);

    if (!user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    if (!allowedRoles.includes(user.role)) {
      return NextResponse.json(
        { error: 'Forbidden - Insufficient permissions' },
        { status: 403 }
      );
    }

    return user;
  };
}

export async function authMiddleware(
  req: NextRequest,
  requiredRoles: Array<'ADMIN' | 'USER' | 'SUBUSER'>
): Promise<AuthUser | NextResponse> {
  const user = await getAuthUser(req);

  if (!user) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }

  if (!requiredRoles.includes(user.role)) {
    return NextResponse.json(
      { error: 'Forbidden' },
      { status: 403 }
    );
  }

  return user;
}

export function extractIpAddress(req: NextRequest): string {
  const forwardedFor = req.headers.get('x-forwarded-for');
  if (forwardedFor) {
    return forwardedFor.split(',')[0].trim();
  }
  return req.headers.get('x-real-ip') || 'unknown';
}

export function getUserAgent(req: NextRequest): string {
  return req.headers.get('user-agent') || 'unknown';
}

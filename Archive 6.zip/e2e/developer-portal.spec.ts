import { test, expect } from '@playwright/test';

test.describe('Developer Portal - API Keys Management', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[type="email"]', 'user@example.com');
    await page.fill('input[type="password"]', 'User@123');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/account/dashboard', { timeout: 10000 });
  });

  test('should display developer portal page', async ({ page }) => {
    await page.goto('/account/user/developer');
    await page.waitForLoadState('networkidle');

    await expect(page.locator('text=Developer Portal')).toBeVisible();
    await expect(page.locator('text=Manage API keys and monitor integration activity')).toBeVisible();
  });

  test('should display Generate API Key button', async ({ page }) => {
    await page.goto('/account/user/developer');
    await page.waitForLoadState('networkidle');

    const generateButton = page.locator('button:has-text("Generate API Key")');
    await expect(generateButton).toBeVisible();
    await expect(generateButton).toBeEnabled();
  });

  test('should open create API key modal', async ({ page }) => {
    await page.goto('/account/user/developer');
    await page.waitForLoadState('networkidle');

    const generateButton = page.locator('button:has-text("Generate API Key")');
    await generateButton.click();
    await page.waitForTimeout(500);

    await expect(page.locator('text=Generate New API Key')).toBeVisible();
    await expect(page.locator('label:has-text("API Key Name")')).toBeVisible();
    await expect(page.locator('label:has-text("Permissions")')).toBeVisible();
  });

  test('should display API Keys tab', async ({ page }) => {
    await page.goto('/account/user/developer');
    await page.waitForLoadState('networkidle');

    const keysTab = page.locator('button:has-text("API Keys")');
    await expect(keysTab).toBeVisible();
  });

  test('should display Activity Logs tab', async ({ page }) => {
    await page.goto('/account/user/developer');
    await page.waitForLoadState('networkidle');

    const logsTab = page.locator('button:has-text("Activity Logs")');
    await expect(logsTab).toBeVisible();
  });

  test('should switch to Activity Logs tab', async ({ page }) => {
    await page.goto('/account/user/developer');
    await page.waitForLoadState('networkidle');

    const logsTab = page.locator('button:has-text("Activity Logs")');
    await logsTab.click();
    await page.waitForTimeout(300);

    const logsSection = page.locator('text=No activity logs yet');
    const visible = await logsSection.isVisible().catch(() => false);
    if (visible) {
      await expect(logsSection).toBeVisible();
    }
  });

  test('should display permissions checkboxes in create modal', async ({ page }) => {
    await page.goto('/account/user/developer');
    await page.waitForLoadState('networkidle');

    const generateButton = page.locator('button:has-text("Generate API Key")');
    await generateButton.click();
    await page.waitForTimeout(500);

    const readCheckbox = page.locator('input[type="checkbox"]').first();
    const writeCheckbox = page.locator('input[type="checkbox"]').nth(1);

    await expect(readCheckbox).toBeVisible();
    await expect(writeCheckbox).toBeVisible();
  });

  test('should show warning message when creating key', async ({ page }) => {
    await page.goto('/account/user/developer');
    await page.waitForLoadState('networkidle');

    const generateButton = page.locator('button:has-text("Generate API Key")');
    await generateButton.click();
    await page.waitForTimeout(500);

    const warningText = page.locator('text=Keep them secure and never share them publicly');
    await expect(warningText).toBeVisible();
  });

  test('should display Cancel button in create modal', async ({ page }) => {
    await page.goto('/account/user/developer');
    await page.waitForLoadState('networkidle');

    const generateButton = page.locator('button:has-text("Generate API Key")');
    await generateButton.click();
    await page.waitForTimeout(500);

    const cancelButton = page.locator('button:has-text("Cancel")');
    await expect(cancelButton).toBeVisible();
  });

  test('should close create modal when Cancel is clicked', async ({ page }) => {
    await page.goto('/account/user/developer');
    await page.waitForLoadState('networkidle');

    const generateButton = page.locator('button:has-text("Generate API Key")');
    await generateButton.click();
    await page.waitForTimeout(500);

    const cancelButton = page.locator('button:has-text("Cancel")');
    await cancelButton.click();
    await page.waitForTimeout(300);

    const modal = page.locator('text=Generate New API Key');
    const visible = await modal.isVisible().catch(() => false);
    expect(visible).toBe(false);
  });
});

test.describe('Admin API Keys Management', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[type="email"]', 'admin@fintech.com');
    await page.fill('input[type="password"]', 'Admin@123');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/account/dashboard', { timeout: 10000 });
  });

  test('should display admin API keys management page', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    await expect(page.locator('text=API Keys Management')).toBeVisible();
    await expect(page.locator('text=Monitor and manage all user API keys')).toBeVisible();
  });

  test('should display API keys statistics', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    await expect(page.locator('text=Total API Keys')).toBeVisible();
    await expect(page.locator('text=Active')).toBeVisible();
    await expect(page.locator('text=Inactive')).toBeVisible();
    await expect(page.locator('text=Total Requests')).toBeVisible();
  });

  test('should display search input', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    const searchInput = page.locator('input[placeholder*="Search"]');
    await expect(searchInput).toBeVisible();
  });

  test('should display filter dropdown', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    const filterSelect = page.locator('select');
    await expect(filterSelect).toBeVisible();
  });

  test('should display API keys table', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    const table = page.locator('table');
    const tableVisible = await table.isVisible().catch(() => false);
    if (tableVisible) {
      await expect(table).toBeVisible();
    }
  });

  test('should display column headers in table', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    const headers = [
      'Key Name',
      'User',
      'Status',
      'Requests',
      'Last Used',
      'Expires',
      'Actions',
    ];

    for (const header of headers) {
      const headerElement = page.locator(`text=${header}`);
      const visible = await headerElement.isVisible().catch(() => false);
      if (visible) {
        await expect(headerElement).toBeVisible();
      }
    }
  });

  test('should have Actions button in table', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    const actionsButtons = page.locator('button:has-text("⚡ Actions")');
    const count = await actionsButtons.count();
    if (count > 0) {
      await expect(actionsButtons.first()).toBeVisible();
    }
  });

  test('should open action modal when Actions button is clicked', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    const actionsButtons = page.locator('button:has-text("⚡ Actions")');
    const count = await actionsButtons.count();
    if (count > 0) {
      await actionsButtons.first().click();
      await page.waitForTimeout(500);

      await expect(page.locator('text=Manage API Key Access')).toBeVisible();
    }
  });

  test('should display action options in modal', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    const actionsButtons = page.locator('button:has-text("⚡ Actions")');
    const count = await actionsButtons.count();
    if (count > 0) {
      await actionsButtons.first().click();
      await page.waitForTimeout(500);

      const select = page.locator('select');
      const options = await select.locator('option').count();
      expect(options).toBeGreaterThan(0);
    }
  });

  test('should display reason textarea in modal', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    const actionsButtons = page.locator('button:has-text("⚡ Actions")');
    const count = await actionsButtons.count();
    if (count > 0) {
      await actionsButtons.first().click();
      await page.waitForTimeout(500);

      const textarea = page.locator('textarea[placeholder*="Why"]');
      await expect(textarea).toBeVisible();
    }
  });

  test('should display Confirm button in modal', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    const actionsButtons = page.locator('button:has-text("⚡ Actions")');
    const count = await actionsButtons.count();
    if (count > 0) {
      await actionsButtons.first().click();
      await page.waitForTimeout(500);

      const confirmButton = page.locator('button:has-text("Confirm")');
      await expect(confirmButton).toBeVisible();
    }
  });

  test('should close action modal when Cancel is clicked', async ({ page }) => {
    await page.goto('/account/admin/api-keys');
    await page.waitForLoadState('networkidle');

    const actionsButtons = page.locator('button:has-text("⚡ Actions")');
    const count = await actionsButtons.count();
    if (count > 0) {
      await actionsButtons.first().click();
      await page.waitForTimeout(500);

      const cancelButton = page.locator('button:has-text("Cancel")');
      await cancelButton.click();
      await page.waitForTimeout(300);

      const modal = page.locator('text=Manage API Key Access');
      const visible = await modal.isVisible().catch(() => false);
      expect(visible).toBe(false);
    }
  });
});

import { test, expect } from '@playwright/test';

test.describe('Payout API Integration - Complete Flow', () => {
  let authToken: string;
  let userId: string;
  let walletBalanceBefore: number;
  let testApiId: string;

  test.beforeEach(async ({ page, request }) => {
    // Login as USER
    await page.goto('/login');
    await page.fill('input[type="email"]', 'user@fintech.com');
    await page.fill('input[type="password"]', 'User@123');
    await page.click('button[type="submit"]');

    await page.waitForURL('**/account/dashboard', { timeout: 10000 });

    const cookies = await page.context().cookies();
    const sessionCookie = cookies.find(c => c.name === 'next-auth.session-token');

    if (sessionCookie) {
      authToken = sessionCookie.value;
    }

    const response = await request.get('/api/user/wallet', {
      headers: { 'Cookie': cookies.map(c => `${c.name}=${c.value}`).join('; ') }
    });

    const walletData = await response.json();
    walletBalanceBefore = Number(walletData.balance) || 0;
  });

  test('should not deduct wallet on failed payout', async ({ page, request }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const walletBefore = await request.get('/api/user/wallet', {
      headers: { 'Cookie': cookieHeader }
    });
    const walletDataBefore = await walletBefore.json();
    const balanceBefore = Number(walletDataBefore.balance);

    const payoutResponse = await request.post('/api/user/payout', {
      headers: {
        'Cookie': cookieHeader,
        'Content-Type': 'application/json',
      },
      data: {
        amount: 10000,
        beneficiaryName: 'Invalid Beneficiary',
        beneficiaryAccount: '0000000000',
        beneficiaryIfsc: 'INVALID0001',
        beneficiaryVpa: 'invalid@upi',
        transferMode: 'neft',
      },
    });

    const payoutData = await payoutResponse.json();

    const walletAfter = await request.get('/api/user/wallet', {
      headers: { 'Cookie': cookieHeader }
    });
    const walletDataAfter = await walletAfter.json();
    const balanceAfter = Number(walletDataAfter.balance);

    if (!payoutData.success) {
      expect(balanceBefore).toBe(balanceAfter);
    }
  });

  test('should show UTR number in successful payout transaction', async ({ page, request }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const transactionsResponse = await request.get('/api/user/payout', {
      headers: { 'Cookie': cookieHeader }
    });

    expect(transactionsResponse.ok()).toBeTruthy();
    const transactionsData = await transactionsResponse.json();

    if (transactionsData.data && transactionsData.data.length > 0) {
      const transaction = transactionsData.data[0];

      if (transaction.status === 'success' || transaction.status === 'processing') {
        const response = await request.get(`/api/user/payout`, {
          headers: { 'Cookie': cookieHeader }
        });
        const data = await response.json();

        if (data.data.length > 0) {
          const tx = data.data.find((t: any) => t.utrNumber);
          if (tx) {
            expect(tx).toHaveProperty('utrNumber');
            expect(tx.utrNumber).toBeTruthy();
          }
        }
      }
    }
  });

  test('should include charge breakdown in payout response', async ({ page, request }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    await page.goto('/account/user/payout');
    await page.click('button:has-text("Create PayOut")');

    await page.fill('input[placeholder="1000"]', '1000');
    await page.click('button:has-text("Create PayOut")', { timeout: 5000 });

    const payoutPromise = page.waitForResponse(response =>
      response.url().includes('/api/user/payout') && response.request().method() === 'POST'
    );

    const payoutResponse = await payoutPromise;
    const payoutData = await payoutResponse.json();

    if (payoutData.success) {
      expect(payoutData).toHaveProperty('charges');
      expect(payoutData.charges).toHaveProperty('userCharge');
      expect(payoutData.charges).toHaveProperty('schemeCharge');
      expect(payoutData.charges).toHaveProperty('totalCharge');

      const userCharge = payoutData.charges.userCharge || 0;
      const schemeCharge = payoutData.charges.schemeCharge || 0;
      const totalCharge = payoutData.charges.totalCharge || 0;

      expect(totalCharge).toBe(userCharge + schemeCharge);
    }
  });

  test('should save responseData with gateway information', async ({ page, request }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const transactionsResponse = await request.get('/api/user/payout', {
      headers: { 'Cookie': cookieHeader }
    });

    const transactionsData = await transactionsResponse.json();

    if (transactionsData.data && transactionsData.data.length > 0) {
      const transaction = transactionsData.data[0];

      if (transaction.responseData) {
        expect(transaction.responseData).toHaveProperty('success');
        expect(transaction.responseData).toHaveProperty('message');
        expect(typeof transaction.responseData.success).toBe('boolean');
      }
    }
  });

  test('should deduct wallet balance only on successful gateway response', async ({ page, request }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const walletBefore = await request.get('/api/user/wallet', {
      headers: { 'Cookie': cookieHeader }
    });
    const walletDataBefore = await walletBefore.json();
    const balanceBefore = Number(walletDataBefore.balance);

    const testAmount = 5000;
    const payoutResponse = await request.post('/api/user/payout', {
      headers: {
        'Cookie': cookieHeader,
        'Content-Type': 'application/json',
      },
      data: {
        amount: testAmount,
        beneficiaryName: 'Test User',
        beneficiaryAccount: '1234567890',
        beneficiaryIfsc: 'SBIN0001234',
        beneficiaryVpa: 'test@upi',
        transferMode: 'neft',
      },
    });

    const payoutData = await payoutResponse.json();

    const walletAfter = await request.get('/api/user/wallet', {
      headers: { 'Cookie': cookieHeader }
    });
    const walletDataAfter = await walletAfter.json();
    const balanceAfter = Number(walletDataAfter.balance);

    if (payoutData.success) {
      const expectedDeduction = testAmount + (payoutData.charges?.totalCharge || 0);
      const actualDeduction = balanceBefore - balanceAfter;

      expect(actualDeduction).toBeGreaterThanOrEqual(testAmount);
    }
  });

  test('should handle API configuration errors gracefully', async ({ request, page }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const response = await request.post('/api/user/payout', {
      headers: {
        'Cookie': cookieHeader,
        'Content-Type': 'application/json',
      },
      data: {
        amount: 1000,
        beneficiaryName: 'Test',
        beneficiaryAccount: 'test',
        beneficiaryIfsc: 'test',
        transferMode: 'neft',
      },
    });

    const data = await response.json();

    if (!response.ok()) {
      expect(data).toHaveProperty('error');
      expect(typeof data.error).toBe('string');
      expect(data.error.length).toBeGreaterThan(0);
    }
  });

  test('API test endpoint should validate configuration', async ({ request, page }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const apisResponse = await request.get('/api/user/custom-payment-apis', {
      headers: { 'Cookie': cookieHeader }
    });

    const apisData = await apisResponse.json();

    if (apisData.myApis && apisData.myApis.length > 0) {
      const api = apisData.myApis[0];

      const testResponse = await request.post('/api/user/test-payout-api', {
        headers: {
          'Cookie': cookieHeader,
          'Content-Type': 'application/json',
        },
        data: {
          apiId: api.id,
          amount: 100,
          beneficiaryName: 'Test User',
          beneficiaryAccount: '1234567890',
          beneficiaryIfsc: 'SBIN0001234',
          transferMode: 'neft',
        },
      });

      const testData = await testResponse.json();

      expect(testData).toHaveProperty('success');
      if (testData.success) {
        expect(testData).toHaveProperty('test');
        expect(testData.test).toHaveProperty('status');
        expect(testData).toHaveProperty('request');
        expect(testData).toHaveProperty('response');
      }
    }
  });

  test('wallet page should display transaction charges explanation', async ({ page }) => {
    await page.goto('/account/wallet');

    const chargesSection = page.locator('text=About Transaction Charges');
    await expect(chargesSection).toBeVisible();

    const userChargeText = page.locator('text=User Charge');
    await expect(userChargeText).toBeVisible();

    const schemeChargeText = page.locator('text=Scheme Charge');
    await expect(schemeChargeText).toBeVisible();

    const failedPayoutText = page.locator('text=Failed Payouts');
    await expect(failedPayoutText).toBeVisible();
  });

  test('transaction list should show status and UTR', async ({ page, request }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const transactionsResponse = await request.get('/api/user/payout', {
      headers: { 'Cookie': cookieHeader }
    });

    const transactionsData = await transactionsResponse.json();

    if (transactionsData.data && transactionsData.data.length > 0) {
      const transaction = transactionsData.data[0];

      expect(transaction).toHaveProperty('status');
      expect(['pending', 'processing', 'success', 'failed']).toContain(transaction.status);

      if (transaction.status === 'success') {
        expect(transaction).toHaveProperty('utrNumber');
      }
    }
  });

  test('should handle different field names from gateway responses', async ({ request, page }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const transactionsResponse = await request.get('/api/user/payout', {
      headers: { 'Cookie': cookieHeader }
    });

    const transactionsData = await transactionsResponse.json();

    if (transactionsData.data && transactionsData.data.length > 0) {
      const transaction = transactionsData.data[0];

      if (transaction.responseData && transaction.responseData.raw) {
        const rawResponse = transaction.responseData.raw;

        if (transaction.utrNumber) {
          expect(typeof transaction.utrNumber).toBe('string');
          expect(transaction.utrNumber.length).toBeGreaterThan(0);
        }
      }
    }
  });

  test('failed transaction should not affect wallet balance', async ({ request, page }) => {
    const cookies = await page.context().cookies();
    const cookieHeader = cookies.map(c => `${c.name}=${c.value}`).join('; ');

    const walletBefore = await request.get('/api/user/wallet', {
      headers: { 'Cookie': cookieHeader }
    });
    const walletDataBefore = await walletBefore.json();
    const balanceBefore = Number(walletDataBefore.balance);

    const payoutResponse = await request.post('/api/user/payout', {
      headers: {
        'Cookie': cookieHeader,
        'Content-Type': 'application/json',
      },
      data: {
        amount: 999999999,
        beneficiaryName: 'Test',
        beneficiaryAccount: 'invalid',
        beneficiaryIfsc: 'NOPE0000001',
        transferMode: 'neft',
      },
    });

    const payoutData = await payoutResponse.json();

    if (!payoutData.success && payoutData.gatewayResponse?.status === 'failed') {
      const walletAfter = await request.get('/api/user/wallet', {
        headers: { 'Cookie': cookieHeader }
      });
      const walletDataAfter = await walletAfter.json();
      const balanceAfter = Number(walletDataAfter.balance);

      expect(balanceBefore).toBe(balanceAfter);
    }
  });
});

test.describe('Wallet Page Enhancements', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[type="email"]', 'user@fintech.com');
    await page.fill('input[type="password"]', 'User@123');
    await page.click('button[type="submit"]');
    await page.waitForURL('**/account/dashboard', { timeout: 10000 });
  });

  test('should display balance with proper formatting', async ({ page }) => {
    await page.goto('/account/wallet');

    const balanceSection = page.locator('text=/Balance.*₹/');
    await expect(balanceSection).toBeVisible();
  });

  test('should show transaction statistics', async ({ page }) => {
    await page.goto('/account/wallet');

    const totalCreditsLabel = page.locator('text=Total Credits');
    const totalDebitsLabel = page.locator('text=Total Debits');
    const transactionsLabel = page.locator('text=/Transactions$/');

    await expect(totalCreditsLabel).toBeVisible();
    await expect(totalDebitsLabel).toBeVisible();
    await expect(transactionsLabel).toBeVisible();
  });

  test('should display transaction history table', async ({ page }) => {
    await page.goto('/account/wallet');

    const typeHeader = page.locator('text=Type');
    const amountHeader = page.locator('text=Amount');
    const dateHeader = page.locator('text=Date');

    await expect(typeHeader).toBeVisible();
    await expect(amountHeader).toBeVisible();
    await expect(dateHeader).toBeVisible();
  });

  test('should color-code debits and credits', async ({ page }) => {
    await page.goto('/account/wallet');

    const debitBadges = page.locator('text=Debit');
    const creditBadges = page.locator('text=Credit');

    if (await debitBadges.count() > 0) {
      const debitBadge = debitBadges.first();
      const bgColor = await debitBadge.evaluate((el) =>
        window.getComputedStyle(el).backgroundColor
      );
      expect(bgColor).toBeTruthy();
    }
  });
});

import prisma from '@/lib/prisma';

describe('wallet idempotency (prisma)', () => {
  it('idempotent debit executes once', async () => {
    const idk = `test-key-${Date.now()}`;
    await prisma
      .$transaction(async (tx) => {
        const w = await tx.$queryRaw<{ id: string; balance: bigint }[]>`
          INSERT INTO wallets(owner_type, owner_id, currency, balance)
          VALUES ('user', gen_random_uuid(), 'USD', 1000)
          RETURNING id, balance`;
        const walletId = w[0].id;

        const up1 = await tx.$queryRaw<{ balance: bigint }[]>`
          UPDATE wallets SET balance = balance - 500
          WHERE id = ${walletId} AND balance >= 500
          RETURNING balance`;
        expect(up1.length).toBe(1);

        await tx.$executeRaw`
          INSERT INTO wallet_transactions(wallet_id, tx_type, amount, balance_after, currency, idempotency_key)
          VALUES (${walletId}, 'debit', 500, ${up1[0].balance}, 'USD', ${idk})`;

        // replay
        await tx.$queryRaw`UPDATE wallets SET balance = balance - 500 WHERE id = ${walletId} AND balance >= 500 RETURNING balance`;
        const ins2 = await tx.$executeRaw`
          INSERT INTO wallet_transactions(wallet_id, tx_type, amount, balance_after, currency, idempotency_key)
          VALUES (${walletId}, 'debit', 500, ${Number(up1[0].balance) - 500}, 'USD', ${idk})
          ON CONFLICT (wallet_id, idempotency_key) DO NOTHING`;
        expect(ins2).toBe(0);

        // Prevent persisting test data
        throw Object.assign(new Error('rollback'), { code: 'TEST_ROLLBACK' });
      })
      .catch((e) => {
        if (e?.code !== 'TEST_ROLLBACK') throw e;
      });
  });
});

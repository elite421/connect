'use client';

import { useState, useCallback } from 'react';
import { ConfirmDialog } from '@/components/confirm-dialog';

interface ConfirmOptions {
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  isDangerous?: boolean;
}

export function useConfirm() {
  const [state, setState] = useState({
    isOpen: false,
    title: '',
    message: '',
    confirmText: 'Confirm',
    cancelText: 'Cancel',
    isDangerous: false,
    isLoading: false,
  });

  const [resolver, setResolver] = useState<{
    resolve: (value: boolean) => void;
  } | null>(null);

  const confirm = useCallback(async (options: ConfirmOptions): Promise<boolean> => {
    return new Promise((resolve) => {
      setState((prev) => ({
        ...prev,
        isOpen: true,
        title: options.title,
        message: options.message,
        confirmText: options.confirmText || 'Confirm',
        cancelText: options.cancelText || 'Cancel',
        isDangerous: options.isDangerous || false,
        isLoading: false,
      }));
      setResolver({ resolve });
    });
  }, []);

  const handleConfirm = useCallback(async () => {
    setState((prev) => ({ ...prev, isLoading: true }));
    resolver?.resolve(true);
    setState((prev) => ({
      ...prev,
      isOpen: false,
      isLoading: false,
    }));
    setResolver(null);
  }, [resolver]);

  const handleCancel = useCallback(() => {
    resolver?.resolve(false);
    setState((prev) => ({
      ...prev,
      isOpen: false,
      isLoading: false,
    }));
    setResolver(null);
  }, [resolver]);

  const ConfirmProvider = useCallback(
    () => (
      <ConfirmDialog
        isOpen={state.isOpen}
        title={state.title}
        message={state.message}
        confirmText={state.confirmText}
        cancelText={state.cancelText}
        isDangerous={state.isDangerous}
        isLoading={state.isLoading}
        onConfirm={handleConfirm}
        onCancel={handleCancel}
      />
    ),
    [state, handleConfirm, handleCancel]
  );

  return { confirm, ConfirmProvider };
}
